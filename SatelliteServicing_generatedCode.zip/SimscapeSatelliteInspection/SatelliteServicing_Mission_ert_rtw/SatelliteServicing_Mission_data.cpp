//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// File: SatelliteServicing_Mission_data.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 4.4
// Simulink Coder version         : 9.8 (R2022b) 13-May-2022
// C/C++ source code generated on : Mon May  1 12:51:07 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "SatelliteServicing_Mission.h"

// Block parameters (default storage)
P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P{
  // Variable: jointControlData
  //  Referenced by: '<S4>/Constant1'

  {
    2.0,

    { 0.7, 0.7, 0.7, 0.034999999999999996, 0.034999999999999996,
      0.034999999999999996 },

    { 4.0, 4.0, 4.0, 3.2, 3.2, 3.2 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { -0.2, -0.25, 0.0, 0.0, 0.4, -0.0, 0.3, 0.4, 0.4, 0.6, 0.271, 0.271, 0.271,
      0.271, 0.271, 1.5707963267948966, 1.5707963267948966, 1.5707963267948966,
      0.78539816339744828, 0.78539816339744828, 0.0, 0.0, 0.0, 0.0, 0.0,
      -1.3962634015954636, -2.6179938779914944, -2.6179938779914944,
      1.5707963267948966, 1.5707963267948966, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 0.0, 20.0, 30.0, 50.0, 70.0 },
    0.0,

    { 2.0, 2.0, 2.0, 2.0, 2.0 },

    { 0.5, 0.5, 0.5 },

    { 0.0001, 0.0001, 0.0001 }
  },

  // Variable: satControlData_Rot
  //  Referenced by:
  //    '<S233>/Constant2'
  //    '<S237>/Saturation1'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },
    10.0
  },

  // Variable: satControlData_Trans
  //  Referenced by:
  //    '<S233>/Constant1'
  //    '<S238>/Saturation1'

  {
    { 0.0, 0.0, 0.0 },

    { 15.0, 15.0, 15.0 },

    { 120.0, 120.0, 120.0 },

    { 0.05, 0.05, 0.05 },
    20.0,

    { -0.049999999999999989, 1.5, 0.25 }
  },

  // Variable: nav
  //  Referenced by: '<S250>/Constant1'

  {
    {
      { -1.5707963267948966, 0.0, -0.78539816339744828 }
    }
  },

  // Computed Parameter: DiscreteTimeIntegrator1_gainval
  //  Referenced by: '<S241>/Discrete-Time Integrator1'

  0.01,

  // Expression: 0
  //  Referenced by: '<S241>/Discrete-Time Integrator1'

  0.0,

  // Expression: -1
  //  Referenced by: '<S241>/Gain1'

  -1.0,

  // Computed Parameter: DiscreteTimeIntegrator1_gainv_f
  //  Referenced by: '<S240>/Discrete-Time Integrator1'

  0.01,

  // Expression: 0
  //  Referenced by: '<S240>/Discrete-Time Integrator1'

  0.0,

  // Expression: -1
  //  Referenced by: '<S240>/Gain1'

  -1.0,

  // Expression: [0 0 0]
  //  Referenced by: '<S250>/Constant2'

  { 0.0, 0.0, 0.0 },

  // Computed Parameter: Bias_Bias
  //  Referenced by: '<S234>/Bias'

  1U
};

//
// File trailer for generated code.
//
// [EOF]
//
