#include "pm_std.h"
#include "math.h"
#include "float.h"
#include "string.h"
#include "stdio.h"
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
void pm_math_lin_alg_qrFactor(uint32_T sm_VLHhnPUiNQpve5VIL9P3O9,uint32_T n,
real_T*sm_F2l4p_g4sn02huHNflQjMH,real_T*sm_kTQbRrK9Zn49jTgjOBqDPQ,int32_T*
sm_FrVYLSQleN4GYXlrWrmRui,real_T*sm_VRZCD_UL_ESThy75dC9J8D);uint32_T
pm_math_lin_alg_getRankWithTol(const real_T*sm_VWCrbzOuAe4hay4E_Unnfg,uint32_T
sm_VLHhnPUiNQpve5VIL9P3O9,uint32_T n,real_T sm_kxaGfrxGoyCxZ1cvYvF8ZN);
boolean_T pm_math_lin_alg_qrSolveTall(uint32_T sm_VLHhnPUiNQpve5VIL9P3O9,
uint32_T n,const real_T*sm_VWCrbzOuAe4hay4E_Unnfg,const real_T*
sm_kTQbRrK9Zn49jTgjOBqDPQ,int32_T*sm_FrVYLSQleN4GYXlrWrmRui,real_T
sm_Vwo26eepTNdHYHWZbLLpBj,real_T*sm_FYb3BU2fbqC_bHhRn9AW9b);int32_T
pm_math_lin_alg_qrSolveWide(const uint32_T sm_VLHhnPUiNQpve5VIL9P3O9,const
uint32_T n,const real_T*sm_VWCrbzOuAe4hay4E_Unnfg,const real_T*
sm_kTQbRrK9Zn49jTgjOBqDPQ,const int32_T*sm_FrVYLSQleN4GYXlrWrmRui,const real_T
*b,real_T sm_Vwo26eepTNdHYHWZbLLpBj,real_T*x);struct sm_Va7rvzSwRbpB_iIiuSF8h_
{real_T x;real_T sm_FzyLWRgau0pMYq2XSI3ETL;real_T sm_FBDi_PCg670TjHgJTNPcHr;};
typedef struct sm_Va7rvzSwRbpB_iIiuSF8h_ sm_FJDxOUSymMGic5lC7ZhrnL;struct
sm_VQiPk6I_S_0teiYbT1MBSN{real_T sm_FQferGZUKft3_i5GvYy4Oy;real_T x;real_T
sm_FzyLWRgau0pMYq2XSI3ETL;real_T sm_FBDi_PCg670TjHgJTNPcHr;};typedef struct
sm_VQiPk6I_S_0teiYbT1MBSN sm__3md8_onIiO6heiNB5D3_3;struct
sm_k5mHxu1pFy4YaeyeIGf5bY{real_T sm_V5gSkPeCSkdzZ1xMyj2v7U,
sm__D1iFBxPf38RWiveIR1Iip,sm__hPet7vW5h0Zi1uUdLa_LW;real_T
sm_kdB_LoVum6OHeDEkf0n58b,sm__tdIR85BSYdzha7Mb8qhKj,sm__WnakhFnl24_bX0NhL6CLW;
real_T sm_FnXzm1MLmt04dPIhRbN5SW,sm_VgeldyT0dAtjeHo3kvxpdi,
sm_F3LgZdApwMGziTfUlk6dzB;};typedef struct sm_k5mHxu1pFy4YaeyeIGf5bY
sm_komYPTPtib40juqhd0nJcN;struct sm__sD2GKinhS_qYTF_z8BajY{
sm__3md8_onIiO6heiNB5D3_3 sm_VnD_HGFKVUOWdDAWvZhyEb;sm_FJDxOUSymMGic5lC7ZhrnL
sm_F32Ql82vv6pW_PYIdpkFQ0;};typedef struct sm__sD2GKinhS_qYTF_z8BajY
sm_k4kL9Om6RgxTZqdxJRM51B;struct sm__CEhElfLt9_7aqLsGROeDF{
sm_FJDxOUSymMGic5lC7ZhrnL sm_FN28mzn7A2hvYLPTU_L4bt;sm_FJDxOUSymMGic5lC7ZhrnL
sm_k61dA_LqfI4EY1W2W1B1mA;};typedef struct sm__CEhElfLt9_7aqLsGROeDF
sm_kNq2SpAav5tbb5Yx_VSirx;void pm_math_Vector3_add(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_subtract(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_negate(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_scale(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,real_T
sm_FQferGZUKft3_i5GvYy4Oy,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Vector3_divide(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4);void
pm_math_Vector3_guardedDivide(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4);real_T
pm_math_Vector3_norm(const sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ
);void pm_math_Vector3_unit(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Vector3_guardedUnit(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;real_T pm_math_Vector3_dot(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kNtPmLll5l8eiqwtk5kfJv);void pm_math_Vector3_cross(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_compOrthogonalBasis(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_FJDxOUSymMGic5lC7ZhrnL*sm_kyp6uAyJE40UVuAQNEYzS1,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_V2__YrimeI4E_yWnhKofpy);void
pm_math_Quaternion_compose(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_composeInverse(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseCompose(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xform(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformI(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformJ(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformK(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXform(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformI(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformJ(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformK(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_Matrix3x3Ctor(const sm_komYPTPtib40juqhd0nJcN*
sm_FqUCZrSGGNOuePgRr82o_8,sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb)
;void pm_math_Matrix3x3_compose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_composeTranspose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_transposeCompose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_preCross(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_postCross(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_xform(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_transposeXform(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_QuaternionCtor(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_komYPTPtib40juqhd0nJcN*sm_FqUCZrSGGNOuePgRr82o_8)
;void pm_math_Matrix3x3_getValuesInColumns(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,double*sm_k4y8mv5uXzheZimBIk_n7I);void
pm_math_Transform3_compose(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_composeInverse(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseCompose(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDir(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kEbBObcYFIxUZ5_77V3CO_,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirI(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirJ(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirK(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDir(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kEbBObcYFIxUZ5_77V3CO_,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirI(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirJ(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirK(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformPoint(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
pm__lqjegyKuwStj56WZLiC_e,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformPoint(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
pm__lqjegyKuwStj56WZLiC_e,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_add(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_kNtPmLll5l8eiqwtk5kfJv,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_subtract(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_kNtPmLll5l8eiqwtk5kfJv,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_xform(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_VgJW5ZqpwPpuY1inYtaofQ,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_inverseXform(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_VgJW5ZqpwPpuY1inYtaofQ,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;typedef void(*sm__jsfq5ol9RO0emwniHUfEG)(const void*sm__MiFOMZ9U7lUWXDyYwo58p
,const sm_FJDxOUSymMGic5lC7ZhrnL*sm_F9yDQxbxjNlSeXydMwl6yG,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__rAKhgz20O_KVajkn1H7GD);boolean_T
sm_core_compiler_computeSignedDistanceConvexConvex(const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,real_T sm_kHfMSiCBJRSoju34wwOKOx,real_T*
sm_Vrk3Pgb1wrhnZmcOkBtvtB);boolean_T
sm_core_compiler_computeProximityInfoConvexConvex(const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,real_T sm_kHfMSiCBJRSoju34wwOKOx,real_T*
sm_Vrk3Pgb1wrhnZmcOkBtvtB,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FBszZdfzzb8sceEY5ruiL_,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__CX5rwUGU2WBd1iYlehENh,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VBX8DCC_il0siL9d2SBkT4,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FgOxFveCHNdAYaZUTotxJZ)
;boolean_T sm__vOk4P4g2_S3W9JJAwV14B(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,real_T
sm_kHfMSiCBJRSoju34wwOKOx,boolean_T sm__onsZLH_ytSGhXn0uJU7bM,
sm_FJDxOUSymMGic5lC7ZhrnL sm_k4v50UutrvdChTHBxBrg_s[][3],int*
sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T*sm_Vrk3Pgb1wrhnZmcOkBtvtB,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FBszZdfzzb8sceEY5ruiL_,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__CX5rwUGU2WBd1iYlehENh);extern int sm_VQ0A0Sv5GWprb1MDSztvuk[16];extern int
sm__qx74ytYCql1WuG2KqMfQS[16];extern size_t sm_k2PuWUcQ_UtHYDFpzYchpd[16][4];
PMF_DEPLOY_STATIC boolean_T sm__oPrRWZb_p0tbD5Lt0Lq4Z(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv){return
sm__AuaKMC5koOPbXxPi_MZvt->x==sm_kNtPmLll5l8eiqwtk5kfJv->x&&
sm__AuaKMC5koOPbXxPi_MZvt->sm_FzyLWRgau0pMYq2XSI3ETL==
sm_kNtPmLll5l8eiqwtk5kfJv->sm_FzyLWRgau0pMYq2XSI3ETL&&
sm__AuaKMC5koOPbXxPi_MZvt->sm_FBDi_PCg670TjHgJTNPcHr==
sm_kNtPmLll5l8eiqwtk5kfJv->sm_FBDi_PCg670TjHgJTNPcHr;}void
sm_F8eCImOfeYKdZuMlfsHdDH(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],int sm_kEhNFwUz1NOuj5cSj5dOF7,int
sm_FkoBKJSu3bdQdPWZgD2fC8,const size_t*sm__FuzaKmDsvhreiSobFRgkV,const real_T*
sm_k7RVes5oHPO2Yi5DMSKkeo,char*sm_VGqPwlpTl6K0jeyUcOcudU);void
sm__6dBgrcOk_GXieU6ApKSyW(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],const int sm_kEhNFwUz1NOuj5cSj5dOF7,const size_t
*sm__FuzaKmDsvhreiSobFRgkV,sm_FJDxOUSymMGic5lC7ZhrnL sm__hj2_lou4YpDgPeaVq55if
[3],sm_FJDxOUSymMGic5lC7ZhrnL*sm_kZKtm8DV37C4ieFPsTyO2E,
sm_FJDxOUSymMGic5lC7ZhrnL sm__TBxRBCon90NeHiMaIfEzO[3],
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FSzIyLZpToGyYTlwh2NE5V);void
sm_ViB8AROo2a_Gd9XrUW2rei(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kburdpU0IjpOXyPmyulx88,const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],int sm_FkoBKJSu3bdQdPWZgD2fC8,const size_t*
sm__FuzaKmDsvhreiSobFRgkV,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VBX8DCC_il0siL9d2SBkT4,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FgOxFveCHNdAYaZUTotxJZ);void
sm_kkIDwZB8zm4Pjyeyqv1cv5(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_F9yDQxbxjNlSeXydMwl6yG,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_FOTdVRJPGqhNba6tdltNZZ,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VCifngWB8ylih96lyIXhqB,
sm_FJDxOUSymMGic5lC7ZhrnL*pm__lqjegyKuwStj56WZLiC_e);void
sm__RvG5_uvnj_NXD47YN1yTH(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,boolean_T
sm__onsZLH_ytSGhXn0uJU7bM,sm_FJDxOUSymMGic5lC7ZhrnL sm_k4v50UutrvdChTHBxBrg_s[
][3],int sm_FOdkmT7jBb4LcqK4Pu9cA3,size_t sm__EedT3_mashziDALw8GyU4[3],real_T*
sm_Vrk3Pgb1wrhnZmcOkBtvtB,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FBszZdfzzb8sceEY5ruiL_,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__CX5rwUGU2WBd1iYlehENh);typedef
sm_FJDxOUSymMGic5lC7ZhrnL sm_kd__PjR5tCWObue2RSyCuW;struct
sm_VunDNPldelGpV14lshDNm7{sm_kd__PjR5tCWObue2RSyCuW sm_FSzIyLZpToGyYTlwh2NE5V;
double sm_VPoUbJUlYg0WaXdmtt1Huf;size_t sm_k4v50UutrvdChTHBxBrg_s[3];size_t
sm_kF_fYTSA5k8nXXjCcUgJvI[3];boolean_T sm__c5XrFgUwWKogTUJHqQfJg;};typedef
struct sm_VunDNPldelGpV14lshDNm7 sm_Vl_xbimdXv_njqt81Wv_1g;PMF_DEPLOY_STATIC
real_T sm__DJP6gbIXup3bTIE8pNaTu(const sm_Vl_xbimdXv_njqt81Wv_1g*
sm__hj2_lou4YpDgPeaVq55if,const sm_kd__PjR5tCWObue2RSyCuW*
sm__rAKhgz20O_KVajkn1H7GD){return pm_math_Vector3_dot(
sm__rAKhgz20O_KVajkn1H7GD,&sm__hj2_lou4YpDgPeaVq55if->
sm_FSzIyLZpToGyYTlwh2NE5V)+sm__hj2_lou4YpDgPeaVq55if->
sm_VPoUbJUlYg0WaXdmtt1Huf;}static boolean_T sm_k1PHMJqlP1lZVyqfXgjI6w(
sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if,const
sm_kd__PjR5tCWObue2RSyCuW sm_k4v50UutrvdChTHBxBrg_s[][3],boolean_T
sm_VhGkkNiLDMWYY9i3LqZhfK){sm_kd__PjR5tCWObue2RSyCuW*sm_FSzIyLZpToGyYTlwh2NE5V
= &sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V;
sm_kd__PjR5tCWObue2RSyCuW sm_F1LfOOnBFbpFWi7QXSZyNj;real_T
sm__wl8R_7yU6GUZ1UMfgnFxP;sm_kd__PjR5tCWObue2RSyCuW sm__AuaKMC5koOPbXxPi_MZvt=
sm_k4v50UutrvdChTHBxBrg_s[sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s
[0]][2];sm_kd__PjR5tCWObue2RSyCuW sm_kNtPmLll5l8eiqwtk5kfJv=
sm_k4v50UutrvdChTHBxBrg_s[sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s
[1]][2];sm_kd__PjR5tCWObue2RSyCuW sm__V7yhs3oelG7WqyGLN1Wqz=
sm_k4v50UutrvdChTHBxBrg_s[sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s
[2]][2];sm_kd__PjR5tCWObue2RSyCuW sm_kZKtm8DV37C4ieFPsTyO2E;
pm_math_Vector3_add(&sm__AuaKMC5koOPbXxPi_MZvt,&sm_kNtPmLll5l8eiqwtk5kfJv,&
sm_kZKtm8DV37C4ieFPsTyO2E);pm_math_Vector3_add(&sm__V7yhs3oelG7WqyGLN1Wqz,&
sm_kZKtm8DV37C4ieFPsTyO2E,&sm_kZKtm8DV37C4ieFPsTyO2E);pm_math_Vector3_divide(&
sm_kZKtm8DV37C4ieFPsTyO2E,3.0,&sm_kZKtm8DV37C4ieFPsTyO2E);
pm_math_Vector3_subtract(&sm__AuaKMC5koOPbXxPi_MZvt,&sm_kZKtm8DV37C4ieFPsTyO2E
,&sm__AuaKMC5koOPbXxPi_MZvt);pm_math_Vector3_subtract(&
sm_kNtPmLll5l8eiqwtk5kfJv,&sm_kZKtm8DV37C4ieFPsTyO2E,&
sm_kNtPmLll5l8eiqwtk5kfJv);pm_math_Vector3_subtract(&sm__V7yhs3oelG7WqyGLN1Wqz
,&sm_kZKtm8DV37C4ieFPsTyO2E,&sm__V7yhs3oelG7WqyGLN1Wqz);pm_math_Vector3_cross(
&sm_kNtPmLll5l8eiqwtk5kfJv,&sm__V7yhs3oelG7WqyGLN1Wqz,
sm_FSzIyLZpToGyYTlwh2NE5V);pm_math_Vector3_cross(&sm__V7yhs3oelG7WqyGLN1Wqz,&
sm__AuaKMC5koOPbXxPi_MZvt,&sm_F1LfOOnBFbpFWi7QXSZyNj);pm_math_Vector3_add(
sm_FSzIyLZpToGyYTlwh2NE5V,&sm_F1LfOOnBFbpFWi7QXSZyNj,sm_FSzIyLZpToGyYTlwh2NE5V
);pm_math_Vector3_cross(&sm__AuaKMC5koOPbXxPi_MZvt,&sm_kNtPmLll5l8eiqwtk5kfJv,
&sm_F1LfOOnBFbpFWi7QXSZyNj);pm_math_Vector3_add(sm_FSzIyLZpToGyYTlwh2NE5V,&
sm_F1LfOOnBFbpFWi7QXSZyNj,sm_FSzIyLZpToGyYTlwh2NE5V);sm__wl8R_7yU6GUZ1UMfgnFxP
=pm_math_Vector3_dot(sm_FSzIyLZpToGyYTlwh2NE5V,sm_FSzIyLZpToGyYTlwh2NE5V);
sm__hj2_lou4YpDgPeaVq55if->sm__c5XrFgUwWKogTUJHqQfJg=false;if(
sm_VhGkkNiLDMWYY9i3LqZhfK){const real_T sm_kG1ouvRcClSTc9EDaRGh6a=
pm_math_Vector3_dot(&sm__AuaKMC5koOPbXxPi_MZvt,&sm__AuaKMC5koOPbXxPi_MZvt);
const real_T sm_F4rsZ73k7f89eHi65BeVqJ=pm_math_Vector3_dot(&
sm_kNtPmLll5l8eiqwtk5kfJv,&sm_kNtPmLll5l8eiqwtk5kfJv);const real_T
sm_FHaoJCt_qJ_BWeCwhFrxmB=pm_math_Vector3_dot(&sm__V7yhs3oelG7WqyGLN1Wqz,&
sm__V7yhs3oelG7WqyGLN1Wqz);const real_T sm_Fl6V51zJl9KheL2eOVZpj5=(
sm_kG1ouvRcClSTc9EDaRGh6a>sm_F4rsZ73k7f89eHi65BeVqJ)?(
sm_kG1ouvRcClSTc9EDaRGh6a>sm_FHaoJCt_qJ_BWeCwhFrxmB?sm_kG1ouvRcClSTc9EDaRGh6a:
sm_FHaoJCt_qJ_BWeCwhFrxmB):(sm_F4rsZ73k7f89eHi65BeVqJ>
sm_FHaoJCt_qJ_BWeCwhFrxmB?sm_F4rsZ73k7f89eHi65BeVqJ:sm_FHaoJCt_qJ_BWeCwhFrxmB)
;if(sm__wl8R_7yU6GUZ1UMfgnFxP<1.0e-12*1.0e-12*sm_Fl6V51zJl9KheL2eOVZpj5){
sm_FSzIyLZpToGyYTlwh2NE5V->x=sm_FSzIyLZpToGyYTlwh2NE5V->
sm_FzyLWRgau0pMYq2XSI3ETL=sm_FSzIyLZpToGyYTlwh2NE5V->sm_FBDi_PCg670TjHgJTNPcHr
=sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf=0.0;
sm__hj2_lou4YpDgPeaVq55if->sm__c5XrFgUwWKogTUJHqQfJg=true;return false;}}
pm_math_Vector3_divide(sm_FSzIyLZpToGyYTlwh2NE5V,sqrt(
sm__wl8R_7yU6GUZ1UMfgnFxP),sm_FSzIyLZpToGyYTlwh2NE5V);
sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf= -pm_math_Vector3_dot(&
sm_kZKtm8DV37C4ieFPsTyO2E,sm_FSzIyLZpToGyYTlwh2NE5V);return true;}static void
sm__fLsYr_Jk8t6bep_2w6GLg(sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if,
const sm_kd__PjR5tCWObue2RSyCuW sm_k4v50UutrvdChTHBxBrg_s[][3]){if(!
sm__hj2_lou4YpDgPeaVq55if->sm__c5XrFgUwWKogTUJHqQfJg){
sm_kd__PjR5tCWObue2RSyCuW*sm_FSzIyLZpToGyYTlwh2NE5V= &
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V;const
sm_kd__PjR5tCWObue2RSyCuW sm__AuaKMC5koOPbXxPi_MZvt=sm_k4v50UutrvdChTHBxBrg_s[
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[0]][2];const
sm_kd__PjR5tCWObue2RSyCuW sm_kNtPmLll5l8eiqwtk5kfJv=sm_k4v50UutrvdChTHBxBrg_s[
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[1]][2];const
sm_kd__PjR5tCWObue2RSyCuW sm__V7yhs3oelG7WqyGLN1Wqz=sm_k4v50UutrvdChTHBxBrg_s[
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[2]][2];
sm_kd__PjR5tCWObue2RSyCuW sm_kZKtm8DV37C4ieFPsTyO2E;pm_math_Vector3_add(&
sm__AuaKMC5koOPbXxPi_MZvt,&sm_kNtPmLll5l8eiqwtk5kfJv,&
sm_kZKtm8DV37C4ieFPsTyO2E);pm_math_Vector3_add(&sm__V7yhs3oelG7WqyGLN1Wqz,&
sm_kZKtm8DV37C4ieFPsTyO2E,&sm_kZKtm8DV37C4ieFPsTyO2E);pm_math_Vector3_divide(&
sm_kZKtm8DV37C4ieFPsTyO2E,3.0,&sm_kZKtm8DV37C4ieFPsTyO2E);
sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf= -pm_math_Vector3_dot(&
sm_kZKtm8DV37C4ieFPsTyO2E,sm_FSzIyLZpToGyYTlwh2NE5V);}}unsigned int
sm__CPFntwZRP4LVTxix2pO_p(const sm_Vl_xbimdXv_njqt81Wv_1g*
sm__hj2_lou4YpDgPeaVq55if,size_t sm_FKidCeoWPxxhYXrf4EHeE8){if(
sm__hj2_lou4YpDgPeaVq55if->sm_kF_fYTSA5k8nXXjCcUgJvI[0]==
sm_FKidCeoWPxxhYXrf4EHeE8)return 0;else if(sm__hj2_lou4YpDgPeaVq55if->
sm_kF_fYTSA5k8nXXjCcUgJvI[1]==sm_FKidCeoWPxxhYXrf4EHeE8)return 1;else if(
sm__hj2_lou4YpDgPeaVq55if->sm_kF_fYTSA5k8nXXjCcUgJvI[2]==
sm_FKidCeoWPxxhYXrf4EHeE8)return 2;(void)0;;return 0;}struct
sm_FloeV0pc7PSIWeI5GsVmJ9{size_t sm_Vs6xonQX17Krc5vXv8T_zq;size_t
sm_FFs4s1wSqB44YDRmAy0PsL[256];};typedef struct sm_FloeV0pc7PSIWeI5GsVmJ9
sm__ywJxOdhydpFYT6CiTxXcf;static void sm__o0m82DpcY_EWyoGrL5QqD(
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU){sm_FRpeUPAgV4_aZXdZVkJHXU
->sm_Vs6xonQX17Krc5vXv8T_zq=1;}void sm_Fyjicail5idk_HymzkTyHM(const
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],const
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU);static boolean_T
sm__OFp2fUjZ3KsZX6V5Ghsmm(const sm_Vl_xbimdXv_njqt81Wv_1g
sm__gLX_E3mfsWCgLgXZERZ67[],size_t sm_kPjvJUhBvMtJim43ftnfn6,
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU){size_t*
sm_FFs4s1wSqB44YDRmAy0PsL=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL
;const sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if=
sm__gLX_E3mfsWCgLgXZERZ67+sm_kPjvJUhBvMtJim43ftnfn6;size_t
sm__Z7eXtpledWXV5NLKDQh86,sm_k6HeriBJpGdZiPlDO4UZXp;if(
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq>=256){if((0>=(1)&&true))
pmf_printf("EPA fault: triangle heap overflow (1)\n");return true;}
sm__Z7eXtpledWXV5NLKDQh86=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq
++;sm_k6HeriBJpGdZiPlDO4UZXp=sm__Z7eXtpledWXV5NLKDQh86>>1;while(
sm__Z7eXtpledWXV5NLKDQh86>1&&sm__hj2_lou4YpDgPeaVq55if->
sm_VPoUbJUlYg0WaXdmtt1Huf>sm__gLX_E3mfsWCgLgXZERZ67[sm_FFs4s1wSqB44YDRmAy0PsL[
sm_k6HeriBJpGdZiPlDO4UZXp]].sm_VPoUbJUlYg0WaXdmtt1Huf){
sm_FFs4s1wSqB44YDRmAy0PsL[sm__Z7eXtpledWXV5NLKDQh86]=sm_FFs4s1wSqB44YDRmAy0PsL
[sm_k6HeriBJpGdZiPlDO4UZXp];sm__Z7eXtpledWXV5NLKDQh86=
sm_k6HeriBJpGdZiPlDO4UZXp;sm_k6HeriBJpGdZiPlDO4UZXp=sm__Z7eXtpledWXV5NLKDQh86
>>1;}sm_FFs4s1wSqB44YDRmAy0PsL[sm__Z7eXtpledWXV5NLKDQh86]=
sm_kPjvJUhBvMtJim43ftnfn6;return false;}static void sm_FQXR9HNwlZSNjqCTaKBulS(
const sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU,const size_t
sm_VL59IGAq4pdhjuflrRxi2Y[],size_t sm__TRcKTAKBz4Qb1Ey7KoSV5){size_t*
sm_FFs4s1wSqB44YDRmAy0PsL=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL
;size_t sm_kwrB3ZoKf7OufTHWaHJV7a,sm_Fyss_XM3F_C4dm6IKoDw4G;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=1;sm_kwrB3ZoKf7OufTHWaHJV7a<=
sm__TRcKTAKBz4Qb1Ey7KoSV5;++sm_kwrB3ZoKf7OufTHWaHJV7a)
sm_FFs4s1wSqB44YDRmAy0PsL[sm_VL59IGAq4pdhjuflrRxi2Y[sm__TRcKTAKBz4Qb1Ey7KoSV5-
sm_kwrB3ZoKf7OufTHWaHJV7a]]=sm_FFs4s1wSqB44YDRmAy0PsL[--
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq];for(
sm_Fyss_XM3F_C4dm6IKoDw4G=(sm_FRpeUPAgV4_aZXdZVkJHXU->
sm_Vs6xonQX17Krc5vXv8T_zq-1)>>1;sm_Fyss_XM3F_C4dm6IKoDw4G>0;--
sm_Fyss_XM3F_C4dm6IKoDw4G){const size_t sm_kPjvJUhBvMtJim43ftnfn6=
sm_FFs4s1wSqB44YDRmAy0PsL[sm_Fyss_XM3F_C4dm6IKoDw4G];const
sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if=sm__gLX_E3mfsWCgLgXZERZ67+
sm_kPjvJUhBvMtJim43ftnfn6;size_t sm__Z7eXtpledWXV5NLKDQh86=
sm_Fyss_XM3F_C4dm6IKoDw4G;while((sm__Z7eXtpledWXV5NLKDQh86<<1)<
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq){const size_t
sm_V0dW4V5md9hDeawyQsnpbD=sm__Z7eXtpledWXV5NLKDQh86<<1;const size_t
sm_kXGmxCwwXVh2cLahzcmgDH=sm_V0dW4V5md9hDeawyQsnpbD+1;const size_t
sm_FFpefy_fScxHhHn8x83g7x=(sm_kXGmxCwwXVh2cLahzcmgDH<sm_FRpeUPAgV4_aZXdZVkJHXU
->sm_Vs6xonQX17Krc5vXv8T_zq&&sm__gLX_E3mfsWCgLgXZERZ67[
sm_FFs4s1wSqB44YDRmAy0PsL[sm_kXGmxCwwXVh2cLahzcmgDH]].
sm_VPoUbJUlYg0WaXdmtt1Huf>sm__gLX_E3mfsWCgLgXZERZ67[sm_FFs4s1wSqB44YDRmAy0PsL[
sm_V0dW4V5md9hDeawyQsnpbD]].sm_VPoUbJUlYg0WaXdmtt1Huf)?
sm_kXGmxCwwXVh2cLahzcmgDH:sm_V0dW4V5md9hDeawyQsnpbD;if(
sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf>=
sm__gLX_E3mfsWCgLgXZERZ67[sm_FFs4s1wSqB44YDRmAy0PsL[sm_FFpefy_fScxHhHn8x83g7x]
].sm_VPoUbJUlYg0WaXdmtt1Huf)break;sm_FFs4s1wSqB44YDRmAy0PsL[
sm__Z7eXtpledWXV5NLKDQh86]=sm_FFs4s1wSqB44YDRmAy0PsL[sm_FFpefy_fScxHhHn8x83g7x
];sm__Z7eXtpledWXV5NLKDQh86=sm_FFpefy_fScxHhHn8x83g7x;}if(
sm__Z7eXtpledWXV5NLKDQh86!=sm_Fyss_XM3F_C4dm6IKoDw4G)sm_FFs4s1wSqB44YDRmAy0PsL
[sm__Z7eXtpledWXV5NLKDQh86]=sm_kPjvJUhBvMtJim43ftnfn6;}}static void
sm_Flw_jMGr_S_xWLbSFTq6Nq(const sm_Vl_xbimdXv_njqt81Wv_1g
sm__gLX_E3mfsWCgLgXZERZ67[],const sm__ywJxOdhydpFYT6CiTxXcf*
sm_FRpeUPAgV4_aZXdZVkJHXU,size_t sm__Z7eXtpledWXV5NLKDQh86,real_T
sm_kAqC_XivnI4FVXW3Q5Ht_f,size_t*sm__oqQ_qIxXF4SWDpvOBksSr,size_t
sm_kd9rqmuOKk0WjmS1BcYcbM[]){const size_t*sm_FFs4s1wSqB44YDRmAy0PsL=
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL;if(
sm__gLX_E3mfsWCgLgXZERZ67[sm_FFs4s1wSqB44YDRmAy0PsL[sm__Z7eXtpledWXV5NLKDQh86]
].sm_VPoUbJUlYg0WaXdmtt1Huf>=sm_kAqC_XivnI4FVXW3Q5Ht_f){
sm_kd9rqmuOKk0WjmS1BcYcbM[(*sm__oqQ_qIxXF4SWDpvOBksSr)++]=
sm__Z7eXtpledWXV5NLKDQh86;sm__Z7eXtpledWXV5NLKDQh86<<=1;if(
sm__Z7eXtpledWXV5NLKDQh86<sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq
)sm_Flw_jMGr_S_xWLbSFTq6Nq(sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU
,sm__Z7eXtpledWXV5NLKDQh86,sm_kAqC_XivnI4FVXW3Q5Ht_f,sm__oqQ_qIxXF4SWDpvOBksSr
,sm_kd9rqmuOKk0WjmS1BcYcbM);++sm__Z7eXtpledWXV5NLKDQh86;if(
sm__Z7eXtpledWXV5NLKDQh86<sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq
)sm_Flw_jMGr_S_xWLbSFTq6Nq(sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU
,sm__Z7eXtpledWXV5NLKDQh86,sm_kAqC_XivnI4FVXW3Q5Ht_f,sm__oqQ_qIxXF4SWDpvOBksSr
,sm_kd9rqmuOKk0WjmS1BcYcbM);}}static size_t sm_FAk8k9WhquCzeLssuMr2Hq(const
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],const
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU,real_T
sm_kAqC_XivnI4FVXW3Q5Ht_f,size_t sm_kd9rqmuOKk0WjmS1BcYcbM[]){size_t
sm__oqQ_qIxXF4SWDpvOBksSr=0;if(sm_FRpeUPAgV4_aZXdZVkJHXU->
sm_Vs6xonQX17Krc5vXv8T_zq>1)sm_Flw_jMGr_S_xWLbSFTq6Nq(
sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU,1,
sm_kAqC_XivnI4FVXW3Q5Ht_f,&sm__oqQ_qIxXF4SWDpvOBksSr,sm_kd9rqmuOKk0WjmS1BcYcbM
);return sm__oqQ_qIxXF4SWDpvOBksSr;}static double sm_V3qf5IfM7RdaZDwMstW9pg(
const sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],const
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU){const size_t*
sm_FFs4s1wSqB44YDRmAy0PsL=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL
;size_t sm__Z7eXtpledWXV5NLKDQh86;real_T sm_kd1Plhqj0HK8XLfhRAQVsc= +1.0e100;
for(sm__Z7eXtpledWXV5NLKDQh86=((sm_FRpeUPAgV4_aZXdZVkJHXU->
sm_Vs6xonQX17Krc5vXv8T_zq-1)>>1)+1;sm__Z7eXtpledWXV5NLKDQh86<
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq;++
sm__Z7eXtpledWXV5NLKDQh86){const real_T sm_F32Ql82vv6pW_PYIdpkFQ0=
sm__gLX_E3mfsWCgLgXZERZ67[sm_FFs4s1wSqB44YDRmAy0PsL[sm__Z7eXtpledWXV5NLKDQh86]
].sm_VPoUbJUlYg0WaXdmtt1Huf;if(sm_F32Ql82vv6pW_PYIdpkFQ0<
sm_kd1Plhqj0HK8XLfhRAQVsc)sm_kd1Plhqj0HK8XLfhRAQVsc=sm_F32Ql82vv6pW_PYIdpkFQ0;
}return sm_kd1Plhqj0HK8XLfhRAQVsc;}void sm_VIvfks0flshaVTeZdVy88f(const
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],const
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU,const
sm_kd__PjR5tCWObue2RSyCuW*sm_VVHOMuY8Vx4_WqfMmhCoVT,size_t
sm__wN5g_p_uwdVVLfRtx9szc,real_T sm_FNpbtDhe3185ZP5CBxcCqz,size_t
sm_FEk_1yHDbA0kiH62fysjoR,int sm_k74yIOzASotVhLxvAZXBzS[],size_t**
sm__X_CJb3g7COKXuUC2NKBlt){const sm_Vl_xbimdXv_njqt81Wv_1g*
sm__hj2_lou4YpDgPeaVq55if=sm__gLX_E3mfsWCgLgXZERZ67+sm__wN5g_p_uwdVVLfRtx9szc;
const boolean_T sm__cqIzg3lmSlDbi4wysZqRI=(sm_FEk_1yHDbA0kiH62fysjoR==(size_t)
-1);unsigned int sm__dwnxU_xQCW_eTNOKQb2_n[3];unsigned int
sm_FFZbGh27ya8eem_J_hUtAZ;sm__dwnxU_xQCW_eTNOKQb2_n[0]=
sm__cqIzg3lmSlDbi4wysZqRI?0:sm__CPFntwZRP4LVTxix2pO_p(
sm__hj2_lou4YpDgPeaVq55if,sm_FEk_1yHDbA0kiH62fysjoR);sm__dwnxU_xQCW_eTNOKQb2_n
[1]=sm__dwnxU_xQCW_eTNOKQb2_n[0]<2?(sm__dwnxU_xQCW_eTNOKQb2_n[0]+1):0;
sm__dwnxU_xQCW_eTNOKQb2_n[2]=sm__dwnxU_xQCW_eTNOKQb2_n[1]<2?(
sm__dwnxU_xQCW_eTNOKQb2_n[1]+1):0;for(sm_FFZbGh27ya8eem_J_hUtAZ=
sm__cqIzg3lmSlDbi4wysZqRI?0:1;sm_FFZbGh27ya8eem_J_hUtAZ<3;++
sm_FFZbGh27ya8eem_J_hUtAZ){const size_t sm_FHx5gV_aJvhMfLNw3LhgFJ=
sm__hj2_lou4YpDgPeaVq55if->sm_kF_fYTSA5k8nXXjCcUgJvI[sm__dwnxU_xQCW_eTNOKQb2_n
[sm_FFZbGh27ya8eem_J_hUtAZ]];boolean_T sm__OzkgH72RfC6fyXyBVRREV=false;if(
sm_k74yIOzASotVhLxvAZXBzS[sm_FHx5gV_aJvhMfLNw3LhgFJ]>0)continue;if(
sm_k74yIOzASotVhLxvAZXBzS[sm_FHx5gV_aJvhMfLNw3LhgFJ]==0){const real_T
sm_Vrk3Pgb1wrhnZmcOkBtvtB=sm__DJP6gbIXup3bTIE8pNaTu(sm__gLX_E3mfsWCgLgXZERZ67+
sm_FHx5gV_aJvhMfLNw3LhgFJ,sm_VVHOMuY8Vx4_WqfMmhCoVT);sm__OzkgH72RfC6fyXyBVRREV
=(sm_Vrk3Pgb1wrhnZmcOkBtvtB>sm_FNpbtDhe3185ZP5CBxcCqz);
sm_k74yIOzASotVhLxvAZXBzS[sm_FHx5gV_aJvhMfLNw3LhgFJ]=sm__OzkgH72RfC6fyXyBVRREV
?+1:-1;}if(sm__OzkgH72RfC6fyXyBVRREV){sm_VIvfks0flshaVTeZdVy88f(
sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU,sm_VVHOMuY8Vx4_WqfMmhCoVT,
sm_FHx5gV_aJvhMfLNw3LhgFJ,sm_FNpbtDhe3185ZP5CBxcCqz,sm__wN5g_p_uwdVVLfRtx9szc,
sm_k74yIOzASotVhLxvAZXBzS,sm__X_CJb3g7COKXuUC2NKBlt);}else{const size_t
sm_VqvO6m2hxttkWiXZ0ty2MU=sm__CPFntwZRP4LVTxix2pO_p(sm__gLX_E3mfsWCgLgXZERZ67+
sm_FHx5gV_aJvhMfLNw3LhgFJ,sm__wN5g_p_uwdVVLfRtx9szc);*(*
sm__X_CJb3g7COKXuUC2NKBlt)++=(sm_FHx5gV_aJvhMfLNw3LhgFJ<<2)+
sm_VqvO6m2hxttkWiXZ0ty2MU;}}}void sm_VayBu4P1dZxueeEwnfoP9Y(const
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],const
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU,const
sm_kd__PjR5tCWObue2RSyCuW*sm_VVHOMuY8Vx4_WqfMmhCoVT,size_t
sm_V0bxBq_fW_GhYasae_DbOG,real_T sm_FNpbtDhe3185ZP5CBxcCqz,size_t
sm__X_CJb3g7COKXuUC2NKBlt[],size_t*sm__JbiCKKNwu0mamlU_2Ci91,size_t
sm_koPVBBTj_5hpZPsGz6Whts[],size_t*sm_VaqYtNtmexdSemnwI3eeJT){const size_t*
sm_FFs4s1wSqB44YDRmAy0PsL=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL
;const size_t sm_kAHiWXkNgKC3capu8EOtHs=sm_FFs4s1wSqB44YDRmAy0PsL[
sm_V0bxBq_fW_GhYasae_DbOG];const size_t sm_kZNYdUAoU4S6eeHGk4GOqu=
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq-1;size_t*
sm__YhdMMtETnlNdinx2wpbuK=sm__X_CJb3g7COKXuUC2NKBlt;size_t*
sm_FFa5_kiNeEGDjPZO8vv3tC=sm_koPVBBTj_5hpZPsGz6Whts;size_t
sm__Z7eXtpledWXV5NLKDQh86,sm_kwrB3ZoKf7OufTHWaHJV7a;int
sm_k74yIOzASotVhLxvAZXBzS[256];for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<sm_kZNYdUAoU4S6eeHGk4GOqu;++
sm_kwrB3ZoKf7OufTHWaHJV7a)sm_k74yIOzASotVhLxvAZXBzS[sm_kwrB3ZoKf7OufTHWaHJV7a]
=0;sm_k74yIOzASotVhLxvAZXBzS[sm_kAHiWXkNgKC3capu8EOtHs]= +1;
sm_VIvfks0flshaVTeZdVy88f(sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU,
sm_VVHOMuY8Vx4_WqfMmhCoVT,sm_kAHiWXkNgKC3capu8EOtHs,sm_FNpbtDhe3185ZP5CBxcCqz,
(size_t)-1,sm_k74yIOzASotVhLxvAZXBzS,&sm__YhdMMtETnlNdinx2wpbuK);*
sm__JbiCKKNwu0mamlU_2Ci91=sm__YhdMMtETnlNdinx2wpbuK-sm__X_CJb3g7COKXuUC2NKBlt;
for(sm__Z7eXtpledWXV5NLKDQh86=1;sm__Z7eXtpledWXV5NLKDQh86<
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq;++
sm__Z7eXtpledWXV5NLKDQh86)if(sm_k74yIOzASotVhLxvAZXBzS[
sm_FFs4s1wSqB44YDRmAy0PsL[sm__Z7eXtpledWXV5NLKDQh86]]>0)*
sm_FFa5_kiNeEGDjPZO8vv3tC++=sm__Z7eXtpledWXV5NLKDQh86;*
sm_VaqYtNtmexdSemnwI3eeJT=sm_FFa5_kiNeEGDjPZO8vv3tC-sm_koPVBBTj_5hpZPsGz6Whts;
if((0>=(4)&&true)){pmf_printf("Visible triangles:");for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<*
sm_VaqYtNtmexdSemnwI3eeJT;++sm_kwrB3ZoKf7OufTHWaHJV7a)pmf_printf(" %zu",
sm_koPVBBTj_5hpZPsGz6Whts[sm_kwrB3ZoKf7OufTHWaHJV7a]);pmf_printf("\n");
pmf_printf("Horizon contour");for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<*sm__JbiCKKNwu0mamlU_2Ci91;++
sm_kwrB3ZoKf7OufTHWaHJV7a){const size_t sm_kh3C5f6ZAPlGWXfJykpWPn=
sm__X_CJb3g7COKXuUC2NKBlt[sm_kwrB3ZoKf7OufTHWaHJV7a]>>2;const size_t
sm_VqvO6m2hxttkWiXZ0ty2MU=sm__X_CJb3g7COKXuUC2NKBlt[sm_kwrB3ZoKf7OufTHWaHJV7a]
&0x3;const size_t*sm__ES3I_smAMxeWymFnmeiT3=sm__gLX_E3mfsWCgLgXZERZ67[
sm_kh3C5f6ZAPlGWXfJykpWPn].sm_k4v50UutrvdChTHBxBrg_s;pmf_printf(
"%s %zu (%zu -> %zu)",sm_kwrB3ZoKf7OufTHWaHJV7a==0?": ":",",
sm_kh3C5f6ZAPlGWXfJykpWPn,sm__ES3I_smAMxeWymFnmeiT3[(sm_VqvO6m2hxttkWiXZ0ty2MU
+2)%3],sm__ES3I_smAMxeWymFnmeiT3[(sm_VqvO6m2hxttkWiXZ0ty2MU+1)%3]);}pmf_printf
("\n");}}static int sm_kCBCG3cMzx0icXr3uGXQIT(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ){const real_T sm_kY_rL_F8Nc0DiX9ImprC4_=fabs(
sm_VgJW5ZqpwPpuY1inYtaofQ->x);const real_T sm_kkkJJmKdVddMYirZwDaWI_=fabs(
sm_VgJW5ZqpwPpuY1inYtaofQ->sm_FzyLWRgau0pMYq2XSI3ETL);const real_T
sm_kn7OR4rQBtCCd5grVmuZLu=fabs(sm_VgJW5ZqpwPpuY1inYtaofQ->
sm_FBDi_PCg670TjHgJTNPcHr);return(sm_kY_rL_F8Nc0DiX9ImprC4_<=
sm_kkkJJmKdVddMYirZwDaWI_)?((sm_kY_rL_F8Nc0DiX9ImprC4_<=
sm_kn7OR4rQBtCCd5grVmuZLu)?0:2):((sm_kkkJJmKdVddMYirZwDaWI_<=
sm_kn7OR4rQBtCCd5grVmuZLu)?1:2);}void sm_kiB3Db7ZfZd8f9Vi_wl6s9(const
sm_kd__PjR5tCWObue2RSyCuW sm_k4v50UutrvdChTHBxBrg_s[][3],size_t
sm_FkoBKJSu3bdQdPWZgD2fC8){size_t sm__wN5g_p_uwdVVLfRtx9szc;pmf_printf(
"Vertices (%d):\n",sm_FkoBKJSu3bdQdPWZgD2fC8);for(sm__wN5g_p_uwdVVLfRtx9szc=0;
sm__wN5g_p_uwdVVLfRtx9szc<sm_FkoBKJSu3bdQdPWZgD2fC8;++
sm__wN5g_p_uwdVVLfRtx9szc)pmf_printf(
"[%2d]  [ %+9.6f  %+9.6f  %+9.6f ][ %+9.6f  %+9.6f  %+9.6f ]"
"[ %+9.6f  %+9.6f  %+9.6f ]\n",sm__wN5g_p_uwdVVLfRtx9szc,
sm_k4v50UutrvdChTHBxBrg_s[sm__wN5g_p_uwdVVLfRtx9szc][0].x,
sm_k4v50UutrvdChTHBxBrg_s[sm__wN5g_p_uwdVVLfRtx9szc][0].
sm_FzyLWRgau0pMYq2XSI3ETL,sm_k4v50UutrvdChTHBxBrg_s[sm__wN5g_p_uwdVVLfRtx9szc]
[0].sm_FBDi_PCg670TjHgJTNPcHr,sm_k4v50UutrvdChTHBxBrg_s[
sm__wN5g_p_uwdVVLfRtx9szc][1].x,sm_k4v50UutrvdChTHBxBrg_s[
sm__wN5g_p_uwdVVLfRtx9szc][1].sm_FzyLWRgau0pMYq2XSI3ETL,
sm_k4v50UutrvdChTHBxBrg_s[sm__wN5g_p_uwdVVLfRtx9szc][1].
sm_FBDi_PCg670TjHgJTNPcHr,sm_k4v50UutrvdChTHBxBrg_s[sm__wN5g_p_uwdVVLfRtx9szc]
[2].x,sm_k4v50UutrvdChTHBxBrg_s[sm__wN5g_p_uwdVVLfRtx9szc][2].
sm_FzyLWRgau0pMYq2XSI3ETL,sm_k4v50UutrvdChTHBxBrg_s[sm__wN5g_p_uwdVVLfRtx9szc]
[2].sm_FBDi_PCg670TjHgJTNPcHr);}void sm_Fyjicail5idk_HymzkTyHM(const
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],const
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU){const size_t*
sm_FFs4s1wSqB44YDRmAy0PsL=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL
;size_t sm__Z7eXtpledWXV5NLKDQh86;pmf_printf("Triangles (%d):\n",
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq-1);pmf_printf(
"Heap  Array  Vertices      Neighbors     Plane\n");for(
sm__Z7eXtpledWXV5NLKDQh86=1;sm__Z7eXtpledWXV5NLKDQh86<
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq;++
sm__Z7eXtpledWXV5NLKDQh86){const sm_Vl_xbimdXv_njqt81Wv_1g*
sm__hj2_lou4YpDgPeaVq55if=sm__gLX_E3mfsWCgLgXZERZ67+sm_FFs4s1wSqB44YDRmAy0PsL[
sm__Z7eXtpledWXV5NLKDQh86];pmf_printf(
"[%2d] (%2d) %5s [%2d  %2d  %2d]  [%2d  %2d  %2d]"
"  [ %+9.6f  %+9.6f  %+9.6f    %+10.6f ]\n",sm__Z7eXtpledWXV5NLKDQh86,
sm_FFs4s1wSqB44YDRmAy0PsL[sm__Z7eXtpledWXV5NLKDQh86],(
sm__hj2_lou4YpDgPeaVq55if->sm__c5XrFgUwWKogTUJHqQfJg?"degen":""),
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[0],
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[1],
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[2],
sm__hj2_lou4YpDgPeaVq55if->sm_kF_fYTSA5k8nXXjCcUgJvI[0],
sm__hj2_lou4YpDgPeaVq55if->sm_kF_fYTSA5k8nXXjCcUgJvI[1],
sm__hj2_lou4YpDgPeaVq55if->sm_kF_fYTSA5k8nXXjCcUgJvI[2],
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V.x,
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V.sm_FzyLWRgau0pMYq2XSI3ETL
,sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V.
sm_FBDi_PCg670TjHgJTNPcHr,sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf
);}}static void sm_kHH_TPMqcAGe_qmFkTpnMl(const sm_Vl_xbimdXv_njqt81Wv_1g
sm__gLX_E3mfsWCgLgXZERZ67[],const sm__ywJxOdhydpFYT6CiTxXcf*
sm_FRpeUPAgV4_aZXdZVkJHXU,size_t sm__TRcKTAKBz4Qb1Ey7KoSV5,size_t
sm_Fda_IqK1ADllVL2ZHjfjxW[]){const size_t*sm_FFs4s1wSqB44YDRmAy0PsL=
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL;size_t
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_kyp6uAyJE40UVuAQNEYzS1;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<
sm__TRcKTAKBz4Qb1Ey7KoSV5;++sm_kwrB3ZoKf7OufTHWaHJV7a)for(
sm_kyp6uAyJE40UVuAQNEYzS1=sm_kwrB3ZoKf7OufTHWaHJV7a+1;
sm_kyp6uAyJE40UVuAQNEYzS1<sm__TRcKTAKBz4Qb1Ey7KoSV5;++
sm_kyp6uAyJE40UVuAQNEYzS1)if(sm__gLX_E3mfsWCgLgXZERZ67[
sm_FFs4s1wSqB44YDRmAy0PsL[sm_Fda_IqK1ADllVL2ZHjfjxW[sm_kyp6uAyJE40UVuAQNEYzS1]
]].sm_VPoUbJUlYg0WaXdmtt1Huf>sm__gLX_E3mfsWCgLgXZERZ67[
sm_FFs4s1wSqB44YDRmAy0PsL[sm_Fda_IqK1ADllVL2ZHjfjxW[sm_kwrB3ZoKf7OufTHWaHJV7a]
]].sm_VPoUbJUlYg0WaXdmtt1Huf){const size_t sm_Fk2O4u6vQUpibmbv8Kjgnn=
sm_Fda_IqK1ADllVL2ZHjfjxW[sm_kwrB3ZoKf7OufTHWaHJV7a];sm_Fda_IqK1ADllVL2ZHjfjxW
[sm_kwrB3ZoKf7OufTHWaHJV7a]=sm_Fda_IqK1ADllVL2ZHjfjxW[
sm_kyp6uAyJE40UVuAQNEYzS1];sm_Fda_IqK1ADllVL2ZHjfjxW[sm_kyp6uAyJE40UVuAQNEYzS1
]=sm_Fk2O4u6vQUpibmbv8Kjgnn;}}void sm__ezYf2_O17_XfyBQ3_mD2L(const
sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if,const
sm_kd__PjR5tCWObue2RSyCuW sm_k4v50UutrvdChTHBxBrg_s[][3],const
sm_kd__PjR5tCWObue2RSyCuW*pm__lqjegyKuwStj56WZLiC_e,real_T
sm_k7RVes5oHPO2Yi5DMSKkeo[3]){const sm_kd__PjR5tCWObue2RSyCuW*
sm__AuaKMC5koOPbXxPi_MZvt= &sm_k4v50UutrvdChTHBxBrg_s[
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[0]][2];const
sm_kd__PjR5tCWObue2RSyCuW*sm_kNtPmLll5l8eiqwtk5kfJv= &
sm_k4v50UutrvdChTHBxBrg_s[sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s
[1]][2];const sm_kd__PjR5tCWObue2RSyCuW*sm__V7yhs3oelG7WqyGLN1Wqz= &
sm_k4v50UutrvdChTHBxBrg_s[sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s
[2]][2];real_T sm_F2l4p_g4sn02huHNflQjMH[12],b[4];real_T
sm_kTQbRrK9Zn49jTgjOBqDPQ[3],sm_VRZCD_UL_ESThy75dC9J8D[3];int
sm_FrVYLSQleN4GYXlrWrmRui[3]={0,0,0};memcpy(sm_F2l4p_g4sn02huHNflQjMH+0,&
sm__AuaKMC5koOPbXxPi_MZvt->x,3*sizeof(real_T));memcpy(
sm_F2l4p_g4sn02huHNflQjMH+4,&sm_kNtPmLll5l8eiqwtk5kfJv->x,3*sizeof(real_T));
memcpy(sm_F2l4p_g4sn02huHNflQjMH+8,&sm__V7yhs3oelG7WqyGLN1Wqz->x,3*sizeof(
real_T));sm_F2l4p_g4sn02huHNflQjMH[3]=sm_F2l4p_g4sn02huHNflQjMH[7]=
sm_F2l4p_g4sn02huHNflQjMH[11]=1.0;pm_math_lin_alg_qrFactor(4,3,
sm_F2l4p_g4sn02huHNflQjMH,sm_kTQbRrK9Zn49jTgjOBqDPQ,sm_FrVYLSQleN4GYXlrWrmRui,
sm_VRZCD_UL_ESThy75dC9J8D);memcpy(b,&pm__lqjegyKuwStj56WZLiC_e->x,3*sizeof(
real_T));b[3]=1.0;pm_math_lin_alg_qrSolveTall(4,3,sm_F2l4p_g4sn02huHNflQjMH,
sm_kTQbRrK9Zn49jTgjOBqDPQ,sm_FrVYLSQleN4GYXlrWrmRui,1.0e-12,b);memcpy(
sm_k7RVes5oHPO2Yi5DMSKkeo,b,3*sizeof(real_T));}void sm_ktKiesCnReWpd5co2v03eg(
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU,size_t
sm_kyQmWVyJU5CqW1ETGHpSfQ){size_t*sm_FFs4s1wSqB44YDRmAy0PsL=
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL;const size_t
sm__QJ6YJM3qEdBfTmwj4Ds74=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq
-1;boolean_T sm_VL5N46E_DJOYa9KUxMVVPs[256];size_t sm__Lc8mLuZNVCWdPuS3Bngfs[
256];size_t sm_kwrB3ZoKf7OufTHWaHJV7a,sm__Z7eXtpledWXV5NLKDQh86,src,dst,*
sm_kh3C5f6ZAPlGWXfJykpWPn;for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<sm_kyQmWVyJU5CqW1ETGHpSfQ;++
sm_kwrB3ZoKf7OufTHWaHJV7a)sm_VL5N46E_DJOYa9KUxMVVPs[sm_kwrB3ZoKf7OufTHWaHJV7a]
=false;for(sm__Z7eXtpledWXV5NLKDQh86=1;sm__Z7eXtpledWXV5NLKDQh86<
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq;++
sm__Z7eXtpledWXV5NLKDQh86)sm_VL5N46E_DJOYa9KUxMVVPs[sm_FFs4s1wSqB44YDRmAy0PsL[
sm__Z7eXtpledWXV5NLKDQh86]]=true;dst=0;for(src=0;src<sm_kyQmWVyJU5CqW1ETGHpSfQ
;++src){if(sm_VL5N46E_DJOYa9KUxMVVPs[src]){sm__Lc8mLuZNVCWdPuS3Bngfs[src]=dst;
sm__gLX_E3mfsWCgLgXZERZ67[dst++]=sm__gLX_E3mfsWCgLgXZERZ67[src];}}(void)0;;
sm_kh3C5f6ZAPlGWXfJykpWPn=sm_FFs4s1wSqB44YDRmAy0PsL+1;for(
sm__Z7eXtpledWXV5NLKDQh86=1;sm__Z7eXtpledWXV5NLKDQh86<
sm_FRpeUPAgV4_aZXdZVkJHXU->sm_Vs6xonQX17Krc5vXv8T_zq;++
sm__Z7eXtpledWXV5NLKDQh86,++sm_kh3C5f6ZAPlGWXfJykpWPn)*
sm_kh3C5f6ZAPlGWXfJykpWPn=sm__Lc8mLuZNVCWdPuS3Bngfs[*sm_kh3C5f6ZAPlGWXfJykpWPn
];for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<
sm__QJ6YJM3qEdBfTmwj4Ds74;++sm_kwrB3ZoKf7OufTHWaHJV7a){size_t*
sm_V6YjlDUEfyKVaine7gxNLh=sm__gLX_E3mfsWCgLgXZERZ67[sm_kwrB3ZoKf7OufTHWaHJV7a]
.sm_kF_fYTSA5k8nXXjCcUgJvI;sm_V6YjlDUEfyKVaine7gxNLh[0]=
sm__Lc8mLuZNVCWdPuS3Bngfs[sm_V6YjlDUEfyKVaine7gxNLh[0]];
sm_V6YjlDUEfyKVaine7gxNLh[1]=sm__Lc8mLuZNVCWdPuS3Bngfs[
sm_V6YjlDUEfyKVaine7gxNLh[1]];sm_V6YjlDUEfyKVaine7gxNLh[2]=
sm__Lc8mLuZNVCWdPuS3Bngfs[sm_V6YjlDUEfyKVaine7gxNLh[2]];}}static void
sm_VeMO3LYTXd0WjH3rzZ_rea(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,sm_kd__PjR5tCWObue2RSyCuW
sm_k4v50UutrvdChTHBxBrg_s[][3],size_t sm_FkoBKJSu3bdQdPWZgD2fC8,
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU){size_t
sm__1eAP9V6_J_NYm_1gTIm7A;boolean_T sm_VncVT15Kdj8bbLIO2xc9Xi;real_T
sm_k06eY_2SxAxF_PegVRm_aY;sm_kd__PjR5tCWObue2RSyCuW sm__5oub5Bfq9_j_LMNrpaKQr[
3];(void)0;;if(sm_FkoBKJSu3bdQdPWZgD2fC8==1){real_T sm__ggmggh__aKLe9WMDN7tHF=
-1.0;int sm_k2eCYXwIlYd7eq6H7e3z3y,sm_VMOP4__P7n0Bhuj17xW302;for(
sm_k2eCYXwIlYd7eq6H7e3z3y=0;sm_k2eCYXwIlYd7eq6H7e3z3y<3;++
sm_k2eCYXwIlYd7eq6H7e3z3y)for(sm_VMOP4__P7n0Bhuj17xW302=0;
sm_VMOP4__P7n0Bhuj17xW302<2;++sm_VMOP4__P7n0Bhuj17xW302){const real_T
sm_V3Prc2Wk2axhj5rXtbFCFI=sm_VMOP4__P7n0Bhuj17xW302==0?-1.0:+1.0;
sm_kd__PjR5tCWObue2RSyCuW sm_F9yDQxbxjNlSeXydMwl6yG,sm_kDTYNj3erXleeDgn6ZWFBW;
double sm_kCEF3KTdHU0vdTwaKdahBe;sm_F9yDQxbxjNlSeXydMwl6yG.x=
sm_F9yDQxbxjNlSeXydMwl6yG.sm_FzyLWRgau0pMYq2XSI3ETL=sm_F9yDQxbxjNlSeXydMwl6yG.
sm_FBDi_PCg670TjHgJTNPcHr=0.0;*(&sm_F9yDQxbxjNlSeXydMwl6yG.x+
sm_k2eCYXwIlYd7eq6H7e3z3y)=sm_V3Prc2Wk2axhj5rXtbFCFI;sm_kkIDwZB8zm4Pjyeyqv1cv5
(sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,sm_F4kGV66idSlLj12YnANYlJ
,sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe
,&sm_F9yDQxbxjNlSeXydMwl6yG,sm__5oub5Bfq9_j_LMNrpaKQr+0,
sm__5oub5Bfq9_j_LMNrpaKQr+1,sm__5oub5Bfq9_j_LMNrpaKQr+2);
pm_math_Vector3_subtract(&sm__5oub5Bfq9_j_LMNrpaKQr[2],&
sm_k4v50UutrvdChTHBxBrg_s[0][2],&sm_kDTYNj3erXleeDgn6ZWFBW);
sm_kCEF3KTdHU0vdTwaKdahBe=pm_math_Vector3_dot(&sm_kDTYNj3erXleeDgn6ZWFBW,&
sm_kDTYNj3erXleeDgn6ZWFBW);if(sm_kCEF3KTdHU0vdTwaKdahBe>
sm__ggmggh__aKLe9WMDN7tHF){sm_k4v50UutrvdChTHBxBrg_s[sm_FkoBKJSu3bdQdPWZgD2fC8
][0]=sm__5oub5Bfq9_j_LMNrpaKQr[0];sm_k4v50UutrvdChTHBxBrg_s[
sm_FkoBKJSu3bdQdPWZgD2fC8][1]=sm__5oub5Bfq9_j_LMNrpaKQr[1];
sm_k4v50UutrvdChTHBxBrg_s[sm_FkoBKJSu3bdQdPWZgD2fC8][2]=
sm__5oub5Bfq9_j_LMNrpaKQr[2];sm__ggmggh__aKLe9WMDN7tHF=
sm_kCEF3KTdHU0vdTwaKdahBe;}}++sm_FkoBKJSu3bdQdPWZgD2fC8;}if(
sm_FkoBKJSu3bdQdPWZgD2fC8==2){int sm_FFZbGh27ya8eem_J_hUtAZ,
sm_VOe8QTG_9opKiTSLxTkS7T,sm_VMOP4__P7n0Bhuj17xW302;real_T
sm__ggmggh__aKLe9WMDN7tHF,sm__dO6okMhD4_sjyovK3Stz8;sm_kd__PjR5tCWObue2RSyCuW
sm_kDTYNj3erXleeDgn6ZWFBW,sm_k2eCYXwIlYd7eq6H7e3z3y,sm_VylwAM70THxk_ewY7IyuK0[
2],sm_F1LfOOnBFbpFWi7QXSZyNj;pm_math_Vector3_subtract(&
sm_k4v50UutrvdChTHBxBrg_s[1][2],&sm_k4v50UutrvdChTHBxBrg_s[0][2],&
sm_kDTYNj3erXleeDgn6ZWFBW);pm_math_Vector3_unit(&sm_kDTYNj3erXleeDgn6ZWFBW,&
sm_kDTYNj3erXleeDgn6ZWFBW);sm_FFZbGh27ya8eem_J_hUtAZ=sm_kCBCG3cMzx0icXr3uGXQIT
(&sm_kDTYNj3erXleeDgn6ZWFBW);sm_k2eCYXwIlYd7eq6H7e3z3y.x=
sm_k2eCYXwIlYd7eq6H7e3z3y.sm_FzyLWRgau0pMYq2XSI3ETL=sm_k2eCYXwIlYd7eq6H7e3z3y.
sm_FBDi_PCg670TjHgJTNPcHr=0.0;*(&sm_k2eCYXwIlYd7eq6H7e3z3y.x+
sm_FFZbGh27ya8eem_J_hUtAZ)=1.0;pm_math_Vector3_scale(&
sm_kDTYNj3erXleeDgn6ZWFBW,*(&sm_kDTYNj3erXleeDgn6ZWFBW.x+
sm_FFZbGh27ya8eem_J_hUtAZ),&sm_F1LfOOnBFbpFWi7QXSZyNj);
pm_math_Vector3_subtract(&sm_k2eCYXwIlYd7eq6H7e3z3y,&sm_F1LfOOnBFbpFWi7QXSZyNj
,&sm_VylwAM70THxk_ewY7IyuK0[0]);pm_math_Vector3_cross(&
sm_kDTYNj3erXleeDgn6ZWFBW,&sm_VylwAM70THxk_ewY7IyuK0[0],&
sm_VylwAM70THxk_ewY7IyuK0[1]);sm__ggmggh__aKLe9WMDN7tHF= -1.0;for(
sm_VOe8QTG_9opKiTSLxTkS7T=0;sm_VOe8QTG_9opKiTSLxTkS7T<2;++
sm_VOe8QTG_9opKiTSLxTkS7T)for(sm_VMOP4__P7n0Bhuj17xW302=0;
sm_VMOP4__P7n0Bhuj17xW302<2;++sm_VMOP4__P7n0Bhuj17xW302){
sm_kd__PjR5tCWObue2RSyCuW*sm_F9yDQxbxjNlSeXydMwl6yG=sm_VylwAM70THxk_ewY7IyuK0+
sm_VOe8QTG_9opKiTSLxTkS7T;if(sm_VMOP4__P7n0Bhuj17xW302>0)
pm_math_Vector3_negate(sm_F9yDQxbxjNlSeXydMwl6yG,sm_F9yDQxbxjNlSeXydMwl6yG);
sm_kkIDwZB8zm4Pjyeyqv1cv5(sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,
sm_F4kGV66idSlLj12YnANYlJ,sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_F9yDQxbxjNlSeXydMwl6yG,sm__5oub5Bfq9_j_LMNrpaKQr+
0,sm__5oub5Bfq9_j_LMNrpaKQr+1,sm__5oub5Bfq9_j_LMNrpaKQr+2);
pm_math_Vector3_cross(&sm_kDTYNj3erXleeDgn6ZWFBW,&sm__5oub5Bfq9_j_LMNrpaKQr[2]
,&sm_F1LfOOnBFbpFWi7QXSZyNj);sm__dO6okMhD4_sjyovK3Stz8=pm_math_Vector3_dot(&
sm_F1LfOOnBFbpFWi7QXSZyNj,&sm_F1LfOOnBFbpFWi7QXSZyNj);if(
sm__dO6okMhD4_sjyovK3Stz8>sm__ggmggh__aKLe9WMDN7tHF){sm_k4v50UutrvdChTHBxBrg_s
[sm_FkoBKJSu3bdQdPWZgD2fC8][0]=sm__5oub5Bfq9_j_LMNrpaKQr[0];
sm_k4v50UutrvdChTHBxBrg_s[sm_FkoBKJSu3bdQdPWZgD2fC8][1]=
sm__5oub5Bfq9_j_LMNrpaKQr[1];sm_k4v50UutrvdChTHBxBrg_s[
sm_FkoBKJSu3bdQdPWZgD2fC8][2]=sm__5oub5Bfq9_j_LMNrpaKQr[2];
sm__ggmggh__aKLe9WMDN7tHF=sm__dO6okMhD4_sjyovK3Stz8;}}++
sm_FkoBKJSu3bdQdPWZgD2fC8;}if(sm_FkoBKJSu3bdQdPWZgD2fC8==3){int
sm_VMOP4__P7n0Bhuj17xW302;real_T sm_Vrk3Pgb1wrhnZmcOkBtvtB,
sm__ggmggh__aKLe9WMDN7tHF;sm_kd__PjR5tCWObue2RSyCuW sm__hj2_lou4YpDgPeaVq55if[
3],sm__TBxRBCon90NeHiMaIfEzO[3],sm_kZKtm8DV37C4ieFPsTyO2E,
sm_F9yDQxbxjNlSeXydMwl6yG,sm_kDTYNj3erXleeDgn6ZWFBW;const size_t
sm__mNZl3Dws0SzjmkHXP_BQz[3]={0,1,2};sm__6dBgrcOk_GXieU6ApKSyW((const
sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])sm_k4v50UutrvdChTHBxBrg_s,2,
sm__mNZl3Dws0SzjmkHXP_BQz,sm__hj2_lou4YpDgPeaVq55if,&sm_kZKtm8DV37C4ieFPsTyO2E
,sm__TBxRBCon90NeHiMaIfEzO,&sm_F9yDQxbxjNlSeXydMwl6yG);
sm__ggmggh__aKLe9WMDN7tHF= -1.0;for(sm_VMOP4__P7n0Bhuj17xW302=0;
sm_VMOP4__P7n0Bhuj17xW302<2;++sm_VMOP4__P7n0Bhuj17xW302){if(
sm_VMOP4__P7n0Bhuj17xW302>0)pm_math_Vector3_negate(&sm_F9yDQxbxjNlSeXydMwl6yG,
&sm_F9yDQxbxjNlSeXydMwl6yG);sm_kkIDwZB8zm4Pjyeyqv1cv5(
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,sm_F4kGV66idSlLj12YnANYlJ,
sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe,
&sm_F9yDQxbxjNlSeXydMwl6yG,sm__5oub5Bfq9_j_LMNrpaKQr+0,
sm__5oub5Bfq9_j_LMNrpaKQr+1,sm__5oub5Bfq9_j_LMNrpaKQr+2);
pm_math_Vector3_subtract(&sm__5oub5Bfq9_j_LMNrpaKQr[2],&
sm_kZKtm8DV37C4ieFPsTyO2E,&sm_kDTYNj3erXleeDgn6ZWFBW);
sm_Vrk3Pgb1wrhnZmcOkBtvtB=fabs(pm_math_Vector3_dot(&sm_kDTYNj3erXleeDgn6ZWFBW,
&sm_F9yDQxbxjNlSeXydMwl6yG));if(sm_Vrk3Pgb1wrhnZmcOkBtvtB>
sm__ggmggh__aKLe9WMDN7tHF){sm_k4v50UutrvdChTHBxBrg_s[sm_FkoBKJSu3bdQdPWZgD2fC8
][0]=sm__5oub5Bfq9_j_LMNrpaKQr[0];sm_k4v50UutrvdChTHBxBrg_s[
sm_FkoBKJSu3bdQdPWZgD2fC8][1]=sm__5oub5Bfq9_j_LMNrpaKQr[1];
sm_k4v50UutrvdChTHBxBrg_s[sm_FkoBKJSu3bdQdPWZgD2fC8][2]=
sm__5oub5Bfq9_j_LMNrpaKQr[2];sm__ggmggh__aKLe9WMDN7tHF=
sm_Vrk3Pgb1wrhnZmcOkBtvtB;}}++sm_FkoBKJSu3bdQdPWZgD2fC8;}{const size_t
sm_kRk_3zNNz10aXT6ExNw6fs[4][3]={{3,2,1},{2,3,0},{1,0,3},{0,1,2}};for(
sm__1eAP9V6_J_NYm_1gTIm7A=0;sm__1eAP9V6_J_NYm_1gTIm7A<4;++
sm__1eAP9V6_J_NYm_1gTIm7A){sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if
=sm__gLX_E3mfsWCgLgXZERZ67+sm__1eAP9V6_J_NYm_1gTIm7A;memcpy(
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s,sm_kRk_3zNNz10aXT6ExNw6fs
[sm__1eAP9V6_J_NYm_1gTIm7A],3*sizeof(size_t));memcpy(sm__hj2_lou4YpDgPeaVq55if
->sm_kF_fYTSA5k8nXXjCcUgJvI,sm_kRk_3zNNz10aXT6ExNw6fs[
sm__1eAP9V6_J_NYm_1gTIm7A],3*sizeof(size_t));sm_k1PHMJqlP1lZVyqfXgjI6w(
sm__hj2_lou4YpDgPeaVq55if,(const sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])
sm_k4v50UutrvdChTHBxBrg_s,false);}}sm_VncVT15Kdj8bbLIO2xc9Xi=false;
sm_k06eY_2SxAxF_PegVRm_aY=0.0;for(sm__1eAP9V6_J_NYm_1gTIm7A=0;
sm__1eAP9V6_J_NYm_1gTIm7A<4;++sm__1eAP9V6_J_NYm_1gTIm7A){const real_T
sm_Vrk3Pgb1wrhnZmcOkBtvtB=sm__gLX_E3mfsWCgLgXZERZ67[sm__1eAP9V6_J_NYm_1gTIm7A]
.sm_VPoUbJUlYg0WaXdmtt1Huf;const real_T sm__rd1qxo_uixygTVW9li2Kf=fabs(
sm_Vrk3Pgb1wrhnZmcOkBtvtB);if(sm__rd1qxo_uixygTVW9li2Kf>
sm_k06eY_2SxAxF_PegVRm_aY){sm_k06eY_2SxAxF_PegVRm_aY=sm__rd1qxo_uixygTVW9li2Kf
;sm_VncVT15Kdj8bbLIO2xc9Xi=sm_Vrk3Pgb1wrhnZmcOkBtvtB>0.0;}}if(
sm_VncVT15Kdj8bbLIO2xc9Xi)for(sm__1eAP9V6_J_NYm_1gTIm7A=0;
sm__1eAP9V6_J_NYm_1gTIm7A<4;++sm__1eAP9V6_J_NYm_1gTIm7A){size_t
sm_Fk2O4u6vQUpibmbv8Kjgnn;sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if=
sm__gLX_E3mfsWCgLgXZERZ67+sm__1eAP9V6_J_NYm_1gTIm7A;pm_math_Vector3_negate(&
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V,&
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V);
sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf= -
sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf;sm_Fk2O4u6vQUpibmbv8Kjgnn
=sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[1];
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[1]=
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[2];
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s[2]=
sm_Fk2O4u6vQUpibmbv8Kjgnn;sm_Fk2O4u6vQUpibmbv8Kjgnn=sm__hj2_lou4YpDgPeaVq55if
->sm_kF_fYTSA5k8nXXjCcUgJvI[1];sm__hj2_lou4YpDgPeaVq55if->
sm_kF_fYTSA5k8nXXjCcUgJvI[1]=sm__hj2_lou4YpDgPeaVq55if->
sm_kF_fYTSA5k8nXXjCcUgJvI[2];sm__hj2_lou4YpDgPeaVq55if->
sm_kF_fYTSA5k8nXXjCcUgJvI[2]=sm_Fk2O4u6vQUpibmbv8Kjgnn;}for(
sm__1eAP9V6_J_NYm_1gTIm7A=0;sm__1eAP9V6_J_NYm_1gTIm7A<4;++
sm__1eAP9V6_J_NYm_1gTIm7A)sm__OFp2fUjZ3KsZX6V5Ghsmm(sm__gLX_E3mfsWCgLgXZERZ67,
sm__1eAP9V6_J_NYm_1gTIm7A,sm_FRpeUPAgV4_aZXdZVkJHXU);}static size_t
sm__6vX0IJAdc_UjTp93HzEvk(const sm_Vl_xbimdXv_njqt81Wv_1g
sm__gLX_E3mfsWCgLgXZERZ67[],const sm__ywJxOdhydpFYT6CiTxXcf*
sm_FRpeUPAgV4_aZXdZVkJHXU,const sm_kd__PjR5tCWObue2RSyCuW*
sm__7tYjX5coPSHiXFIj_LkVZ,size_t sm_kd9rqmuOKk0WjmS1BcYcbM[]){const size_t*
sm_FFs4s1wSqB44YDRmAy0PsL=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL
;size_t sm__oqQ_qIxXF4SWDpvOBksSr=0;const real_T sm_V_cqcJaAbF8FZm3a__044p=
sm__gLX_E3mfsWCgLgXZERZ67[sm_FFs4s1wSqB44YDRmAy0PsL[1]].
sm_VPoUbJUlYg0WaXdmtt1Huf;const real_T sm_kd1Plhqj0HK8XLfhRAQVsc=
sm_V3qf5IfM7RdaZDwMstW9pg(sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU)
;const real_T sm_kdgpOTyUDs8jieGZdzY2Hb=sm_V_cqcJaAbF8FZm3a__044p-1.0e-8*(
sm_V_cqcJaAbF8FZm3a__044p-sm_kd1Plhqj0HK8XLfhRAQVsc);sm__oqQ_qIxXF4SWDpvOBksSr
=sm_FAk8k9WhquCzeLssuMr2Hq(sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU
,sm_kdgpOTyUDs8jieGZdzY2Hb,sm_kd9rqmuOKk0WjmS1BcYcbM);if(
sm__oqQ_qIxXF4SWDpvOBksSr==0)sm_kd9rqmuOKk0WjmS1BcYcbM[
sm__oqQ_qIxXF4SWDpvOBksSr++]=1;if(sm__7tYjX5coPSHiXFIj_LkVZ!=0){size_t
sm_kwrB3ZoKf7OufTHWaHJV7a;size_t*src,*dst;real_T sm_FfDTppU8N_tOWuLK37x_08;
real_T sm_VmXeCXgOHt4Wa9ZhwNu69v= -1.0e100;src=sm_kd9rqmuOKk0WjmS1BcYcbM;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<
sm__oqQ_qIxXF4SWDpvOBksSr;++sm_kwrB3ZoKf7OufTHWaHJV7a,++src){const real_T
sm_VEQsp_aoMC0UaaqSMZlIJV=pm_math_Vector3_dot(&sm__gLX_E3mfsWCgLgXZERZ67[
sm_FFs4s1wSqB44YDRmAy0PsL[*src]].sm_FSzIyLZpToGyYTlwh2NE5V,
sm__7tYjX5coPSHiXFIj_LkVZ);if(sm_VEQsp_aoMC0UaaqSMZlIJV>
sm_VmXeCXgOHt4Wa9ZhwNu69v)sm_VmXeCXgOHt4Wa9ZhwNu69v=sm_VEQsp_aoMC0UaaqSMZlIJV;
}sm_FfDTppU8N_tOWuLK37x_08=sm_VmXeCXgOHt4Wa9ZhwNu69v-1.0e-12;src=dst=
sm_kd9rqmuOKk0WjmS1BcYcbM;for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<sm__oqQ_qIxXF4SWDpvOBksSr;++
sm_kwrB3ZoKf7OufTHWaHJV7a,++src)if(pm_math_Vector3_dot(&
sm__gLX_E3mfsWCgLgXZERZ67[sm_FFs4s1wSqB44YDRmAy0PsL[*src]].
sm_FSzIyLZpToGyYTlwh2NE5V,sm__7tYjX5coPSHiXFIj_LkVZ)>sm_FfDTppU8N_tOWuLK37x_08
)*dst++= *src;sm__oqQ_qIxXF4SWDpvOBksSr=dst-sm_kd9rqmuOKk0WjmS1BcYcbM;}
sm_kHH_TPMqcAGe_qmFkTpnMl(sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU,
sm__oqQ_qIxXF4SWDpvOBksSr,sm_kd9rqmuOKk0WjmS1BcYcbM);return
sm__oqQ_qIxXF4SWDpvOBksSr;}static void sm__11l1iasF6xBjHH8AvfTqN(
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],size_t
sm_kbu8w0vYuX8_dHRq2Pe2Dw,size_t sm_Vs6xonQX17Krc5vXv8T_zq,const
sm_kd__PjR5tCWObue2RSyCuW sm_k4v50UutrvdChTHBxBrg_s[][3],const
sm_kd__PjR5tCWObue2RSyCuW*sm_FhIvn_jcZgK7aaaEhUlMPj){size_t
sm__wN5g_p_uwdVVLfRtx9szc;sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if;
sm_kd__PjR5tCWObue2RSyCuW*sm_FSzIyLZpToGyYTlwh2NE5V;real_T
sm_kN8Vg2U3TlCdWLFYLCHy_u=1.0e-15;for(sm__wN5g_p_uwdVVLfRtx9szc=
sm_kbu8w0vYuX8_dHRq2Pe2Dw;sm__wN5g_p_uwdVVLfRtx9szc<sm_Vs6xonQX17Krc5vXv8T_zq;
++sm__wN5g_p_uwdVVLfRtx9szc){sm__hj2_lou4YpDgPeaVq55if=
sm__gLX_E3mfsWCgLgXZERZ67+sm__wN5g_p_uwdVVLfRtx9szc;sm_FSzIyLZpToGyYTlwh2NE5V=
&sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V;
sm__hj2_lou4YpDgPeaVq55if->sm__c5XrFgUwWKogTUJHqQfJg=false;if(
sm_FSzIyLZpToGyYTlwh2NE5V->x==0.0&&sm_FSzIyLZpToGyYTlwh2NE5V->
sm_FzyLWRgau0pMYq2XSI3ETL==0.0&&sm_FSzIyLZpToGyYTlwh2NE5V->
sm_FBDi_PCg670TjHgJTNPcHr==0.0){sm__hj2_lou4YpDgPeaVq55if->
sm__c5XrFgUwWKogTUJHqQfJg=true;*sm_FSzIyLZpToGyYTlwh2NE5V= *
sm_FhIvn_jcZgK7aaaEhUlMPj;sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf
= -1.0e100;}}}static real_T sm_VMzqAkdT_UtugHaeRZPRBG(int
sm_kEhNFwUz1NOuj5cSj5dOF7,const size_t sm__FuzaKmDsvhreiSobFRgkV[3],const
sm_kd__PjR5tCWObue2RSyCuW sm_k4v50UutrvdChTHBxBrg_s[][3],const real_T
sm_k7RVes5oHPO2Yi5DMSKkeo[3]){real_T sm_VYECQNj31_8jcmIurRArPD;const
sm_kd__PjR5tCWObue2RSyCuW*sm__AuaKMC5koOPbXxPi_MZvt= &
sm_k4v50UutrvdChTHBxBrg_s[sm__FuzaKmDsvhreiSobFRgkV[0]][
sm_kEhNFwUz1NOuj5cSj5dOF7];const sm_kd__PjR5tCWObue2RSyCuW*
sm_kNtPmLll5l8eiqwtk5kfJv= &sm_k4v50UutrvdChTHBxBrg_s[
sm__FuzaKmDsvhreiSobFRgkV[1]][sm_kEhNFwUz1NOuj5cSj5dOF7];const
sm_kd__PjR5tCWObue2RSyCuW*sm__V7yhs3oelG7WqyGLN1Wqz= &
sm_k4v50UutrvdChTHBxBrg_s[sm__FuzaKmDsvhreiSobFRgkV[2]][
sm_kEhNFwUz1NOuj5cSj5dOF7];if(sm__oPrRWZb_p0tbD5Lt0Lq4Z(
sm__AuaKMC5koOPbXxPi_MZvt,sm_kNtPmLll5l8eiqwtk5kfJv)){if(
sm__oPrRWZb_p0tbD5Lt0Lq4Z(sm__AuaKMC5koOPbXxPi_MZvt,sm__V7yhs3oelG7WqyGLN1Wqz)
)sm_VYECQNj31_8jcmIurRArPD=0.0;else sm_VYECQNj31_8jcmIurRArPD=
sm_k7RVes5oHPO2Yi5DMSKkeo[2]<0.5?-sm_k7RVes5oHPO2Yi5DMSKkeo[2]:(
sm_k7RVes5oHPO2Yi5DMSKkeo[2]-1.0);}else{if(sm__oPrRWZb_p0tbD5Lt0Lq4Z(
sm__AuaKMC5koOPbXxPi_MZvt,sm__V7yhs3oelG7WqyGLN1Wqz))sm_VYECQNj31_8jcmIurRArPD
=sm_k7RVes5oHPO2Yi5DMSKkeo[1]<0.5?-sm_k7RVes5oHPO2Yi5DMSKkeo[1]:(
sm_k7RVes5oHPO2Yi5DMSKkeo[1]-1.0);else{if(sm__oPrRWZb_p0tbD5Lt0Lq4Z(
sm_kNtPmLll5l8eiqwtk5kfJv,sm__V7yhs3oelG7WqyGLN1Wqz))sm_VYECQNj31_8jcmIurRArPD
=sm_k7RVes5oHPO2Yi5DMSKkeo[0]<0.5?-sm_k7RVes5oHPO2Yi5DMSKkeo[0]:(
sm_k7RVes5oHPO2Yi5DMSKkeo[0]-1.0);else{real_T sm_FvkP8MLE04OAbiOHNtsqNn,
sm__D1y07gUN0xPgeisx_r1jL,sm_kwuavsPDW6W7jynMhTxXlq,sm_FjKHOzaAcKlReHdAyuoypA;
if(sm_k7RVes5oHPO2Yi5DMSKkeo[0]<sm_k7RVes5oHPO2Yi5DMSKkeo[1]){if(
sm_k7RVes5oHPO2Yi5DMSKkeo[1]<sm_k7RVes5oHPO2Yi5DMSKkeo[2])
sm_FvkP8MLE04OAbiOHNtsqNn=sm_k7RVes5oHPO2Yi5DMSKkeo[0],
sm__D1y07gUN0xPgeisx_r1jL=sm_k7RVes5oHPO2Yi5DMSKkeo[2];else{
sm_FvkP8MLE04OAbiOHNtsqNn=(sm_k7RVes5oHPO2Yi5DMSKkeo[0]<
sm_k7RVes5oHPO2Yi5DMSKkeo[2])?sm_k7RVes5oHPO2Yi5DMSKkeo[0]:
sm_k7RVes5oHPO2Yi5DMSKkeo[2];sm__D1y07gUN0xPgeisx_r1jL=
sm_k7RVes5oHPO2Yi5DMSKkeo[1];}}else{if(sm_k7RVes5oHPO2Yi5DMSKkeo[0]<
sm_k7RVes5oHPO2Yi5DMSKkeo[2])sm_FvkP8MLE04OAbiOHNtsqNn=
sm_k7RVes5oHPO2Yi5DMSKkeo[1],sm__D1y07gUN0xPgeisx_r1jL=
sm_k7RVes5oHPO2Yi5DMSKkeo[2];else{sm_FvkP8MLE04OAbiOHNtsqNn=(
sm_k7RVes5oHPO2Yi5DMSKkeo[1]<sm_k7RVes5oHPO2Yi5DMSKkeo[2])?
sm_k7RVes5oHPO2Yi5DMSKkeo[1]:sm_k7RVes5oHPO2Yi5DMSKkeo[2];
sm__D1y07gUN0xPgeisx_r1jL=sm_k7RVes5oHPO2Yi5DMSKkeo[0];}}
sm_kwuavsPDW6W7jynMhTxXlq= -sm_FvkP8MLE04OAbiOHNtsqNn;
sm_FjKHOzaAcKlReHdAyuoypA=sm__D1y07gUN0xPgeisx_r1jL-1.0;
sm_VYECQNj31_8jcmIurRArPD=sm_kwuavsPDW6W7jynMhTxXlq>sm_FjKHOzaAcKlReHdAyuoypA?
sm_kwuavsPDW6W7jynMhTxXlq:sm_FjKHOzaAcKlReHdAyuoypA;}}}return
sm_VYECQNj31_8jcmIurRArPD>0.0?sm_VYECQNj31_8jcmIurRArPD:0.0;}static const
sm_Vl_xbimdXv_njqt81Wv_1g*sm_VgYc13oQoDGPYHM76GCX_n(const
sm_Vl_xbimdXv_njqt81Wv_1g sm__gLX_E3mfsWCgLgXZERZ67[],const
sm__ywJxOdhydpFYT6CiTxXcf*sm_FRpeUPAgV4_aZXdZVkJHXU,const
sm_kd__PjR5tCWObue2RSyCuW*sm__7tYjX5coPSHiXFIj_LkVZ,const
sm_kd__PjR5tCWObue2RSyCuW sm_k4v50UutrvdChTHBxBrg_s[][3],boolean_T
sm__onsZLH_ytSGhXn0uJU7bM,real_T*sm_Vrk3Pgb1wrhnZmcOkBtvtB,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kburdpU0IjpOXyPmyulx88){size_t sm_kwrB3ZoKf7OufTHWaHJV7a,
sm__1eAP9V6_J_NYm_1gTIm7A,sm__DG85fEYfJdgimqY5QnRID;size_t
sm_kd9rqmuOKk0WjmS1BcYcbM[256];const size_t*sm_kRk_3zNNz10aXT6ExNw6fs;real_T
sm__ggmggh__aKLe9WMDN7tHF,sm_k7RVes5oHPO2Yi5DMSKkeo[3]={0.0,0.0,0.0};const
sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if;const size_t*
sm_FFs4s1wSqB44YDRmAy0PsL=sm_FRpeUPAgV4_aZXdZVkJHXU->sm_FFs4s1wSqB44YDRmAy0PsL
;size_t sm__oqQ_qIxXF4SWDpvOBksSr=sm__6vX0IJAdc_UjTp93HzEvk(
sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU,sm__7tYjX5coPSHiXFIj_LkVZ,
sm_kd9rqmuOKk0WjmS1BcYcbM);if(sm__oqQ_qIxXF4SWDpvOBksSr==0){if((0>=(1)&&true))
pmf_printf("EPA fault: no appropriate final triangles\n");
sm__6vX0IJAdc_UjTp93HzEvk(sm__gLX_E3mfsWCgLgXZERZ67,sm_FRpeUPAgV4_aZXdZVkJHXU,
0,sm_kd9rqmuOKk0WjmS1BcYcbM);}(void)0;;if((0>=(4)&&true)){pmf_printf(
"Candidate final triangles:");for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<sm__oqQ_qIxXF4SWDpvOBksSr;++
sm_kwrB3ZoKf7OufTHWaHJV7a)pmf_printf(" %d",sm_kd9rqmuOKk0WjmS1BcYcbM[
sm_kwrB3ZoKf7OufTHWaHJV7a]);pmf_printf("\n");}sm__ggmggh__aKLe9WMDN7tHF= +
1.0e100;sm__DG85fEYfJdgimqY5QnRID=((size_t)-1);for(sm__1eAP9V6_J_NYm_1gTIm7A=0
;sm__1eAP9V6_J_NYm_1gTIm7A<sm__oqQ_qIxXF4SWDpvOBksSr;++
sm__1eAP9V6_J_NYm_1gTIm7A){real_T sm_k2rBvYf4GrluheEz1UyRIS,
sm_V2gaCcmolT86ZPCGVEUO_9,sm_VYECQNj31_8jcmIurRArPD,sm_k5iiHLlORl0BgHk0uNfg7_[
3];const sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if=
sm__gLX_E3mfsWCgLgXZERZ67+sm_FFs4s1wSqB44YDRmAy0PsL[sm_kd9rqmuOKk0WjmS1BcYcbM[
sm__1eAP9V6_J_NYm_1gTIm7A]];sm_kd__PjR5tCWObue2RSyCuW sm_kTPl1hFg3FlqYPkMHb9cFR
;if((0>=(3)&&true))if(sm__1eAP9V6_J_NYm_1gTIm7A>0)pmf_printf(
"Fallback loop for lambda: Take %d\n",sm__1eAP9V6_J_NYm_1gTIm7A);
pm_math_Vector3_scale(&sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V,-
sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf,&
sm_kTPl1hFg3FlqYPkMHb9cFR);sm__ezYf2_O17_XfyBQ3_mD2L(sm__hj2_lou4YpDgPeaVq55if
,sm_k4v50UutrvdChTHBxBrg_s,&sm_kTPl1hFg3FlqYPkMHb9cFR,
sm_k5iiHLlORl0BgHk0uNfg7_);sm_k2rBvYf4GrluheEz1UyRIS=sm_VMzqAkdT_UtugHaeRZPRBG
(0,sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s,
sm_k4v50UutrvdChTHBxBrg_s,sm_k5iiHLlORl0BgHk0uNfg7_);sm_V2gaCcmolT86ZPCGVEUO_9
=sm_VMzqAkdT_UtugHaeRZPRBG(1,sm__hj2_lou4YpDgPeaVq55if->
sm_k4v50UutrvdChTHBxBrg_s,sm_k4v50UutrvdChTHBxBrg_s,sm_k5iiHLlORl0BgHk0uNfg7_)
;sm_VYECQNj31_8jcmIurRArPD=sm_k2rBvYf4GrluheEz1UyRIS>sm_V2gaCcmolT86ZPCGVEUO_9
?sm_k2rBvYf4GrluheEz1UyRIS:sm_V2gaCcmolT86ZPCGVEUO_9;if(
sm_VYECQNj31_8jcmIurRArPD<sm__ggmggh__aKLe9WMDN7tHF){memcpy(
sm_k7RVes5oHPO2Yi5DMSKkeo,sm_k5iiHLlORl0BgHk0uNfg7_,3*sizeof(real_T));if(
sm_VYECQNj31_8jcmIurRArPD<1.0e-12)break;sm__ggmggh__aKLe9WMDN7tHF=
sm_VYECQNj31_8jcmIurRArPD;sm__DG85fEYfJdgimqY5QnRID=sm__1eAP9V6_J_NYm_1gTIm7A;
}if((0>=(3)&&true))pmf_printf(
"Invalid lambda values: [%+19.12e, %+19.12e, %+19.12e]\n",
sm_k7RVes5oHPO2Yi5DMSKkeo[0],sm_k7RVes5oHPO2Yi5DMSKkeo[1],
sm_k7RVes5oHPO2Yi5DMSKkeo[2]);}if(sm__1eAP9V6_J_NYm_1gTIm7A==
sm__oqQ_qIxXF4SWDpvOBksSr){sm__1eAP9V6_J_NYm_1gTIm7A=sm__DG85fEYfJdgimqY5QnRID
;if((0>=(3)&&true))pmf_printf(
"Could not find valid lambda; using best found.\n");}if((0>=(3)&&true))
pmf_printf("lambda = [%+19.12e, %+19.12e, %+19.12e]'\n",
sm_k7RVes5oHPO2Yi5DMSKkeo[0],sm_k7RVes5oHPO2Yi5DMSKkeo[1],
sm_k7RVes5oHPO2Yi5DMSKkeo[2]);sm__hj2_lou4YpDgPeaVq55if=
sm__gLX_E3mfsWCgLgXZERZ67+sm_FFs4s1wSqB44YDRmAy0PsL[sm_kd9rqmuOKk0WjmS1BcYcbM[
sm__1eAP9V6_J_NYm_1gTIm7A]];*sm_Vrk3Pgb1wrhnZmcOkBtvtB=
sm__hj2_lou4YpDgPeaVq55if->sm_VPoUbJUlYg0WaXdmtt1Huf;if(!
sm__onsZLH_ytSGhXn0uJU7bM){sm_kd__PjR5tCWObue2RSyCuW sm_F1LfOOnBFbpFWi7QXSZyNj
;sm_kRk_3zNNz10aXT6ExNw6fs=sm__hj2_lou4YpDgPeaVq55if->
sm_k4v50UutrvdChTHBxBrg_s;pm_math_Vector3_scale(&sm_k4v50UutrvdChTHBxBrg_s[
sm_kRk_3zNNz10aXT6ExNw6fs[0]][0],sm_k7RVes5oHPO2Yi5DMSKkeo[0],
sm_kSBaR7c6O38sa5ZMZ1k4Y1);pm_math_Vector3_scale(&sm_k4v50UutrvdChTHBxBrg_s[
sm_kRk_3zNNz10aXT6ExNw6fs[1]][0],sm_k7RVes5oHPO2Yi5DMSKkeo[1],&
sm_F1LfOOnBFbpFWi7QXSZyNj);pm_math_Vector3_add(sm_kSBaR7c6O38sa5ZMZ1k4Y1,&
sm_F1LfOOnBFbpFWi7QXSZyNj,sm_kSBaR7c6O38sa5ZMZ1k4Y1);pm_math_Vector3_scale(&
sm_k4v50UutrvdChTHBxBrg_s[sm_kRk_3zNNz10aXT6ExNw6fs[2]][0],
sm_k7RVes5oHPO2Yi5DMSKkeo[2],&sm_F1LfOOnBFbpFWi7QXSZyNj);pm_math_Vector3_add(
sm_kSBaR7c6O38sa5ZMZ1k4Y1,&sm_F1LfOOnBFbpFWi7QXSZyNj,sm_kSBaR7c6O38sa5ZMZ1k4Y1
);pm_math_Vector3_scale(&sm_k4v50UutrvdChTHBxBrg_s[sm_kRk_3zNNz10aXT6ExNw6fs[0
]][1],sm_k7RVes5oHPO2Yi5DMSKkeo[0],sm_kburdpU0IjpOXyPmyulx88);
pm_math_Vector3_scale(&sm_k4v50UutrvdChTHBxBrg_s[sm_kRk_3zNNz10aXT6ExNw6fs[1]]
[1],sm_k7RVes5oHPO2Yi5DMSKkeo[1],&sm_F1LfOOnBFbpFWi7QXSZyNj);
pm_math_Vector3_add(sm_kburdpU0IjpOXyPmyulx88,&sm_F1LfOOnBFbpFWi7QXSZyNj,
sm_kburdpU0IjpOXyPmyulx88);pm_math_Vector3_scale(&sm_k4v50UutrvdChTHBxBrg_s[
sm_kRk_3zNNz10aXT6ExNw6fs[2]][1],sm_k7RVes5oHPO2Yi5DMSKkeo[2],&
sm_F1LfOOnBFbpFWi7QXSZyNj);pm_math_Vector3_add(sm_kburdpU0IjpOXyPmyulx88,&
sm_F1LfOOnBFbpFWi7QXSZyNj,sm_kburdpU0IjpOXyPmyulx88);}if((0>=(2)&&true)){char
sm_VGqPwlpTl6K0jeyUcOcudU[512];sm_F8eCImOfeYKdZuMlfsHdDH(
sm_k4v50UutrvdChTHBxBrg_s,0,3,sm__hj2_lou4YpDgPeaVq55if->
sm_k4v50UutrvdChTHBxBrg_s,sm_k7RVes5oHPO2Yi5DMSKkeo,sm_VGqPwlpTl6K0jeyUcOcudU)
;pmf_printf("Feature 0: %s\n",sm_VGqPwlpTl6K0jeyUcOcudU);
sm_F8eCImOfeYKdZuMlfsHdDH(sm_k4v50UutrvdChTHBxBrg_s,1,3,
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s,sm_k7RVes5oHPO2Yi5DMSKkeo
,sm_VGqPwlpTl6K0jeyUcOcudU);pmf_printf("Feature 1: %s\n",
sm_VGqPwlpTl6K0jeyUcOcudU);}return sm__hj2_lou4YpDgPeaVq55if;}void
sm__RvG5_uvnj_NXD47YN1yTH(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,boolean_T
sm__onsZLH_ytSGhXn0uJU7bM,sm_FJDxOUSymMGic5lC7ZhrnL sm_k4v50UutrvdChTHBxBrg_s[
][3],int sm_FOdkmT7jBb4LcqK4Pu9cA3,size_t sm__EedT3_mashziDALw8GyU4[3],real_T*
sm_Vrk3Pgb1wrhnZmcOkBtvtB,sm_FJDxOUSymMGic5lC7ZhrnL*sm_kSBaR7c6O38sa5ZMZ1k4Y1,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kburdpU0IjpOXyPmyulx88){int
sm_FFsuQCG7t_tPjLkBG5xyTx;size_t sm_FMkwQ2uWuP8JdPHhRP1eS3=0;size_t
sm_FkoBKJSu3bdQdPWZgD2fC8;size_t sm_kwrB3ZoKf7OufTHWaHJV7a,
sm__oqQ_qIxXF4SWDpvOBksSr;size_t sm_kd9rqmuOKk0WjmS1BcYcbM[256];size_t
sm___H_Vw_r57hziPhWiXl2ud,sm__TuFaMjDjcGrc9NFFj_gCl,sm_VDtdA5Cgum0ug5N24ue1ge;
boolean_T sm_V2rG8ddjf3CyaD7Vytqu7d;boolean_T sm_FFjhhaat7SpAcD3Nm9hD2N;const
sm_kd__PjR5tCWObue2RSyCuW*sm__7tYjX5coPSHiXFIj_LkVZ;sm_Vl_xbimdXv_njqt81Wv_1g
sm__gLX_E3mfsWCgLgXZERZ67[256];sm__ywJxOdhydpFYT6CiTxXcf
sm_FRpeUPAgV4_aZXdZVkJHXU;const size_t*sm_FFs4s1wSqB44YDRmAy0PsL=
sm_FRpeUPAgV4_aZXdZVkJHXU.sm_FFs4s1wSqB44YDRmAy0PsL;const
sm_Vl_xbimdXv_njqt81Wv_1g*sm__hj2_lou4YpDgPeaVq55if;size_t
sm_koPVBBTj_5hpZPsGz6Whts[256];size_t sm__X_CJb3g7COKXuUC2NKBlt[2*256];size_t
sm__JbiCKKNwu0mamlU_2Ci91,sm_VaqYtNtmexdSemnwI3eeJT;sm_FkoBKJSu3bdQdPWZgD2fC8=
sm_VQ0A0Sv5GWprb1MDSztvuk[sm_FOdkmT7jBb4LcqK4Pu9cA3];{const size_t*
sm__mNZl3Dws0SzjmkHXP_BQz=sm_k2PuWUcQ_UtHYDFpzYchpd[sm_FOdkmT7jBb4LcqK4Pu9cA3]
;int sm_kyp6uAyJE40UVuAQNEYzS1;for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<sm_FkoBKJSu3bdQdPWZgD2fC8;++
sm_kwrB3ZoKf7OufTHWaHJV7a)for(sm_kyp6uAyJE40UVuAQNEYzS1=0;
sm_kyp6uAyJE40UVuAQNEYzS1<3;++sm_kyp6uAyJE40UVuAQNEYzS1)
sm_k4v50UutrvdChTHBxBrg_s[sm_kwrB3ZoKf7OufTHWaHJV7a][sm_kyp6uAyJE40UVuAQNEYzS1
]=sm_k4v50UutrvdChTHBxBrg_s[sm__mNZl3Dws0SzjmkHXP_BQz[
sm_kwrB3ZoKf7OufTHWaHJV7a]][sm_kyp6uAyJE40UVuAQNEYzS1];}
sm__o0m82DpcY_EWyoGrL5QqD(&sm_FRpeUPAgV4_aZXdZVkJHXU);if((0>=(3)&&true))
pmf_printf("Computing initial polytope\n");sm_VeMO3LYTXd0WjH3rzZ_rea(
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,sm_F4kGV66idSlLj12YnANYlJ,
sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_k4v50UutrvdChTHBxBrg_s,sm_FkoBKJSu3bdQdPWZgD2fC8,sm__gLX_E3mfsWCgLgXZERZ67,
&sm_FRpeUPAgV4_aZXdZVkJHXU);sm_FkoBKJSu3bdQdPWZgD2fC8=4;
sm__7tYjX5coPSHiXFIj_LkVZ=0;sm_V2rG8ddjf3CyaD7Vytqu7d=false;
sm_FFjhhaat7SpAcD3Nm9hD2N=false;for(sm_FFsuQCG7t_tPjLkBG5xyTx=0;
sm_FFsuQCG7t_tPjLkBG5xyTx<100&&!sm_V2rG8ddjf3CyaD7Vytqu7d&&!
sm_FFjhhaat7SpAcD3Nm9hD2N;++sm_FFsuQCG7t_tPjLkBG5xyTx){size_t
sm__1eAP9V6_J_NYm_1gTIm7A,sm_kCOapU_4YFS8def05Sea5i;double
sm__ggmggh__aKLe9WMDN7tHF;if((0>=(2)&&true)){pmf_printf("EPA loop %d\n\n",
sm_FFsuQCG7t_tPjLkBG5xyTx+1);if((0>=(3)&&true)){sm_kiB3Db7ZfZd8f9Vi_wl6s9((
const sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])sm_k4v50UutrvdChTHBxBrg_s,
sm_FkoBKJSu3bdQdPWZgD2fC8);pmf_printf("\n");sm_Fyjicail5idk_HymzkTyHM(
sm__gLX_E3mfsWCgLgXZERZ67,&sm_FRpeUPAgV4_aZXdZVkJHXU);pmf_printf("\n");}}if(
sm_FRpeUPAgV4_aZXdZVkJHXU.sm_Vs6xonQX17Krc5vXv8T_zq>sm_FMkwQ2uWuP8JdPHhRP1eS3)
sm_FMkwQ2uWuP8JdPHhRP1eS3=sm_FRpeUPAgV4_aZXdZVkJHXU.sm_Vs6xonQX17Krc5vXv8T_zq;
sm__oqQ_qIxXF4SWDpvOBksSr=sm__6vX0IJAdc_UjTp93HzEvk(sm__gLX_E3mfsWCgLgXZERZ67,
&sm_FRpeUPAgV4_aZXdZVkJHXU,0,sm_kd9rqmuOKk0WjmS1BcYcbM);(void)0;;if((0>=(3)&&
true)){pmf_printf("Candidate expansion triangles:");for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<
sm__oqQ_qIxXF4SWDpvOBksSr;++sm_kwrB3ZoKf7OufTHWaHJV7a)pmf_printf(" %d",
sm_kd9rqmuOKk0WjmS1BcYcbM[sm_kwrB3ZoKf7OufTHWaHJV7a]);pmf_printf("\n");}
sm_kCOapU_4YFS8def05Sea5i=((size_t)-1);sm__ggmggh__aKLe9WMDN7tHF= +1.0e100;for
(sm__1eAP9V6_J_NYm_1gTIm7A=0;sm__1eAP9V6_J_NYm_1gTIm7A<=
sm__oqQ_qIxXF4SWDpvOBksSr;++sm__1eAP9V6_J_NYm_1gTIm7A){size_t
sm_FCMoPwLeYFCfherwNS2L8C,sm__Z7eXtpledWXV5NLKDQh86;real_T
sm___pJWrwdZE0xYuQX75hJzb,sm_FNpbtDhe3185ZP5CBxcCqz;const
sm_kd__PjR5tCWObue2RSyCuW*sm_FhIvn_jcZgK7aaaEhUlMPj;const
sm_kd__PjR5tCWObue2RSyCuW*sm_VVHOMuY8Vx4_WqfMmhCoVT;size_t
sm__e6aWNPeKg0EeeMfMFNBJA;sm_kd__PjR5tCWObue2RSyCuW*sm__ES3I_smAMxeWymFnmeiT3;
const size_t sm__e157Vy_TR8Daaj118luar=(sm__1eAP9V6_J_NYm_1gTIm7A<
sm__oqQ_qIxXF4SWDpvOBksSr)?sm_kd9rqmuOKk0WjmS1BcYcbM[sm__1eAP9V6_J_NYm_1gTIm7A
]:sm_kCOapU_4YFS8def05Sea5i;const sm_Vl_xbimdXv_njqt81Wv_1g*
sm__hj2_lou4YpDgPeaVq55if=sm__gLX_E3mfsWCgLgXZERZ67+sm_FFs4s1wSqB44YDRmAy0PsL[
sm__e157Vy_TR8Daaj118luar];if(sm__hj2_lou4YpDgPeaVq55if->
sm__c5XrFgUwWKogTUJHqQfJg)continue;sm_FhIvn_jcZgK7aaaEhUlMPj= &
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V;sm__e6aWNPeKg0EeeMfMFNBJA
=sm_FkoBKJSu3bdQdPWZgD2fC8++;sm__ES3I_smAMxeWymFnmeiT3=
sm_k4v50UutrvdChTHBxBrg_s[sm__e6aWNPeKg0EeeMfMFNBJA];sm_FFjhhaat7SpAcD3Nm9hD2N
=(sm_FkoBKJSu3bdQdPWZgD2fC8>1000);if(sm_FFjhhaat7SpAcD3Nm9hD2N){if((0>=(1)&&
true))pmf_printf("EPA fault: vertex array overflow\n");break;}
sm_kkIDwZB8zm4Pjyeyqv1cv5(sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,
sm_F4kGV66idSlLj12YnANYlJ,sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_FhIvn_jcZgK7aaaEhUlMPj,sm__ES3I_smAMxeWymFnmeiT3+
0,sm__ES3I_smAMxeWymFnmeiT3+1,sm__ES3I_smAMxeWymFnmeiT3+2);
sm_VVHOMuY8Vx4_WqfMmhCoVT=sm__ES3I_smAMxeWymFnmeiT3+2;
sm___pJWrwdZE0xYuQX75hJzb=sm__DJP6gbIXup3bTIE8pNaTu(sm__hj2_lou4YpDgPeaVq55if,
sm_VVHOMuY8Vx4_WqfMmhCoVT);if((0>=(3)&&true)){pmf_printf(
"Closest plane id:   %d%s\n",(sm__1eAP9V6_J_NYm_1gTIm7A<
sm__oqQ_qIxXF4SWDpvOBksSr)?sm_kd9rqmuOKk0WjmS1BcYcbM[sm__1eAP9V6_J_NYm_1gTIm7A
]:sm_kCOapU_4YFS8def05Sea5i,(sm__1eAP9V6_J_NYm_1gTIm7A<
sm__oqQ_qIxXF4SWDpvOBksSr)?"":"  [forced]");if((0>=(4)&&true)){pmf_printf(
"Support direction:  dir = [%+19.12e, %+19.12e, %+19.12e]'\n",
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V.x,
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V.sm_FzyLWRgau0pMYq2XSI3ETL
,sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V.
sm_FBDi_PCg670TjHgJTNPcHr);pmf_printf(
"New vertex %3d:     v   = [%+19.12e, %+19.12e, %+19.12e]'\n",
sm__e6aWNPeKg0EeeMfMFNBJA,sm_VVHOMuY8Vx4_WqfMmhCoVT->x,
sm_VVHOMuY8Vx4_WqfMmhCoVT->sm_FzyLWRgau0pMYq2XSI3ETL,sm_VVHOMuY8Vx4_WqfMmhCoVT
->sm_FBDi_PCg670TjHgJTNPcHr);}pmf_printf(
"Improvement:              %+19.12e\n\n",sm___pJWrwdZE0xYuQX75hJzb);}if(
sm___pJWrwdZE0xYuQX75hJzb<1.0e-12){sm__7tYjX5coPSHiXFIj_LkVZ= &
sm__hj2_lou4YpDgPeaVq55if->sm_FSzIyLZpToGyYTlwh2NE5V;sm_V2rG8ddjf3CyaD7Vytqu7d
=true;break;}sm_FNpbtDhe3185ZP5CBxcCqz= -sm___pJWrwdZE0xYuQX75hJzb*1.0e-8;
sm_VayBu4P1dZxueeEwnfoP9Y(sm__gLX_E3mfsWCgLgXZERZ67,&sm_FRpeUPAgV4_aZXdZVkJHXU
,sm_VVHOMuY8Vx4_WqfMmhCoVT,sm__e157Vy_TR8Daaj118luar,sm_FNpbtDhe3185ZP5CBxcCqz
,sm__X_CJb3g7COKXuUC2NKBlt,&sm__JbiCKKNwu0mamlU_2Ci91,
sm_koPVBBTj_5hpZPsGz6Whts,&sm_VaqYtNtmexdSemnwI3eeJT);if((0>=(4)&&true)){
size_t sm_k7hvALo420t2Wiw5UM_t_9=0;for(sm__Z7eXtpledWXV5NLKDQh86=1;
sm__Z7eXtpledWXV5NLKDQh86<sm_FRpeUPAgV4_aZXdZVkJHXU.sm_Vs6xonQX17Krc5vXv8T_zq;
++sm__Z7eXtpledWXV5NLKDQh86){const sm_Vl_xbimdXv_njqt81Wv_1g*
sm__hj2_lou4YpDgPeaVq55if=sm__gLX_E3mfsWCgLgXZERZ67+sm_FFs4s1wSqB44YDRmAy0PsL[
sm__Z7eXtpledWXV5NLKDQh86];const real_T sm_Vrk3Pgb1wrhnZmcOkBtvtB=
sm__DJP6gbIXup3bTIE8pNaTu(sm__hj2_lou4YpDgPeaVq55if,sm_VVHOMuY8Vx4_WqfMmhCoVT)
;const boolean_T sm__OzkgH72RfC6fyXyBVRREV=(sm_k7hvALo420t2Wiw5UM_t_9<
sm_VaqYtNtmexdSemnwI3eeJT&&sm__Z7eXtpledWXV5NLKDQh86==
sm_koPVBBTj_5hpZPsGz6Whts[sm_k7hvALo420t2Wiw5UM_t_9]);pmf_printf(
"Triangle %d dist: %+19.12e",sm__Z7eXtpledWXV5NLKDQh86,
sm_Vrk3Pgb1wrhnZmcOkBtvtB);if(sm__OzkgH72RfC6fyXyBVRREV){++
sm_k7hvALo420t2Wiw5UM_t_9;pmf_printf("  <== visible");}else if(
sm_Vrk3Pgb1wrhnZmcOkBtvtB>sm_FNpbtDhe3185ZP5CBxcCqz)pmf_printf(
"  <== unreachable");pmf_printf("\n");}}sm___H_Vw_r57hziPhWiXl2ud=
sm_FRpeUPAgV4_aZXdZVkJHXU.sm_Vs6xonQX17Krc5vXv8T_zq-1;
sm_VDtdA5Cgum0ug5N24ue1ge=sm___H_Vw_r57hziPhWiXl2ud;for(
sm_FCMoPwLeYFCfherwNS2L8C=0;sm_FCMoPwLeYFCfherwNS2L8C<
sm__JbiCKKNwu0mamlU_2Ci91;++sm_FCMoPwLeYFCfherwNS2L8C){const size_t
sm_FHx5gV_aJvhMfLNw3LhgFJ=sm__X_CJb3g7COKXuUC2NKBlt[sm_FCMoPwLeYFCfherwNS2L8C]
>>2;const size_t sm_VqvO6m2hxttkWiXZ0ty2MU=sm__X_CJb3g7COKXuUC2NKBlt[
sm_FCMoPwLeYFCfherwNS2L8C]&0x3;const size_t*sm_VRcuyE9xSDG2WPKRI_sho7=
sm__gLX_E3mfsWCgLgXZERZ67[sm_FHx5gV_aJvhMfLNw3LhgFJ].sm_k4v50UutrvdChTHBxBrg_s
;const size_t sm__AuaKMC5koOPbXxPi_MZvt=sm_VRcuyE9xSDG2WPKRI_sho7[
sm_VqvO6m2hxttkWiXZ0ty2MU>0?(sm_VqvO6m2hxttkWiXZ0ty2MU-1):2];const size_t
sm_kNtPmLll5l8eiqwtk5kfJv=sm_VRcuyE9xSDG2WPKRI_sho7[sm_VqvO6m2hxttkWiXZ0ty2MU<
2?(sm_VqvO6m2hxttkWiXZ0ty2MU+1):0];boolean_T sm_VxjJDZaNR3pMZDFQi2rnQW;
sm_Vl_xbimdXv_njqt81Wv_1g*sm__It2KXKUkvS2dXLDGkRWlk;sm_FFjhhaat7SpAcD3Nm9hD2N=
(sm_VDtdA5Cgum0ug5N24ue1ge+1>=256);if(sm_FFjhhaat7SpAcD3Nm9hD2N){if((0>=(1)&&
true))pmf_printf("EPA fault: triangle heap overflow (2)\n");break;}
sm__It2KXKUkvS2dXLDGkRWlk=sm__gLX_E3mfsWCgLgXZERZ67+sm_VDtdA5Cgum0ug5N24ue1ge
++;sm__It2KXKUkvS2dXLDGkRWlk->sm_k4v50UutrvdChTHBxBrg_s[0]=
sm__e6aWNPeKg0EeeMfMFNBJA;sm__It2KXKUkvS2dXLDGkRWlk->sm_k4v50UutrvdChTHBxBrg_s
[1]=sm__AuaKMC5koOPbXxPi_MZvt;sm__It2KXKUkvS2dXLDGkRWlk->
sm_k4v50UutrvdChTHBxBrg_s[2]=sm_kNtPmLll5l8eiqwtk5kfJv;if((0>=(4)&&true))
pmf_printf("Building triangle %d %d %d\n",sm__e6aWNPeKg0EeeMfMFNBJA,
sm__AuaKMC5koOPbXxPi_MZvt,sm_kNtPmLll5l8eiqwtk5kfJv);sm_VxjJDZaNR3pMZDFQi2rnQW
=sm_k1PHMJqlP1lZVyqfXgjI6w(sm__It2KXKUkvS2dXLDGkRWlk,(const
sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])sm_k4v50UutrvdChTHBxBrg_s,true);if((0>=(4)&&
true)){if(!sm_VxjJDZaNR3pMZDFQi2rnQW){pmf_printf(
"  Triangle is degenerate (geometrically 1-D or 0-D).\n");pmf_printf(
"  Triangle will not be considered for polytope expansion\n");}else pmf_printf
("  Plane:  [ %+9.6f  %+9.6f  %+9.6f    %+10.6f ]%s\n",
sm__It2KXKUkvS2dXLDGkRWlk->sm_FSzIyLZpToGyYTlwh2NE5V.x,
sm__It2KXKUkvS2dXLDGkRWlk->sm_FSzIyLZpToGyYTlwh2NE5V.sm_FzyLWRgau0pMYq2XSI3ETL
,sm__It2KXKUkvS2dXLDGkRWlk->sm_FSzIyLZpToGyYTlwh2NE5V.
sm_FBDi_PCg670TjHgJTNPcHr,sm__It2KXKUkvS2dXLDGkRWlk->sm_VPoUbJUlYg0WaXdmtt1Huf
,(sm__It2KXKUkvS2dXLDGkRWlk->sm_VPoUbJUlYg0WaXdmtt1Huf>0.0)?" <== bad plane":
"");}}if(sm_FFjhhaat7SpAcD3Nm9hD2N)break;sm__TuFaMjDjcGrc9NFFj_gCl=
sm_VDtdA5Cgum0ug5N24ue1ge;sm__11l1iasF6xBjHH8AvfTqN(sm__gLX_E3mfsWCgLgXZERZ67,
sm___H_Vw_r57hziPhWiXl2ud,sm__TuFaMjDjcGrc9NFFj_gCl,(const
sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])sm_k4v50UutrvdChTHBxBrg_s,
sm_FhIvn_jcZgK7aaaEhUlMPj);if(sm__oqQ_qIxXF4SWDpvOBksSr>1&&
sm__1eAP9V6_J_NYm_1gTIm7A<sm__oqQ_qIxXF4SWDpvOBksSr){real_T
sm_VYECQNj31_8jcmIurRArPD= -1.0e100;size_t sm_kwrB3ZoKf7OufTHWaHJV7a;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=sm___H_Vw_r57hziPhWiXl2ud;sm_kwrB3ZoKf7OufTHWaHJV7a
!=sm__TuFaMjDjcGrc9NFFj_gCl;++sm_kwrB3ZoKf7OufTHWaHJV7a){const real_T
sm_FQferGZUKft3_i5GvYy4Oy=sm__gLX_E3mfsWCgLgXZERZ67[sm_kwrB3ZoKf7OufTHWaHJV7a]
.sm_VPoUbJUlYg0WaXdmtt1Huf;if(sm_FQferGZUKft3_i5GvYy4Oy>
sm_VYECQNj31_8jcmIurRArPD)sm_VYECQNj31_8jcmIurRArPD=sm_FQferGZUKft3_i5GvYy4Oy;
}if(sm_VYECQNj31_8jcmIurRArPD>0.0){if((0>=(3)&&true))pmf_printf(
"Positive plane score %+13.6e ;"" keep looking for expansion triangles\n",
sm_VYECQNj31_8jcmIurRArPD);if(sm_VYECQNj31_8jcmIurRArPD<
sm__ggmggh__aKLe9WMDN7tHF){sm__ggmggh__aKLe9WMDN7tHF=sm_VYECQNj31_8jcmIurRArPD
;sm_kCOapU_4YFS8def05Sea5i=sm_kd9rqmuOKk0WjmS1BcYcbM[sm__1eAP9V6_J_NYm_1gTIm7A
];}continue;}}for(sm_FCMoPwLeYFCfherwNS2L8C=0;sm_FCMoPwLeYFCfherwNS2L8C<
sm__JbiCKKNwu0mamlU_2Ci91;++sm_FCMoPwLeYFCfherwNS2L8C){const size_t
sm_FCYTqwg6eo__j9JXcVBs_j=sm___H_Vw_r57hziPhWiXl2ud+sm_FCMoPwLeYFCfherwNS2L8C;
const size_t sm_FHx5gV_aJvhMfLNw3LhgFJ=sm__X_CJb3g7COKXuUC2NKBlt[
sm_FCMoPwLeYFCfherwNS2L8C]>>2;const size_t sm_VqvO6m2hxttkWiXZ0ty2MU=
sm__X_CJb3g7COKXuUC2NKBlt[sm_FCMoPwLeYFCfherwNS2L8C]&0x3;
sm_Vl_xbimdXv_njqt81Wv_1g*sm_kbSznaEVGLhB_Pj8IIG5Sd=sm__gLX_E3mfsWCgLgXZERZ67+
sm_FCYTqwg6eo__j9JXcVBs_j;sm_Vl_xbimdXv_njqt81Wv_1g*sm_VOhbVA4eOypgg5AizVgbrf=
sm__gLX_E3mfsWCgLgXZERZ67+sm_FHx5gV_aJvhMfLNw3LhgFJ;sm_kbSznaEVGLhB_Pj8IIG5Sd
->sm_kF_fYTSA5k8nXXjCcUgJvI[0]=sm_FHx5gV_aJvhMfLNw3LhgFJ;
sm_kbSznaEVGLhB_Pj8IIG5Sd->sm_kF_fYTSA5k8nXXjCcUgJvI[1]=(
sm_FCMoPwLeYFCfherwNS2L8C<sm__JbiCKKNwu0mamlU_2Ci91-1)?(
sm_FCYTqwg6eo__j9JXcVBs_j+1):sm___H_Vw_r57hziPhWiXl2ud;
sm_kbSznaEVGLhB_Pj8IIG5Sd->sm_kF_fYTSA5k8nXXjCcUgJvI[2]=(
sm_FCMoPwLeYFCfherwNS2L8C>0)?(sm_FCYTqwg6eo__j9JXcVBs_j-1):
sm__TuFaMjDjcGrc9NFFj_gCl-1;sm_VOhbVA4eOypgg5AizVgbrf->
sm_kF_fYTSA5k8nXXjCcUgJvI[sm_VqvO6m2hxttkWiXZ0ty2MU]=sm_FCYTqwg6eo__j9JXcVBs_j
;}sm_FQXR9HNwlZSNjqCTaKBulS(sm__gLX_E3mfsWCgLgXZERZ67,&
sm_FRpeUPAgV4_aZXdZVkJHXU,sm_koPVBBTj_5hpZPsGz6Whts,sm_VaqYtNtmexdSemnwI3eeJT)
;if((0>=(4)&&true))pmf_printf("%d triangles removed\n",
sm_VaqYtNtmexdSemnwI3eeJT);for(sm_kwrB3ZoKf7OufTHWaHJV7a=
sm___H_Vw_r57hziPhWiXl2ud;sm_kwrB3ZoKf7OufTHWaHJV7a<sm__TuFaMjDjcGrc9NFFj_gCl
&&!sm_FFjhhaat7SpAcD3Nm9hD2N;++sm_kwrB3ZoKf7OufTHWaHJV7a)
sm_FFjhhaat7SpAcD3Nm9hD2N=sm__OFp2fUjZ3KsZX6V5Ghsmm(sm__gLX_E3mfsWCgLgXZERZ67,
sm_kwrB3ZoKf7OufTHWaHJV7a,&sm_FRpeUPAgV4_aZXdZVkJHXU);if(
sm_FFjhhaat7SpAcD3Nm9hD2N)break;if((0>=(4)&&true))pmf_printf(
"%d triangles added\n",sm__TuFaMjDjcGrc9NFFj_gCl-sm___H_Vw_r57hziPhWiXl2ud);
sm_FFjhhaat7SpAcD3Nm9hD2N=(sm_FRpeUPAgV4_aZXdZVkJHXU.sm_Vs6xonQX17Krc5vXv8T_zq
==1);if(sm_FFjhhaat7SpAcD3Nm9hD2N){if((0>=(1)&&true))pmf_printf(
"EPA fault: empty triangle heap\n");break;}sm_ktKiesCnReWpd5co2v03eg(
sm__gLX_E3mfsWCgLgXZERZ67,&sm_FRpeUPAgV4_aZXdZVkJHXU,sm__TuFaMjDjcGrc9NFFj_gCl
);break;}}sm__hj2_lou4YpDgPeaVq55if=sm_VgYc13oQoDGPYHM76GCX_n(
sm__gLX_E3mfsWCgLgXZERZ67,&sm_FRpeUPAgV4_aZXdZVkJHXU,sm__7tYjX5coPSHiXFIj_LkVZ
,(const sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])sm_k4v50UutrvdChTHBxBrg_s,
sm__onsZLH_ytSGhXn0uJU7bM,sm_Vrk3Pgb1wrhnZmcOkBtvtB,sm_kSBaR7c6O38sa5ZMZ1k4Y1,
sm_kburdpU0IjpOXyPmyulx88);memcpy(sm__EedT3_mashziDALw8GyU4,
sm__hj2_lou4YpDgPeaVq55if->sm_k4v50UutrvdChTHBxBrg_s,3*sizeof(size_t));}
