#include "pm_std.h"
#include "math.h"
#include "stdio.h"
#include "string.h"
#include "pm_std.h"
struct sm_Va7rvzSwRbpB_iIiuSF8h_{real_T x;real_T sm_FzyLWRgau0pMYq2XSI3ETL;
real_T sm_FBDi_PCg670TjHgJTNPcHr;};typedef struct sm_Va7rvzSwRbpB_iIiuSF8h_
sm_FJDxOUSymMGic5lC7ZhrnL;struct sm_VQiPk6I_S_0teiYbT1MBSN{real_T
sm_FQferGZUKft3_i5GvYy4Oy;real_T x;real_T sm_FzyLWRgau0pMYq2XSI3ETL;real_T
sm_FBDi_PCg670TjHgJTNPcHr;};typedef struct sm_VQiPk6I_S_0teiYbT1MBSN
sm__3md8_onIiO6heiNB5D3_3;struct sm_k5mHxu1pFy4YaeyeIGf5bY{real_T
sm_V5gSkPeCSkdzZ1xMyj2v7U,sm__D1iFBxPf38RWiveIR1Iip,sm__hPet7vW5h0Zi1uUdLa_LW;
real_T sm_kdB_LoVum6OHeDEkf0n58b,sm__tdIR85BSYdzha7Mb8qhKj,
sm__WnakhFnl24_bX0NhL6CLW;real_T sm_FnXzm1MLmt04dPIhRbN5SW,
sm_VgeldyT0dAtjeHo3kvxpdi,sm_F3LgZdApwMGziTfUlk6dzB;};typedef struct
sm_k5mHxu1pFy4YaeyeIGf5bY sm_komYPTPtib40juqhd0nJcN;struct
sm__sD2GKinhS_qYTF_z8BajY{sm__3md8_onIiO6heiNB5D3_3 sm_VnD_HGFKVUOWdDAWvZhyEb;
sm_FJDxOUSymMGic5lC7ZhrnL sm_F32Ql82vv6pW_PYIdpkFQ0;};typedef struct
sm__sD2GKinhS_qYTF_z8BajY sm_k4kL9Om6RgxTZqdxJRM51B;struct
sm__CEhElfLt9_7aqLsGROeDF{sm_FJDxOUSymMGic5lC7ZhrnL sm_FN28mzn7A2hvYLPTU_L4bt;
sm_FJDxOUSymMGic5lC7ZhrnL sm_k61dA_LqfI4EY1W2W1B1mA;};typedef struct
sm__CEhElfLt9_7aqLsGROeDF sm_kNq2SpAav5tbb5Yx_VSirx;void pm_math_Vector3_add(
const sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_subtract(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_negate(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_scale(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,real_T
sm_FQferGZUKft3_i5GvYy4Oy,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Vector3_divide(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4);void
pm_math_Vector3_guardedDivide(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4);real_T
pm_math_Vector3_norm(const sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ
);void pm_math_Vector3_unit(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Vector3_guardedUnit(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;real_T pm_math_Vector3_dot(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kNtPmLll5l8eiqwtk5kfJv);void pm_math_Vector3_cross(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_compOrthogonalBasis(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_FJDxOUSymMGic5lC7ZhrnL*sm_kyp6uAyJE40UVuAQNEYzS1,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_V2__YrimeI4E_yWnhKofpy);void
pm_math_Quaternion_compose(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_composeInverse(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseCompose(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xform(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformI(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformJ(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformK(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXform(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformI(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformJ(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformK(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_Matrix3x3Ctor(const sm_komYPTPtib40juqhd0nJcN*
sm_FqUCZrSGGNOuePgRr82o_8,sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb)
;void pm_math_Matrix3x3_compose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_composeTranspose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_transposeCompose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_preCross(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_postCross(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_xform(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_transposeXform(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_QuaternionCtor(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_komYPTPtib40juqhd0nJcN*sm_FqUCZrSGGNOuePgRr82o_8)
;void pm_math_Matrix3x3_getValuesInColumns(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,double*sm_k4y8mv5uXzheZimBIk_n7I);void
pm_math_Transform3_compose(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_composeInverse(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseCompose(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDir(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kEbBObcYFIxUZ5_77V3CO_,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirI(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirJ(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirK(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDir(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kEbBObcYFIxUZ5_77V3CO_,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirI(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirJ(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirK(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformPoint(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
pm__lqjegyKuwStj56WZLiC_e,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformPoint(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
pm__lqjegyKuwStj56WZLiC_e,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_add(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_kNtPmLll5l8eiqwtk5kfJv,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_subtract(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_kNtPmLll5l8eiqwtk5kfJv,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_xform(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_VgJW5ZqpwPpuY1inYtaofQ,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_inverseXform(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_VgJW5ZqpwPpuY1inYtaofQ,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;typedef void(*sm__jsfq5ol9RO0emwniHUfEG)(const void*sm__MiFOMZ9U7lUWXDyYwo58p
,const sm_FJDxOUSymMGic5lC7ZhrnL*sm_F9yDQxbxjNlSeXydMwl6yG,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__rAKhgz20O_KVajkn1H7GD);boolean_T
sm_core_compiler_computeSignedDistanceConvexConvex(const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,real_T sm_kHfMSiCBJRSoju34wwOKOx,real_T*
sm_Vrk3Pgb1wrhnZmcOkBtvtB);boolean_T
sm_core_compiler_computeProximityInfoConvexConvex(const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,real_T sm_kHfMSiCBJRSoju34wwOKOx,real_T*
sm_Vrk3Pgb1wrhnZmcOkBtvtB,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FBszZdfzzb8sceEY5ruiL_,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__CX5rwUGU2WBd1iYlehENh,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VBX8DCC_il0siL9d2SBkT4,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FgOxFveCHNdAYaZUTotxJZ)
;boolean_T sm__vOk4P4g2_S3W9JJAwV14B(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,real_T
sm_kHfMSiCBJRSoju34wwOKOx,boolean_T sm__onsZLH_ytSGhXn0uJU7bM,
sm_FJDxOUSymMGic5lC7ZhrnL sm_k4v50UutrvdChTHBxBrg_s[][3],int*
sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T*sm_Vrk3Pgb1wrhnZmcOkBtvtB,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FBszZdfzzb8sceEY5ruiL_,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__CX5rwUGU2WBd1iYlehENh);extern int sm_VQ0A0Sv5GWprb1MDSztvuk[16];extern int
sm__qx74ytYCql1WuG2KqMfQS[16];extern size_t sm_k2PuWUcQ_UtHYDFpzYchpd[16][4];
PMF_DEPLOY_STATIC boolean_T sm__oPrRWZb_p0tbD5Lt0Lq4Z(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv){return
sm__AuaKMC5koOPbXxPi_MZvt->x==sm_kNtPmLll5l8eiqwtk5kfJv->x&&
sm__AuaKMC5koOPbXxPi_MZvt->sm_FzyLWRgau0pMYq2XSI3ETL==
sm_kNtPmLll5l8eiqwtk5kfJv->sm_FzyLWRgau0pMYq2XSI3ETL&&
sm__AuaKMC5koOPbXxPi_MZvt->sm_FBDi_PCg670TjHgJTNPcHr==
sm_kNtPmLll5l8eiqwtk5kfJv->sm_FBDi_PCg670TjHgJTNPcHr;}void
sm_F8eCImOfeYKdZuMlfsHdDH(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],int sm_kEhNFwUz1NOuj5cSj5dOF7,int
sm_FkoBKJSu3bdQdPWZgD2fC8,const size_t*sm__FuzaKmDsvhreiSobFRgkV,const real_T*
sm_k7RVes5oHPO2Yi5DMSKkeo,char*sm_VGqPwlpTl6K0jeyUcOcudU);void
sm__6dBgrcOk_GXieU6ApKSyW(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],const int sm_kEhNFwUz1NOuj5cSj5dOF7,const size_t
*sm__FuzaKmDsvhreiSobFRgkV,sm_FJDxOUSymMGic5lC7ZhrnL sm__hj2_lou4YpDgPeaVq55if
[3],sm_FJDxOUSymMGic5lC7ZhrnL*sm_kZKtm8DV37C4ieFPsTyO2E,
sm_FJDxOUSymMGic5lC7ZhrnL sm__TBxRBCon90NeHiMaIfEzO[3],
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FSzIyLZpToGyYTlwh2NE5V);void
sm_ViB8AROo2a_Gd9XrUW2rei(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kburdpU0IjpOXyPmyulx88,const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],int sm_FkoBKJSu3bdQdPWZgD2fC8,const size_t*
sm__FuzaKmDsvhreiSobFRgkV,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VBX8DCC_il0siL9d2SBkT4,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FgOxFveCHNdAYaZUTotxJZ);void
sm_kkIDwZB8zm4Pjyeyqv1cv5(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_F9yDQxbxjNlSeXydMwl6yG,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_FOTdVRJPGqhNba6tdltNZZ,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VCifngWB8ylih96lyIXhqB,
sm_FJDxOUSymMGic5lC7ZhrnL*pm__lqjegyKuwStj56WZLiC_e);int
sm_VQ0A0Sv5GWprb1MDSztvuk[16]={0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,};int
sm__qx74ytYCql1WuG2KqMfQS[16]={0,1,0,2,0,1,0,3,0,1,0,2,0,1,0,4,};size_t
sm_k2PuWUcQ_UtHYDFpzYchpd[16][4]={{0,0,0,0},{0,0,0,0},{1,0,0,0},{0,1,0,0},{2,0
,0,0},{0,2,0,0},{1,2,0,0},{0,1,2,0},{3,0,0,0},{0,3,0,0},{1,3,0,0},{0,1,3,0},{2
,3,0,0},{0,2,3,0},{1,2,3,0},{0,1,2,3},};void sm_F8eCImOfeYKdZuMlfsHdDH(const
sm_FJDxOUSymMGic5lC7ZhrnL sm_k4v50UutrvdChTHBxBrg_s[4][3],int
sm_kEhNFwUz1NOuj5cSj5dOF7,int sm_FkoBKJSu3bdQdPWZgD2fC8,const size_t*
sm__FuzaKmDsvhreiSobFRgkV,const real_T*sm_k7RVes5oHPO2Yi5DMSKkeo,char*
sm_VGqPwlpTl6K0jeyUcOcudU){int sm_kwrB3ZoKf7OufTHWaHJV7a;size_t
sm__4rObdzus2SNd15fsAQ0Vr[3];real_T sm_FTWM5hZy5kdEfHkNQcmnfx[3];{int src,dst=
0;for(src=0;src<sm_FkoBKJSu3bdQdPWZgD2fC8;++src){for(sm_kwrB3ZoKf7OufTHWaHJV7a
=0;sm_kwrB3ZoKf7OufTHWaHJV7a<dst;++sm_kwrB3ZoKf7OufTHWaHJV7a)if(
sm__oPrRWZb_p0tbD5Lt0Lq4Z(&sm_k4v50UutrvdChTHBxBrg_s[sm__FuzaKmDsvhreiSobFRgkV
[src]][sm_kEhNFwUz1NOuj5cSj5dOF7],&sm_k4v50UutrvdChTHBxBrg_s[
sm__4rObdzus2SNd15fsAQ0Vr[sm_kwrB3ZoKf7OufTHWaHJV7a]][
sm_kEhNFwUz1NOuj5cSj5dOF7])){sm_FTWM5hZy5kdEfHkNQcmnfx[
sm_kwrB3ZoKf7OufTHWaHJV7a]+=sm_k7RVes5oHPO2Yi5DMSKkeo[src];break;}if(
sm_kwrB3ZoKf7OufTHWaHJV7a==dst){sm__4rObdzus2SNd15fsAQ0Vr[dst]=
sm__FuzaKmDsvhreiSobFRgkV[src];sm_FTWM5hZy5kdEfHkNQcmnfx[dst]=
sm_k7RVes5oHPO2Yi5DMSKkeo[src];++dst;}}sm_FkoBKJSu3bdQdPWZgD2fC8=dst;}{(void)0
;;(void)0;;if(sm_FkoBKJSu3bdQdPWZgD2fC8==1){const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ= &sm_k4v50UutrvdChTHBxBrg_s[
sm__4rObdzus2SNd15fsAQ0Vr[0]][sm_kEhNFwUz1NOuj5cSj5dOF7];sprintf(
sm_VGqPwlpTl6K0jeyUcOcudU,"Vertex [%+.2f, %+.2f, %+.2f]",
sm_VgJW5ZqpwPpuY1inYtaofQ->x,sm_VgJW5ZqpwPpuY1inYtaofQ->
sm_FzyLWRgau0pMYq2XSI3ETL,sm_VgJW5ZqpwPpuY1inYtaofQ->sm_FBDi_PCg670TjHgJTNPcHr
);}else if(sm_FkoBKJSu3bdQdPWZgD2fC8==2){const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__AuaKMC5koOPbXxPi_MZvt= &sm_k4v50UutrvdChTHBxBrg_s[
sm__4rObdzus2SNd15fsAQ0Vr[0]][sm_kEhNFwUz1NOuj5cSj5dOF7];const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv= &
sm_k4v50UutrvdChTHBxBrg_s[sm__4rObdzus2SNd15fsAQ0Vr[1]][
sm_kEhNFwUz1NOuj5cSj5dOF7];sprintf(sm_VGqPwlpTl6K0jeyUcOcudU,
"Edge [%+.2f, %+.2f, %+.2f] -> [%+.2f, %+.2f, %+.2f]"", lambda = %+19.12e",
sm__AuaKMC5koOPbXxPi_MZvt->x,sm__AuaKMC5koOPbXxPi_MZvt->
sm_FzyLWRgau0pMYq2XSI3ETL,sm__AuaKMC5koOPbXxPi_MZvt->sm_FBDi_PCg670TjHgJTNPcHr
,sm_kNtPmLll5l8eiqwtk5kfJv->x,sm_kNtPmLll5l8eiqwtk5kfJv->
sm_FzyLWRgau0pMYq2XSI3ETL,sm_kNtPmLll5l8eiqwtk5kfJv->sm_FBDi_PCg670TjHgJTNPcHr
,sm_FTWM5hZy5kdEfHkNQcmnfx[1]);}else{const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__AuaKMC5koOPbXxPi_MZvt= &sm_k4v50UutrvdChTHBxBrg_s[
sm__4rObdzus2SNd15fsAQ0Vr[0]][sm_kEhNFwUz1NOuj5cSj5dOF7];const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv= &
sm_k4v50UutrvdChTHBxBrg_s[sm__4rObdzus2SNd15fsAQ0Vr[1]][
sm_kEhNFwUz1NOuj5cSj5dOF7];const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__V7yhs3oelG7WqyGLN1Wqz= &sm_k4v50UutrvdChTHBxBrg_s[
sm__4rObdzus2SNd15fsAQ0Vr[2]][sm_kEhNFwUz1NOuj5cSj5dOF7];sprintf(
sm_VGqPwlpTl6K0jeyUcOcudU,
"Face [%+.2f, %+.2f, %+.2f] [%+.2f, %+.2f, %+.2f] [%+.2f, %+.2f, %+.2f]"
", lambda = [%+.2f, %+.2f, %+.2f]",sm__AuaKMC5koOPbXxPi_MZvt->x,
sm__AuaKMC5koOPbXxPi_MZvt->sm_FzyLWRgau0pMYq2XSI3ETL,sm__AuaKMC5koOPbXxPi_MZvt
->sm_FBDi_PCg670TjHgJTNPcHr,sm_kNtPmLll5l8eiqwtk5kfJv->x,
sm_kNtPmLll5l8eiqwtk5kfJv->sm_FzyLWRgau0pMYq2XSI3ETL,sm_kNtPmLll5l8eiqwtk5kfJv
->sm_FBDi_PCg670TjHgJTNPcHr,sm__V7yhs3oelG7WqyGLN1Wqz->x,
sm__V7yhs3oelG7WqyGLN1Wqz->sm_FzyLWRgau0pMYq2XSI3ETL,sm__V7yhs3oelG7WqyGLN1Wqz
->sm_FBDi_PCg670TjHgJTNPcHr,sm_FTWM5hZy5kdEfHkNQcmnfx[0],
sm_FTWM5hZy5kdEfHkNQcmnfx[1],sm_FTWM5hZy5kdEfHkNQcmnfx[2]);}}}void
sm__6dBgrcOk_GXieU6ApKSyW(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],const int sm_kEhNFwUz1NOuj5cSj5dOF7,const size_t
*sm__FuzaKmDsvhreiSobFRgkV,sm_FJDxOUSymMGic5lC7ZhrnL sm__hj2_lou4YpDgPeaVq55if
[3],sm_FJDxOUSymMGic5lC7ZhrnL*sm_kZKtm8DV37C4ieFPsTyO2E,
sm_FJDxOUSymMGic5lC7ZhrnL sm__TBxRBCon90NeHiMaIfEzO[3],
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FSzIyLZpToGyYTlwh2NE5V){pm_math_Vector3_add(&
sm_k4v50UutrvdChTHBxBrg_s[sm__FuzaKmDsvhreiSobFRgkV[0]][
sm_kEhNFwUz1NOuj5cSj5dOF7],&sm_k4v50UutrvdChTHBxBrg_s[
sm__FuzaKmDsvhreiSobFRgkV[1]][sm_kEhNFwUz1NOuj5cSj5dOF7],
sm_kZKtm8DV37C4ieFPsTyO2E);pm_math_Vector3_add(&sm_k4v50UutrvdChTHBxBrg_s[
sm__FuzaKmDsvhreiSobFRgkV[2]][sm_kEhNFwUz1NOuj5cSj5dOF7],
sm_kZKtm8DV37C4ieFPsTyO2E,sm_kZKtm8DV37C4ieFPsTyO2E);pm_math_Vector3_divide(
sm_kZKtm8DV37C4ieFPsTyO2E,3.0,sm_kZKtm8DV37C4ieFPsTyO2E);
pm_math_Vector3_subtract(&sm_k4v50UutrvdChTHBxBrg_s[sm__FuzaKmDsvhreiSobFRgkV[
0]][sm_kEhNFwUz1NOuj5cSj5dOF7],sm_kZKtm8DV37C4ieFPsTyO2E,
sm__hj2_lou4YpDgPeaVq55if+0);pm_math_Vector3_subtract(&
sm_k4v50UutrvdChTHBxBrg_s[sm__FuzaKmDsvhreiSobFRgkV[1]][
sm_kEhNFwUz1NOuj5cSj5dOF7],sm_kZKtm8DV37C4ieFPsTyO2E,sm__hj2_lou4YpDgPeaVq55if
+1);pm_math_Vector3_subtract(&sm_k4v50UutrvdChTHBxBrg_s[
sm__FuzaKmDsvhreiSobFRgkV[2]][sm_kEhNFwUz1NOuj5cSj5dOF7],
sm_kZKtm8DV37C4ieFPsTyO2E,sm__hj2_lou4YpDgPeaVq55if+2);pm_math_Vector3_cross(
sm__hj2_lou4YpDgPeaVq55if+1,sm__hj2_lou4YpDgPeaVq55if+2,
sm__TBxRBCon90NeHiMaIfEzO+0);pm_math_Vector3_cross(sm__hj2_lou4YpDgPeaVq55if+2
,sm__hj2_lou4YpDgPeaVq55if+0,sm__TBxRBCon90NeHiMaIfEzO+1);pm_math_Vector3_add(
sm__TBxRBCon90NeHiMaIfEzO+0,sm__TBxRBCon90NeHiMaIfEzO+1,
sm_FSzIyLZpToGyYTlwh2NE5V);pm_math_Vector3_cross(sm__hj2_lou4YpDgPeaVq55if+0,
sm__hj2_lou4YpDgPeaVq55if+1,sm__TBxRBCon90NeHiMaIfEzO+2);pm_math_Vector3_add(
sm_FSzIyLZpToGyYTlwh2NE5V,sm__TBxRBCon90NeHiMaIfEzO+2,
sm_FSzIyLZpToGyYTlwh2NE5V);}static boolean_T sm__QZjIf69H6dvWLEk3BxI2n(const
sm_FJDxOUSymMGic5lC7ZhrnL sm__hj2_lou4YpDgPeaVq55if[3],const
sm_FJDxOUSymMGic5lC7ZhrnL sm__TBxRBCon90NeHiMaIfEzO[3],size_t
sm__FuzaKmDsvhreiSobFRgkV[3]){int sm_kwrB3ZoKf7OufTHWaHJV7a;const real_T
sm___NpRNlrP_pWZ9fsm8IijM=1.0e-2;real_T sm_Vs7_tYMMsA4pYDjUeVU_M1[3];boolean_T
sm__c5XrFgUwWKogTUJHqQfJg=false;for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<3;++sm_kwrB3ZoKf7OufTHWaHJV7a){const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__ygszzgd2_xZcyvPmMOssW= &
sm__hj2_lou4YpDgPeaVq55if[sm_kwrB3ZoKf7OufTHWaHJV7a];if(fabs(
sm__ygszzgd2_xZcyvPmMOssW->x)>sm___NpRNlrP_pWZ9fsm8IijM||fabs(
sm__ygszzgd2_xZcyvPmMOssW->sm_FzyLWRgau0pMYq2XSI3ETL)>
sm___NpRNlrP_pWZ9fsm8IijM||fabs(sm__ygszzgd2_xZcyvPmMOssW->
sm_FBDi_PCg670TjHgJTNPcHr)>sm___NpRNlrP_pWZ9fsm8IijM)return
sm__c5XrFgUwWKogTUJHqQfJg;}for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<3;++sm_kwrB3ZoKf7OufTHWaHJV7a){
sm_Vs7_tYMMsA4pYDjUeVU_M1[sm_kwrB3ZoKf7OufTHWaHJV7a]=pm_math_Vector3_norm(
sm__hj2_lou4YpDgPeaVq55if+sm_kwrB3ZoKf7OufTHWaHJV7a);}for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<3;++
sm_kwrB3ZoKf7OufTHWaHJV7a){const real_T sm_F7pf6W3cHK_ogudJC1_WYA=
pm_math_Vector3_norm(sm__TBxRBCon90NeHiMaIfEzO+sm_kwrB3ZoKf7OufTHWaHJV7a);
const real_T sm_VSPRpTLII6KIdDMaWO6v7h=sm_Vs7_tYMMsA4pYDjUeVU_M1[(
sm_kwrB3ZoKf7OufTHWaHJV7a+1)%3]*sm_Vs7_tYMMsA4pYDjUeVU_M1[(
sm_kwrB3ZoKf7OufTHWaHJV7a+2)%3]*1.0e-3;sm__c5XrFgUwWKogTUJHqQfJg=
sm__c5XrFgUwWKogTUJHqQfJg||sm_F7pf6W3cHK_ogudJC1_WYA<sm_VSPRpTLII6KIdDMaWO6v7h
;if(sm__c5XrFgUwWKogTUJHqQfJg)break;}if(sm__c5XrFgUwWKogTUJHqQfJg){size_t
sm_kaXDh6FS5xpYgXUIs9_0MJ[3];memcpy(sm_kaXDh6FS5xpYgXUIs9_0MJ,
sm__FuzaKmDsvhreiSobFRgkV,3*sizeof(size_t));if(sm_Vs7_tYMMsA4pYDjUeVU_M1[0]>
sm_Vs7_tYMMsA4pYDjUeVU_M1[1]){sm__FuzaKmDsvhreiSobFRgkV[1]=
sm_Vs7_tYMMsA4pYDjUeVU_M1[1]>sm_Vs7_tYMMsA4pYDjUeVU_M1[2]?
sm_kaXDh6FS5xpYgXUIs9_0MJ[1]:sm_kaXDh6FS5xpYgXUIs9_0MJ[2];}else{
sm__FuzaKmDsvhreiSobFRgkV[0]=sm_kaXDh6FS5xpYgXUIs9_0MJ[1];
sm__FuzaKmDsvhreiSobFRgkV[1]=sm_Vs7_tYMMsA4pYDjUeVU_M1[0]>
sm_Vs7_tYMMsA4pYDjUeVU_M1[2]?sm_kaXDh6FS5xpYgXUIs9_0MJ[0]:
sm_kaXDh6FS5xpYgXUIs9_0MJ[2];}}return sm__c5XrFgUwWKogTUJHqQfJg;}static void
sm__xZyCyvetkxDcX1XZD_w0G(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kSBaR7c6O38sa5ZMZ1k4Y1,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kburdpU0IjpOXyPmyulx88,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VBX8DCC_il0siL9d2SBkT4,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FgOxFveCHNdAYaZUTotxJZ)
{sm_FJDxOUSymMGic5lC7ZhrnL sm_FIVkGL6Mej4KVio7KUGaL1,sm_VQ8_IE57wqKqias1a7HK06
,sm_kdo3q5PDHnlnduddJs4mxt;real_T sm__DTLPgXYFnlec9XJ9H7Ggd,
sm_VPq99_EJgbKHd9i1LLwQtL;pm_math_Vector3_negate(sm_VBX8DCC_il0siL9d2SBkT4,&
sm_FIVkGL6Mej4KVio7KUGaL1);(*sm__TDB1qycHttnhabay6VIVQ)(
sm_kgkmYuXOxPtmdTDiHKeNa5,sm_VBX8DCC_il0siL9d2SBkT4,&sm_VQ8_IE57wqKqias1a7HK06
);(*sm__TDB1qycHttnhabay6VIVQ)(sm_kgkmYuXOxPtmdTDiHKeNa5,&
sm_FIVkGL6Mej4KVio7KUGaL1,&sm_kdo3q5PDHnlnduddJs4mxt);pm_math_Vector3_subtract
(&sm_VQ8_IE57wqKqias1a7HK06,sm_kSBaR7c6O38sa5ZMZ1k4Y1,&
sm_VQ8_IE57wqKqias1a7HK06);pm_math_Vector3_subtract(&sm_kdo3q5PDHnlnduddJs4mxt
,sm_kSBaR7c6O38sa5ZMZ1k4Y1,&sm_kdo3q5PDHnlnduddJs4mxt);pm_math_Vector3_unit(
sm_VBX8DCC_il0siL9d2SBkT4,sm_VBX8DCC_il0siL9d2SBkT4);sm__DTLPgXYFnlec9XJ9H7Ggd
=fabs(pm_math_Vector3_dot(&sm_VQ8_IE57wqKqias1a7HK06,sm_VBX8DCC_il0siL9d2SBkT4
));sm_VPq99_EJgbKHd9i1LLwQtL=fabs(pm_math_Vector3_dot(&
sm_kdo3q5PDHnlnduddJs4mxt,sm_VBX8DCC_il0siL9d2SBkT4));if(fabs(
sm__DTLPgXYFnlec9XJ9H7Ggd-sm_VPq99_EJgbKHd9i1LLwQtL)<1.0e-8){
pm_math_Transform3_xformDir(sm__yWh8B7tCCdhiXMhhHUqbN,
sm_VBX8DCC_il0siL9d2SBkT4,sm_FgOxFveCHNdAYaZUTotxJZ);
pm_math_Transform3_inverseXformDir(sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_FgOxFveCHNdAYaZUTotxJZ,sm_FgOxFveCHNdAYaZUTotxJZ);pm_math_Vector3_negate(
sm_FgOxFveCHNdAYaZUTotxJZ,&sm_FIVkGL6Mej4KVio7KUGaL1);(*
sm_kr84ZslsgzG2ei26cNKR9_)(sm_F4kGV66idSlLj12YnANYlJ,sm_FgOxFveCHNdAYaZUTotxJZ
,&sm_VQ8_IE57wqKqias1a7HK06);(*sm_kr84ZslsgzG2ei26cNKR9_)(
sm_F4kGV66idSlLj12YnANYlJ,&sm_FIVkGL6Mej4KVio7KUGaL1,&
sm_kdo3q5PDHnlnduddJs4mxt);pm_math_Vector3_subtract(&sm_VQ8_IE57wqKqias1a7HK06
,sm_kburdpU0IjpOXyPmyulx88,&sm_VQ8_IE57wqKqias1a7HK06);
pm_math_Vector3_subtract(&sm_kdo3q5PDHnlnduddJs4mxt,sm_kburdpU0IjpOXyPmyulx88,
&sm_kdo3q5PDHnlnduddJs4mxt);sm__DTLPgXYFnlec9XJ9H7Ggd=fabs(pm_math_Vector3_dot
(&sm_VQ8_IE57wqKqias1a7HK06,sm_FgOxFveCHNdAYaZUTotxJZ));
sm_VPq99_EJgbKHd9i1LLwQtL=fabs(pm_math_Vector3_dot(&sm_kdo3q5PDHnlnduddJs4mxt,
sm_FgOxFveCHNdAYaZUTotxJZ));if(fabs(sm__DTLPgXYFnlec9XJ9H7Ggd-
sm_VPq99_EJgbKHd9i1LLwQtL)<1.0e-8){pm_math_Vector3_negate(
sm_FgOxFveCHNdAYaZUTotxJZ,sm_FgOxFveCHNdAYaZUTotxJZ);}else{if(
sm_VPq99_EJgbKHd9i1LLwQtL<sm__DTLPgXYFnlec9XJ9H7Ggd){pm_math_Vector3_negate(
sm_FgOxFveCHNdAYaZUTotxJZ,sm_FgOxFveCHNdAYaZUTotxJZ);}else{
pm_math_Vector3_negate(sm_VBX8DCC_il0siL9d2SBkT4,sm_VBX8DCC_il0siL9d2SBkT4);}}
}else{if(sm_VPq99_EJgbKHd9i1LLwQtL<sm__DTLPgXYFnlec9XJ9H7Ggd)
pm_math_Vector3_negate(sm_VBX8DCC_il0siL9d2SBkT4,sm_VBX8DCC_il0siL9d2SBkT4);
pm_math_Transform3_xformDir(sm__yWh8B7tCCdhiXMhhHUqbN,
sm_VBX8DCC_il0siL9d2SBkT4,sm_FgOxFveCHNdAYaZUTotxJZ);
pm_math_Transform3_inverseXformDir(sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_FgOxFveCHNdAYaZUTotxJZ,sm_FgOxFveCHNdAYaZUTotxJZ);pm_math_Vector3_negate(
sm_FgOxFveCHNdAYaZUTotxJZ,sm_FgOxFveCHNdAYaZUTotxJZ);}}static void
sm_k0aO9492L4OBhDO9cgW_NB(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kSBaR7c6O38sa5ZMZ1k4Y1,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kburdpU0IjpOXyPmyulx88,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VBX8DCC_il0siL9d2SBkT4,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FgOxFveCHNdAYaZUTotxJZ)
{sm_FJDxOUSymMGic5lC7ZhrnL sm_FIVkGL6Mej4KVio7KUGaL1,sm_VQ8_IE57wqKqias1a7HK06
,sm_kdo3q5PDHnlnduddJs4mxt;real_T sm__DTLPgXYFnlec9XJ9H7Ggd,
sm_VPq99_EJgbKHd9i1LLwQtL;if(sm_VBX8DCC_il0siL9d2SBkT4->x==0.0&&
sm_VBX8DCC_il0siL9d2SBkT4->sm_FzyLWRgau0pMYq2XSI3ETL==0.0&&
sm_VBX8DCC_il0siL9d2SBkT4->sm_FBDi_PCg670TjHgJTNPcHr==0.0){
pm_math_Vector3_subtract(&sm_FGPQyC36Ly4PgaEVTyCKbe->sm_F32Ql82vv6pW_PYIdpkFQ0
,&sm__yWh8B7tCCdhiXMhhHUqbN->sm_F32Ql82vv6pW_PYIdpkFQ0,
sm_VBX8DCC_il0siL9d2SBkT4);if(sm_VBX8DCC_il0siL9d2SBkT4->x==0.0&&
sm_VBX8DCC_il0siL9d2SBkT4->sm_FzyLWRgau0pMYq2XSI3ETL==0.0&&
sm_VBX8DCC_il0siL9d2SBkT4->sm_FBDi_PCg670TjHgJTNPcHr==0.0)
sm_VBX8DCC_il0siL9d2SBkT4->sm_FBDi_PCg670TjHgJTNPcHr=1.0;}
pm_math_Transform3_inverseXformDir(sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_VBX8DCC_il0siL9d2SBkT4,sm_FgOxFveCHNdAYaZUTotxJZ);
pm_math_Transform3_inverseXformDir(sm__yWh8B7tCCdhiXMhhHUqbN,
sm_VBX8DCC_il0siL9d2SBkT4,sm_VBX8DCC_il0siL9d2SBkT4);pm_math_Vector3_negate(
sm_VBX8DCC_il0siL9d2SBkT4,&sm_FIVkGL6Mej4KVio7KUGaL1);(*
sm__TDB1qycHttnhabay6VIVQ)(sm_kgkmYuXOxPtmdTDiHKeNa5,sm_VBX8DCC_il0siL9d2SBkT4
,&sm_VQ8_IE57wqKqias1a7HK06);(*sm__TDB1qycHttnhabay6VIVQ)(
sm_kgkmYuXOxPtmdTDiHKeNa5,&sm_FIVkGL6Mej4KVio7KUGaL1,&
sm_kdo3q5PDHnlnduddJs4mxt);pm_math_Vector3_subtract(&sm_VQ8_IE57wqKqias1a7HK06
,sm_kSBaR7c6O38sa5ZMZ1k4Y1,&sm_VQ8_IE57wqKqias1a7HK06);
pm_math_Vector3_subtract(&sm_kdo3q5PDHnlnduddJs4mxt,sm_kSBaR7c6O38sa5ZMZ1k4Y1,
&sm_kdo3q5PDHnlnduddJs4mxt);pm_math_Vector3_unit(sm_VBX8DCC_il0siL9d2SBkT4,
sm_VBX8DCC_il0siL9d2SBkT4);pm_math_Vector3_unit(sm_FgOxFveCHNdAYaZUTotxJZ,
sm_FgOxFveCHNdAYaZUTotxJZ);sm__DTLPgXYFnlec9XJ9H7Ggd=fabs(pm_math_Vector3_dot(
&sm_VQ8_IE57wqKqias1a7HK06,sm_VBX8DCC_il0siL9d2SBkT4));
sm_VPq99_EJgbKHd9i1LLwQtL=fabs(pm_math_Vector3_dot(&sm_kdo3q5PDHnlnduddJs4mxt,
sm_VBX8DCC_il0siL9d2SBkT4));if(fabs(sm__DTLPgXYFnlec9XJ9H7Ggd-
sm_VPq99_EJgbKHd9i1LLwQtL)<1.0e-8){pm_math_Vector3_negate(
sm_FgOxFveCHNdAYaZUTotxJZ,&sm_FIVkGL6Mej4KVio7KUGaL1);(*
sm_kr84ZslsgzG2ei26cNKR9_)(sm_F4kGV66idSlLj12YnANYlJ,sm_FgOxFveCHNdAYaZUTotxJZ
,&sm_VQ8_IE57wqKqias1a7HK06);(*sm_kr84ZslsgzG2ei26cNKR9_)(
sm_F4kGV66idSlLj12YnANYlJ,&sm_FIVkGL6Mej4KVio7KUGaL1,&
sm_kdo3q5PDHnlnduddJs4mxt);pm_math_Vector3_subtract(&sm_VQ8_IE57wqKqias1a7HK06
,sm_kburdpU0IjpOXyPmyulx88,&sm_VQ8_IE57wqKqias1a7HK06);
pm_math_Vector3_subtract(&sm_kdo3q5PDHnlnduddJs4mxt,sm_kburdpU0IjpOXyPmyulx88,
&sm_kdo3q5PDHnlnduddJs4mxt);sm__DTLPgXYFnlec9XJ9H7Ggd=fabs(pm_math_Vector3_dot
(&sm_VQ8_IE57wqKqias1a7HK06,sm_FgOxFveCHNdAYaZUTotxJZ));
sm_VPq99_EJgbKHd9i1LLwQtL=fabs(pm_math_Vector3_dot(&sm_kdo3q5PDHnlnduddJs4mxt,
sm_FgOxFveCHNdAYaZUTotxJZ));if(fabs(sm__DTLPgXYFnlec9XJ9H7Ggd-
sm_VPq99_EJgbKHd9i1LLwQtL)<1.0e-8){pm_math_Vector3_negate(
sm_FgOxFveCHNdAYaZUTotxJZ,sm_FgOxFveCHNdAYaZUTotxJZ);}else{if(
sm_VPq99_EJgbKHd9i1LLwQtL<sm__DTLPgXYFnlec9XJ9H7Ggd){pm_math_Vector3_negate(
sm_FgOxFveCHNdAYaZUTotxJZ,sm_FgOxFveCHNdAYaZUTotxJZ);}else{
pm_math_Vector3_negate(sm_VBX8DCC_il0siL9d2SBkT4,sm_VBX8DCC_il0siL9d2SBkT4);}}
}else{if(sm_VPq99_EJgbKHd9i1LLwQtL<sm__DTLPgXYFnlec9XJ9H7Ggd){
pm_math_Vector3_negate(sm_VBX8DCC_il0siL9d2SBkT4,sm_VBX8DCC_il0siL9d2SBkT4);}
else{pm_math_Vector3_negate(sm_FgOxFveCHNdAYaZUTotxJZ,
sm_FgOxFveCHNdAYaZUTotxJZ);}}}void sm_ViB8AROo2a_Gd9XrUW2rei(const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_FJDxOUSymMGic5lC7ZhrnL*sm_kburdpU0IjpOXyPmyulx88,
const sm_FJDxOUSymMGic5lC7ZhrnL sm_k4v50UutrvdChTHBxBrg_s[][3],int
sm_FkoBKJSu3bdQdPWZgD2fC8,const size_t*sm__FuzaKmDsvhreiSobFRgkV,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VBX8DCC_il0siL9d2SBkT4,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_FgOxFveCHNdAYaZUTotxJZ){int sm_kroDE6vXus_JX98FOaT7_a=0,
sm__cQx3tlWTC4Bf9AkNaYwft=0;boolean_T sm_FHU1lTq9LD4_d1BdEULZbY=true;size_t
sm__ACCv6_EtJ4ZgD2vs_MsI7[3],sm_kBJAFXZje6togaYoXKwgCj[3];int
sm_FbsbQRdIBwKmhqkBxxfakr;for(sm_FbsbQRdIBwKmhqkBxxfakr=0;
sm_FbsbQRdIBwKmhqkBxxfakr<sm_FkoBKJSu3bdQdPWZgD2fC8;++
sm_FbsbQRdIBwKmhqkBxxfakr){const size_t sm_kwrB3ZoKf7OufTHWaHJV7a=
sm__FuzaKmDsvhreiSobFRgkV[sm_FbsbQRdIBwKmhqkBxxfakr];int
sm_kyp6uAyJE40UVuAQNEYzS1;for(sm_kyp6uAyJE40UVuAQNEYzS1=0;
sm_kyp6uAyJE40UVuAQNEYzS1<sm_kroDE6vXus_JX98FOaT7_a&&!
sm__oPrRWZb_p0tbD5Lt0Lq4Z(&sm_k4v50UutrvdChTHBxBrg_s[sm__ACCv6_EtJ4ZgD2vs_MsI7
[sm_kyp6uAyJE40UVuAQNEYzS1]][0],&sm_k4v50UutrvdChTHBxBrg_s[
sm_kwrB3ZoKf7OufTHWaHJV7a][0]);++sm_kyp6uAyJE40UVuAQNEYzS1){}if(
sm_kyp6uAyJE40UVuAQNEYzS1==sm_kroDE6vXus_JX98FOaT7_a)sm__ACCv6_EtJ4ZgD2vs_MsI7
[sm_kroDE6vXus_JX98FOaT7_a++]=sm_kwrB3ZoKf7OufTHWaHJV7a;for(
sm_kyp6uAyJE40UVuAQNEYzS1=0;sm_kyp6uAyJE40UVuAQNEYzS1<
sm__cQx3tlWTC4Bf9AkNaYwft&&!sm__oPrRWZb_p0tbD5Lt0Lq4Z(&
sm_k4v50UutrvdChTHBxBrg_s[sm_kBJAFXZje6togaYoXKwgCj[sm_kyp6uAyJE40UVuAQNEYzS1]
][1],&sm_k4v50UutrvdChTHBxBrg_s[sm_kwrB3ZoKf7OufTHWaHJV7a][1]);++
sm_kyp6uAyJE40UVuAQNEYzS1){}if(sm_kyp6uAyJE40UVuAQNEYzS1==
sm__cQx3tlWTC4Bf9AkNaYwft)sm_kBJAFXZje6togaYoXKwgCj[sm__cQx3tlWTC4Bf9AkNaYwft
++]=sm_kwrB3ZoKf7OufTHWaHJV7a;}(void)0;;(void)0;;if(sm_kroDE6vXus_JX98FOaT7_a
==3){sm_FJDxOUSymMGic5lC7ZhrnL sm_Fg_amAE7KQdZVTsKSFige3[3],
sm__OOgLLgVVI_DiTF9PhY8kt[3],sm_FuGTz2zwfVGyhqzsP2leHC;
sm__6dBgrcOk_GXieU6ApKSyW(sm_k4v50UutrvdChTHBxBrg_s,0,
sm__ACCv6_EtJ4ZgD2vs_MsI7,sm_Fg_amAE7KQdZVTsKSFige3,&sm_FuGTz2zwfVGyhqzsP2leHC
,sm__OOgLLgVVI_DiTF9PhY8kt,sm_VBX8DCC_il0siL9d2SBkT4);if(
sm__QZjIf69H6dvWLEk3BxI2n(sm_Fg_amAE7KQdZVTsKSFige3,sm__OOgLLgVVI_DiTF9PhY8kt,
sm__ACCv6_EtJ4ZgD2vs_MsI7))sm_kroDE6vXus_JX98FOaT7_a=2;}if(
sm__cQx3tlWTC4Bf9AkNaYwft==3){sm_FJDxOUSymMGic5lC7ZhrnL
sm_kvSETIZubLCjhqD7S7O_ad[3],sm_VhR2hOpIcbOE_TpsEEkajv[3],
sm__IFtOTMKzV_QeXnUwQtc5v;sm__6dBgrcOk_GXieU6ApKSyW(sm_k4v50UutrvdChTHBxBrg_s,
1,sm_kBJAFXZje6togaYoXKwgCj,sm_kvSETIZubLCjhqD7S7O_ad,&
sm__IFtOTMKzV_QeXnUwQtc5v,sm_VhR2hOpIcbOE_TpsEEkajv,sm_FgOxFveCHNdAYaZUTotxJZ)
;if(sm__QZjIf69H6dvWLEk3BxI2n(sm_kvSETIZubLCjhqD7S7O_ad,
sm_VhR2hOpIcbOE_TpsEEkajv,sm_kBJAFXZje6togaYoXKwgCj))sm__cQx3tlWTC4Bf9AkNaYwft
=2;}if(sm_kroDE6vXus_JX98FOaT7_a==3&&sm__cQx3tlWTC4Bf9AkNaYwft==3)
sm_FHU1lTq9LD4_d1BdEULZbY=pm_math_Vector3_norm(sm_VBX8DCC_il0siL9d2SBkT4)>
pm_math_Vector3_norm(sm_FgOxFveCHNdAYaZUTotxJZ);if(sm_kroDE6vXus_JX98FOaT7_a==
3&&sm_FHU1lTq9LD4_d1BdEULZbY){sm__xZyCyvetkxDcX1XZD_w0G(
sm_kgkmYuXOxPtmdTDiHKeNa5,sm_F4kGV66idSlLj12YnANYlJ,sm__TDB1qycHttnhabay6VIVQ,
sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_kburdpU0IjpOXyPmyulx88,sm_VBX8DCC_il0siL9d2SBkT4,
sm_FgOxFveCHNdAYaZUTotxJZ);}else if(sm__cQx3tlWTC4Bf9AkNaYwft==3){
sm__xZyCyvetkxDcX1XZD_w0G(sm_F4kGV66idSlLj12YnANYlJ,sm_kgkmYuXOxPtmdTDiHKeNa5,
sm_kr84ZslsgzG2ei26cNKR9_,sm__TDB1qycHttnhabay6VIVQ,sm_FGPQyC36Ly4PgaEVTyCKbe,
sm__yWh8B7tCCdhiXMhhHUqbN,sm_kburdpU0IjpOXyPmyulx88,sm_kSBaR7c6O38sa5ZMZ1k4Y1,
sm_FgOxFveCHNdAYaZUTotxJZ,sm_VBX8DCC_il0siL9d2SBkT4);}else if(
sm_kroDE6vXus_JX98FOaT7_a==2&&sm__cQx3tlWTC4Bf9AkNaYwft==2){real_T
sm_VcOApJYdvE0oYaufgNYi63,sm_ky49hhylngSUguEPrn1OF_,sm_FQferGZUKft3_i5GvYy4Oy;
sm_FJDxOUSymMGic5lC7ZhrnL sm_kx7ZYJKm9m0TVinTOVzJHH,sm_V0326kAHEEpmhLXuJRHsRa,
sm_FTJD5C_7k_tEeLfXggjMaB,sm_krNpvlJ9GRxTimAjn553Ub,sm_kDTYNj3erXleeDgn6ZWFBW;
pm_math_Vector3_subtract(&sm_k4v50UutrvdChTHBxBrg_s[sm__ACCv6_EtJ4ZgD2vs_MsI7[
1]][0],&sm_k4v50UutrvdChTHBxBrg_s[sm__ACCv6_EtJ4ZgD2vs_MsI7[0]][0],&
sm_kx7ZYJKm9m0TVinTOVzJHH);pm_math_Vector3_subtract(&sm_k4v50UutrvdChTHBxBrg_s
[sm_kBJAFXZje6togaYoXKwgCj[1]][1],&sm_k4v50UutrvdChTHBxBrg_s[
sm_kBJAFXZje6togaYoXKwgCj[0]][1],&sm_V0326kAHEEpmhLXuJRHsRa);
pm_math_Transform3_xformDir(sm__yWh8B7tCCdhiXMhhHUqbN,&
sm_kx7ZYJKm9m0TVinTOVzJHH,&sm_kx7ZYJKm9m0TVinTOVzJHH);
pm_math_Transform3_xformDir(sm_FGPQyC36Ly4PgaEVTyCKbe,&
sm_V0326kAHEEpmhLXuJRHsRa,&sm_V0326kAHEEpmhLXuJRHsRa);pm_math_Vector3_cross(&
sm_kx7ZYJKm9m0TVinTOVzJHH,&sm_V0326kAHEEpmhLXuJRHsRa,sm_VBX8DCC_il0siL9d2SBkT4
);sm_VcOApJYdvE0oYaufgNYi63=pm_math_Vector3_dot(&sm_kx7ZYJKm9m0TVinTOVzJHH,&
sm_kx7ZYJKm9m0TVinTOVzJHH);sm_ky49hhylngSUguEPrn1OF_=pm_math_Vector3_dot(&
sm_V0326kAHEEpmhLXuJRHsRa,&sm_V0326kAHEEpmhLXuJRHsRa);if(pm_math_Vector3_dot(
sm_VBX8DCC_il0siL9d2SBkT4,sm_VBX8DCC_il0siL9d2SBkT4)<sm_VcOApJYdvE0oYaufgNYi63
*sm_ky49hhylngSUguEPrn1OF_*1.0e-2*1.0e-2){pm_math_Transform3_xformPoint(
sm__yWh8B7tCCdhiXMhhHUqbN,sm_kSBaR7c6O38sa5ZMZ1k4Y1,&sm_FTJD5C_7k_tEeLfXggjMaB
);pm_math_Transform3_xformPoint(sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_kburdpU0IjpOXyPmyulx88,&sm_krNpvlJ9GRxTimAjn553Ub);pm_math_Vector3_subtract
(&sm_krNpvlJ9GRxTimAjn553Ub,&sm_FTJD5C_7k_tEeLfXggjMaB,&
sm_kDTYNj3erXleeDgn6ZWFBW);sm_FQferGZUKft3_i5GvYy4Oy=pm_math_Vector3_dot(&
sm_kDTYNj3erXleeDgn6ZWFBW,&sm_kx7ZYJKm9m0TVinTOVzJHH)/
sm_VcOApJYdvE0oYaufgNYi63;pm_math_Vector3_scale(&sm_kx7ZYJKm9m0TVinTOVzJHH,
sm_FQferGZUKft3_i5GvYy4Oy,&sm_kx7ZYJKm9m0TVinTOVzJHH);pm_math_Vector3_subtract
(&sm_kDTYNj3erXleeDgn6ZWFBW,&sm_kx7ZYJKm9m0TVinTOVzJHH,
sm_VBX8DCC_il0siL9d2SBkT4);}sm_k0aO9492L4OBhDO9cgW_NB(
sm_kgkmYuXOxPtmdTDiHKeNa5,sm_F4kGV66idSlLj12YnANYlJ,sm__TDB1qycHttnhabay6VIVQ,
sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_kburdpU0IjpOXyPmyulx88,sm_VBX8DCC_il0siL9d2SBkT4,
sm_FgOxFveCHNdAYaZUTotxJZ);}else if(sm_kroDE6vXus_JX98FOaT7_a==2&&
sm__cQx3tlWTC4Bf9AkNaYwft==1){real_T sm_FQferGZUKft3_i5GvYy4Oy;
sm_FJDxOUSymMGic5lC7ZhrnL sm_F9yDQxbxjNlSeXydMwl6yG,sm_FTJD5C_7k_tEeLfXggjMaB,
sm_krNpvlJ9GRxTimAjn553Ub,sm_kDTYNj3erXleeDgn6ZWFBW;pm_math_Vector3_subtract(&
sm_k4v50UutrvdChTHBxBrg_s[sm__ACCv6_EtJ4ZgD2vs_MsI7[1]][0],&
sm_k4v50UutrvdChTHBxBrg_s[sm__ACCv6_EtJ4ZgD2vs_MsI7[0]][0],&
sm_F9yDQxbxjNlSeXydMwl6yG);pm_math_Transform3_xformDir(
sm__yWh8B7tCCdhiXMhhHUqbN,&sm_F9yDQxbxjNlSeXydMwl6yG,&
sm_F9yDQxbxjNlSeXydMwl6yG);pm_math_Transform3_xformPoint(
sm__yWh8B7tCCdhiXMhhHUqbN,sm_kSBaR7c6O38sa5ZMZ1k4Y1,&sm_FTJD5C_7k_tEeLfXggjMaB
);pm_math_Transform3_xformPoint(sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_kburdpU0IjpOXyPmyulx88,&sm_krNpvlJ9GRxTimAjn553Ub);pm_math_Vector3_subtract
(&sm_krNpvlJ9GRxTimAjn553Ub,&sm_FTJD5C_7k_tEeLfXggjMaB,&
sm_kDTYNj3erXleeDgn6ZWFBW);sm_FQferGZUKft3_i5GvYy4Oy=pm_math_Vector3_dot(&
sm_kDTYNj3erXleeDgn6ZWFBW,&sm_F9yDQxbxjNlSeXydMwl6yG)/pm_math_Vector3_dot(&
sm_F9yDQxbxjNlSeXydMwl6yG,&sm_F9yDQxbxjNlSeXydMwl6yG);pm_math_Vector3_scale(&
sm_F9yDQxbxjNlSeXydMwl6yG,sm_FQferGZUKft3_i5GvYy4Oy,&sm_F9yDQxbxjNlSeXydMwl6yG
);pm_math_Vector3_subtract(&sm_kDTYNj3erXleeDgn6ZWFBW,&
sm_F9yDQxbxjNlSeXydMwl6yG,sm_VBX8DCC_il0siL9d2SBkT4);sm_k0aO9492L4OBhDO9cgW_NB
(sm_kgkmYuXOxPtmdTDiHKeNa5,sm_F4kGV66idSlLj12YnANYlJ,sm__TDB1qycHttnhabay6VIVQ
,sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe
,sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_kburdpU0IjpOXyPmyulx88,sm_VBX8DCC_il0siL9d2SBkT4
,sm_FgOxFveCHNdAYaZUTotxJZ);}else if(sm__cQx3tlWTC4Bf9AkNaYwft==2&&
sm_kroDE6vXus_JX98FOaT7_a==1){real_T sm_FQferGZUKft3_i5GvYy4Oy;
sm_FJDxOUSymMGic5lC7ZhrnL sm_F9yDQxbxjNlSeXydMwl6yG,sm_FTJD5C_7k_tEeLfXggjMaB,
sm_krNpvlJ9GRxTimAjn553Ub,sm_kDTYNj3erXleeDgn6ZWFBW;pm_math_Vector3_subtract(&
sm_k4v50UutrvdChTHBxBrg_s[sm_kBJAFXZje6togaYoXKwgCj[1]][1],&
sm_k4v50UutrvdChTHBxBrg_s[sm_kBJAFXZje6togaYoXKwgCj[0]][1],&
sm_F9yDQxbxjNlSeXydMwl6yG);pm_math_Transform3_xformDir(
sm_FGPQyC36Ly4PgaEVTyCKbe,&sm_F9yDQxbxjNlSeXydMwl6yG,&
sm_F9yDQxbxjNlSeXydMwl6yG);pm_math_Transform3_xformPoint(
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_kburdpU0IjpOXyPmyulx88,&sm_krNpvlJ9GRxTimAjn553Ub
);pm_math_Transform3_xformPoint(sm__yWh8B7tCCdhiXMhhHUqbN,
sm_kSBaR7c6O38sa5ZMZ1k4Y1,&sm_FTJD5C_7k_tEeLfXggjMaB);pm_math_Vector3_subtract
(&sm_FTJD5C_7k_tEeLfXggjMaB,&sm_krNpvlJ9GRxTimAjn553Ub,&
sm_kDTYNj3erXleeDgn6ZWFBW);sm_FQferGZUKft3_i5GvYy4Oy=pm_math_Vector3_dot(&
sm_kDTYNj3erXleeDgn6ZWFBW,&sm_F9yDQxbxjNlSeXydMwl6yG)/pm_math_Vector3_dot(&
sm_F9yDQxbxjNlSeXydMwl6yG,&sm_F9yDQxbxjNlSeXydMwl6yG);pm_math_Vector3_scale(&
sm_F9yDQxbxjNlSeXydMwl6yG,sm_FQferGZUKft3_i5GvYy4Oy,&sm_F9yDQxbxjNlSeXydMwl6yG
);pm_math_Vector3_subtract(&sm_kDTYNj3erXleeDgn6ZWFBW,&
sm_F9yDQxbxjNlSeXydMwl6yG,sm_FgOxFveCHNdAYaZUTotxJZ);sm_k0aO9492L4OBhDO9cgW_NB
(sm_F4kGV66idSlLj12YnANYlJ,sm_kgkmYuXOxPtmdTDiHKeNa5,sm_kr84ZslsgzG2ei26cNKR9_
,sm__TDB1qycHttnhabay6VIVQ,sm_FGPQyC36Ly4PgaEVTyCKbe,sm__yWh8B7tCCdhiXMhhHUqbN
,sm_kburdpU0IjpOXyPmyulx88,sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_FgOxFveCHNdAYaZUTotxJZ
,sm_VBX8DCC_il0siL9d2SBkT4);}else{sm_FJDxOUSymMGic5lC7ZhrnL
sm_FTJD5C_7k_tEeLfXggjMaB,sm_krNpvlJ9GRxTimAjn553Ub;
pm_math_Transform3_xformPoint(sm__yWh8B7tCCdhiXMhhHUqbN,
sm_kSBaR7c6O38sa5ZMZ1k4Y1,&sm_FTJD5C_7k_tEeLfXggjMaB);
pm_math_Transform3_xformPoint(sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_kburdpU0IjpOXyPmyulx88,&sm_krNpvlJ9GRxTimAjn553Ub);pm_math_Vector3_subtract
(&sm_krNpvlJ9GRxTimAjn553Ub,&sm_FTJD5C_7k_tEeLfXggjMaB,
sm_VBX8DCC_il0siL9d2SBkT4);sm_k0aO9492L4OBhDO9cgW_NB(sm_kgkmYuXOxPtmdTDiHKeNa5
,sm_F4kGV66idSlLj12YnANYlJ,sm__TDB1qycHttnhabay6VIVQ,sm_kr84ZslsgzG2ei26cNKR9_
,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe,sm_kSBaR7c6O38sa5ZMZ1k4Y1
,sm_kburdpU0IjpOXyPmyulx88,sm_VBX8DCC_il0siL9d2SBkT4,sm_FgOxFveCHNdAYaZUTotxJZ
);}}void sm_kkIDwZB8zm4Pjyeyqv1cv5(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_F9yDQxbxjNlSeXydMwl6yG,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_FOTdVRJPGqhNba6tdltNZZ,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VCifngWB8ylih96lyIXhqB,
sm_FJDxOUSymMGic5lC7ZhrnL*pm__lqjegyKuwStj56WZLiC_e){sm_FJDxOUSymMGic5lC7ZhrnL
sm_FkPsjyP396CaheWK6ztO8y,sm_kx7ZYJKm9m0TVinTOVzJHH,sm_V0326kAHEEpmhLXuJRHsRa,
sm_FTJD5C_7k_tEeLfXggjMaB,sm_krNpvlJ9GRxTimAjn553Ub;pm_math_Vector3_negate(
sm_F9yDQxbxjNlSeXydMwl6yG,&sm_FkPsjyP396CaheWK6ztO8y);
pm_math_Transform3_inverseXformDir(sm__yWh8B7tCCdhiXMhhHUqbN,&
sm_FkPsjyP396CaheWK6ztO8y,&sm_kx7ZYJKm9m0TVinTOVzJHH);
pm_math_Transform3_inverseXformDir(sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_F9yDQxbxjNlSeXydMwl6yG,&sm_V0326kAHEEpmhLXuJRHsRa);(*
sm__TDB1qycHttnhabay6VIVQ)(sm_kgkmYuXOxPtmdTDiHKeNa5,&
sm_kx7ZYJKm9m0TVinTOVzJHH,sm_FOTdVRJPGqhNba6tdltNZZ);(*
sm_kr84ZslsgzG2ei26cNKR9_)(sm_F4kGV66idSlLj12YnANYlJ,&
sm_V0326kAHEEpmhLXuJRHsRa,sm_VCifngWB8ylih96lyIXhqB);
pm_math_Transform3_xformPoint(sm__yWh8B7tCCdhiXMhhHUqbN,
sm_FOTdVRJPGqhNba6tdltNZZ,&sm_FTJD5C_7k_tEeLfXggjMaB);
pm_math_Transform3_xformPoint(sm_FGPQyC36Ly4PgaEVTyCKbe,
sm_VCifngWB8ylih96lyIXhqB,&sm_krNpvlJ9GRxTimAjn553Ub);pm_math_Vector3_subtract
(&sm_krNpvlJ9GRxTimAjn553Ub,&sm_FTJD5C_7k_tEeLfXggjMaB,
pm__lqjegyKuwStj56WZLiC_e);}
