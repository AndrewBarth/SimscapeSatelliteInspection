#include "pm_std.h"
#include "math.h"
#include "float.h"
#include "string.h"
#include "stdio.h"
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
struct sm_Va7rvzSwRbpB_iIiuSF8h_{real_T x;real_T sm_FzyLWRgau0pMYq2XSI3ETL;
real_T sm_FBDi_PCg670TjHgJTNPcHr;};typedef struct sm_Va7rvzSwRbpB_iIiuSF8h_
sm_FJDxOUSymMGic5lC7ZhrnL;struct sm_VQiPk6I_S_0teiYbT1MBSN{real_T
sm_FQferGZUKft3_i5GvYy4Oy;real_T x;real_T sm_FzyLWRgau0pMYq2XSI3ETL;real_T
sm_FBDi_PCg670TjHgJTNPcHr;};typedef struct sm_VQiPk6I_S_0teiYbT1MBSN
sm__3md8_onIiO6heiNB5D3_3;struct sm_k5mHxu1pFy4YaeyeIGf5bY{real_T
sm_V5gSkPeCSkdzZ1xMyj2v7U,sm__D1iFBxPf38RWiveIR1Iip,sm__hPet7vW5h0Zi1uUdLa_LW;
real_T sm_kdB_LoVum6OHeDEkf0n58b,sm__tdIR85BSYdzha7Mb8qhKj,
sm__WnakhFnl24_bX0NhL6CLW;real_T sm_FnXzm1MLmt04dPIhRbN5SW,
sm_VgeldyT0dAtjeHo3kvxpdi,sm_F3LgZdApwMGziTfUlk6dzB;};typedef struct
sm_k5mHxu1pFy4YaeyeIGf5bY sm_komYPTPtib40juqhd0nJcN;struct
sm__sD2GKinhS_qYTF_z8BajY{sm__3md8_onIiO6heiNB5D3_3 sm_VnD_HGFKVUOWdDAWvZhyEb;
sm_FJDxOUSymMGic5lC7ZhrnL sm_F32Ql82vv6pW_PYIdpkFQ0;};typedef struct
sm__sD2GKinhS_qYTF_z8BajY sm_k4kL9Om6RgxTZqdxJRM51B;struct
sm__CEhElfLt9_7aqLsGROeDF{sm_FJDxOUSymMGic5lC7ZhrnL sm_FN28mzn7A2hvYLPTU_L4bt;
sm_FJDxOUSymMGic5lC7ZhrnL sm_k61dA_LqfI4EY1W2W1B1mA;};typedef struct
sm__CEhElfLt9_7aqLsGROeDF sm_kNq2SpAav5tbb5Yx_VSirx;void pm_math_Vector3_add(
const sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_subtract(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_negate(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_scale(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,real_T
sm_FQferGZUKft3_i5GvYy4Oy,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Vector3_divide(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4);void
pm_math_Vector3_guardedDivide(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4);real_T
pm_math_Vector3_norm(const sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ
);void pm_math_Vector3_unit(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Vector3_guardedUnit(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;real_T pm_math_Vector3_dot(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kNtPmLll5l8eiqwtk5kfJv);void pm_math_Vector3_cross(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_compOrthogonalBasis(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_FJDxOUSymMGic5lC7ZhrnL*sm_kyp6uAyJE40UVuAQNEYzS1,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_V2__YrimeI4E_yWnhKofpy);void
pm_math_Quaternion_compose(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_composeInverse(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseCompose(const sm__3md8_onIiO6heiNB5D3_3*
sm_FbCdebDtDIhMduMKWA8Khy,const sm__3md8_onIiO6heiNB5D3_3*
sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xform(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformI(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformJ(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_xformK(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXform(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformI(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformJ(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_inverseXformK(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Quaternion_Matrix3x3Ctor(const sm_komYPTPtib40juqhd0nJcN*
sm_FqUCZrSGGNOuePgRr82o_8,sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb)
;void pm_math_Matrix3x3_compose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_composeTranspose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_transposeCompose(const sm_komYPTPtib40juqhd0nJcN*
sm_Fcuud3IN0odMZi54a1R_8f,const sm_komYPTPtib40juqhd0nJcN*
sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_preCross(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_postCross(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_komYPTPtib40juqhd0nJcN*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_xform(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_transposeXform(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Matrix3x3_QuaternionCtor(const sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb,sm_komYPTPtib40juqhd0nJcN*sm_FqUCZrSGGNOuePgRr82o_8)
;void pm_math_Matrix3x3_getValuesInColumns(const sm_komYPTPtib40juqhd0nJcN*
sm_F2l4p_g4sn02huHNflQjMH,double*sm_k4y8mv5uXzheZimBIk_n7I);void
pm_math_Transform3_compose(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_composeInverse(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseCompose(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDir(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kEbBObcYFIxUZ5_77V3CO_,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirI(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirJ(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformDirK(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDir(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kEbBObcYFIxUZ5_77V3CO_,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirI(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirJ(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformDirK(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_xformPoint(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
pm__lqjegyKuwStj56WZLiC_e,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Transform3_inverseXformPoint(const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,const sm_FJDxOUSymMGic5lC7ZhrnL*
pm__lqjegyKuwStj56WZLiC_e,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_add(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_kNtPmLll5l8eiqwtk5kfJv,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_subtract(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_kNtPmLll5l8eiqwtk5kfJv,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_xform(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_VgJW5ZqpwPpuY1inYtaofQ,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_SpatialVector_inverseXform(const sm_kNq2SpAav5tbb5Yx_VSirx*
sm_VgJW5ZqpwPpuY1inYtaofQ,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_V91rYIvDBkGRba7MvGcPUK,sm_kNq2SpAav5tbb5Yx_VSirx*sm__1Zf2IciMRCub1vvbEr1C4)
;typedef void(*sm__jsfq5ol9RO0emwniHUfEG)(const void*sm__MiFOMZ9U7lUWXDyYwo58p
,const sm_FJDxOUSymMGic5lC7ZhrnL*sm_F9yDQxbxjNlSeXydMwl6yG,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__rAKhgz20O_KVajkn1H7GD);boolean_T
sm_core_compiler_computeSignedDistanceConvexConvex(const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,real_T sm_kHfMSiCBJRSoju34wwOKOx,real_T*
sm_Vrk3Pgb1wrhnZmcOkBtvtB);boolean_T
sm_core_compiler_computeProximityInfoConvexConvex(const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,real_T sm_kHfMSiCBJRSoju34wwOKOx,real_T*
sm_Vrk3Pgb1wrhnZmcOkBtvtB,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FBszZdfzzb8sceEY5ruiL_,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__CX5rwUGU2WBd1iYlehENh,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VBX8DCC_il0siL9d2SBkT4,sm_FJDxOUSymMGic5lC7ZhrnL*sm_FgOxFveCHNdAYaZUTotxJZ)
;boolean_T sm__vOk4P4g2_S3W9JJAwV14B(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,real_T
sm_kHfMSiCBJRSoju34wwOKOx,boolean_T sm__onsZLH_ytSGhXn0uJU7bM,
sm_FJDxOUSymMGic5lC7ZhrnL sm_k4v50UutrvdChTHBxBrg_s[][3],int*
sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T*sm_Vrk3Pgb1wrhnZmcOkBtvtB,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FBszZdfzzb8sceEY5ruiL_,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__CX5rwUGU2WBd1iYlehENh);extern int sm_VQ0A0Sv5GWprb1MDSztvuk[16];extern int
sm__qx74ytYCql1WuG2KqMfQS[16];extern size_t sm_k2PuWUcQ_UtHYDFpzYchpd[16][4];
PMF_DEPLOY_STATIC boolean_T sm__oPrRWZb_p0tbD5Lt0Lq4Z(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv){return
sm__AuaKMC5koOPbXxPi_MZvt->x==sm_kNtPmLll5l8eiqwtk5kfJv->x&&
sm__AuaKMC5koOPbXxPi_MZvt->sm_FzyLWRgau0pMYq2XSI3ETL==
sm_kNtPmLll5l8eiqwtk5kfJv->sm_FzyLWRgau0pMYq2XSI3ETL&&
sm__AuaKMC5koOPbXxPi_MZvt->sm_FBDi_PCg670TjHgJTNPcHr==
sm_kNtPmLll5l8eiqwtk5kfJv->sm_FBDi_PCg670TjHgJTNPcHr;}void
sm_F8eCImOfeYKdZuMlfsHdDH(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],int sm_kEhNFwUz1NOuj5cSj5dOF7,int
sm_FkoBKJSu3bdQdPWZgD2fC8,const size_t*sm__FuzaKmDsvhreiSobFRgkV,const real_T*
sm_k7RVes5oHPO2Yi5DMSKkeo,char*sm_VGqPwlpTl6K0jeyUcOcudU);void
sm__6dBgrcOk_GXieU6ApKSyW(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],const int sm_kEhNFwUz1NOuj5cSj5dOF7,const size_t
*sm__FuzaKmDsvhreiSobFRgkV,sm_FJDxOUSymMGic5lC7ZhrnL sm__hj2_lou4YpDgPeaVq55if
[3],sm_FJDxOUSymMGic5lC7ZhrnL*sm_kZKtm8DV37C4ieFPsTyO2E,
sm_FJDxOUSymMGic5lC7ZhrnL sm__TBxRBCon90NeHiMaIfEzO[3],
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FSzIyLZpToGyYTlwh2NE5V);void
sm_ViB8AROo2a_Gd9XrUW2rei(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kburdpU0IjpOXyPmyulx88,const sm_FJDxOUSymMGic5lC7ZhrnL
sm_k4v50UutrvdChTHBxBrg_s[][3],int sm_FkoBKJSu3bdQdPWZgD2fC8,const size_t*
sm__FuzaKmDsvhreiSobFRgkV,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VBX8DCC_il0siL9d2SBkT4,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_FgOxFveCHNdAYaZUTotxJZ);void
sm_kkIDwZB8zm4Pjyeyqv1cv5(const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_F9yDQxbxjNlSeXydMwl6yG,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_FOTdVRJPGqhNba6tdltNZZ,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VCifngWB8ylih96lyIXhqB,
sm_FJDxOUSymMGic5lC7ZhrnL*pm__lqjegyKuwStj56WZLiC_e);static int
sm_Fgaezw42jeKce15Lg1GG8N(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ){const real_T sm_kY_rL_F8Nc0DiX9ImprC4_=fabs(
sm_VgJW5ZqpwPpuY1inYtaofQ->x);const real_T sm_kkkJJmKdVddMYirZwDaWI_=fabs(
sm_VgJW5ZqpwPpuY1inYtaofQ->sm_FzyLWRgau0pMYq2XSI3ETL);const real_T
sm_kn7OR4rQBtCCd5grVmuZLu=fabs(sm_VgJW5ZqpwPpuY1inYtaofQ->
sm_FBDi_PCg670TjHgJTNPcHr);return(sm_kY_rL_F8Nc0DiX9ImprC4_>=
sm_kkkJJmKdVddMYirZwDaWI_)?((sm_kY_rL_F8Nc0DiX9ImprC4_>=
sm_kn7OR4rQBtCCd5grVmuZLu)?0:2):((sm_kkkJJmKdVddMYirZwDaWI_>=
sm_kn7OR4rQBtCCd5grVmuZLu)?1:2);}PMF_DEPLOY_STATIC real_T
sm_FwU5JAoK_3WSeL0pprHYfD(const real_T*sm_Va9evmuafmdkiPNcZmdl3Y,const real_T*
sm_kMGBCYsWuASnV93g6HrFl7){return sm_Va9evmuafmdkiPNcZmdl3Y[0]*
sm_kMGBCYsWuASnV93g6HrFl7[1]-sm_Va9evmuafmdkiPNcZmdl3Y[1]*
sm_kMGBCYsWuASnV93g6HrFl7[0];}PMF_DEPLOY_STATIC real_T
sm_V_FoLVGO37G4eXJuucTSjm(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_Va9evmuafmdkiPNcZmdl3Y,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kMGBCYsWuASnV93g6HrFl7,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__E2YBge0HSdQXuehCPGj40){sm_FJDxOUSymMGic5lC7ZhrnL sm_F8T4Wenwml4P_y3ftibPPh
;pm_math_Vector3_cross(sm_kMGBCYsWuASnV93g6HrFl7,sm__E2YBge0HSdQXuehCPGj40,&
sm_F8T4Wenwml4P_y3ftibPPh);return pm_math_Vector3_dot(
sm_Va9evmuafmdkiPNcZmdl3Y,&sm_F8T4Wenwml4P_y3ftibPPh);}static void
sm_FlRYiIS9Oc8yiqhApQXUvX(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_kHyFeJsHAGdqW1uya_2WO5[4][3],int sm_FOdkmT7jBb4LcqK4Pu9cA3,const real_T*
sm_k7RVes5oHPO2Yi5DMSKkeo,sm_FJDxOUSymMGic5lC7ZhrnL*sm__rAKhgz20O_KVajkn1H7GD)
{int sm_kwrB3ZoKf7OufTHWaHJV7a,sm_VU18hM_2GHSHWue20_mnXQ;
sm_FJDxOUSymMGic5lC7ZhrnL sm_k84YR5pJZZpTVTG8BXcaAd;sm__rAKhgz20O_KVajkn1H7GD
->x=sm__rAKhgz20O_KVajkn1H7GD->sm_FzyLWRgau0pMYq2XSI3ETL=
sm__rAKhgz20O_KVajkn1H7GD->sm_FBDi_PCg670TjHgJTNPcHr=0.0;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0,sm_VU18hM_2GHSHWue20_mnXQ=1;
sm_kwrB3ZoKf7OufTHWaHJV7a<4;++sm_kwrB3ZoKf7OufTHWaHJV7a,
sm_VU18hM_2GHSHWue20_mnXQ<<=1)if((sm_FOdkmT7jBb4LcqK4Pu9cA3&
sm_VU18hM_2GHSHWue20_mnXQ)!=0){pm_math_Vector3_scale(&
sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][2],*
sm_k7RVes5oHPO2Yi5DMSKkeo++,&sm_k84YR5pJZZpTVTG8BXcaAd);pm_math_Vector3_add(
sm__rAKhgz20O_KVajkn1H7GD,&sm_k84YR5pJZZpTVTG8BXcaAd,sm__rAKhgz20O_KVajkn1H7GD
);}}static void sm_FdnL4nnTkgSqV90Sd_2_Vx(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_kHyFeJsHAGdqW1uya_2WO5[4][3],int sm__OhtPosUzNtdWmQIbxRfnx,int*
sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T*sm_k7RVes5oHPO2Yi5DMSKkeo){const size_t*
sm__mNZl3Dws0SzjmkHXP_BQz=sm_k2PuWUcQ_UtHYDFpzYchpd[*sm_FOdkmT7jBb4LcqK4Pu9cA3
];int sm_FFZbGh27ya8eem_J_hUtAZ,sm_kwrB3ZoKf7OufTHWaHJV7a,
sm_ksNwqwBbYj_4b5edpJakga;real_T sm_kyfq6L_eQbdYcPuOovpRDW,
sm_FStFcQlyAJ_dVy4kGZXBPQ[2],sm_kIRXiT7AM00NeLMByGqY73;
sm_FJDxOUSymMGic5lC7ZhrnL sm_k2ef3XxY9M8TY1yBQB5Tp7[2],
sm_FSGvWwJ5a8CYdT8a_C4tA5,sm__1eAP9V6_J_NYm_1gTIm7A,sm_k0lyfkUpC88AWmipXS8FGy;
pm_math_Vector3_add(&sm_kHyFeJsHAGdqW1uya_2WO5[sm__mNZl3Dws0SzjmkHXP_BQz[0]][2
],&sm_kHyFeJsHAGdqW1uya_2WO5[sm__mNZl3Dws0SzjmkHXP_BQz[1]][2],&
sm_FSGvWwJ5a8CYdT8a_C4tA5);pm_math_Vector3_scale(&sm_FSGvWwJ5a8CYdT8a_C4tA5,
0.5,&sm_FSGvWwJ5a8CYdT8a_C4tA5);pm_math_Vector3_subtract(&
sm_kHyFeJsHAGdqW1uya_2WO5[sm__mNZl3Dws0SzjmkHXP_BQz[0]][2],&
sm_FSGvWwJ5a8CYdT8a_C4tA5,sm_k2ef3XxY9M8TY1yBQB5Tp7+0);
pm_math_Vector3_subtract(&sm_kHyFeJsHAGdqW1uya_2WO5[sm__mNZl3Dws0SzjmkHXP_BQz[
1]][2],&sm_FSGvWwJ5a8CYdT8a_C4tA5,sm_k2ef3XxY9M8TY1yBQB5Tp7+1);
pm_math_Vector3_subtract(sm_k2ef3XxY9M8TY1yBQB5Tp7+1,sm_k2ef3XxY9M8TY1yBQB5Tp7
+0,&sm__1eAP9V6_J_NYm_1gTIm7A);{const real_T sm_FhiZqzaqadOsVP1Uvke9jy= -
pm_math_Vector3_dot(&sm_FSGvWwJ5a8CYdT8a_C4tA5,&sm__1eAP9V6_J_NYm_1gTIm7A);
const real_T sm_FVXcwERBgq_pgLcAw7YO4S=pm_math_Vector3_dot(&
sm__1eAP9V6_J_NYm_1gTIm7A,&sm__1eAP9V6_J_NYm_1gTIm7A);pm_math_Vector3_scale(&
sm__1eAP9V6_J_NYm_1gTIm7A,sm_FhiZqzaqadOsVP1Uvke9jy/sm_FVXcwERBgq_pgLcAw7YO4S,
&sm_k0lyfkUpC88AWmipXS8FGy);}sm_FFZbGh27ya8eem_J_hUtAZ=
sm_Fgaezw42jeKce15Lg1GG8N(&sm__1eAP9V6_J_NYm_1gTIm7A);{real_T
sm_VHLTbWeg4h81XDSnIz4mLS[2];const real_T sm__CCrcyQtdk8yXiLn9r9rFD= *(&
sm_k0lyfkUpC88AWmipXS8FGy.x+sm_FFZbGh27ya8eem_J_hUtAZ);
sm_VHLTbWeg4h81XDSnIz4mLS[0]= *(&sm_k2ef3XxY9M8TY1yBQB5Tp7[0].x+
sm_FFZbGh27ya8eem_J_hUtAZ);sm_VHLTbWeg4h81XDSnIz4mLS[1]= *(&
sm_k2ef3XxY9M8TY1yBQB5Tp7[1].x+sm_FFZbGh27ya8eem_J_hUtAZ);
sm_kyfq6L_eQbdYcPuOovpRDW=sm_VHLTbWeg4h81XDSnIz4mLS[0]-
sm_VHLTbWeg4h81XDSnIz4mLS[1];sm_FStFcQlyAJ_dVy4kGZXBPQ[0]=
sm__CCrcyQtdk8yXiLn9r9rFD-sm_VHLTbWeg4h81XDSnIz4mLS[1];
sm_FStFcQlyAJ_dVy4kGZXBPQ[1]=sm_VHLTbWeg4h81XDSnIz4mLS[0]-
sm__CCrcyQtdk8yXiLn9r9rFD;}{const real_T sm_kY_rL_F8Nc0DiX9ImprC4_=fabs(
sm_FStFcQlyAJ_dVy4kGZXBPQ[0]);const real_T sm_kkkJJmKdVddMYirZwDaWI_=fabs(
sm_FStFcQlyAJ_dVy4kGZXBPQ[1]);real_T sm_knamDCITCbKjXew_Mtv_8s;int
sm_VgCUWD77M3p7h5wHUW6Rj9;if(sm_kY_rL_F8Nc0DiX9ImprC4_>=
sm_kkkJJmKdVddMYirZwDaWI_)sm_knamDCITCbKjXew_Mtv_8s=sm_kY_rL_F8Nc0DiX9ImprC4_,
sm_VgCUWD77M3p7h5wHUW6Rj9=0;else sm_knamDCITCbKjXew_Mtv_8s=
sm_kkkJJmKdVddMYirZwDaWI_,sm_VgCUWD77M3p7h5wHUW6Rj9=1;if(fabs(
sm_kyfq6L_eQbdYcPuOovpRDW)<1.0e-10*sm_knamDCITCbKjXew_Mtv_8s){*
sm_FOdkmT7jBb4LcqK4Pu9cA3&=~(1<<sm_VgCUWD77M3p7h5wHUW6Rj9);
sm_k7RVes5oHPO2Yi5DMSKkeo[0]=1.0;return;}}sm_ksNwqwBbYj_4b5edpJakga=0;
sm_kIRXiT7AM00NeLMByGqY73=1.0e100;for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<2;++sm_kwrB3ZoKf7OufTHWaHJV7a){const size_t
sm_kMTy37a8TehzcLiuYGqV3M=sm__mNZl3Dws0SzjmkHXP_BQz[sm_kwrB3ZoKf7OufTHWaHJV7a]
;if(sm_kMTy37a8TehzcLiuYGqV3M!=(size_t)sm__OhtPosUzNtdWmQIbxRfnx){if(
sm_FStFcQlyAJ_dVy4kGZXBPQ[sm_kwrB3ZoKf7OufTHWaHJV7a]*sm_kyfq6L_eQbdYcPuOovpRDW
<=0.0){int sm_kxxsc7psSv_IYPVSdgmxG8= *sm_FOdkmT7jBb4LcqK4Pu9cA3;real_T
sm_k5iiHLlORl0BgHk0uNfg7_[1]={1.0},sm_F5U8Z42ivq0rgXHzE7grZD;
sm_FJDxOUSymMGic5lC7ZhrnL sm_VgJW5ZqpwPpuY1inYtaofQ;sm_kxxsc7psSv_IYPVSdgmxG8
&=~(1<<sm_kMTy37a8TehzcLiuYGqV3M);sm_FlRYiIS9Oc8yiqhApQXUvX(
sm_kHyFeJsHAGdqW1uya_2WO5,sm_kxxsc7psSv_IYPVSdgmxG8,sm_k5iiHLlORl0BgHk0uNfg7_,
&sm_VgJW5ZqpwPpuY1inYtaofQ);sm_F5U8Z42ivq0rgXHzE7grZD=pm_math_Vector3_dot(&
sm_VgJW5ZqpwPpuY1inYtaofQ,&sm_VgJW5ZqpwPpuY1inYtaofQ);if(
sm_F5U8Z42ivq0rgXHzE7grZD<sm_kIRXiT7AM00NeLMByGqY73){sm_ksNwqwBbYj_4b5edpJakga
=sm_kxxsc7psSv_IYPVSdgmxG8;sm_k7RVes5oHPO2Yi5DMSKkeo[0]=
sm_k5iiHLlORl0BgHk0uNfg7_[0];sm_kIRXiT7AM00NeLMByGqY73=
sm_F5U8Z42ivq0rgXHzE7grZD;}}}}if(sm_ksNwqwBbYj_4b5edpJakga==0){
sm_k7RVes5oHPO2Yi5DMSKkeo[0]=sm_FStFcQlyAJ_dVy4kGZXBPQ[0]/
sm_kyfq6L_eQbdYcPuOovpRDW;sm_k7RVes5oHPO2Yi5DMSKkeo[1]=
sm_FStFcQlyAJ_dVy4kGZXBPQ[1]/sm_kyfq6L_eQbdYcPuOovpRDW;}else*
sm_FOdkmT7jBb4LcqK4Pu9cA3=sm_ksNwqwBbYj_4b5edpJakga;}static void
sm__xbY9Wq3kdtBdPxIQuMurJ(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_kHyFeJsHAGdqW1uya_2WO5[4][3],int sm__OhtPosUzNtdWmQIbxRfnx,int*
sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T*sm_k7RVes5oHPO2Yi5DMSKkeo){const size_t*
sm__mNZl3Dws0SzjmkHXP_BQz=sm_k2PuWUcQ_UtHYDFpzYchpd[*sm_FOdkmT7jBb4LcqK4Pu9cA3
];int sm_FFZbGh27ya8eem_J_hUtAZ,sm_kwrB3ZoKf7OufTHWaHJV7a,
sm_ksNwqwBbYj_4b5edpJakga;real_T sm_VujUQwE_1ApFg1ThgD_p9p[3][2],
sm__CCrcyQtdk8yXiLn9r9rFD[2],sm_kyfq6L_eQbdYcPuOovpRDW,
sm_FStFcQlyAJ_dVy4kGZXBPQ[3],sm_kIRXiT7AM00NeLMByGqY73;
sm_FJDxOUSymMGic5lC7ZhrnL sm_kpVk0WGYlRKHbewq41x9uF[3],
sm_k9JGE1wG3YSaiqqcy6mvNS[3],sm_kVFmnbWkyy0LfyvBnLonNP,n,
sm_k0lyfkUpC88AWmipXS8FGy;sm__6dBgrcOk_GXieU6ApKSyW(sm_kHyFeJsHAGdqW1uya_2WO5,
2,sm__mNZl3Dws0SzjmkHXP_BQz,sm_kpVk0WGYlRKHbewq41x9uF,&
sm_kVFmnbWkyy0LfyvBnLonNP,sm_k9JGE1wG3YSaiqqcy6mvNS,&n);{const real_T
sm_FhiZqzaqadOsVP1Uvke9jy=pm_math_Vector3_dot(&sm_kVFmnbWkyy0LfyvBnLonNP,&n);
const real_T sm_FVXcwERBgq_pgLcAw7YO4S=pm_math_Vector3_dot(&n,&n);
pm_math_Vector3_scale(&n,sm_FhiZqzaqadOsVP1Uvke9jy/sm_FVXcwERBgq_pgLcAw7YO4S,&
sm_k0lyfkUpC88AWmipXS8FGy);pm_math_Vector3_subtract(&sm_k0lyfkUpC88AWmipXS8FGy
,&sm_kVFmnbWkyy0LfyvBnLonNP,&sm_k0lyfkUpC88AWmipXS8FGy);}
sm_FFZbGh27ya8eem_J_hUtAZ=sm_Fgaezw42jeKce15Lg1GG8N(&n);{if(
sm_FFZbGh27ya8eem_J_hUtAZ!=0){sm_VujUQwE_1ApFg1ThgD_p9p[0][0]=
sm_kpVk0WGYlRKHbewq41x9uF[0].x;sm_VujUQwE_1ApFg1ThgD_p9p[1][0]=
sm_kpVk0WGYlRKHbewq41x9uF[1].x;sm_VujUQwE_1ApFg1ThgD_p9p[2][0]=
sm_kpVk0WGYlRKHbewq41x9uF[2].x;sm__CCrcyQtdk8yXiLn9r9rFD[0]=
sm_k0lyfkUpC88AWmipXS8FGy.x;}else{sm_VujUQwE_1ApFg1ThgD_p9p[0][0]=
sm_kpVk0WGYlRKHbewq41x9uF[0].sm_FzyLWRgau0pMYq2XSI3ETL;
sm_VujUQwE_1ApFg1ThgD_p9p[1][0]=sm_kpVk0WGYlRKHbewq41x9uF[1].
sm_FzyLWRgau0pMYq2XSI3ETL;sm_VujUQwE_1ApFg1ThgD_p9p[2][0]=
sm_kpVk0WGYlRKHbewq41x9uF[2].sm_FzyLWRgau0pMYq2XSI3ETL;
sm__CCrcyQtdk8yXiLn9r9rFD[0]=sm_k0lyfkUpC88AWmipXS8FGy.
sm_FzyLWRgau0pMYq2XSI3ETL;}if(sm_FFZbGh27ya8eem_J_hUtAZ!=2){
sm_VujUQwE_1ApFg1ThgD_p9p[0][1]=sm_kpVk0WGYlRKHbewq41x9uF[0].
sm_FBDi_PCg670TjHgJTNPcHr;sm_VujUQwE_1ApFg1ThgD_p9p[1][1]=
sm_kpVk0WGYlRKHbewq41x9uF[1].sm_FBDi_PCg670TjHgJTNPcHr;
sm_VujUQwE_1ApFg1ThgD_p9p[2][1]=sm_kpVk0WGYlRKHbewq41x9uF[2].
sm_FBDi_PCg670TjHgJTNPcHr;sm__CCrcyQtdk8yXiLn9r9rFD[1]=
sm_k0lyfkUpC88AWmipXS8FGy.sm_FBDi_PCg670TjHgJTNPcHr;}else{
sm_VujUQwE_1ApFg1ThgD_p9p[0][1]=sm_kpVk0WGYlRKHbewq41x9uF[0].
sm_FzyLWRgau0pMYq2XSI3ETL;sm_VujUQwE_1ApFg1ThgD_p9p[1][1]=
sm_kpVk0WGYlRKHbewq41x9uF[1].sm_FzyLWRgau0pMYq2XSI3ETL;
sm_VujUQwE_1ApFg1ThgD_p9p[2][1]=sm_kpVk0WGYlRKHbewq41x9uF[2].
sm_FzyLWRgau0pMYq2XSI3ETL;sm__CCrcyQtdk8yXiLn9r9rFD[1]=
sm_k0lyfkUpC88AWmipXS8FGy.sm_FzyLWRgau0pMYq2XSI3ETL;}}{real_T
sm_V8XMtcd13M8FjLV0KvZZWM[3],sm__I45QXDj9vhGZeg1ViY2wU[3];
sm_V8XMtcd13M8FjLV0KvZZWM[0]=sm_FwU5JAoK_3WSeL0pprHYfD(
sm_VujUQwE_1ApFg1ThgD_p9p[1],sm_VujUQwE_1ApFg1ThgD_p9p[2]);
sm_V8XMtcd13M8FjLV0KvZZWM[1]=sm_FwU5JAoK_3WSeL0pprHYfD(
sm_VujUQwE_1ApFg1ThgD_p9p[2],sm_VujUQwE_1ApFg1ThgD_p9p[0]);
sm_V8XMtcd13M8FjLV0KvZZWM[2]=sm_FwU5JAoK_3WSeL0pprHYfD(
sm_VujUQwE_1ApFg1ThgD_p9p[0],sm_VujUQwE_1ApFg1ThgD_p9p[1]);
sm__I45QXDj9vhGZeg1ViY2wU[0]=sm_FwU5JAoK_3WSeL0pprHYfD(
sm__CCrcyQtdk8yXiLn9r9rFD,sm_VujUQwE_1ApFg1ThgD_p9p[0]);
sm__I45QXDj9vhGZeg1ViY2wU[1]=sm_FwU5JAoK_3WSeL0pprHYfD(
sm__CCrcyQtdk8yXiLn9r9rFD,sm_VujUQwE_1ApFg1ThgD_p9p[1]);
sm__I45QXDj9vhGZeg1ViY2wU[2]=sm_FwU5JAoK_3WSeL0pprHYfD(
sm__CCrcyQtdk8yXiLn9r9rFD,sm_VujUQwE_1ApFg1ThgD_p9p[2]);
sm_kyfq6L_eQbdYcPuOovpRDW=sm_V8XMtcd13M8FjLV0KvZZWM[0]+
sm_V8XMtcd13M8FjLV0KvZZWM[1]+sm_V8XMtcd13M8FjLV0KvZZWM[2];
sm_FStFcQlyAJ_dVy4kGZXBPQ[0]=sm_V8XMtcd13M8FjLV0KvZZWM[0]+
sm__I45QXDj9vhGZeg1ViY2wU[1]-sm__I45QXDj9vhGZeg1ViY2wU[2];
sm_FStFcQlyAJ_dVy4kGZXBPQ[1]=sm_V8XMtcd13M8FjLV0KvZZWM[1]+
sm__I45QXDj9vhGZeg1ViY2wU[2]-sm__I45QXDj9vhGZeg1ViY2wU[0];
sm_FStFcQlyAJ_dVy4kGZXBPQ[2]=sm_V8XMtcd13M8FjLV0KvZZWM[2]+
sm__I45QXDj9vhGZeg1ViY2wU[0]-sm__I45QXDj9vhGZeg1ViY2wU[1];}{const real_T
sm_kY_rL_F8Nc0DiX9ImprC4_=fabs(sm_FStFcQlyAJ_dVy4kGZXBPQ[0]);const real_T
sm_kkkJJmKdVddMYirZwDaWI_=fabs(sm_FStFcQlyAJ_dVy4kGZXBPQ[1]);const real_T
sm_kn7OR4rQBtCCd5grVmuZLu=fabs(sm_FStFcQlyAJ_dVy4kGZXBPQ[2]);real_T
sm_knamDCITCbKjXew_Mtv_8s;int sm_VgCUWD77M3p7h5wHUW6Rj9;if(
sm_kY_rL_F8Nc0DiX9ImprC4_>=sm_kkkJJmKdVddMYirZwDaWI_){if(
sm_kY_rL_F8Nc0DiX9ImprC4_>=sm_kn7OR4rQBtCCd5grVmuZLu)sm_knamDCITCbKjXew_Mtv_8s
=sm_kY_rL_F8Nc0DiX9ImprC4_,sm_VgCUWD77M3p7h5wHUW6Rj9=0;else
sm_knamDCITCbKjXew_Mtv_8s=sm_kn7OR4rQBtCCd5grVmuZLu,sm_VgCUWD77M3p7h5wHUW6Rj9=
2;}else{if(sm_kkkJJmKdVddMYirZwDaWI_>=sm_kn7OR4rQBtCCd5grVmuZLu)
sm_knamDCITCbKjXew_Mtv_8s=sm_kkkJJmKdVddMYirZwDaWI_,sm_VgCUWD77M3p7h5wHUW6Rj9=
1;else sm_knamDCITCbKjXew_Mtv_8s=sm_kn7OR4rQBtCCd5grVmuZLu,
sm_VgCUWD77M3p7h5wHUW6Rj9=2;}if(fabs(sm_kyfq6L_eQbdYcPuOovpRDW)<1.0e-10*
sm_knamDCITCbKjXew_Mtv_8s){*sm_FOdkmT7jBb4LcqK4Pu9cA3&=~(1<<
sm_VgCUWD77M3p7h5wHUW6Rj9);sm_FdnL4nnTkgSqV90Sd_2_Vx(sm_kHyFeJsHAGdqW1uya_2WO5
,-1,sm_FOdkmT7jBb4LcqK4Pu9cA3,sm_k7RVes5oHPO2Yi5DMSKkeo);return;}}
sm_ksNwqwBbYj_4b5edpJakga=0;sm_kIRXiT7AM00NeLMByGqY73=1.0e100;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<3;++
sm_kwrB3ZoKf7OufTHWaHJV7a){const size_t sm_kMTy37a8TehzcLiuYGqV3M=
sm__mNZl3Dws0SzjmkHXP_BQz[sm_kwrB3ZoKf7OufTHWaHJV7a];if(
sm_kMTy37a8TehzcLiuYGqV3M!=(size_t)sm__OhtPosUzNtdWmQIbxRfnx){if(
sm_FStFcQlyAJ_dVy4kGZXBPQ[sm_kwrB3ZoKf7OufTHWaHJV7a]*sm_kyfq6L_eQbdYcPuOovpRDW
<=0.0){int sm_kxxsc7psSv_IYPVSdgmxG8= *sm_FOdkmT7jBb4LcqK4Pu9cA3;real_T
sm_k5iiHLlORl0BgHk0uNfg7_[2],sm_F5U8Z42ivq0rgXHzE7grZD;
sm_FJDxOUSymMGic5lC7ZhrnL sm_VgJW5ZqpwPpuY1inYtaofQ;sm_kxxsc7psSv_IYPVSdgmxG8
&=~(1<<sm_kMTy37a8TehzcLiuYGqV3M);sm_FdnL4nnTkgSqV90Sd_2_Vx(
sm_kHyFeJsHAGdqW1uya_2WO5,sm__OhtPosUzNtdWmQIbxRfnx,&sm_kxxsc7psSv_IYPVSdgmxG8
,sm_k5iiHLlORl0BgHk0uNfg7_);sm_FlRYiIS9Oc8yiqhApQXUvX(
sm_kHyFeJsHAGdqW1uya_2WO5,sm_kxxsc7psSv_IYPVSdgmxG8,sm_k5iiHLlORl0BgHk0uNfg7_,
&sm_VgJW5ZqpwPpuY1inYtaofQ);sm_F5U8Z42ivq0rgXHzE7grZD=pm_math_Vector3_dot(&
sm_VgJW5ZqpwPpuY1inYtaofQ,&sm_VgJW5ZqpwPpuY1inYtaofQ);if(
sm_F5U8Z42ivq0rgXHzE7grZD<sm_kIRXiT7AM00NeLMByGqY73){sm_ksNwqwBbYj_4b5edpJakga
=sm_kxxsc7psSv_IYPVSdgmxG8;sm_k7RVes5oHPO2Yi5DMSKkeo[0]=
sm_k5iiHLlORl0BgHk0uNfg7_[0],sm_k7RVes5oHPO2Yi5DMSKkeo[1]=
sm_k5iiHLlORl0BgHk0uNfg7_[1];sm_kIRXiT7AM00NeLMByGqY73=
sm_F5U8Z42ivq0rgXHzE7grZD;}}}}if(sm_ksNwqwBbYj_4b5edpJakga==0){
sm_k7RVes5oHPO2Yi5DMSKkeo[0]=sm_FStFcQlyAJ_dVy4kGZXBPQ[0]/
sm_kyfq6L_eQbdYcPuOovpRDW;sm_k7RVes5oHPO2Yi5DMSKkeo[1]=
sm_FStFcQlyAJ_dVy4kGZXBPQ[1]/sm_kyfq6L_eQbdYcPuOovpRDW;
sm_k7RVes5oHPO2Yi5DMSKkeo[2]=sm_FStFcQlyAJ_dVy4kGZXBPQ[2]/
sm_kyfq6L_eQbdYcPuOovpRDW;}else*sm_FOdkmT7jBb4LcqK4Pu9cA3=
sm_ksNwqwBbYj_4b5edpJakga;}static void sm_FDZiVGZcog_zX5aYfMfwFp(const
sm_FJDxOUSymMGic5lC7ZhrnL sm_kHyFeJsHAGdqW1uya_2WO5[4][3],int
sm__OhtPosUzNtdWmQIbxRfnx,int*sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T*
sm_k7RVes5oHPO2Yi5DMSKkeo){int sm_kwrB3ZoKf7OufTHWaHJV7a,
sm_ksNwqwBbYj_4b5edpJakga;real_T sm_kyfq6L_eQbdYcPuOovpRDW,
sm_FStFcQlyAJ_dVy4kGZXBPQ[4],sm_kIRXiT7AM00NeLMByGqY73;
sm_FStFcQlyAJ_dVy4kGZXBPQ[0]= -sm_V_FoLVGO37G4eXJuucTSjm(&
sm_kHyFeJsHAGdqW1uya_2WO5[1][2],&sm_kHyFeJsHAGdqW1uya_2WO5[2][2],&
sm_kHyFeJsHAGdqW1uya_2WO5[3][2]);sm_FStFcQlyAJ_dVy4kGZXBPQ[1]= +
sm_V_FoLVGO37G4eXJuucTSjm(&sm_kHyFeJsHAGdqW1uya_2WO5[0][2],&
sm_kHyFeJsHAGdqW1uya_2WO5[2][2],&sm_kHyFeJsHAGdqW1uya_2WO5[3][2]);
sm_FStFcQlyAJ_dVy4kGZXBPQ[2]= -sm_V_FoLVGO37G4eXJuucTSjm(&
sm_kHyFeJsHAGdqW1uya_2WO5[0][2],&sm_kHyFeJsHAGdqW1uya_2WO5[1][2],&
sm_kHyFeJsHAGdqW1uya_2WO5[3][2]);sm_FStFcQlyAJ_dVy4kGZXBPQ[3]= +
sm_V_FoLVGO37G4eXJuucTSjm(&sm_kHyFeJsHAGdqW1uya_2WO5[0][2],&
sm_kHyFeJsHAGdqW1uya_2WO5[1][2],&sm_kHyFeJsHAGdqW1uya_2WO5[2][2]);
sm_kyfq6L_eQbdYcPuOovpRDW=sm_FStFcQlyAJ_dVy4kGZXBPQ[0]+
sm_FStFcQlyAJ_dVy4kGZXBPQ[1]+sm_FStFcQlyAJ_dVy4kGZXBPQ[2]+
sm_FStFcQlyAJ_dVy4kGZXBPQ[3];{int sm_VgCUWD77M3p7h5wHUW6Rj9=0;real_T
sm_knamDCITCbKjXew_Mtv_8s=fabs(sm_FStFcQlyAJ_dVy4kGZXBPQ[0]);for(
sm_kwrB3ZoKf7OufTHWaHJV7a=1;sm_kwrB3ZoKf7OufTHWaHJV7a<4;++
sm_kwrB3ZoKf7OufTHWaHJV7a){const real_T sm_Fkbrfbd5DA0yb1kdOaIHtl=fabs(
sm_FStFcQlyAJ_dVy4kGZXBPQ[sm_kwrB3ZoKf7OufTHWaHJV7a]);if(
sm_Fkbrfbd5DA0yb1kdOaIHtl>sm_knamDCITCbKjXew_Mtv_8s)sm_VgCUWD77M3p7h5wHUW6Rj9=
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_knamDCITCbKjXew_Mtv_8s=sm_Fkbrfbd5DA0yb1kdOaIHtl;
}if(fabs(sm_kyfq6L_eQbdYcPuOovpRDW)<1.0e-10*sm_knamDCITCbKjXew_Mtv_8s){*
sm_FOdkmT7jBb4LcqK4Pu9cA3&=~(1<<sm_VgCUWD77M3p7h5wHUW6Rj9);
sm__xbY9Wq3kdtBdPxIQuMurJ(sm_kHyFeJsHAGdqW1uya_2WO5,-1,
sm_FOdkmT7jBb4LcqK4Pu9cA3,sm_k7RVes5oHPO2Yi5DMSKkeo);return;}}
sm_ksNwqwBbYj_4b5edpJakga=0;sm_kIRXiT7AM00NeLMByGqY73=1.0e100;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<4;++
sm_kwrB3ZoKf7OufTHWaHJV7a){if(sm_kwrB3ZoKf7OufTHWaHJV7a!=
sm__OhtPosUzNtdWmQIbxRfnx){if(sm_FStFcQlyAJ_dVy4kGZXBPQ[
sm_kwrB3ZoKf7OufTHWaHJV7a]*sm_kyfq6L_eQbdYcPuOovpRDW<=0.0){int
sm_kxxsc7psSv_IYPVSdgmxG8= *sm_FOdkmT7jBb4LcqK4Pu9cA3;real_T
sm_k5iiHLlORl0BgHk0uNfg7_[3],sm_F5U8Z42ivq0rgXHzE7grZD;
sm_FJDxOUSymMGic5lC7ZhrnL sm_VgJW5ZqpwPpuY1inYtaofQ;sm_kxxsc7psSv_IYPVSdgmxG8
&=~(1<<sm_kwrB3ZoKf7OufTHWaHJV7a);sm__xbY9Wq3kdtBdPxIQuMurJ(
sm_kHyFeJsHAGdqW1uya_2WO5,sm__OhtPosUzNtdWmQIbxRfnx,&sm_kxxsc7psSv_IYPVSdgmxG8
,sm_k5iiHLlORl0BgHk0uNfg7_);sm_FlRYiIS9Oc8yiqhApQXUvX(
sm_kHyFeJsHAGdqW1uya_2WO5,sm_kxxsc7psSv_IYPVSdgmxG8,sm_k5iiHLlORl0BgHk0uNfg7_,
&sm_VgJW5ZqpwPpuY1inYtaofQ);sm_F5U8Z42ivq0rgXHzE7grZD=pm_math_Vector3_dot(&
sm_VgJW5ZqpwPpuY1inYtaofQ,&sm_VgJW5ZqpwPpuY1inYtaofQ);if(
sm_F5U8Z42ivq0rgXHzE7grZD<sm_kIRXiT7AM00NeLMByGqY73){sm_ksNwqwBbYj_4b5edpJakga
=sm_kxxsc7psSv_IYPVSdgmxG8;sm_k7RVes5oHPO2Yi5DMSKkeo[0]=
sm_k5iiHLlORl0BgHk0uNfg7_[0];sm_k7RVes5oHPO2Yi5DMSKkeo[1]=
sm_k5iiHLlORl0BgHk0uNfg7_[1];sm_k7RVes5oHPO2Yi5DMSKkeo[2]=
sm_k5iiHLlORl0BgHk0uNfg7_[2];sm_kIRXiT7AM00NeLMByGqY73=
sm_F5U8Z42ivq0rgXHzE7grZD;}}}}if(sm_ksNwqwBbYj_4b5edpJakga==0){
sm_k7RVes5oHPO2Yi5DMSKkeo[0]=sm_FStFcQlyAJ_dVy4kGZXBPQ[0]/
sm_kyfq6L_eQbdYcPuOovpRDW;sm_k7RVes5oHPO2Yi5DMSKkeo[1]=
sm_FStFcQlyAJ_dVy4kGZXBPQ[1]/sm_kyfq6L_eQbdYcPuOovpRDW;
sm_k7RVes5oHPO2Yi5DMSKkeo[2]=sm_FStFcQlyAJ_dVy4kGZXBPQ[2]/
sm_kyfq6L_eQbdYcPuOovpRDW;sm_k7RVes5oHPO2Yi5DMSKkeo[3]=
sm_FStFcQlyAJ_dVy4kGZXBPQ[3]/sm_kyfq6L_eQbdYcPuOovpRDW;}else*
sm_FOdkmT7jBb4LcqK4Pu9cA3=sm_ksNwqwBbYj_4b5edpJakga;}static void
sm_V4e27rMSGpKGiaLaBZER7d(const sm_FJDxOUSymMGic5lC7ZhrnL
sm_kHyFeJsHAGdqW1uya_2WO5[4][3],int sm__OhtPosUzNtdWmQIbxRfnx,int*
sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T sm_k7RVes5oHPO2Yi5DMSKkeo[3]){const int n=
sm_VQ0A0Sv5GWprb1MDSztvuk[*sm_FOdkmT7jBb4LcqK4Pu9cA3]-1;switch(n){case 3:
sm_FDZiVGZcog_zX5aYfMfwFp(sm_kHyFeJsHAGdqW1uya_2WO5,sm__OhtPosUzNtdWmQIbxRfnx,
sm_FOdkmT7jBb4LcqK4Pu9cA3,sm_k7RVes5oHPO2Yi5DMSKkeo);break;case 2:
sm__xbY9Wq3kdtBdPxIQuMurJ(sm_kHyFeJsHAGdqW1uya_2WO5,sm__OhtPosUzNtdWmQIbxRfnx,
sm_FOdkmT7jBb4LcqK4Pu9cA3,sm_k7RVes5oHPO2Yi5DMSKkeo);break;case 1:
sm_FdnL4nnTkgSqV90Sd_2_Vx(sm_kHyFeJsHAGdqW1uya_2WO5,sm__OhtPosUzNtdWmQIbxRfnx,
sm_FOdkmT7jBb4LcqK4Pu9cA3,sm_k7RVes5oHPO2Yi5DMSKkeo);break;case 0:
sm_k7RVes5oHPO2Yi5DMSKkeo[0]=1.0;break;}}real_T sm___5fPI_mfAGueitrdQJ5ul(
sm_FJDxOUSymMGic5lC7ZhrnL sm_kHyFeJsHAGdqW1uya_2WO5[4][3],int*
sm_FOdkmT7jBb4LcqK4Pu9cA3,const void*sm_kgkmYuXOxPtmdTDiHKeNa5,
sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,const void*
sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG sm_kr84ZslsgzG2ei26cNKR9_,
const sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe){const size_t*
sm__mNZl3Dws0SzjmkHXP_BQz=sm_k2PuWUcQ_UtHYDFpzYchpd[*sm_FOdkmT7jBb4LcqK4Pu9cA3
];sm_FJDxOUSymMGic5lC7ZhrnL n;sm_FJDxOUSymMGic5lC7ZhrnL
sm_FOTdVRJPGqhNba6tdltNZZ,sm_VCifngWB8ylih96lyIXhqB,sm_kKqBGNT_1FKwc50fpD5uis;
sm_FJDxOUSymMGic5lC7ZhrnL sm_VPoUbJUlYg0WaXdmtt1Huf;sm_FJDxOUSymMGic5lC7ZhrnL
sm_kpVk0WGYlRKHbewq41x9uF[3],sm_k9JGE1wG3YSaiqqcy6mvNS[3];
sm_FJDxOUSymMGic5lC7ZhrnL sm_kVFmnbWkyy0LfyvBnLonNP;real_T
sm_FlNS_jIgWatX_XbUxaqWPa,sm_VYjLOtl_CMxjXXS4VrY5yO;sm__6dBgrcOk_GXieU6ApKSyW(
(const sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])sm_kHyFeJsHAGdqW1uya_2WO5,2,
sm__mNZl3Dws0SzjmkHXP_BQz,sm_kpVk0WGYlRKHbewq41x9uF,&sm_kVFmnbWkyy0LfyvBnLonNP
,sm_k9JGE1wG3YSaiqqcy6mvNS,&n);sm_kkIDwZB8zm4Pjyeyqv1cv5(
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,sm_F4kGV66idSlLj12YnANYlJ,
sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe,
&n,&sm_FOTdVRJPGqhNba6tdltNZZ,&sm_VCifngWB8ylih96lyIXhqB,&
sm_kKqBGNT_1FKwc50fpD5uis);pm_math_Vector3_subtract(&sm_kKqBGNT_1FKwc50fpD5uis
,&sm_kHyFeJsHAGdqW1uya_2WO5[sm__mNZl3Dws0SzjmkHXP_BQz[0]][0],&
sm_VPoUbJUlYg0WaXdmtt1Huf);sm_FlNS_jIgWatX_XbUxaqWPa=pm_math_Vector3_dot(&
sm_VPoUbJUlYg0WaXdmtt1Huf,&n);pm_math_Vector3_negate(&n,&n);
sm_kkIDwZB8zm4Pjyeyqv1cv5(sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,
sm_F4kGV66idSlLj12YnANYlJ,sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,
sm_FGPQyC36Ly4PgaEVTyCKbe,&n,&sm_FOTdVRJPGqhNba6tdltNZZ,&
sm_VCifngWB8ylih96lyIXhqB,&sm_kKqBGNT_1FKwc50fpD5uis);pm_math_Vector3_subtract
(&sm_kKqBGNT_1FKwc50fpD5uis,&sm_kHyFeJsHAGdqW1uya_2WO5[
sm__mNZl3Dws0SzjmkHXP_BQz[0]][0],&sm_VPoUbJUlYg0WaXdmtt1Huf);
sm_VYjLOtl_CMxjXXS4VrY5yO=pm_math_Vector3_dot(&sm_VPoUbJUlYg0WaXdmtt1Huf,&n);
return(sm_FlNS_jIgWatX_XbUxaqWPa<sm_VYjLOtl_CMxjXXS4VrY5yO?
sm_FlNS_jIgWatX_XbUxaqWPa:sm_VYjLOtl_CMxjXXS4VrY5yO)/pm_math_Vector3_norm(&n);
}boolean_T sm_Vh1_44SlmTOhY1HNQIICca(sm_FJDxOUSymMGic5lC7ZhrnL
sm_kHyFeJsHAGdqW1uya_2WO5[4][3],int*sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T
sm_VWHEU_oaO2WtaP7gkPamVl,real_T sm_FfDTppU8N_tOWuLK37x_08,const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe){real_T sm_kOBZciiPjSd_f9gtTNt5Do,
sm_Fdz1ggcPpLxJV9ZNbaEDax,sm_Vba5hjf_scWOYXCaqzJdzO;int
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_VU18hM_2GHSHWue20_mnXQ;if(*
sm_FOdkmT7jBb4LcqK4Pu9cA3==0xF){return true;}sm_Fdz1ggcPpLxJV9ZNbaEDax=0.0;for
(sm_kwrB3ZoKf7OufTHWaHJV7a=0,sm_VU18hM_2GHSHWue20_mnXQ=1;
sm_kwrB3ZoKf7OufTHWaHJV7a<4;++sm_kwrB3ZoKf7OufTHWaHJV7a,
sm_VU18hM_2GHSHWue20_mnXQ<<=1){if((*sm_FOdkmT7jBb4LcqK4Pu9cA3&
sm_VU18hM_2GHSHWue20_mnXQ)!=0){const real_T sm_VZ1PPWRmmSSpgi0CzOE2JQ=
pm_math_Vector3_dot(&sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][2],&
sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][2]);if(
sm_VZ1PPWRmmSSpgi0CzOE2JQ>sm_Fdz1ggcPpLxJV9ZNbaEDax)sm_Fdz1ggcPpLxJV9ZNbaEDax=
sm_VZ1PPWRmmSSpgi0CzOE2JQ;}}sm_kOBZciiPjSd_f9gtTNt5Do=sqrt(
sm_Fdz1ggcPpLxJV9ZNbaEDax);sm_Vba5hjf_scWOYXCaqzJdzO=sm_FfDTppU8N_tOWuLK37x_08
*sm_kOBZciiPjSd_f9gtTNt5Do;if(sm_VWHEU_oaO2WtaP7gkPamVl<=
sm_Vba5hjf_scWOYXCaqzJdzO){return true;}if(sm_VQ0A0Sv5GWprb1MDSztvuk[*
sm_FOdkmT7jBb4LcqK4Pu9cA3]==3){if(sm_VWHEU_oaO2WtaP7gkPamVl<=10*
sm_Vba5hjf_scWOYXCaqzJdzO){real_T sm_FIU9yCcafX4JVLNOAk4OCy=
sm___5fPI_mfAGueitrdQJ5ul(sm_kHyFeJsHAGdqW1uya_2WO5,sm_FOdkmT7jBb4LcqK4Pu9cA3,
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,sm_F4kGV66idSlLj12YnANYlJ,
sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe)
;if(sm_FIU9yCcafX4JVLNOAk4OCy>1.0e-8*(sm_Fdz1ggcPpLxJV9ZNbaEDax)){return true;
}}}return false;}boolean_T sm__vOk4P4g2_S3W9JJAwV14B(const void*
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__jsfq5ol9RO0emwniHUfEG sm__TDB1qycHttnhabay6VIVQ,
const void*sm_F4kGV66idSlLj12YnANYlJ,sm__jsfq5ol9RO0emwniHUfEG
sm_kr84ZslsgzG2ei26cNKR9_,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm__yWh8B7tCCdhiXMhhHUqbN,const sm_k4kL9Om6RgxTZqdxJRM51B*
sm_FGPQyC36Ly4PgaEVTyCKbe,real_T sm_kHfMSiCBJRSoju34wwOKOx,boolean_T
sm__onsZLH_ytSGhXn0uJU7bM,sm_FJDxOUSymMGic5lC7ZhrnL sm_kHyFeJsHAGdqW1uya_2WO5[
4][3],int*sm_FOdkmT7jBb4LcqK4Pu9cA3,real_T*sm_Vrk3Pgb1wrhnZmcOkBtvtB,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kSBaR7c6O38sa5ZMZ1k4Y1,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kburdpU0IjpOXyPmyulx88){int sm_FFsuQCG7t_tPjLkBG5xyTx,
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_VU18hM_2GHSHWue20_mnXQ,sm_kQR_dvX384WTaHXnTc5mPL;
real_T sm_FfDTppU8N_tOWuLK37x_08=1.0e-12;boolean_T sm_FFjhhaat7SpAcD3Nm9hD2N=
false;boolean_T sm__sj4Zxp6uxl9fXu8v5iGfM=false;real_T
sm_V5oIfiXv7oWja1Pk03zPhj=0.0;real_T sm__doXtAi8xItyburV7Wsu2b=0.0;real_T
sm_VWHEU_oaO2WtaP7gkPamVl=0.0;real_T sm_k7RVes5oHPO2Yi5DMSKkeo[4];
sm_FJDxOUSymMGic5lC7ZhrnL sm_VgJW5ZqpwPpuY1inYtaofQ,sm__S1KkqUqaFK9huLL5uNrBl,
sm__Ym8MwanDSdYc5d5L4xVRq,sm_V1pxxydYEnWVVi3QKesjvf,sm_F1LfOOnBFbpFWi7QXSZyNj;
sm_FJDxOUSymMGic5lC7ZhrnL sm_F9yDQxbxjNlSeXydMwl6yG;pm_math_Vector3_subtract(&
sm__yWh8B7tCCdhiXMhhHUqbN->sm_F32Ql82vv6pW_PYIdpkFQ0,&
sm_FGPQyC36Ly4PgaEVTyCKbe->sm_F32Ql82vv6pW_PYIdpkFQ0,&
sm_F9yDQxbxjNlSeXydMwl6yG);if(sm_F9yDQxbxjNlSeXydMwl6yG.x==0.0&&
sm_F9yDQxbxjNlSeXydMwl6yG.sm_FzyLWRgau0pMYq2XSI3ETL==0.0&&
sm_F9yDQxbxjNlSeXydMwl6yG.sm_FBDi_PCg670TjHgJTNPcHr==0.0)
sm_F9yDQxbxjNlSeXydMwl6yG.sm_FBDi_PCg670TjHgJTNPcHr=1.0;*
sm_Vrk3Pgb1wrhnZmcOkBtvtB=0.0;*sm_FOdkmT7jBb4LcqK4Pu9cA3=0;
sm_kkIDwZB8zm4Pjyeyqv1cv5(sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,
sm_F4kGV66idSlLj12YnANYlJ,sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,
sm_FGPQyC36Ly4PgaEVTyCKbe,&sm_F9yDQxbxjNlSeXydMwl6yG,&
sm_kHyFeJsHAGdqW1uya_2WO5[0][0],&sm_kHyFeJsHAGdqW1uya_2WO5[0][1],&
sm_kHyFeJsHAGdqW1uya_2WO5[0][2]);*sm_FOdkmT7jBb4LcqK4Pu9cA3=1;
sm_k7RVes5oHPO2Yi5DMSKkeo[0]=1.0;sm_VgJW5ZqpwPpuY1inYtaofQ=
sm_kHyFeJsHAGdqW1uya_2WO5[0][2];sm_kQR_dvX384WTaHXnTc5mPL=0;for(
sm_FFsuQCG7t_tPjLkBG5xyTx=0;sm_FFsuQCG7t_tPjLkBG5xyTx<200&&*
sm_FOdkmT7jBb4LcqK4Pu9cA3!=0x0F;++sm_FFsuQCG7t_tPjLkBG5xyTx,++
sm_kQR_dvX384WTaHXnTc5mPL){if((0>=(2)&&true)){pmf_printf("\nGJK Iter %d\n",
sm_FFsuQCG7t_tPjLkBG5xyTx+1);if((0>=(3)&&true)){int sm_FQferGZUKft3_i5GvYy4Oy;
const char*sm_Fy_wyqR8Xf_uh1TOlojtsJ[3]={"Geom 0","Geom 1","Minkowski"};
pmf_printf("simplexFlags: %d\n",*sm_FOdkmT7jBb4LcqK4Pu9cA3);for(
sm_FQferGZUKft3_i5GvYy4Oy=0;sm_FQferGZUKft3_i5GvYy4Oy<3;++
sm_FQferGZUKft3_i5GvYy4Oy){pmf_printf("%s\n",sm_Fy_wyqR8Xf_uh1TOlojtsJ[
sm_FQferGZUKft3_i5GvYy4Oy]);for(sm_kwrB3ZoKf7OufTHWaHJV7a=0,
sm_VU18hM_2GHSHWue20_mnXQ=1;sm_kwrB3ZoKf7OufTHWaHJV7a<4;++
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_VU18hM_2GHSHWue20_mnXQ<<=1)if((*
sm_FOdkmT7jBb4LcqK4Pu9cA3&sm_VU18hM_2GHSHWue20_mnXQ)!=0)pmf_printf(
"  simplex[%d] = [ %+13.6e %+13.6e %+13.6e ]'\n",sm_kwrB3ZoKf7OufTHWaHJV7a,
sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][sm_FQferGZUKft3_i5GvYy4Oy
].x,sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][
sm_FQferGZUKft3_i5GvYy4Oy].sm_FzyLWRgau0pMYq2XSI3ETL,sm_kHyFeJsHAGdqW1uya_2WO5
[sm_kwrB3ZoKf7OufTHWaHJV7a][sm_FQferGZUKft3_i5GvYy4Oy].
sm_FBDi_PCg670TjHgJTNPcHr);}pmf_printf(
"  v =          [ %+13.6e %+13.6e %+13.6e ]'\n",sm_VgJW5ZqpwPpuY1inYtaofQ.x,
sm_VgJW5ZqpwPpuY1inYtaofQ.sm_FzyLWRgau0pMYq2XSI3ETL,sm_VgJW5ZqpwPpuY1inYtaofQ.
sm_FBDi_PCg670TjHgJTNPcHr);}}pm_math_Vector3_negate(&sm_VgJW5ZqpwPpuY1inYtaofQ
,&sm_F1LfOOnBFbpFWi7QXSZyNj);sm_kkIDwZB8zm4Pjyeyqv1cv5(
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,sm_F4kGV66idSlLj12YnANYlJ,
sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe,
&sm_F1LfOOnBFbpFWi7QXSZyNj,&sm__S1KkqUqaFK9huLL5uNrBl,&
sm__Ym8MwanDSdYc5d5L4xVRq,&sm_V1pxxydYEnWVVi3QKesjvf);if((0>=(3)&&true)){int
sm_FQferGZUKft3_i5GvYy4Oy;const char*sm_FX6wAiSDe8GIZmcz7Sh3lo[3]={"w0","w1",
"wM"};const sm_FJDxOUSymMGic5lC7ZhrnL*sm__2pALOaESl8mXyXP_Xhdy_[3];
sm__2pALOaESl8mXyXP_Xhdy_[0]= &sm__S1KkqUqaFK9huLL5uNrBl,
sm__2pALOaESl8mXyXP_Xhdy_[1]= &sm__Ym8MwanDSdYc5d5L4xVRq,
sm__2pALOaESl8mXyXP_Xhdy_[2]= &sm_V1pxxydYEnWVVi3QKesjvf;for(
sm_FQferGZUKft3_i5GvYy4Oy=0;sm_FQferGZUKft3_i5GvYy4Oy<3;++
sm_FQferGZUKft3_i5GvYy4Oy)pmf_printf(
"  %s =         [ %+13.6e %+13.6e %+13.6e ]'\n",sm_FX6wAiSDe8GIZmcz7Sh3lo[
sm_FQferGZUKft3_i5GvYy4Oy],sm__2pALOaESl8mXyXP_Xhdy_[sm_FQferGZUKft3_i5GvYy4Oy
]->x,sm__2pALOaESl8mXyXP_Xhdy_[sm_FQferGZUKft3_i5GvYy4Oy]->
sm_FzyLWRgau0pMYq2XSI3ETL,sm__2pALOaESl8mXyXP_Xhdy_[sm_FQferGZUKft3_i5GvYy4Oy]
->sm_FBDi_PCg670TjHgJTNPcHr);}sm_VWHEU_oaO2WtaP7gkPamVl=pm_math_Vector3_norm(&
sm_VgJW5ZqpwPpuY1inYtaofQ);sm_FFjhhaat7SpAcD3Nm9hD2N=(
sm_VWHEU_oaO2WtaP7gkPamVl!=sm_VWHEU_oaO2WtaP7gkPamVl);if(
sm_FFjhhaat7SpAcD3Nm9hD2N)break;if(sm_VWHEU_oaO2WtaP7gkPamVl>0.0){const real_T
sm_VhdPbvAlxE_ociw9erLVwp=pm_math_Vector3_dot(&sm_V1pxxydYEnWVVi3QKesjvf,&
sm_VgJW5ZqpwPpuY1inYtaofQ)/sm_VWHEU_oaO2WtaP7gkPamVl;if(
sm_VhdPbvAlxE_ociw9erLVwp>sm_V5oIfiXv7oWja1Pk03zPhj){sm_V5oIfiXv7oWja1Pk03zPhj
=sm_VhdPbvAlxE_ociw9erLVwp;sm_kQR_dvX384WTaHXnTc5mPL=0;}else if(
sm_kQR_dvX384WTaHXnTc5mPL>5){if(sm_VhdPbvAlxE_ociw9erLVwp>
sm__doXtAi8xItyburV7Wsu2b)sm__doXtAi8xItyburV7Wsu2b=sm_VhdPbvAlxE_ociw9erLVwp;
if(sm_kQR_dvX384WTaHXnTc5mPL>2*5&&sm_VhdPbvAlxE_ociw9erLVwp>=
sm__doXtAi8xItyburV7Wsu2b){if((0>=(3)&&true))pmf_printf(
"Cycle detected in GJK; breaking out\n");break;}}}if((0>=(3)&&true)){
pmf_printf("  vNorm:          %+19.12e\n",sm_VWHEU_oaO2WtaP7gkPamVl);
pmf_printf("  distLowerBound: %+19.12e\n",sm_V5oIfiXv7oWja1Pk03zPhj);
pmf_printf("  tol:            %+19.12e\n",sm_FfDTppU8N_tOWuLK37x_08);
pmf_printf("  scale:          %+19.12e\n",sm_kHfMSiCBJRSoju34wwOKOx);
pmf_printf("  check:          %+13.6e\n",sm_VWHEU_oaO2WtaP7gkPamVl-(
sm_V5oIfiXv7oWja1Pk03zPhj+sm_FfDTppU8N_tOWuLK37x_08*sm_kHfMSiCBJRSoju34wwOKOx)
);}if(sm_VWHEU_oaO2WtaP7gkPamVl<sm_V5oIfiXv7oWja1Pk03zPhj+
sm_FfDTppU8N_tOWuLK37x_08*sm_kHfMSiCBJRSoju34wwOKOx)break;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0,sm_VU18hM_2GHSHWue20_mnXQ=1;
sm_kwrB3ZoKf7OufTHWaHJV7a<4;++sm_kwrB3ZoKf7OufTHWaHJV7a,
sm_VU18hM_2GHSHWue20_mnXQ<<=1)if((*sm_FOdkmT7jBb4LcqK4Pu9cA3&
sm_VU18hM_2GHSHWue20_mnXQ)!=0&&sm__oPrRWZb_p0tbD5Lt0Lq4Z(&
sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][2],&
sm_V1pxxydYEnWVVi3QKesjvf))break;if(sm_kwrB3ZoKf7OufTHWaHJV7a<4)break;
sm_kwrB3ZoKf7OufTHWaHJV7a=sm__qx74ytYCql1WuG2KqMfQS[*sm_FOdkmT7jBb4LcqK4Pu9cA3
];*sm_FOdkmT7jBb4LcqK4Pu9cA3|=(1<<sm_kwrB3ZoKf7OufTHWaHJV7a);
sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][0]=
sm__S1KkqUqaFK9huLL5uNrBl;sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a]
[1]=sm__Ym8MwanDSdYc5d5L4xVRq;sm_kHyFeJsHAGdqW1uya_2WO5[
sm_kwrB3ZoKf7OufTHWaHJV7a][2]=sm_V1pxxydYEnWVVi3QKesjvf;
sm_V4e27rMSGpKGiaLaBZER7d((const sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])
sm_kHyFeJsHAGdqW1uya_2WO5,sm_kwrB3ZoKf7OufTHWaHJV7a,sm_FOdkmT7jBb4LcqK4Pu9cA3,
sm_k7RVes5oHPO2Yi5DMSKkeo);sm_FlRYiIS9Oc8yiqhApQXUvX((const
sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])sm_kHyFeJsHAGdqW1uya_2WO5,*
sm_FOdkmT7jBb4LcqK4Pu9cA3,sm_k7RVes5oHPO2Yi5DMSKkeo,&sm_VgJW5ZqpwPpuY1inYtaofQ
);}if(sm_FFjhhaat7SpAcD3Nm9hD2N){if((0>=(1)&&true))pmf_printf(
"GJK fault: NaN in simplex vector\n");*sm_Vrk3Pgb1wrhnZmcOkBtvtB=
sm_VWHEU_oaO2WtaP7gkPamVl;if(!sm__onsZLH_ytSGhXn0uJU7bM){
sm_kSBaR7c6O38sa5ZMZ1k4Y1->x=sm_kSBaR7c6O38sa5ZMZ1k4Y1->
sm_FzyLWRgau0pMYq2XSI3ETL=sm_kSBaR7c6O38sa5ZMZ1k4Y1->sm_FBDi_PCg670TjHgJTNPcHr
=sm_VWHEU_oaO2WtaP7gkPamVl;sm_kburdpU0IjpOXyPmyulx88->x=
sm_kburdpU0IjpOXyPmyulx88->sm_FzyLWRgau0pMYq2XSI3ETL=sm_kburdpU0IjpOXyPmyulx88
->sm_FBDi_PCg670TjHgJTNPcHr=sm_VWHEU_oaO2WtaP7gkPamVl;}return false;}
sm__sj4Zxp6uxl9fXu8v5iGfM=sm_Vh1_44SlmTOhY1HNQIICca(sm_kHyFeJsHAGdqW1uya_2WO5,
sm_FOdkmT7jBb4LcqK4Pu9cA3,sm_VWHEU_oaO2WtaP7gkPamVl,sm_FfDTppU8N_tOWuLK37x_08,
sm_kgkmYuXOxPtmdTDiHKeNa5,sm__TDB1qycHttnhabay6VIVQ,sm_F4kGV66idSlLj12YnANYlJ,
sm_kr84ZslsgzG2ei26cNKR9_,sm__yWh8B7tCCdhiXMhhHUqbN,sm_FGPQyC36Ly4PgaEVTyCKbe)
;if(!sm__sj4Zxp6uxl9fXu8v5iGfM){const real_T*sm__VUeq7b0oR40cyPlMWXOei=
sm_k7RVes5oHPO2Yi5DMSKkeo;if((0>=(2)&&true)){char sm_VGqPwlpTl6K0jeyUcOcudU[
512];const int sm_FkoBKJSu3bdQdPWZgD2fC8=sm_VQ0A0Sv5GWprb1MDSztvuk[*
sm_FOdkmT7jBb4LcqK4Pu9cA3];const size_t*sm__mNZl3Dws0SzjmkHXP_BQz=
sm_k2PuWUcQ_UtHYDFpzYchpd[*sm_FOdkmT7jBb4LcqK4Pu9cA3];
sm_F8eCImOfeYKdZuMlfsHdDH((const sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])
sm_kHyFeJsHAGdqW1uya_2WO5,0,sm_FkoBKJSu3bdQdPWZgD2fC8,
sm__mNZl3Dws0SzjmkHXP_BQz,sm_k7RVes5oHPO2Yi5DMSKkeo,sm_VGqPwlpTl6K0jeyUcOcudU)
;pmf_printf("Feature 0: %s\n",sm_VGqPwlpTl6K0jeyUcOcudU);
sm_F8eCImOfeYKdZuMlfsHdDH((const sm_FJDxOUSymMGic5lC7ZhrnL(*)[3])
sm_kHyFeJsHAGdqW1uya_2WO5,1,sm_FkoBKJSu3bdQdPWZgD2fC8,
sm__mNZl3Dws0SzjmkHXP_BQz,sm_k7RVes5oHPO2Yi5DMSKkeo,sm_VGqPwlpTl6K0jeyUcOcudU)
;pmf_printf("Feature 1: %s\n",sm_VGqPwlpTl6K0jeyUcOcudU);}if(!
sm__onsZLH_ytSGhXn0uJU7bM){sm_kSBaR7c6O38sa5ZMZ1k4Y1->x=
sm_kSBaR7c6O38sa5ZMZ1k4Y1->sm_FzyLWRgau0pMYq2XSI3ETL=sm_kSBaR7c6O38sa5ZMZ1k4Y1
->sm_FBDi_PCg670TjHgJTNPcHr=0.0;sm_kburdpU0IjpOXyPmyulx88->x=
sm_kburdpU0IjpOXyPmyulx88->sm_FzyLWRgau0pMYq2XSI3ETL=sm_kburdpU0IjpOXyPmyulx88
->sm_FBDi_PCg670TjHgJTNPcHr=0.0;for(sm_kwrB3ZoKf7OufTHWaHJV7a=0,
sm_VU18hM_2GHSHWue20_mnXQ=1;sm_kwrB3ZoKf7OufTHWaHJV7a<4;++
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_VU18hM_2GHSHWue20_mnXQ<<=1)if((*
sm_FOdkmT7jBb4LcqK4Pu9cA3&sm_VU18hM_2GHSHWue20_mnXQ)!=0){pm_math_Vector3_scale
(&sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][0],*
sm__VUeq7b0oR40cyPlMWXOei,&sm_F1LfOOnBFbpFWi7QXSZyNj);pm_math_Vector3_add(
sm_kSBaR7c6O38sa5ZMZ1k4Y1,&sm_F1LfOOnBFbpFWi7QXSZyNj,sm_kSBaR7c6O38sa5ZMZ1k4Y1
);pm_math_Vector3_scale(&sm_kHyFeJsHAGdqW1uya_2WO5[sm_kwrB3ZoKf7OufTHWaHJV7a][
1],*sm__VUeq7b0oR40cyPlMWXOei,&sm_F1LfOOnBFbpFWi7QXSZyNj);pm_math_Vector3_add(
sm_kburdpU0IjpOXyPmyulx88,&sm_F1LfOOnBFbpFWi7QXSZyNj,sm_kburdpU0IjpOXyPmyulx88
);++sm__VUeq7b0oR40cyPlMWXOei;}}*sm_Vrk3Pgb1wrhnZmcOkBtvtB=
sm_VWHEU_oaO2WtaP7gkPamVl;return false;}else{if((0>=(2)&&true))pmf_printf(
"Detected Penetration!\n");return true;}}
