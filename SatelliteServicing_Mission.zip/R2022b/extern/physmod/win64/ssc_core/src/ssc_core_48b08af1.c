#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
#include "ne_std.h"
void ssc_core_V81iI5z1xZOUeiCJ8AMtqC(const NeuDiagnosticTree*
ssc_core_kBj0wT0jErl0hDNP9N5QnJ);
#include "pm_std.h"
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);
#include "ne_std.h"
typedef struct ssc_core_kVAtZCZNf88lYiQwM5AQKG ssc_core__fsqLDrbYpKihm1eGDg1Gt
;typedef struct ssc_core_VFZYs2bhQ7hfVPoiZraac0 ssc_core_VBBN_xeCnNxOVL_sk_83e_
;struct ssc_core_kVAtZCZNf88lYiQwM5AQKG{ssc_core_VBBN_xeCnNxOVL_sk_83e_*
mPrivateData;const char*(*ssc_core_VNwUYfxptElMayUsox2R6t)(
ssc_core__fsqLDrbYpKihm1eGDg1Gt*ssc_core_VAHb4SwSnpW6d5eaPKPVMS,const
NeuDiagnosticTree*ssc_core_kBj0wT0jErl0hDNP9N5QnJ);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(ssc_core__fsqLDrbYpKihm1eGDg1Gt*
ssc_core_VAHb4SwSnpW6d5eaPKPVMS);};ssc_core__fsqLDrbYpKihm1eGDg1Gt*
neu_create_diagnostic_tree_printer(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z);
#include "ne_std.h"
const char*ssc_core_FklPsIWdcv4ra9YnF_YSgF(const NeuDiagnosticTree*
ssc_core_kBj0wT0jErl0hDNP9N5QnJ);const char*ssc_core__2lqkvRfia4Meqpodds2S6(
const NeuDiagnosticTree*ssc_core_kBj0wT0jErl0hDNP9N5QnJ);NeuDiagnosticLevel
ssc_core__6mDXRaqmlWxceo9irjPSa(const NeuDiagnosticTree*
ssc_core_kBj0wT0jErl0hDNP9N5QnJ);size_t ssc_core__lBbVf0HSftzcLnQ_Z0qa_(const
NeuDiagnosticTree*ssc_core_kBj0wT0jErl0hDNP9N5QnJ);const NeuDiagnosticTree*
ssc_core__FHcTUUP4s_rbu4n0hd0z2(const NeuDiagnosticTree*
ssc_core_kBj0wT0jErl0hDNP9N5QnJ,size_t ssc_core_V2__YrimeI4E_yWnhKofpy);void
ssc_core_V81iI5z1xZOUeiCJ8AMtqC(const NeuDiagnosticTree*
ssc_core_kBj0wT0jErl0hDNP9N5QnJ){ssc_core__fsqLDrbYpKihm1eGDg1Gt*
ssc_core_VAHb4SwSnpW6d5eaPKPVMS=neu_create_diagnostic_tree_printer(
pm_default_allocator());const char*ssc_core_kvsOBKjJwlx5dTxrw7qAwS=(
ssc_core_VAHb4SwSnpW6d5eaPKPVMS)->ssc_core_VNwUYfxptElMayUsox2R6t((
ssc_core_VAHb4SwSnpW6d5eaPKPVMS),(ssc_core_kBj0wT0jErl0hDNP9N5QnJ));
pmf_preformatted_warning(ssc_core_FklPsIWdcv4ra9YnF_YSgF(
ssc_core_kBj0wT0jErl0hDNP9N5QnJ),(ssc_core_VAHb4SwSnpW6d5eaPKPVMS)->
ssc_core_VNwUYfxptElMayUsox2R6t((ssc_core_VAHb4SwSnpW6d5eaPKPVMS),(
ssc_core_kBj0wT0jErl0hDNP9N5QnJ)));(ssc_core_VAHb4SwSnpW6d5eaPKPVMS)->
mc_VYGWBho6N1K_eyHOMGjDiW((ssc_core_VAHb4SwSnpW6d5eaPKPVMS));}
