#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
#include "ne_std.h"
typedef struct ssc_core_V3scVTYpjYthiPB7SQIxc_ ssc_core_FlZrG1BcKjtGV1aBRQ0fZ8
;typedef struct ssc_core_kIPOBZ_WiKlfjLUfb6Vbcm ssc_core__SHoBDzmLMOwaLvvD5hSet
;struct ssc_core_kIPOBZ_WiKlfjLUfb6Vbcm{boolean_T(*
ssc_core_FBsF3SW3Cyp_j5Pu5wPhdl)(const ssc_core__SHoBDzmLMOwaLvvD5hSet*
ssc_core_FeUzPe0YQn4rca7KjD_v4G,const NeSystemInput*mc_kDRphcAfRHSbf1ZLKEDW9k)
;void(*mc_VrNsQKHIiLOFaL3PHRFxZL)(const ssc_core__SHoBDzmLMOwaLvvD5hSet*
ssc_core_FeUzPe0YQn4rca7KjD_v4G);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core_FeUzPe0YQn4rca7KjD_v4G);
ssc_core_FlZrG1BcKjtGV1aBRQ0fZ8*mc_VFNhKLCqbHpDYXjdjCOMmT;};
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core_VlRDyoY8Z4C2Vy6qnfIfjk(
NeSystemInputSizes sizes,boolean_T ssc_core_kFxS3Lt0_2dX_mARPrjLL1,boolean_T
ssc_core__5hVjWGkxohgVTAjSVMW3a,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core__BnL6AKHA_KDhap6bFRZzx(
NeSystemInputSizes sizes,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core_FNXCmS38tFlnW5HGhPIM6s(
NeSystemInputSizes sizes,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core_kBca8i4PhxS0j9d1s9qjOH(
NeSystemInputSizes sizes,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core_VlRDyoY8Z4C2Vy6qnfIfjk(
NeSystemInputSizes sizes,boolean_T ssc_core_kFxS3Lt0_2dX_mARPrjLL1,boolean_T
ssc_core__5hVjWGkxohgVTAjSVMW3a,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY){if(
ssc_core__5hVjWGkxohgVTAjSVMW3a){return ssc_core_kBca8i4PhxS0j9d1s9qjOH(sizes,
pm_FbYb_iLqY2hwZTVlVaiqJY);}else if(ssc_core_kFxS3Lt0_2dX_mARPrjLL1){return
ssc_core__BnL6AKHA_KDhap6bFRZzx(sizes,pm_FbYb_iLqY2hwZTVlVaiqJY);}else{return
ssc_core_FNXCmS38tFlnW5HGhPIM6s(sizes,pm_FbYb_iLqY2hwZTVlVaiqJY);}}
