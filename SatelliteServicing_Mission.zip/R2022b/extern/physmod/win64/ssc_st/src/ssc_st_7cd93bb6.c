#include "pm_std.h"
#include "ne_std.h"
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
NeDynamicSystemInputSizes neu_get_empty_dynamic_system_input_sizes(void){
NeDynamicSystemInputSizes sizes;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_Q]=0;
sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_M]=0;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_T]=0;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_U]=0;
sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_V]=0;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_X]=0;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_D]=0;
sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_E]=0;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CR]=0;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_CI]=0
;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_W]=0;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_S]=0;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_P_L]=0
;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_P_I]=0;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_J]=0;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_P_R]
=0;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_DP_L]=0;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_I]=0;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_J]=0;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_R]=0;return sizes;}NeDynamicSystemInputSizes
neu_get_dynamic_system_input_sizes(const NeDynamicSystemInput*
mc__XfQXtB6cfd9fyc_v3eEup){NeDynamicSystemInputSizes sizes;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_Q]=mc__XfQXtB6cfd9fyc_v3eEup->mQ.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_M]=mc__XfQXtB6cfd9fyc_v3eEup->mM.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_T]=mc__XfQXtB6cfd9fyc_v3eEup->mT.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_U]=mc__XfQXtB6cfd9fyc_v3eEup->mU.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_V]=mc__XfQXtB6cfd9fyc_v3eEup->mV.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_X]=mc__XfQXtB6cfd9fyc_v3eEup->mX.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_D]=mc__XfQXtB6cfd9fyc_v3eEup->mD.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_E]=mc__XfQXtB6cfd9fyc_v3eEup->mE.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CR]=mc__XfQXtB6cfd9fyc_v3eEup->mCR.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CI]=mc__XfQXtB6cfd9fyc_v3eEup->mCI.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_W]=mc__XfQXtB6cfd9fyc_v3eEup->mW.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_S]=mc__XfQXtB6cfd9fyc_v3eEup->mS.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_L]=mc__XfQXtB6cfd9fyc_v3eEup->mP_L.mN;sizes.
mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_P_I]=mc__XfQXtB6cfd9fyc_v3eEup->mP_I.mN;
sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_P_J]=mc__XfQXtB6cfd9fyc_v3eEup->mP_J.
mN;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_P_R]=mc__XfQXtB6cfd9fyc_v3eEup->
mP_R.mN;sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_DP_L]=
mc__XfQXtB6cfd9fyc_v3eEup->mDP_L.mN;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_I]=mc__XfQXtB6cfd9fyc_v3eEup->mDP_I.mN;sizes.
mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_DP_J]=mc__XfQXtB6cfd9fyc_v3eEup->mDP_J.mN;
sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_DP_R]=mc__XfQXtB6cfd9fyc_v3eEup->mDP_R
.mN;return sizes;}NeDynamicSystemInput*neu_create_dynamic_system_input(
NeDynamicSystemInputSizes sizes,PmAllocator*pm__8zlSpb2Hixod149p2zadR){
NeDynamicSystemInput*sysInputPtr=(NeDynamicSystemInput*)((
pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(
NeDynamicSystemInput)),(1)));pm_create_int_vector_fields(&(sysInputPtr->mQ),(
size_t)sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_Q],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mM),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_M],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mT),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_T],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mU),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_U],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mV),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_V],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mX),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_X],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mD),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_D],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mE),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_E],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mCR),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CR],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mCI),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CI],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mW),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_W],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mS),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_S],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mP_L),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_L],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mP_I),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_I],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mP_J),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_J],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mP_R),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_R],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mDP_L),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_L],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mDP_I),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_I],pm__8zlSpb2Hixod149p2zadR);
pm_create_int_vector_fields(&(sysInputPtr->mDP_J),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_J],pm__8zlSpb2Hixod149p2zadR);
pm_create_real_vector_fields(&(sysInputPtr->mDP_R),(size_t)sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_R],pm__8zlSpb2Hixod149p2zadR);return sysInputPtr
;}void neu_destroy_dynamic_system_input(NeDynamicSystemInput*sysInputPtr,
PmAllocator*pm__8zlSpb2Hixod149p2zadR){(void)0;;pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mQ),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mM),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mT),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mU),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mV),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mX),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mD),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mE),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mCR),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mCI),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mW),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mS),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mP_L),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mP_I),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mP_J),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mP_R),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mDP_L),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mDP_I),pm__8zlSpb2Hixod149p2zadR);pm_V_eFnKjg5I4Uc1DwG4yU27(&(
sysInputPtr->mDP_J),pm__8zlSpb2Hixod149p2zadR);pm_VeffaD_A8DxagH31Usec1H(&(
sysInputPtr->mDP_R),pm__8zlSpb2Hixod149p2zadR);{void*
ssc_st_kk06poLCQlh5i5Yv6GSh7e=(sysInputPtr);if(ssc_st_kk06poLCQlh5i5Yv6GSh7e!=
0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(pm__8zlSpb2Hixod149p2zadR,
ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};}void neu_dsi_equals_dsi(const
NeDynamicSystemInput*destPtr,const NeDynamicSystemInput*srcPtr){
pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mQ),&(srcPtr->mQ));
pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mM),&(srcPtr->mM));pm_rv_equals_rv(&(
destPtr->mT),&(srcPtr->mT));pm_rv_equals_rv(&(destPtr->mU),&(srcPtr->mU));
pm_rv_equals_rv(&(destPtr->mV),&(srcPtr->mV));pm_rv_equals_rv(&(destPtr->mX),&
(srcPtr->mX));pm_rv_equals_rv(&(destPtr->mD),&(srcPtr->mD));
pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mE),&(srcPtr->mE));pm_rv_equals_rv(&(
destPtr->mCR),&(srcPtr->mCR));pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mCI),&(
srcPtr->mCI));pm_rv_equals_rv(&(destPtr->mW),&(srcPtr->mW));pm_rv_equals_rv(&(
destPtr->mS),&(srcPtr->mS));pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mP_L),&(
srcPtr->mP_L));pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mP_I),&(srcPtr->mP_I));
pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mP_J),&(srcPtr->mP_J));pm_rv_equals_rv(&(
destPtr->mP_R),&(srcPtr->mP_R));pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mDP_L),&(
srcPtr->mDP_L));pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mDP_I),&(srcPtr->mDP_I));
pm_VeeoZXnlJQ4u_112lGs8YD(&(destPtr->mDP_J),&(srcPtr->mDP_J));pm_rv_equals_rv(
&(destPtr->mDP_R),&(srcPtr->mDP_R));}NeDynamicSystemInput*neu_copy_dsi(const
NeDynamicSystemInput*mc__XfQXtB6cfd9fyc_v3eEup,PmAllocator*
mc_FZx3iFiX1YW7j5eEojoAPc){NeDynamicSystemInput*mc_V2mBNcV1EqCifyH9UdCbkF=
neu_create_dynamic_system_input(neu_get_dynamic_system_input_sizes(
mc__XfQXtB6cfd9fyc_v3eEup),mc_FZx3iFiX1YW7j5eEojoAPc);neu_dsi_equals_dsi(
mc_V2mBNcV1EqCifyH9UdCbkF,mc__XfQXtB6cfd9fyc_v3eEup);return
mc_V2mBNcV1EqCifyH9UdCbkF;}boolean_T neu_dsi_equalequals_dsi(const
NeDynamicSystemInput*destPtr,const NeDynamicSystemInput*srcPtr){return true&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mQ),&(srcPtr->mQ))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mM),&(srcPtr->mM))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mT),&(srcPtr->mT))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mU),&(srcPtr->mU))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mV),&(srcPtr->mV))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mX),&(srcPtr->mX))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mD),&(srcPtr->mD))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mE),&(srcPtr->mE))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mCR),&(srcPtr->mCR))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mCI),&(srcPtr->mCI))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mW),&(srcPtr->mW))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mS),&(srcPtr->mS))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mP_L),&(srcPtr->mP_L))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mP_I),&(srcPtr->mP_I))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mP_J),&(srcPtr->mP_J))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mP_R),&(srcPtr->mP_R))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mDP_L),&(srcPtr->mDP_L))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mDP_I),&(srcPtr->mDP_I))&&
pm_V8yYQkcd0vp_YaLM_nd75E(&(destPtr->mDP_J),&(srcPtr->mDP_J))&&
pm_FltUsml2sTlHZuCkbw_pdM(&(destPtr->mDP_R),&(srcPtr->mDP_R));}boolean_T
neu_dsis_equalequals_dsis(const NeDynamicSystemInputSizes
mc_kh0AzKGHcX8tfeDoNul_TU,const NeDynamicSystemInputSizes
mc__Oliq0seKPWShTNRpvAarb){return true&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_Q]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_Q])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_M]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_M])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_T]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_T])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_U]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_U])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_V]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_V])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_X]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_X])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_D]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_D])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_E]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_E])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CR]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CR])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CI]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_CI])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_W]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_W])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_S]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_S])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_L]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_L])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_I]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_I])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_J]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_J])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_R]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_P_R])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_L]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_L])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_I]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_I])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_J]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_J])&&(mc_kh0AzKGHcX8tfeDoNul_TU.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_R]==mc__Oliq0seKPWShTNRpvAarb.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_DP_R]);}
