#include "pm_std.h"
real_T pm_math_FbClXSm2MEW_gDjN18cA_U(const real_T*
pm_math_VgJW5ZqpwPpuY1inYtaofQ,uint32_T n);real_T
pm_math_V1oag74lTiOv_aubp3aT9k(const real_T*pm_math_F2l4p_g4sn02huHNflQjMH,
uint32_T pm_math_VLHhnPUiNQpve5VIL9P3O9,uint32_T n);real_T
pm_math_VtKWxJZti9h2aTofzH3eQO(const real_T*pm_math_F2l4p_g4sn02huHNflQjMH,
uint32_T n);
#include "math.h"
real_T pm_math_FbClXSm2MEW_gDjN18cA_U(const real_T*
pm_math_VgJW5ZqpwPpuY1inYtaofQ,uint32_T n){real_T
pm_math_Vzz7fHz6oElvjujXUEM3YM=0.0;const real_T*pm_math_Vs6xonQX17Krc5vXv8T_zq
=pm_math_VgJW5ZqpwPpuY1inYtaofQ+n;while(pm_math_VgJW5ZqpwPpuY1inYtaofQ<
pm_math_Vs6xonQX17Krc5vXv8T_zq)pm_math_Vzz7fHz6oElvjujXUEM3YM+=fabs(*
pm_math_VgJW5ZqpwPpuY1inYtaofQ++);return pm_math_Vzz7fHz6oElvjujXUEM3YM;}
real_T pm_math_V1oag74lTiOv_aubp3aT9k(const real_T*
pm_math_F2l4p_g4sn02huHNflQjMH,uint32_T pm_math_VLHhnPUiNQpve5VIL9P3O9,
uint32_T n){real_T pm_math__446Z18pDz01XqF3lvLPLC=0.0;real_T
pm_math_khH3Rs1Ha1xF_LaFGM_VyG;uint32_T pm_math_kwrB3ZoKf7OufTHWaHJV7a,
pm_math_kyp6uAyJE40UVuAQNEYzS1;for(pm_math_kyp6uAyJE40UVuAQNEYzS1=0;
pm_math_kyp6uAyJE40UVuAQNEYzS1<n;pm_math_kyp6uAyJE40UVuAQNEYzS1++){
pm_math_khH3Rs1Ha1xF_LaFGM_VyG=0.0;for(pm_math_kwrB3ZoKf7OufTHWaHJV7a=0;
pm_math_kwrB3ZoKf7OufTHWaHJV7a<pm_math_VLHhnPUiNQpve5VIL9P3O9;++
pm_math_kwrB3ZoKf7OufTHWaHJV7a)pm_math_khH3Rs1Ha1xF_LaFGM_VyG+=fabs(*
pm_math_F2l4p_g4sn02huHNflQjMH++);if(pm_math_khH3Rs1Ha1xF_LaFGM_VyG>
pm_math__446Z18pDz01XqF3lvLPLC)pm_math__446Z18pDz01XqF3lvLPLC=
pm_math_khH3Rs1Ha1xF_LaFGM_VyG;}return pm_math__446Z18pDz01XqF3lvLPLC;}real_T
pm_math_VtKWxJZti9h2aTofzH3eQO(const real_T*pm_math_F2l4p_g4sn02huHNflQjMH,
uint32_T n){real_T pm_math__446Z18pDz01XqF3lvLPLC=0.0;real_T
pm_math_khH3Rs1Ha1xF_LaFGM_VyG;uint32_T pm_math_kwrB3ZoKf7OufTHWaHJV7a,
pm_math_kyp6uAyJE40UVuAQNEYzS1;for(pm_math_kyp6uAyJE40UVuAQNEYzS1=0;
pm_math_kyp6uAyJE40UVuAQNEYzS1<n;pm_math_kyp6uAyJE40UVuAQNEYzS1++,
pm_math_F2l4p_g4sn02huHNflQjMH+=n-pm_math_kyp6uAyJE40UVuAQNEYzS1){
pm_math_khH3Rs1Ha1xF_LaFGM_VyG=0.0;for(pm_math_kwrB3ZoKf7OufTHWaHJV7a=0;
pm_math_kwrB3ZoKf7OufTHWaHJV7a<=pm_math_kyp6uAyJE40UVuAQNEYzS1;++
pm_math_kwrB3ZoKf7OufTHWaHJV7a)pm_math_khH3Rs1Ha1xF_LaFGM_VyG+=fabs(*
pm_math_F2l4p_g4sn02huHNflQjMH++);if(pm_math_khH3Rs1Ha1xF_LaFGM_VyG>
pm_math__446Z18pDz01XqF3lvLPLC)pm_math__446Z18pDz01XqF3lvLPLC=
pm_math_khH3Rs1Ha1xF_LaFGM_VyG;}return pm_math__446Z18pDz01XqF3lvLPLC;}
