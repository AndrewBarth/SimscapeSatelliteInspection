//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission_data.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.126
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Thu Aug 29 15:56:20 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "SatelliteServicing_Mission.h"

// Block parameters (default storage)
P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P{
  // Variable: satControlData_Rot
  //  Referenced by:
  //    '<S249>/Constant2'
  //    '<S250>/Constant2'
  //    '<S252>/Saturation1'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },
    10.0
  },

  // Variable: satControlData_Trans
  //  Referenced by:
  //    '<S249>/Constant1'
  //    '<S250>/Constant1'
  //    '<S253>/Saturation1'

  {
    { 0.0, 0.0, 0.0 },

    { 15.0, 15.0, 15.0 },

    { 120.0, 120.0, 120.0 },

    { 0.05, 0.05, 0.05 },
    20.0,

    { -0.0, 1.5, -0.0 }
  },

  // Variable: cubesat
  //  Referenced by:
  //    '<S119>/Constant1'
  //    '<S149>/Constant1'
  //    '<S179>/Constant1'
  //    '<S209>/Constant1'
  //    '<S119>/Subsystem_around_RTP_5F0325A4_PxPositionTargetValue'
  //    '<S119>/Subsystem_around_RTP_5F0325A4_PxVelocityTargetValue'
  //    '<S119>/Subsystem_around_RTP_5F0325A4_PyPositionTargetValue'
  //    '<S119>/Subsystem_around_RTP_5F0325A4_PyVelocityTargetValue'
  //    '<S119>/Subsystem_around_RTP_5F0325A4_PzPositionTargetValue'
  //    '<S119>/Subsystem_around_RTP_5F0325A4_PzVelocityTargetValue'
  //    '<S149>/Subsystem_around_RTP_517418D9_PxPositionTargetValue'
  //    '<S149>/Subsystem_around_RTP_517418D9_PxVelocityTargetValue'
  //    '<S149>/Subsystem_around_RTP_517418D9_PyPositionTargetValue'
  //    '<S149>/Subsystem_around_RTP_517418D9_PyVelocityTargetValue'
  //    '<S149>/Subsystem_around_RTP_517418D9_PzPositionTargetValue'
  //    '<S149>/Subsystem_around_RTP_517418D9_PzVelocityTargetValue'
  //    '<S179>/Subsystem_around_RTP_6835F894_PxPositionTargetValue'
  //    '<S179>/Subsystem_around_RTP_6835F894_PxVeloc
  { {
      10.0,
      360.0,
      3.0,

      { 0.1, 0.1, 0.3 },

      {
        { 0.0, -50.0, 0.0 },

        { -0.025953950670690607, 0.0, 0.14507597709729153 },

        { 0.0, 0.0, 0.0 }
      }
    }, { 15.0,
      360.0,
      3.0,

      { 0.1, 0.1, 0.3 },

      {
        { 0.0, -5.0, 0.0 },

        { -0.0025953950670690607, 0.0, -0.0061256697260279255 },

        { 0.0, 0.0, 0.0 }
      }
    }, { 20.0,
      360.0,
      3.0,

      { 0.1, 0.1, 0.3 },

      {
        { 0.0, -48.57678, 0.0 },

        { -0.0252151870372198, 0.0, -0.012012957527872896 },

        { 0.0, 0.0, 0.0 }
      }
    }, { 30.0,
      360.0,
      3.0,

      { 0.1, 0.1, 0.3 },

      {
        { 0.0, -50.0, 0.0 },

        { -0.025953950670690607, 0.0, 0.043211517289723632 },

        { 0.0, 0.0, 0.0 }
      }
    } },

  // Variable: orbit
  //  Referenced by: '<S113>/Constant1'

  {
    800000.0,
    0.0010381580268276243,
    6052.2436322912963
  },

  // Variable: nsat
  //  Referenced by: '<S114>/Constant1'

  4.0,

  // Computed Parameter: DiscreteTimeIntegrator1_gainval
  //  Referenced by: '<S255>/Discrete-Time Integrator1'

  0.5,

  // Expression: 0
  //  Referenced by: '<S255>/Discrete-Time Integrator1'

  0.0,

  // Expression: -1
  //  Referenced by: '<S255>/Gain1'

  -1.0,

  // Computed Parameter: DiscreteTimeIntegrator1_gainv_b
  //  Referenced by: '<S254>/Discrete-Time Integrator1'

  0.5,

  // Expression: 0
  //  Referenced by: '<S254>/Discrete-Time Integrator1'

  0.0,

  // Expression: -1
  //  Referenced by: '<S254>/Gain1'

  -1.0,

  // Expression: client.faceCenter
  //  Referenced by: '<S114>/Constant3'

  { -2.2204460492503132E-17, -4.0207916090183886, -2.4849858760537424,
    2.4849858760537424, 4.0207916090183895, 1.3322676295501878E-16,
    -2.4849858760537424, -4.0207916090183886, -8.8817841970012528E-17,
    4.0207916090183886, 2.4849858760537424, -8.8817841970012528E-17,
    -2.6308820604357375, -7.4014868308343765E-17, 2.6308820604357375,
    1.6259745337416407, -1.6259745337416405, -4.2568565941773775,
    -2.6308820604357375, 2.6308820604357366, 4.2568565941773775,
    1.4802973661668753E-16, -4.2568565941773775, -1.8503717077085943E-16,
    4.2568565941773775, 2.6308820604357375, -2.630882060435737,
    -2.6308820604357375, -1.6259745337416407, 1.6259745337416405,
    2.630882060435737, 0.0, 4.0207916090183886, 2.4849858760537429,
    -8.8817841970012528E-17, -1.3322676295501878E-16, 2.4849858760537424,
    4.0207916090183886, 3.1086244689504381E-16, -2.4849858760537424,
    -4.0207916090183886, -2.4849858760537424, 2.6645352591003756E-16,
    -4.0207916090183886, 2.6308820604357366, 1.6259745337416398,
    2.6308820604357366, 4.2568565941773775, 4.2568565941773775,
    3.3306690738754696E-16, -2.630882060435737, -2.6308820604357366,
    2.5905203907920321E-16, 1.6259745337416405, 7.4014868308343765E-17,
    -1.6259745337416405, 1.4802973661668753E-16, 2.630882060435737,
    2.630882060435737, -2.6308820604357366, -4.2568565941773775,
    -4.2568565941773775, -2.6308820604357366, -1.6259745337416398,
    -2.4849858760537424, 3.5527136788005011E-16, -4.0207916090183886,
    -4.0207916090183886, -1.7763568394002506E-16, 2.4849858760537429,
    4.0207916090183886, -3.1086244689504381E-16, -2.4849858760537429,
    -1.5760986249044126E-16, 4.0207916090183886, 2.4849858760537429,
    -2.6308820604357366, -4.2568565941773775, -2.6308820604357366,
    7.4014868308343765E-17, 2.5905203907920321E-16, 1.6259745337416405,
    -2.6308820604357375, -2.6308820604357375, 1.6259745337416402,
    4.2568565941773775, -1.6259745337416405, -4.2568565941773775,
    -1.6259745337416405, 2.6308820604357366, 2.6308820604357375,
    2.6308820604357366, -2.5905203907920321E-16, -1.6653345369377348E-16,
    2.630882060435737, 4.2568565941773775 },

  // Expression: client.inspectionFOV
  //  Referenced by: '<S114>/Constant2'

  { 0.87266462599716477, 0.87266462599716477, 0.87266462599716477,
    0.87266462599716477 },

  // Expression: client.inspectionSphereRadius
  //  Referenced by: '<S114>/Constant6'

  5.0,

  // Expression: client.faceRadius
  //  Referenced by: '<S114>/Constant5'

  { 1.6303619330261394, 1.6303619330261392, 1.6303619330261392,
    1.6303619330261387, 1.6303619330261387, 1.6303619330261392,
    1.6303619330261392, 1.6303619330261387, 1.6303619330261392,
    1.6303619330261392, 1.6303619330261392, 1.6303619330261394,
    2.0580035841154967, 2.0580035841154971, 2.0580035841154971,
    2.0580035841154971, 2.0580035841154971, 2.0580035841154971,
    2.0580035841154971, 2.0580035841154971, 2.0580035841154971,
    2.0580035841154971, 2.0580035841154971, 2.0580035841154967,
    2.0580035841154971, 2.0580035841154971, 2.0580035841154971,
    2.0580035841154971, 2.0580035841154971, 2.0580035841154976,
    2.0580035841154971, 2.0580035841154971 },

  // Expression: zeros(client.nFaces,1)
  //  Referenced by: '<S114>/Constant4'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0 },

  // Expression: [0,0,0]
  //  Referenced by: '<S113>/Constant'

  { 0.0, 0.0, 0.0 }
};

//
// File trailer for generated code.
//
// [EOF]
//
