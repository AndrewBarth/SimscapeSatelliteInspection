/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

void SatelliteServicing_Mission_e7143f6a_1_computeRuntimeParameters(const real_T
  t0[], real_T out[])
{
  real_T t10[1];
  real_T t11[1];
  real_T t12[1];
  real_T t13[1];
  real_T t7[1];
  real_T t8[1];
  real_T t9[1];
  real_T t22;
  real_T t23;
  real_T t24;
  real_T t25;
  real_T t26;
  real_T t27;
  t9[0ULL] = t0[0ULL];
  t10[0ULL] = t0[1ULL];
  t11[0ULL] = t0[2ULL];
  t12[0ULL] = t0[3ULL];
  t13[0ULL] = t0[4ULL];
  t7[0ULL] = t0[5ULL];
  memcpy(&t8[0], &t9[0], 8U);
  memcpy(&t9[0], &t10[0], 8U);
  memcpy(&t10[0], &t11[0], 8U);
  memcpy(&t11[0], &t12[0], 8U);
  memcpy(&t12[0], &t13[0], 8U);
  memcpy(&t13[0], &t7[0], 8U);
  t22 = t8[0ULL];
  t23 = t9[0ULL];
  t24 = t10[0ULL];
  t25 = t11[0ULL];
  t26 = t12[0ULL];
  t27 = t13[0ULL];
  out[0] = t22;
  out[1] = t23;
  out[2] = t24;
  out[3] = t25;
  out[4] = t26;
  out[5] = t27;
}

void SatelliteServicing_Mission_e7143f6a_1_computeAsmRuntimeDerivedValuesDoubles
  (const double *rtp, double *rtdvd)
{
  boolean_T bb[2];
  double xx[7];
  xx[0] = rtp[0];
  bb[0] = sm_core_math_anyIsInf(1, xx + 0);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = 0.0;
  xx[1] = !bb[0] && !bb[1] ? rtp[0] : xx[0];
  xx[2] = rtp[1];
  bb[0] = sm_core_math_anyIsInf(1, xx + 2);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 2);
  xx[2] = !bb[0] && !bb[1] ? rtp[1] : xx[0];
  xx[3] = rtp[2];
  bb[0] = sm_core_math_anyIsInf(1, xx + 3);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 3);
  xx[3] = !bb[0] && !bb[1] ? rtp[2] : xx[0];
  xx[4] = rtp[3];
  bb[0] = sm_core_math_anyIsInf(1, xx + 4);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 4);
  xx[4] = !bb[0] && !bb[1] ? rtp[3] : xx[0];
  xx[5] = rtp[4];
  bb[0] = sm_core_math_anyIsInf(1, xx + 5);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 5);
  xx[5] = !bb[0] && !bb[1] ? rtp[4] : xx[0];
  xx[6] = rtp[5];
  bb[0] = sm_core_math_anyIsInf(1, xx + 6);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 6);
  xx[6] = !bb[0] && !bb[1] ? rtp[5] : xx[0];
  rtdvd[0] = xx[1];
  rtdvd[1] = xx[2];
  rtdvd[2] = xx[3];
  rtdvd[3] = xx[4];
  rtdvd[4] = xx[5];
  rtdvd[5] = xx[6];
  rtdvd[6] = xx[1];
  rtdvd[7] = xx[2];
  rtdvd[8] = xx[3];
  rtdvd[9] = xx[4];
  rtdvd[10] = xx[5];
  rtdvd[11] = xx[6];
}

void SatelliteServicing_Mission_e7143f6a_1_computeAsmRuntimeDerivedValuesInts(
  const double *rtp, int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void SatelliteServicing_Mission_e7143f6a_1_computeAsmRuntimeDerivedValues(const
  double *rtp, RuntimeDerivedValuesBundle *rtdv)
{
  SatelliteServicing_Mission_e7143f6a_1_computeAsmRuntimeDerivedValuesDoubles
    (rtp, rtdv->mDoubles.mValues);
  SatelliteServicing_Mission_e7143f6a_1_computeAsmRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}

void SatelliteServicing_Mission_e7143f6a_1_computeSimRuntimeDerivedValuesDoubles
  (const double *rtp, double *rtdvd)
{
  (void) rtp;
  (void) rtdvd;
}

void SatelliteServicing_Mission_e7143f6a_1_computeSimRuntimeDerivedValuesInts(
  const double *rtp, int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void SatelliteServicing_Mission_e7143f6a_1_computeSimRuntimeDerivedValues(const
  double *rtp, RuntimeDerivedValuesBundle *rtdv)
{
  SatelliteServicing_Mission_e7143f6a_1_computeSimRuntimeDerivedValuesDoubles
    (rtp, rtdv->mDoubles.mValues);
  SatelliteServicing_Mission_e7143f6a_1_computeSimRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}
