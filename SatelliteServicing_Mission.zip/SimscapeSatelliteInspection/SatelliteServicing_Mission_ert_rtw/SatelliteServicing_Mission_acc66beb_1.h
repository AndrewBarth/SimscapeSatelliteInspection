// Simscape target specific file.
//  This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.


#ifndef __SatelliteServicing_Mission_acc66beb_1_h__
#define __SatelliteServicing_Mission_acc66beb_1_h__
#ifdef __cplusplus

extern "C"
{

#endif

  extern void SatelliteServicing_Mission_acc66beb_1_dae( NeDae **dae, const
    NeModelParameters
    *modelParams,
    const NeSolverParameters *solverParams);

#ifdef __cplusplus

}

#endif
#endif
