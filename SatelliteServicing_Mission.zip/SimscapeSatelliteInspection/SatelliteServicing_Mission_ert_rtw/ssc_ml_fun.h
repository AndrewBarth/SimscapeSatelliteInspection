// Simscape target specific file.
//  This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration'.


#ifdef __cplusplus

extern "C"
{

#endif

#ifndef SSC_ML_FUN_H
#define SSC_ML_FUN_H                   1
#endif

#ifdef __cplusplus

}

;

#endif
