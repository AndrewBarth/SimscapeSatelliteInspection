/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

void SatelliteServicing_Mission_acc66beb_1_validateRuntimeParameters(const
  double *rtp, int32_T *satFlags)
{
  boolean_T bb[48];
  double xx[1];
  xx[0] = rtp[0];
  bb[0] = sm_core_math_anyIsInf(1, xx + 0);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[1];
  bb[2] = sm_core_math_anyIsInf(1, xx + 0);
  bb[3] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[2];
  bb[4] = sm_core_math_anyIsInf(1, xx + 0);
  bb[5] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[3];
  bb[6] = sm_core_math_anyIsInf(1, xx + 0);
  bb[7] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[4];
  bb[8] = sm_core_math_anyIsInf(1, xx + 0);
  bb[9] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[5];
  bb[10] = sm_core_math_anyIsInf(1, xx + 0);
  bb[11] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[6];
  bb[12] = sm_core_math_anyIsInf(1, xx + 0);
  bb[13] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[7];
  bb[14] = sm_core_math_anyIsInf(1, xx + 0);
  bb[15] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[8];
  bb[16] = sm_core_math_anyIsInf(1, xx + 0);
  bb[17] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[9];
  bb[18] = sm_core_math_anyIsInf(1, xx + 0);
  bb[19] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[10];
  bb[20] = sm_core_math_anyIsInf(1, xx + 0);
  bb[21] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[11];
  bb[22] = sm_core_math_anyIsInf(1, xx + 0);
  bb[23] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[12];
  bb[24] = sm_core_math_anyIsInf(1, xx + 0);
  bb[25] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[13];
  bb[26] = sm_core_math_anyIsInf(1, xx + 0);
  bb[27] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[14];
  bb[28] = sm_core_math_anyIsInf(1, xx + 0);
  bb[29] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[15];
  bb[30] = sm_core_math_anyIsInf(1, xx + 0);
  bb[31] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[16];
  bb[32] = sm_core_math_anyIsInf(1, xx + 0);
  bb[33] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[17];
  bb[34] = sm_core_math_anyIsInf(1, xx + 0);
  bb[35] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[18];
  bb[36] = sm_core_math_anyIsInf(1, xx + 0);
  bb[37] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[19];
  bb[38] = sm_core_math_anyIsInf(1, xx + 0);
  bb[39] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[20];
  bb[40] = sm_core_math_anyIsInf(1, xx + 0);
  bb[41] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[21];
  bb[42] = sm_core_math_anyIsInf(1, xx + 0);
  bb[43] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[22];
  bb[44] = sm_core_math_anyIsInf(1, xx + 0);
  bb[45] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[23];
  bb[46] = sm_core_math_anyIsInf(1, xx + 0);
  bb[47] = sm_core_math_anyIsNaN(1, xx + 0);
  satFlags[0] = !bb[0] ? 1 : 0;
  satFlags[1] = !bb[1] ? 1 : 0;
  satFlags[2] = !bb[2] ? 1 : 0;
  satFlags[3] = !bb[3] ? 1 : 0;
  satFlags[4] = !bb[4] ? 1 : 0;
  satFlags[5] = !bb[5] ? 1 : 0;
  satFlags[6] = !bb[6] ? 1 : 0;
  satFlags[7] = !bb[7] ? 1 : 0;
  satFlags[8] = !bb[8] ? 1 : 0;
  satFlags[9] = !bb[9] ? 1 : 0;
  satFlags[10] = !bb[10] ? 1 : 0;
  satFlags[11] = !bb[11] ? 1 : 0;
  satFlags[12] = !bb[12] ? 1 : 0;
  satFlags[13] = !bb[13] ? 1 : 0;
  satFlags[14] = !bb[14] ? 1 : 0;
  satFlags[15] = !bb[15] ? 1 : 0;
  satFlags[16] = !bb[16] ? 1 : 0;
  satFlags[17] = !bb[17] ? 1 : 0;
  satFlags[18] = !bb[18] ? 1 : 0;
  satFlags[19] = !bb[19] ? 1 : 0;
  satFlags[20] = !bb[20] ? 1 : 0;
  satFlags[21] = !bb[21] ? 1 : 0;
  satFlags[22] = !bb[22] ? 1 : 0;
  satFlags[23] = !bb[23] ? 1 : 0;
  satFlags[24] = !bb[24] ? 1 : 0;
  satFlags[25] = !bb[25] ? 1 : 0;
  satFlags[26] = !bb[26] ? 1 : 0;
  satFlags[27] = !bb[27] ? 1 : 0;
  satFlags[28] = !bb[28] ? 1 : 0;
  satFlags[29] = !bb[29] ? 1 : 0;
  satFlags[30] = !bb[30] ? 1 : 0;
  satFlags[31] = !bb[31] ? 1 : 0;
  satFlags[32] = !bb[32] ? 1 : 0;
  satFlags[33] = !bb[33] ? 1 : 0;
  satFlags[34] = !bb[34] ? 1 : 0;
  satFlags[35] = !bb[35] ? 1 : 0;
  satFlags[36] = !bb[36] ? 1 : 0;
  satFlags[37] = !bb[37] ? 1 : 0;
  satFlags[38] = !bb[38] ? 1 : 0;
  satFlags[39] = !bb[39] ? 1 : 0;
  satFlags[40] = !bb[40] ? 1 : 0;
  satFlags[41] = !bb[41] ? 1 : 0;
  satFlags[42] = !bb[42] ? 1 : 0;
  satFlags[43] = !bb[43] ? 1 : 0;
  satFlags[44] = !bb[44] ? 1 : 0;
  satFlags[45] = !bb[45] ? 1 : 0;
  satFlags[46] = !bb[46] ? 1 : 0;
  satFlags[47] = !bb[47] ? 1 : 0;
}

const NeAssertData SatelliteServicing_Mission_acc66beb_1_assertData[48] = {
  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat1.CubeSat1_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat2.CubeSat2_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat3.CubeSat3_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" }
};
