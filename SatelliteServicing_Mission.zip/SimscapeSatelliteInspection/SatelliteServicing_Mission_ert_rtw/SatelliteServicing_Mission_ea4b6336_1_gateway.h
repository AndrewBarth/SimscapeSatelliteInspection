// Simscape target specific file.
//  This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration'.


#ifndef __SatelliteServicing_Mission_ea4b6336_1_gateway_h__
#define __SatelliteServicing_Mission_ea4b6336_1_gateway_h__
#ifdef __cplusplus

extern "C"
{

#endif

  extern void SatelliteServicing_Mission_ea4b6336_1_gateway(void);

#ifdef __cplusplus

}

#endif
#endif           // #ifndef __SatelliteServicing_Mission_ea4b6336_1_gateway_h__
