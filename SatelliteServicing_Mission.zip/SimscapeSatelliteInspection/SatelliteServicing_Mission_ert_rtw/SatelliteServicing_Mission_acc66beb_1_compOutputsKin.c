/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "SatelliteServicing_Mission_acc66beb_1_geometries.h"

PmfMessageId SatelliteServicing_Mission_acc66beb_1_compOutputsKin(const
  RuntimeDerivedValuesBundle *rtdv, const double *state, const int *modeVector,
  const double *input, const double *inputDot, const double *inputDdot, const
  double *discreteState, double *output, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  boolean_T bb[1];
  double xx[49];
  (void) rtdvd;
  (void) rtdvi;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 1.0;
  xx[1] = 0.0;
  xx[2] = 9.87654321;
  xx[3] = state[3];
  xx[4] = state[4];
  xx[5] = state[5];
  xx[6] = state[6];
  xx[7] = 0.5;
  xx[8] = - xx[7];
  xx[9] = xx[8];
  xx[10] = xx[7];
  xx[11] = xx[7];
  xx[12] = xx[8];
  pm_math_Quaternion_composeInverse_ra(xx + 3, xx + 9, xx + 13);
  pm_math_Quaternion_compose_ra(xx + 13, xx + 9, xx + 3);
  xx[8] = xx[3] * xx[3];
  xx[17] = 2.0;
  xx[18] = (xx[8] + xx[4] * xx[4]) * xx[17] - xx[0];
  xx[19] = xx[4] * xx[5];
  xx[20] = xx[3] * xx[6];
  xx[21] = (xx[19] + xx[20]) * xx[17];
  xx[22] = xx[4] * xx[6];
  xx[23] = xx[3] * xx[5];
  xx[24] = xx[17] * (xx[22] - xx[23]);
  xx[25] = xx[17] * (xx[19] - xx[20]);
  xx[19] = (xx[8] + xx[5] * xx[5]) * xx[17] - xx[0];
  xx[20] = xx[5] * xx[6];
  xx[26] = xx[3] * xx[4];
  xx[27] = (xx[20] + xx[26]) * xx[17];
  xx[28] = (xx[8] + xx[6] * xx[6]) * xx[17] - xx[0];
  bb[0] = fabs(xx[24]) > 0.99999999999999;
  xx[29] = - xx[25];
  xx[8] = (xx[29] == 0.0 && xx[19] == 0.0) ? 0.0 : atan2(xx[29], xx[19]);
  xx[29] = (xx[21] == 0.0 && xx[18] == 0.0) ? 0.0 : atan2(xx[21], xx[18]);
  xx[30] = bb[0] ? xx[7] * xx[8] : xx[29];
  if (xx[24] < 0.0)
    xx[7] = -1.0;
  else if (xx[24] > 0.0)
    xx[7] = +1.0;
  else
    xx[7] = 0.0;
  xx[8] = - xx[24];
  xx[8] = fabs(xx[8]) > 1.0 ? atan2(xx[8], 0.0) : asin(xx[8]);
  xx[29] = (xx[27] == 0.0 && xx[28] == 0.0) ? 0.0 : atan2(xx[27], xx[28]);
  xx[31] = state[10];
  xx[32] = state[11];
  xx[33] = state[12];
  pm_math_Quaternion_xform_ra(xx + 9, xx + 31, xx + 34);
  pm_math_Quaternion_inverseXform_ra(xx + 9, xx + 34, xx + 31);
  pm_math_Quaternion_xform_ra(xx + 3, xx + 31, xx + 37);
  xx[31] = 2.775557561562891e-17;
  xx[32] = xx[31] * xx[16];
  xx[33] = 1.982541115402078e-18;
  xx[40] = xx[33] * xx[15] - xx[31] * xx[14];
  xx[41] = xx[32];
  xx[42] = - (xx[33] * xx[16]);
  xx[43] = xx[40];
  pm_math_Vector3_cross_ra(xx + 14, xx + 41, xx + 44);
  xx[41] = xx[17] * (xx[44] + xx[13] * xx[32]);
  xx[32] = (xx[45] - xx[33] * xx[13] * xx[16]) * xx[17];
  xx[42] = (xx[13] * xx[40] + xx[46]) * xx[17];
  xx[43] = state[7];
  xx[44] = state[8];
  xx[45] = state[9];
  pm_math_Quaternion_inverseXform_ra(xx + 13, xx + 43, xx + 46);
  xx[13] = xx[31] * xx[36];
  xx[14] = xx[33] * xx[36];
  xx[15] = xx[33] * xx[35];
  xx[16] = xx[31] * xx[34];
  xx[33] = xx[46] - xx[13] + xx[13];
  xx[34] = xx[47] + xx[14] - xx[14];
  xx[35] = xx[15] - xx[16] + xx[48] + xx[16] - xx[15];
  pm_math_Quaternion_inverseXform_ra(xx + 9, xx + 33, xx + 13);
  pm_math_Quaternion_xform_ra(xx + 3, xx + 13, xx + 9);
  output[0] = xx[0];
  output[1] = xx[1];
  output[2] = xx[1];
  output[3] = xx[1];
  output[4] = xx[0];
  output[5] = xx[1];
  output[6] = xx[1];
  output[7] = xx[1];
  output[8] = xx[0];
  output[9] = xx[1];
  output[10] = xx[1];
  output[11] = xx[1];
  output[12] = xx[0];
  output[13] = xx[1];
  output[14] = xx[1];
  output[15] = xx[1];
  output[16] = xx[1];
  output[17] = xx[1];
  output[18] = xx[1];
  output[22] = 0.1629720934100242;
  output[23] = xx[1];
  output[24] = xx[1];
  output[25] = xx[1];
  output[26] = xx[1];
  output[27] = xx[1];
  output[31] = - xx[0];
  output[32] = xx[1];
  output[33] = xx[1];
  output[34] = xx[1];
  output[35] = xx[0];
  output[36] = xx[1];
  output[37] = xx[1];
  output[38] = xx[1];
  output[39] = xx[0];
  output[40] = xx[1];
  output[41] = xx[1];
  output[42] = xx[1];
  output[43] = xx[0];
  output[44] = xx[1];
  output[45] = xx[1];
  output[46] = xx[1];
  output[47] = xx[1];
  output[48] = xx[1];
  output[49] = xx[1];
  output[53] = xx[1];
  output[54] = xx[1];
  output[55] = xx[1];
  output[56] = xx[1];
  output[57] = xx[1];
  output[58] = xx[1];
  output[62] = - xx[3];
  output[63] = - xx[4];
  output[64] = - xx[5];
  output[65] = - xx[6];
  output[66] = xx[18];
  output[67] = xx[21];
  output[68] = xx[24];
  output[69] = xx[25];
  output[70] = xx[19];
  output[71] = xx[27];
  output[72] = (xx[22] + xx[23]) * xx[17];
  output[73] = xx[17] * (xx[20] - xx[26]);
  output[74] = xx[28];
  output[75] = xx[30];
  output[76] = bb[0] ? - (1.570796326794897 * xx[7]) : xx[8];
  output[77] = bb[0] ? xx[7] * xx[30] : xx[29];
  output[78] = xx[37];
  output[79] = xx[38];
  output[80] = xx[39];
  output[84] = xx[41] + state[0] - xx[41];
  output[85] = xx[32] + state[1] - xx[32];
  output[86] = xx[42] + state[2] - xx[42];
  output[87] = xx[9];
  output[88] = xx[10];
  output[89] = xx[11];
  return NULL;
}
