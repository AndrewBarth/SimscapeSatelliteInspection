//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission_private.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.5
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Mon Nov 13 10:47:25 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_SatelliteServicing_Mission_private_h_
#define RTW_HEADER_SatelliteServicing_Mission_private_h_
#include "rtwtypes.h"
#include "SatelliteServicing_Mission_types.h"
#include "SatelliteServicing_Mission.h"

// Private macros used by the generated code to access rtModel
#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

#if !defined(rt_VALIDATE_MEMORY)
#define rt_VALIDATE_MEMORY(S, ptr)     if(!(ptr)) {\
 rtmSetErrorStatus(SatelliteServicing_Mission_M, RT_MEMORY_ALLOCATION_ERROR);\
 }
#endif

#if !defined(rt_FREE)
#if !defined(_WIN32)
#define rt_FREE(ptr)                   if((ptr) != (nullptr)) {\
 free((ptr));\
 (ptr) = (nullptr);\
 }
#else

// Visual and other windows compilers declare free without const
#define rt_FREE(ptr)                   if((ptr) != (nullptr)) {\
 free((void *)(ptr));\
 (ptr) = (nullptr);\
 }
#endif
#endif

void SatelliteServici_MATLABFunction(const real_T rtu_qin[4], real_T rty_qout[4]);
void SatelliteServicing_Mi_QuatToDCM(const real_T rtu_q[4], real_T rty_mat[9]);
void SatelliteServici_QuatToEuler321(const real_T rtu_q[4], real_T rty_euler[3]);
void SatelliteServicing__formPoseMat(const real_T rtu_rotMat[9], const real_T
  rtu_posVec[3], real_T rty_mat[16]);
void SatelliteServicing_Mis_quat2MRP(const real_T rtu_q[4], real_T rty_mrp[3]);
void SatelliteServicing_positiveQuat(const real_T rtu_qIn[4], real_T rty_qOut[4]);
void SatelliteSe_MATLABFunction_Term(void);
void SatelliteServici_QuatToDCM_Term(void);
void SatelliteSe_QuatToEuler321_Term(void);
void SatelliteServi_formPoseMat_Term(void);
void SatelliteServicin_quat2MRP_Term(void);
void SatelliteServici_quat2MPR1_Term(void);
void SatelliteServ_positiveQuat_Term(void);

// private model entry point functions
extern void SatelliteServicing_Mission_derivatives
  (RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M);

#endif                      // RTW_HEADER_SatelliteServicing_Mission_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
