// Simscape target specific file.
//  This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration'.

struct RuntimeDerivedValuesBundleTag;
void SatelliteServicing_Mission_587682d_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
