/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

void SatelliteServicing_Mission_acc66beb_1_computeRuntimeParameters(const real_T
  t0[], real_T out[])
{
  real_T t3[1];
  real_T t5[1];
  real_T t6[1];
  real_T t7[1];
  real_T t13;
  real_T t14;
  real_T t15;
  t7[0ULL] = t0[0ULL];
  t3[0ULL] = t0[1ULL];
  t6[0ULL] = t0[2ULL];
  memcpy(&t5[0], &t6[0], 8U);
  memcpy(&t6[0], &t7[0], 8U);
  memcpy(&t7[0], &t3[0], 8U);
  t13 = t5[0ULL];
  t14 = t6[0ULL];
  t15 = t7[0ULL];
  out[0] = t13;
  out[1] = t14;
  out[2] = t15;
}

void SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValuesDoubles
  (const double *rtp, double *rtdvd)
{
  boolean_T bb[2];
  double xx[5];
  xx[0] = rtp[0];
  bb[0] = sm_core_math_anyIsInf(1, xx + 0);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = 0.0174532925199433;
  xx[1] = 0.0;
  xx[2] = !bb[0] && !bb[1] ? xx[0] * rtp[0] : xx[1];
  xx[3] = rtp[1];
  bb[0] = sm_core_math_anyIsInf(1, xx + 3);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 3);
  xx[3] = !bb[0] && !bb[1] ? xx[0] * rtp[1] : xx[1];
  xx[4] = rtp[2];
  bb[0] = sm_core_math_anyIsInf(1, xx + 4);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 4);
  xx[4] = !bb[0] && !bb[1] ? xx[0] * rtp[2] : xx[1];
  xx[0] = 57.29577951308232;
  rtdvd[0] = xx[2];
  rtdvd[1] = xx[3];
  rtdvd[2] = xx[4];
  rtdvd[3] = xx[0] * xx[2];
  rtdvd[4] = xx[0] * xx[3];
  rtdvd[5] = xx[0] * xx[4];
}

void SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValuesInts(
  const double *rtp, int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValues(const
  double *rtp, RuntimeDerivedValuesBundle *rtdv)
{
  SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValuesDoubles
    (rtp, rtdv->mDoubles.mValues);
  SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}

void SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValuesDoubles
  (const double *rtp, double *rtdvd)
{
  (void) rtp;
  (void) rtdvd;
}

void SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValuesInts(
  const double *rtp, int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValues(const
  double *rtp, RuntimeDerivedValuesBundle *rtdv)
{
  SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValuesDoubles
    (rtp, rtdv->mDoubles.mValues);
  SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}
