/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

void SatelliteServicing_Mission_acc66beb_1_computeRuntimeParameters(const real_T
  t0[], real_T out[])
{
  real_T t25[1];
  real_T t26[1];
  real_T t27[1];
  real_T t28[1];
  real_T t29[1];
  real_T t30[1];
  real_T t31[1];
  real_T t32[1];
  real_T t33[1];
  real_T t34[1];
  real_T t35[1];
  real_T t36[1];
  real_T t37[1];
  real_T t38[1];
  real_T t39[1];
  real_T t40[1];
  real_T t41[1];
  real_T t42[1];
  real_T t43[1];
  real_T t44[1];
  real_T t45[1];
  real_T t46[1];
  real_T t47[1];
  real_T t48[1];
  real_T t49[1];
  real_T t76;
  real_T t77;
  real_T t78;
  real_T t79;
  real_T t80;
  real_T t81;
  real_T t82;
  real_T t83;
  real_T t84;
  real_T t85;
  real_T t86;
  real_T t87;
  real_T t88;
  real_T t89;
  real_T t90;
  real_T t91;
  real_T t92;
  real_T t93;
  real_T t94;
  real_T t95;
  real_T t96;
  real_T t97;
  real_T t98;
  real_T t99;
  t33[0ULL] = t0[0ULL];
  t34[0ULL] = t0[1ULL];
  t35[0ULL] = t0[2ULL];
  t36[0ULL] = t0[3ULL];
  t37[0ULL] = t0[4ULL];
  t38[0ULL] = t0[5ULL];
  t27[0ULL] = t0[6ULL];
  t28[0ULL] = t0[7ULL];
  t29[0ULL] = t0[8ULL];
  t30[0ULL] = t0[9ULL];
  t31[0ULL] = t0[10ULL];
  t32[0ULL] = t0[11ULL];
  t39[0ULL] = t0[12ULL];
  t40[0ULL] = t0[13ULL];
  t41[0ULL] = t0[14ULL];
  t42[0ULL] = t0[15ULL];
  t43[0ULL] = t0[16ULL];
  t44[0ULL] = t0[17ULL];
  t45[0ULL] = t0[18ULL];
  t46[0ULL] = t0[19ULL];
  t47[0ULL] = t0[20ULL];
  t48[0ULL] = t0[21ULL];
  t49[0ULL] = t0[22ULL];
  t25[0ULL] = t0[23ULL];
  memcpy(&t26[0], &t27[0], 8U);
  memcpy(&t27[0], &t28[0], 8U);
  memcpy(&t28[0], &t29[0], 8U);
  memcpy(&t29[0], &t30[0], 8U);
  memcpy(&t30[0], &t31[0], 8U);
  memcpy(&t31[0], &t32[0], 8U);
  memcpy(&t32[0], &t33[0], 8U);
  memcpy(&t33[0], &t34[0], 8U);
  memcpy(&t34[0], &t35[0], 8U);
  memcpy(&t35[0], &t36[0], 8U);
  memcpy(&t36[0], &t37[0], 8U);
  memcpy(&t37[0], &t38[0], 8U);
  memcpy(&t38[0], &t39[0], 8U);
  memcpy(&t39[0], &t40[0], 8U);
  memcpy(&t40[0], &t41[0], 8U);
  memcpy(&t41[0], &t42[0], 8U);
  memcpy(&t42[0], &t43[0], 8U);
  memcpy(&t43[0], &t44[0], 8U);
  memcpy(&t44[0], &t45[0], 8U);
  memcpy(&t45[0], &t46[0], 8U);
  memcpy(&t46[0], &t47[0], 8U);
  memcpy(&t47[0], &t48[0], 8U);
  memcpy(&t48[0], &t49[0], 8U);
  memcpy(&t49[0], &t25[0], 8U);
  t76 = t26[0ULL];
  t77 = t27[0ULL];
  t78 = t28[0ULL];
  t79 = t29[0ULL];
  t80 = t30[0ULL];
  t81 = t31[0ULL];
  t82 = t32[0ULL];
  t83 = t33[0ULL];
  t84 = t34[0ULL];
  t85 = t35[0ULL];
  t86 = t36[0ULL];
  t87 = t37[0ULL];
  t88 = t38[0ULL];
  t89 = t39[0ULL];
  t90 = t40[0ULL];
  t91 = t41[0ULL];
  t92 = t42[0ULL];
  t93 = t43[0ULL];
  t94 = t44[0ULL];
  t95 = t45[0ULL];
  t96 = t46[0ULL];
  t97 = t47[0ULL];
  t98 = t48[0ULL];
  t99 = t49[0ULL];
  out[0] = t76;
  out[1] = t77;
  out[2] = t78;
  out[3] = t79;
  out[4] = t80;
  out[5] = t81;
  out[6] = t82;
  out[7] = t83;
  out[8] = t84;
  out[9] = t85;
  out[10] = t86;
  out[11] = t87;
  out[12] = t88;
  out[13] = t89;
  out[14] = t90;
  out[15] = t91;
  out[16] = t92;
  out[17] = t93;
  out[18] = t94;
  out[19] = t95;
  out[20] = t96;
  out[21] = t97;
  out[22] = t98;
  out[23] = t99;
}

void SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValuesDoubles
  (const double *rtp, double *rtdvd)
{
  boolean_T bb[2];
  double xx[25];
  xx[0] = rtp[0];
  bb[0] = sm_core_math_anyIsInf(1, xx + 0);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = 0.0;
  xx[1] = !bb[0] && !bb[1] ? rtp[0] : xx[0];
  xx[2] = rtp[1];
  bb[0] = sm_core_math_anyIsInf(1, xx + 2);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 2);
  xx[2] = !bb[0] && !bb[1] ? rtp[1] : xx[0];
  xx[3] = rtp[2];
  bb[0] = sm_core_math_anyIsInf(1, xx + 3);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 3);
  xx[3] = !bb[0] && !bb[1] ? rtp[2] : xx[0];
  xx[4] = rtp[3];
  bb[0] = sm_core_math_anyIsInf(1, xx + 4);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 4);
  xx[4] = !bb[0] && !bb[1] ? rtp[3] : xx[0];
  xx[5] = rtp[4];
  bb[0] = sm_core_math_anyIsInf(1, xx + 5);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 5);
  xx[5] = !bb[0] && !bb[1] ? rtp[4] : xx[0];
  xx[6] = rtp[5];
  bb[0] = sm_core_math_anyIsInf(1, xx + 6);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 6);
  xx[6] = !bb[0] && !bb[1] ? rtp[5] : xx[0];
  xx[7] = rtp[6];
  bb[0] = sm_core_math_anyIsInf(1, xx + 7);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 7);
  xx[7] = !bb[0] && !bb[1] ? rtp[6] : xx[0];
  xx[8] = rtp[7];
  bb[0] = sm_core_math_anyIsInf(1, xx + 8);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 8);
  xx[8] = !bb[0] && !bb[1] ? rtp[7] : xx[0];
  xx[9] = rtp[8];
  bb[0] = sm_core_math_anyIsInf(1, xx + 9);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 9);
  xx[9] = !bb[0] && !bb[1] ? rtp[8] : xx[0];
  xx[10] = rtp[9];
  bb[0] = sm_core_math_anyIsInf(1, xx + 10);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 10);
  xx[10] = !bb[0] && !bb[1] ? rtp[9] : xx[0];
  xx[11] = rtp[10];
  bb[0] = sm_core_math_anyIsInf(1, xx + 11);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 11);
  xx[11] = !bb[0] && !bb[1] ? rtp[10] : xx[0];
  xx[12] = rtp[11];
  bb[0] = sm_core_math_anyIsInf(1, xx + 12);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 12);
  xx[12] = !bb[0] && !bb[1] ? rtp[11] : xx[0];
  xx[13] = rtp[12];
  bb[0] = sm_core_math_anyIsInf(1, xx + 13);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 13);
  xx[13] = !bb[0] && !bb[1] ? rtp[12] : xx[0];
  xx[14] = rtp[13];
  bb[0] = sm_core_math_anyIsInf(1, xx + 14);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 14);
  xx[14] = !bb[0] && !bb[1] ? rtp[13] : xx[0];
  xx[15] = rtp[14];
  bb[0] = sm_core_math_anyIsInf(1, xx + 15);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 15);
  xx[15] = !bb[0] && !bb[1] ? rtp[14] : xx[0];
  xx[16] = rtp[15];
  bb[0] = sm_core_math_anyIsInf(1, xx + 16);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 16);
  xx[16] = !bb[0] && !bb[1] ? rtp[15] : xx[0];
  xx[17] = rtp[16];
  bb[0] = sm_core_math_anyIsInf(1, xx + 17);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 17);
  xx[17] = !bb[0] && !bb[1] ? rtp[16] : xx[0];
  xx[18] = rtp[17];
  bb[0] = sm_core_math_anyIsInf(1, xx + 18);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 18);
  xx[18] = !bb[0] && !bb[1] ? rtp[17] : xx[0];
  xx[19] = rtp[18];
  bb[0] = sm_core_math_anyIsInf(1, xx + 19);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 19);
  xx[19] = !bb[0] && !bb[1] ? rtp[18] : xx[0];
  xx[20] = rtp[19];
  bb[0] = sm_core_math_anyIsInf(1, xx + 20);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 20);
  xx[20] = !bb[0] && !bb[1] ? rtp[19] : xx[0];
  xx[21] = rtp[20];
  bb[0] = sm_core_math_anyIsInf(1, xx + 21);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 21);
  xx[21] = !bb[0] && !bb[1] ? rtp[20] : xx[0];
  xx[22] = rtp[21];
  bb[0] = sm_core_math_anyIsInf(1, xx + 22);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 22);
  xx[22] = !bb[0] && !bb[1] ? rtp[21] : xx[0];
  xx[23] = rtp[22];
  bb[0] = sm_core_math_anyIsInf(1, xx + 23);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 23);
  xx[23] = !bb[0] && !bb[1] ? rtp[22] : xx[0];
  xx[24] = rtp[23];
  bb[0] = sm_core_math_anyIsInf(1, xx + 24);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 24);
  xx[24] = !bb[0] && !bb[1] ? rtp[23] : xx[0];
  rtdvd[0] = xx[1];
  rtdvd[1] = xx[2];
  rtdvd[2] = xx[3];
  rtdvd[3] = xx[4];
  rtdvd[4] = xx[5];
  rtdvd[5] = xx[6];
  rtdvd[6] = xx[7];
  rtdvd[7] = xx[8];
  rtdvd[8] = xx[9];
  rtdvd[9] = xx[10];
  rtdvd[10] = xx[11];
  rtdvd[11] = xx[12];
  rtdvd[12] = xx[13];
  rtdvd[13] = xx[14];
  rtdvd[14] = xx[15];
  rtdvd[15] = xx[16];
  rtdvd[16] = xx[17];
  rtdvd[17] = xx[18];
  rtdvd[18] = xx[19];
  rtdvd[19] = xx[20];
  rtdvd[20] = xx[21];
  rtdvd[21] = xx[22];
  rtdvd[22] = xx[23];
  rtdvd[23] = xx[24];
  rtdvd[24] = xx[1];
  rtdvd[25] = xx[2];
  rtdvd[26] = xx[3];
  rtdvd[27] = xx[4];
  rtdvd[28] = xx[5];
  rtdvd[29] = xx[6];
  rtdvd[30] = xx[7];
  rtdvd[31] = xx[8];
  rtdvd[32] = xx[9];
  rtdvd[33] = xx[10];
  rtdvd[34] = xx[11];
  rtdvd[35] = xx[12];
  rtdvd[36] = xx[13];
  rtdvd[37] = xx[14];
  rtdvd[38] = xx[15];
  rtdvd[39] = xx[16];
  rtdvd[40] = xx[17];
  rtdvd[41] = xx[18];
  rtdvd[42] = xx[19];
  rtdvd[43] = xx[20];
  rtdvd[44] = xx[21];
  rtdvd[45] = xx[22];
  rtdvd[46] = xx[23];
  rtdvd[47] = xx[24];
}

void SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValuesInts(
  const double *rtp, int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValues(const
  double *rtp, RuntimeDerivedValuesBundle *rtdv)
{
  SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValuesDoubles
    (rtp, rtdv->mDoubles.mValues);
  SatelliteServicing_Mission_acc66beb_1_computeAsmRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}

void SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValuesDoubles
  (const double *rtp, double *rtdvd)
{
  (void) rtp;
  (void) rtdvd;
}

void SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValuesInts(
  const double *rtp, int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValues(const
  double *rtp, RuntimeDerivedValuesBundle *rtdv)
{
  SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValuesDoubles
    (rtp, rtdv->mDoubles.mValues);
  SatelliteServicing_Mission_acc66beb_1_computeSimRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}
