//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission_types.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.27
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Wed Mar  6 22:36:49 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_SatelliteServicing_Mission_types_h_
#define RTW_HEADER_SatelliteServicing_Mission_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_RotStateBus_
#define DEFINED_TYPEDEF_FOR_RotStateBus_

struct RotStateBus
{
  real_T quat[4];
  real_T mrp[3];
  real_T euler[3];
  real_T angular_rate[3];
  real_T angular_accel[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_TransStateBus_
#define DEFINED_TYPEDEF_FOR_TransStateBus_

struct TransStateBus
{
  real_T position[3];
  real_T velocity[3];
  real_T accel[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_StateBus_
#define DEFINED_TYPEDEF_FOR_StateBus_

struct StateBus
{
  RotStateBus rotation;
  TransStateBus translation;
  real_T poseMatrix[16];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_jointControlDataBus_
#define DEFINED_TYPEDEF_FOR_jointControlDataBus_

struct jointControlDataBus
{
  real_T cntrlMode;
  real_T Kp[6];
  real_T Kd[6];
  real_T Ki[6];
  real_T qCmdDot[3];
  real_T qCmd[3];
  real_T eeCmd[12];
  real_T eeRefTraj[60];
  real_T refTime[5];
  real_T jointControlMode;
  real_T jointControlModeVec[5];
  real_T torqueLimit[3];
  real_T deadzone[3];
  real_T angleLimit[6];
  real_T rateLimit[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_satControlDataBus_Trans_
#define DEFINED_TYPEDEF_FOR_satControlDataBus_Trans_

struct satControlDataBus_Trans
{
  real_T cmdVel[3];
  real_T Kp[3];
  real_T Kd[3];
  real_T Ki[3];
  real_T forceLimit;
  real_T cmdPos[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_satControlDataBus_Rot_
#define DEFINED_TYPEDEF_FOR_satControlDataBus_Rot_

struct satControlDataBus_Rot
{
  real_T cmdAngle[3];
  real_T cmdRate[3];
  real_T Kp[3];
  real_T Kd[3];
  real_T Ki[3];
  real_T torqueLimit;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_aYxKlApFCan0g3NFJuMP7B_
#define DEFINED_TYPEDEF_FOR_struct_aYxKlApFCan0g3NFJuMP7B_

struct struct_aYxKlApFCan0g3NFJuMP7B
{
  real_T mass;
  real_T dim[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_kskDyotS523t4kXE8GJRSG_
#define DEFINED_TYPEDEF_FOR_struct_kskDyotS523t4kXE8GJRSG_

struct struct_kskDyotS523t4kXE8GJRSG
{
  real_T x;
  real_T y;
  real_T z;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_ohK4RcXGHvWkjV5Hv3ohZC_
#define DEFINED_TYPEDEF_FOR_struct_ohK4RcXGHvWkjV5Hv3ohZC_

struct struct_ohK4RcXGHvWkjV5Hv3ohZC
{
  struct_kskDyotS523t4kXE8GJRSG position;
  real_T orientation[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_6E2NORKtftzEWrxcV67s5_
#define DEFINED_TYPEDEF_FOR_struct_6E2NORKtftzEWrxcV67s5_

struct struct_6E2NORKtftzEWrxcV67s5
{
  struct_kskDyotS523t4kXE8GJRSG linear;
  real_T angular[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_UltVIOKv0gBS80BkpMl93E_
#define DEFINED_TYPEDEF_FOR_struct_UltVIOKv0gBS80BkpMl93E_

struct struct_UltVIOKv0gBS80BkpMl93E
{
  struct_ohK4RcXGHvWkjV5Hv3ohZC pose;
  struct_6E2NORKtftzEWrxcV67s5 twist;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_cXVdT1Na3picdh1vZOEcVB_
#define DEFINED_TYPEDEF_FOR_struct_cXVdT1Na3picdh1vZOEcVB_

struct struct_cXVdT1Na3picdh1vZOEcVB
{
  real_T attachOrientation[3];
  real_T bodyOrientation[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_NqyQleb1nsTesBSwEQEyYD_
#define DEFINED_TYPEDEF_FOR_struct_NqyQleb1nsTesBSwEQEyYD_

struct struct_NqyQleb1nsTesBSwEQEyYD
{
  real_T mass;
  real_T radius;
  real_T length;
  real_T Com[3];
  real_T MoI[3];
  real_T PoI[3];
  struct_aYxKlApFCan0g3NFJuMP7B panel;
  struct_aYxKlApFCan0g3NFJuMP7B panel_mount;
  struct_UltVIOKv0gBS80BkpMl93E IC;
  struct_cXVdT1Na3picdh1vZOEcVB camera;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_DHCRVnkEm19RV0sC60koMF_
#define DEFINED_TYPEDEF_FOR_struct_DHCRVnkEm19RV0sC60koMF_

struct struct_DHCRVnkEm19RV0sC60koMF
{
  real_T angular[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_bPcFM3YMrINmQpEBgpqClB_
#define DEFINED_TYPEDEF_FOR_struct_bPcFM3YMrINmQpEBgpqClB_

struct struct_bPcFM3YMrINmQpEBgpqClB
{
  struct_DHCRVnkEm19RV0sC60koMF twist;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_9YKzMAKtJEXVHW4YMJt7EC_
#define DEFINED_TYPEDEF_FOR_struct_9YKzMAKtJEXVHW4YMJt7EC_

struct struct_9YKzMAKtJEXVHW4YMJt7EC
{
  real_T mass;
  real_T dim[3];
  struct_bPcFM3YMrINmQpEBgpqClB IC;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_CjV8PIdupg6M5zWtsCj9wG_
#define DEFINED_TYPEDEF_FOR_struct_CjV8PIdupg6M5zWtsCj9wG_

struct struct_CjV8PIdupg6M5zWtsCj9wG
{
  struct_NqyQleb1nsTesBSwEQEyYD service;
  struct_9YKzMAKtJEXVHW4YMJt7EC client;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_sotpre7KxUaoL136v1cRVF_
#define DEFINED_TYPEDEF_FOR_struct_sotpre7KxUaoL136v1cRVF_

struct struct_sotpre7KxUaoL136v1cRVF
{
  real_T rel_position[3];
  real_T rel_orientation[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_OG8aupUXdrWkKEsenZVzDB_
#define DEFINED_TYPEDEF_FOR_struct_OG8aupUXdrWkKEsenZVzDB_

struct struct_OG8aupUXdrWkKEsenZVzDB
{
  real_T Joint_Limits[6];
};

#endif

// Parameters (default storage)
typedef struct P_SatelliteServicing_Mission_T_ P_SatelliteServicing_Mission_T;

// Forward declaration for rtModel
typedef struct tag_RTM_SatelliteServicing_Mi_T RT_MODEL_SatelliteServicing_M_T;

#endif                        // RTW_HEADER_SatelliteServicing_Mission_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
