/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "SatelliteServicing_Mission_acc66beb_1_geometries.h"

PmfMessageId SatelliteServicing_Mission_acc66beb_1_compDerivs(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *deriv, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  int ii[1];
  double xx[290];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  xx[4] = state[10];
  xx[5] = state[11];
  xx[6] = state[12];
  pm_math_Quaternion_compDeriv_ra(xx + 0, xx + 4, xx + 7);
  xx[0] = 1.0;
  xx[1] = 0.1498247203858118;
  xx[2] = 0.9887125735830982;
  xx[3] = xx[1] * state[6] + xx[2] * state[5];
  xx[4] = xx[3] * xx[3];
  xx[5] = xx[1] * state[5] - xx[2] * state[6];
  xx[6] = xx[5] * xx[5];
  xx[11] = 2.0;
  xx[12] = xx[0] - (xx[4] + xx[6]) * xx[11];
  xx[13] = xx[2] * state[3] - xx[1] * state[4];
  xx[14] = xx[5] * xx[13];
  xx[15] = xx[1] * state[3] + xx[2] * state[4];
  xx[16] = xx[15] * xx[3];
  xx[17] = xx[14] + xx[16];
  xx[18] = xx[3] * xx[13];
  xx[19] = xx[5] * xx[15];
  xx[20] = xx[18] - xx[19];
  xx[21] = xx[12];
  xx[22] = xx[17] * xx[11];
  xx[23] = xx[11] * xx[20];
  xx[24] = 21.89654004214702;
  xx[25] = 0.6991253654250121;
  xx[26] = 0.5;
  xx[27] = xx[26] * state[13];
  xx[28] = sin(xx[27]);
  xx[29] = xx[25] * xx[28];
  xx[30] = cos(xx[27]);
  xx[27] = xx[25] * xx[30];
  xx[25] = xx[29] - xx[27];
  xx[31] = xx[25] * xx[25];
  xx[32] = 0.1059420757741859;
  xx[33] = xx[32] * xx[30];
  xx[30] = xx[32] * xx[28];
  xx[28] = xx[33] - xx[30];
  xx[32] = xx[29] + xx[27];
  xx[27] = xx[32] * xx[25];
  xx[29] = xx[33] + xx[30];
  xx[30] = xx[28] * xx[29];
  xx[33] = xx[28] * xx[32];
  xx[34] = xx[29] * xx[25];
  xx[35] = xx[32] * xx[29];
  xx[36] = xx[28] * xx[25];
  xx[37] = (xx[31] + xx[28] * xx[28]) * xx[11] - xx[0];
  xx[38] = xx[11] * (xx[27] - xx[30]);
  xx[39] = - ((xx[33] + xx[34]) * xx[11]);
  xx[40] = - ((xx[30] + xx[27]) * xx[11]);
  xx[41] = (xx[31] + xx[29] * xx[29]) * xx[11] - xx[0];
  xx[42] = xx[11] * (xx[35] - xx[36]);
  xx[43] = xx[11] * (xx[34] - xx[33]);
  xx[44] = (xx[35] + xx[36]) * xx[11];
  xx[45] = (xx[31] + xx[32] * xx[32]) * xx[11] - xx[0];
  xx[27] = 0.706996650878707;
  xx[30] = xx[26] * state[17];
  xx[31] = cos(xx[30]);
  xx[33] = xx[27] * xx[31];
  xx[34] = 0.01247940889192258;
  xx[35] = 0.9993770574148331;
  xx[36] = sin(xx[30]);
  xx[30] = xx[35] * xx[36];
  xx[46] = xx[34] * xx[30];
  xx[47] = 0.03529160116614088;
  xx[48] = xx[47] * xx[36];
  xx[36] = xx[27] * xx[48];
  xx[49] = xx[33] + xx[46] - xx[36];
  xx[50] = xx[49] * xx[49];
  xx[51] = xx[46] - (xx[36] + xx[33]);
  xx[33] = (xx[50] + xx[51] * xx[51]) * xx[11] - xx[0];
  xx[36] = xx[34] * xx[31];
  xx[31] = xx[27] * xx[30];
  xx[27] = xx[34] * xx[48];
  xx[30] = xx[36] - xx[31] - xx[27];
  xx[34] = xx[30] * xx[51];
  xx[46] = xx[36] + xx[31] + xx[27];
  xx[27] = xx[46] * xx[49];
  xx[31] = xx[11] * (xx[34] - xx[27]);
  xx[36] = xx[46] * xx[51];
  xx[48] = xx[30] * xx[49];
  xx[52] = (xx[36] + xx[48]) * xx[11];
  xx[53] = (xx[34] + xx[27]) * xx[11];
  xx[27] = (xx[50] + xx[30] * xx[30]) * xx[11] - xx[0];
  xx[34] = xx[51] * xx[49];
  xx[54] = xx[30] * xx[46];
  xx[55] = xx[11] * (xx[34] - xx[54]);
  xx[56] = xx[11] * (xx[48] - xx[36]);
  xx[36] = (xx[54] + xx[34]) * xx[11];
  xx[34] = (xx[50] + xx[46] * xx[46]) * xx[11] - xx[0];
  xx[57] = xx[33];
  xx[58] = xx[31];
  xx[59] = - xx[52];
  xx[60] = xx[53];
  xx[61] = xx[27];
  xx[62] = xx[55];
  xx[63] = xx[56];
  xx[64] = - xx[36];
  xx[65] = xx[34];
  xx[48] = 1.874972840133549e-4;
  xx[50] = - 0.03048690607057176;
  xx[54] = 1.076602391309018e-3;
  xx[66] = 0.3005077589543408;
  xx[67] = xx[48];
  xx[68] = xx[50];
  xx[69] = xx[48];
  xx[70] = 0.3058106300311961;
  xx[71] = xx[54];
  xx[72] = xx[50];
  xx[73] = xx[54];
  xx[74] = 0.1307625769666682;
  pm_math_Matrix3x3_composeTranspose_ra(xx + 66, xx + 57, xx + 75);
  pm_math_Matrix3x3_compose_ra(xx + 57, xx + 75, xx + 66);
  xx[48] = 2.32122758249235e-5;
  xx[50] = 8.197090122227829e-7;
  xx[54] = 1.332840195117554e-4;
  xx[75] = xx[48] * xx[33] - xx[50] * xx[31] - xx[54] * xx[52];
  xx[76] = 9.400287671014188e-4;
  xx[77] = 3.319579941034257e-5;
  xx[78] = 5.39761001811936e-3;
  xx[79] = xx[76] * xx[33] - xx[77] * xx[31] - xx[78] * xx[52];
  xx[80] = xx[75] * xx[56] - xx[79] * xx[36];
  xx[81] = - xx[49];
  xx[82] = xx[51];
  xx[83] = xx[30];
  xx[84] = - xx[46];
  xx[85] = - 0.04301910471975233;
  xx[86] = 1.291704527118732e-3;
  xx[87] = 7.500000000000014e-3;
  pm_math_Quaternion_xform_ra(xx + 81, xx + 85, xx + 88);
  xx[85] = 0.1176215303281901 - xx[88];
  xx[86] = - xx[89];
  xx[87] = - xx[90];
  pm_math_Matrix3x3_postCross_ra(xx + 66, xx + 85, xx + 88);
  xx[30] = xx[80] - xx[90];
  xx[46] = 0.1023784696718099;
  xx[49] = xx[30] + xx[46] * xx[67];
  xx[51] = 2.963809584071401e-3;
  xx[97] = 2.838512081711205e-4;
  xx[98] = 4.109659807588575e-6;
  xx[99] = 2.396506957713739e-4;
  xx[100] = 5.198601248673849e-4;
  xx[101] = xx[97] * xx[33] - xx[98] * xx[31];
  xx[102] = xx[97] * xx[53] - xx[98] * xx[27];
  xx[103] = xx[97] * xx[56] + xx[98] * xx[36];
  xx[104] = xx[99] * xx[31] - xx[98] * xx[33];
  xx[105] = xx[99] * xx[27] - xx[98] * xx[53];
  xx[106] = - (xx[98] * xx[56] + xx[99] * xx[36]);
  xx[107] = - (xx[100] * xx[52]);
  xx[108] = xx[100] * xx[55];
  xx[109] = xx[100] * xx[34];
  pm_math_Matrix3x3_compose_ra(xx + 57, xx + 101, xx + 110);
  xx[52] = xx[75] * xx[33] + xx[79] * xx[31];
  xx[57] = xx[48] * xx[53] - xx[50] * xx[27] + xx[54] * xx[55];
  xx[58] = xx[76] * xx[53] - xx[77] * xx[27] + xx[78] * xx[55];
  xx[55] = xx[57] * xx[33] + xx[58] * xx[31];
  xx[59] = xx[48] * xx[56] + xx[50] * xx[36] + xx[54] * xx[34];
  xx[48] = xx[76] * xx[56] + xx[77] * xx[36] + xx[78] * xx[34];
  xx[34] = xx[59] * xx[33] + xx[48] * xx[31];
  xx[31] = xx[75] * xx[53] + xx[79] * xx[27];
  xx[33] = xx[57] * xx[53] + xx[58] * xx[27];
  xx[50] = xx[59] * xx[53] + xx[48] * xx[27];
  xx[27] = xx[57] * xx[56] - xx[58] * xx[36];
  xx[53] = xx[59] * xx[56] - xx[48] * xx[36];
  xx[56] = xx[52];
  xx[57] = xx[55];
  xx[58] = xx[34];
  xx[59] = xx[31];
  xx[60] = xx[33];
  xx[61] = xx[50];
  xx[62] = xx[80];
  xx[63] = xx[27];
  xx[64] = xx[53];
  pm_math_Matrix3x3_postCross_ra(xx + 56, xx + 85, xx + 101);
  pm_math_Matrix3x3_preCross_ra(xx + 88, xx + 85, xx + 56);
  xx[36] = xx[51] + xx[118] - xx[109] - xx[109] - xx[64];
  xx[48] = xx[27] - xx[93];
  xx[27] = xx[36] + xx[46] * xx[48];
  xx[54] = 0.820357293382213;
  xx[65] = xx[54] + xx[70];
  xx[70] = xx[48] + xx[65] * xx[46];
  xx[75] = xx[27] + xx[70] * xx[46];
  ii[0] = factorSymmetricPosDef(xx + 75, 1, xx + 76);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'SatelliteServicing_Mission/Mission/Robotic_Arm/RoboticArm/RoboticArmPlanar3Link/Joint 2' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[76] = xx[49] / xx[75];
  xx[77] = xx[66] - xx[49] * xx[76] + xx[54];
  xx[78] = xx[26] * state[15];
  xx[26] = cos(xx[78]);
  xx[79] = xx[26] * xx[26];
  xx[80] = xx[11] * xx[79] - xx[0];
  xx[90] = sin(xx[78]);
  xx[78] = xx[11] * xx[26] * xx[90];
  xx[93] = xx[70] * xx[76];
  xx[97] = xx[67] - xx[93];
  xx[98] = xx[77] * xx[80] - xx[78] * xx[97];
  xx[99] = xx[69] - xx[93];
  xx[93] = xx[70] / xx[75];
  xx[119] = xx[65] - xx[70] * xx[93];
  xx[120] = xx[99] * xx[80] - xx[78] * xx[119];
  xx[121] = xx[98] * xx[80] - xx[78] * xx[120];
  xx[122] = (xx[79] + xx[90] * xx[90]) * xx[11] - xx[0];
  xx[79] = xx[30] - xx[27] * xx[76];
  xx[123] = xx[48] - xx[27] * xx[93];
  xx[124] = xx[122] * (xx[80] * xx[79] - xx[78] * xx[123]);
  xx[125] = xx[46] * xx[90];
  xx[126] = 0.22 - xx[11] * xx[125] * xx[90];
  xx[127] = xx[77] * xx[78] + xx[97] * xx[80];
  xx[77] = xx[78] * xx[99] + xx[119] * xx[80];
  xx[97] = xx[127] * xx[80] - xx[77] * xx[78];
  xx[99] = xx[11] * xx[26] * xx[125];
  xx[119] = xx[126] * xx[97] - xx[99] * xx[121];
  xx[125] = xx[124] + xx[119];
  xx[128] = xx[125] + xx[46] * xx[97];
  xx[129] = 2.963809584071399e-3;
  xx[130] = xx[27] / xx[75];
  xx[131] = (xx[78] * xx[79] + xx[80] * xx[123]) * xx[122];
  xx[79] = xx[126] * xx[131] - xx[99] * xx[124];
  xx[123] = xx[127] * xx[78] + xx[77] * xx[80];
  xx[77] = xx[78] * xx[98] + xx[80] * xx[120];
  xx[98] = xx[123] * xx[126] - xx[77] * xx[99];
  xx[120] = xx[129] + (xx[36] - xx[27] * xx[130]) * xx[122] * xx[122] + xx[79] +
    xx[79] + xx[98] * xx[126] - xx[119] * xx[99];
  xx[36] = xx[131] + xx[98];
  xx[79] = xx[120] + xx[36] * xx[46];
  xx[98] = xx[54] + xx[123];
  xx[119] = xx[36] + xx[98] * xx[46];
  xx[123] = xx[79] + xx[119] * xx[46];
  ii[0] = factorSymmetricPosDef(xx + 123, 1, xx + 124);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'SatelliteServicing_Mission/Mission/Robotic_Arm/RoboticArm/RoboticArmPlanar3Link/Joint 1' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[124] = xx[128] / xx[123];
  xx[127] = xx[119] * xx[124];
  xx[131] = xx[53] - xx[96];
  xx[53] = xx[131] + xx[46] * xx[73];
  xx[96] = xx[53] * xx[76];
  xx[132] = (xx[68] - xx[96]) * xx[122];
  xx[133] = xx[53] * xx[93];
  xx[134] = (xx[71] - xx[133]) * xx[122];
  xx[135] = xx[132] * xx[80] - xx[78] * xx[134];
  xx[136] = xx[53] / xx[75];
  xx[137] = xx[122] * (xx[131] - xx[27] * xx[136]) * xx[122];
  xx[138] = xx[72] - xx[96];
  xx[96] = xx[73] - xx[133];
  xx[133] = (xx[78] * xx[138] + xx[96] * xx[80]) * xx[122];
  xx[139] = xx[122] * (xx[138] * xx[80] - xx[78] * xx[96]);
  xx[96] = xx[126] * xx[133] - xx[99] * xx[139];
  xx[138] = xx[137] + xx[96];
  xx[140] = xx[138] + xx[46] * xx[133];
  xx[141] = xx[140] * xx[124];
  xx[142] = xx[119] / xx[123];
  xx[143] = xx[78] * xx[132] + xx[134] * xx[80];
  xx[132] = xx[140] * xx[142];
  xx[134] = (xx[74] - xx[53] * xx[136] + xx[54]) * xx[122] * xx[122];
  xx[144] = xx[140] / xx[123];
  xx[145] = xx[121] - xx[128] * xx[124] + xx[54];
  xx[146] = xx[97] - xx[127];
  xx[147] = xx[135] - xx[141];
  xx[148] = xx[77] - xx[127];
  xx[149] = xx[98] - xx[119] * xx[142];
  xx[150] = xx[143] - xx[132];
  xx[151] = xx[139] - xx[141];
  xx[152] = xx[133] - xx[132];
  xx[153] = xx[134] - xx[140] * xx[144] + xx[54];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 145, xx + 37, xx + 154);
  pm_math_Matrix3x3_compose_ra(xx + 37, xx + 154, xx + 145);
  xx[127] = xx[24] + xx[145];
  xx[132] = xx[24] + xx[149];
  xx[141] = xx[24] + xx[153];
  xx[154] = xx[127];
  xx[155] = xx[146];
  xx[156] = xx[147];
  xx[157] = xx[148];
  xx[158] = xx[132];
  xx[159] = xx[150];
  xx[160] = xx[151];
  xx[161] = xx[152];
  xx[162] = xx[141];
  pm_math_Matrix3x3_xform_ra(xx + 154, xx + 21, xx + 163);
  xx[24] = xx[16] - xx[14];
  xx[14] = xx[15] * xx[15];
  xx[16] = xx[0] - (xx[6] + xx[14]) * xx[11];
  xx[6] = xx[15] * xx[13];
  xx[166] = xx[5] * xx[3];
  xx[167] = xx[6] + xx[166];
  xx[168] = xx[11] * xx[24];
  xx[169] = xx[16];
  xx[170] = - (xx[167] * xx[11]);
  pm_math_Matrix3x3_xform_ra(xx + 154, xx + 168, xx + 171);
  xx[174] = pm_math_Vector3_dot_ra(xx + 21, xx + 171);
  xx[175] = xx[18] + xx[19];
  xx[18] = xx[6] - xx[166];
  xx[6] = xx[0] - (xx[14] + xx[4]) * xx[11];
  xx[176] = - (xx[175] * xx[11]);
  xx[177] = xx[11] * xx[18];
  xx[178] = xx[6];
  pm_math_Matrix3x3_xform_ra(xx + 154, xx + 176, xx + 179);
  xx[4] = pm_math_Vector3_dot_ra(xx + 21, xx + 179);
  xx[14] = xx[52] - xx[88];
  xx[19] = xx[112] - xx[103] - xx[107] - xx[58];
  xx[52] = xx[55] - xx[91];
  xx[55] = xx[19] + xx[46] * xx[52];
  xx[88] = xx[14] - xx[55] * xx[76];
  xx[91] = xx[52] - xx[55] * xx[93];
  xx[166] = xx[80] * xx[88] - xx[78] * xx[91];
  xx[182] = xx[31] - xx[89];
  xx[31] = xx[115] - xx[106] - xx[108] - xx[61];
  xx[89] = xx[33] - xx[92];
  xx[33] = xx[31] + xx[46] * xx[89];
  xx[92] = xx[182] - xx[33] * xx[76];
  xx[183] = xx[89] - xx[33] * xx[93];
  xx[184] = xx[80] * xx[92] - xx[78] * xx[183];
  xx[185] = xx[80] * xx[166] - xx[78] * xx[184];
  xx[186] = xx[99] * xx[135];
  xx[187] = xx[185] + xx[186];
  xx[188] = xx[55] / xx[75];
  xx[189] = xx[27] * xx[188];
  xx[190] = xx[122] * (xx[19] - xx[189]);
  xx[19] = xx[33] / xx[75];
  xx[191] = xx[27] * xx[19];
  xx[192] = xx[122] * (xx[31] - xx[191]);
  xx[31] = xx[78] * xx[88] + xx[80] * xx[91];
  xx[88] = xx[78] * xx[92] + xx[80] * xx[183];
  xx[91] = xx[31] * xx[80] - xx[88] * xx[78];
  xx[92] = xx[126] * xx[91] - xx[99] * xx[185];
  xx[183] = xx[99] * xx[137];
  xx[185] = xx[190] * xx[80] - xx[78] * xx[192] + xx[92] + xx[183] + xx[96] *
    xx[99];
  xx[193] = xx[143] * xx[99];
  xx[194] = xx[91] + xx[193];
  xx[91] = xx[185] + xx[46] * xx[194];
  xx[195] = xx[34] - xx[94];
  xx[34] = xx[122] * (xx[195] - xx[55] * xx[136]);
  xx[94] = xx[50] - xx[95];
  xx[50] = xx[122] * (xx[94] - xx[33] * xx[136]);
  xx[95] = xx[34] * xx[80] - xx[78] * xx[50];
  xx[196] = xx[99] * xx[134];
  xx[197] = xx[95] + xx[196];
  xx[198] = xx[78] * xx[166] + xx[80] * xx[184];
  xx[166] = xx[126] * xx[135];
  xx[184] = xx[198] - xx[166];
  xx[199] = xx[31] * xx[78] + xx[88] * xx[80];
  xx[31] = xx[199] * xx[126] - xx[198] * xx[99];
  xx[88] = xx[126] * xx[137];
  xx[137] = xx[78] * xx[190] + xx[192] * xx[80] + xx[31] - xx[88] - xx[126] *
    xx[96];
  xx[96] = xx[143] * xx[126];
  xx[190] = xx[199] - xx[96];
  xx[192] = xx[137] + xx[46] * xx[190];
  xx[198] = xx[78] * xx[34] + xx[50] * xx[80];
  xx[34] = xx[126] * xx[134];
  xx[50] = xx[198] - xx[34];
  xx[199] = xx[187] - xx[91] * xx[124];
  xx[200] = xx[194] - xx[91] * xx[142];
  xx[201] = xx[197] - xx[91] * xx[144];
  xx[202] = xx[184] - xx[192] * xx[124];
  xx[203] = xx[190] - xx[192] * xx[142];
  xx[204] = xx[50] - xx[192] * xx[144];
  xx[205] = xx[125] - xx[79] * xx[124];
  xx[206] = xx[36] - xx[79] * xx[142];
  xx[207] = xx[138] - xx[79] * xx[144];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 199, xx + 37, xx + 208);
  pm_math_Matrix3x3_compose_ra(xx + 37, xx + 208, xx + 199);
  xx[208] = xx[46] * xx[29];
  xx[209] = xx[32] * xx[46];
  xx[210] = - ((xx[208] * xx[29] + xx[32] * xx[209]) * xx[11] - xx[46]);
  xx[211] = 0.4228853449076685 - (xx[209] * xx[25] + xx[28] * xx[208]) * xx[11];
  xx[212] = 0.1007490398879719 - xx[11] * (xx[28] * xx[209] - xx[208] * xx[25]);
  pm_math_Matrix3x3_postCross_ra(xx + 145, xx + 210, xx + 213);
  xx[145] = xx[199] - xx[213];
  xx[149] = 0.01325891460016969;
  xx[153] = 5.788614537302341e-3;
  xx[208] = xx[200] - xx[216];
  xx[209] = xx[208] + xx[149] * xx[150] - xx[132] * xx[153];
  xx[132] = xx[201] - xx[219];
  xx[150] = xx[132] + xx[141] * xx[149] - xx[153] * xx[152];
  xx[222] = xx[145] + xx[149] * xx[147] - xx[153] * xx[146];
  xx[223] = xx[209];
  xx[224] = xx[150];
  xx[141] = pm_math_Vector3_dot_ra(xx + 21, xx + 222);
  xx[146] = 0.9551051063226266;
  xx[147] = xx[202] - xx[214];
  xx[152] = 0.2962671697580482;
  xx[225] = xx[205] - xx[215];
  xx[226] = 9.456916405766791e-3;
  xx[227] = xx[146] * xx[147] - xx[152] * xx[225] + xx[127] * xx[226];
  xx[228] = xx[203] - xx[217];
  xx[229] = xx[206] - xx[218];
  xx[230] = xx[146] * xx[228] - xx[152] * xx[229] + xx[226] * xx[148];
  xx[231] = xx[204] - xx[220];
  xx[232] = xx[207] - xx[221];
  xx[233] = xx[146] * xx[231] - xx[152] * xx[232] + xx[226] * xx[151];
  xx[234] = xx[227];
  xx[235] = xx[230];
  xx[236] = xx[233];
  xx[237] = pm_math_Vector3_dot_ra(xx + 21, xx + 234);
  xx[238] = 0.01094868059313084;
  xx[239] = xx[152] * xx[147] + xx[146] * xx[225] - xx[127] * xx[238];
  xx[127] = xx[152] * xx[228] + xx[146] * xx[229] - xx[238] * xx[148];
  xx[148] = xx[152] * xx[231] + xx[146] * xx[232] - xx[238] * xx[151];
  xx[240] = xx[239];
  xx[241] = xx[127];
  xx[242] = xx[148];
  xx[151] = pm_math_Vector3_dot_ra(xx + 21, xx + 240);
  xx[243] = pm_math_Vector3_dot_ra(xx + 168, xx + 179);
  xx[244] = pm_math_Vector3_dot_ra(xx + 168, xx + 222);
  xx[245] = pm_math_Vector3_dot_ra(xx + 168, xx + 234);
  xx[246] = pm_math_Vector3_dot_ra(xx + 168, xx + 240);
  xx[247] = pm_math_Vector3_dot_ra(xx + 176, xx + 222);
  xx[222] = pm_math_Vector3_dot_ra(xx + 176, xx + 234);
  xx[223] = pm_math_Vector3_dot_ra(xx + 176, xx + 240);
  xx[224] = 6.888807787960385e-4;
  xx[234] = 6.888807787960384e-4;
  xx[235] = xx[234] + xx[110] - xx[101] - xx[101] - xx[56];
  xx[236] = xx[235] - xx[55] * xx[188];
  xx[240] = xx[111] - xx[102] - xx[104] - xx[57];
  xx[241] = xx[33] * xx[188];
  xx[242] = xx[240] - xx[241];
  xx[248] = xx[236] * xx[80] - xx[78] * xx[242];
  xx[249] = xx[113] - xx[104] - xx[102] - xx[59];
  xx[250] = xx[249] - xx[241];
  xx[241] = 3.215220610171269e-3;
  xx[101] = xx[241] + xx[114] - xx[105] - xx[105] - xx[60];
  xx[102] = xx[101] - xx[33] * xx[19];
  xx[104] = xx[80] * xx[250] - xx[78] * xx[102];
  xx[105] = xx[99] * xx[95];
  xx[109] = xx[224] + xx[80] * xx[248] - xx[78] * xx[104] + xx[105] + xx[105] +
    xx[99] * xx[196];
  xx[105] = xx[91] / xx[123];
  xx[251] = xx[78] * xx[236] + xx[80] * xx[242];
  xx[236] = xx[78] * xx[250] + xx[102] * xx[80];
  xx[102] = xx[126] * xx[95];
  xx[95] = xx[198] * xx[99];
  xx[242] = xx[251] * xx[80] - xx[236] * xx[78] - xx[102] + xx[95] - xx[34] *
    xx[99];
  xx[250] = xx[192] * xx[105];
  xx[252] = xx[79] * xx[105];
  xx[253] = xx[78] * xx[248] + xx[80] * xx[104] + xx[95] - xx[102] - xx[126] *
    xx[196];
  xx[95] = 3.215220610171268e-3;
  xx[102] = xx[198] * xx[126];
  xx[104] = xx[95] + xx[251] * xx[78] + xx[236] * xx[80] - xx[102] - xx[102] +
    xx[126] * xx[34];
  xx[34] = xx[192] / xx[123];
  xx[102] = xx[79] * xx[34];
  xx[196] = xx[116] - xx[107] - xx[103] - xx[62];
  xx[103] = xx[196] - xx[189];
  xx[56] = xx[117] - xx[108] - xx[106] - xx[63];
  xx[57] = xx[56] - xx[191];
  xx[58] = xx[122] * (xx[80] * xx[103] - xx[78] * xx[57]) + xx[183] + xx[92] -
    (xx[99] * xx[186] - xx[126] * xx[193]);
  xx[59] = (xx[78] * xx[103] + xx[80] * xx[57]) * xx[122] - xx[88] + xx[31] -
    (xx[126] * xx[96] - xx[166] * xx[99]);
  xx[31] = xx[79] / xx[123];
  xx[110] = xx[109] - xx[91] * xx[105];
  xx[111] = xx[242] - xx[250];
  xx[112] = xx[185] - xx[252];
  xx[113] = xx[253] - xx[250];
  xx[114] = xx[104] - xx[192] * xx[34];
  xx[115] = xx[137] - xx[102];
  xx[116] = xx[58] - xx[252];
  xx[117] = xx[59] - xx[102];
  xx[118] = xx[120] - xx[79] * xx[31];
  pm_math_Matrix3x3_composeTranspose_ra(xx + 110, xx + 37, xx + 254);
  pm_math_Matrix3x3_compose_ra(xx + 37, xx + 254, xx + 110);
  pm_math_Matrix3x3_postCross_ra(xx + 199, xx + 210, xx + 37);
  pm_math_Matrix3x3_preCross_ra(xx + 213, xx + 210, xx + 198);
  xx[57] = 0.8113174366025879;
  xx[60] = xx[111] - xx[38] - xx[40] - xx[199];
  xx[61] = xx[112] - xx[39] - xx[43] - xx[200];
  xx[62] = xx[146] * xx[60] - xx[152] * xx[61] + xx[226] * xx[145] + xx[233] *
    xx[149] - xx[230] * xx[153];
  xx[63] = xx[152] * xx[60] + xx[146] * xx[61] - xx[238] * xx[145] + xx[148] *
    xx[149] - xx[127] * xx[153];
  xx[60] = 0.7788170342228772;
  xx[61] = xx[60] + xx[114] - xx[41] - xx[41] - xx[202];
  xx[64] = xx[115] - xx[42] - xx[44] - xx[203];
  xx[78] = xx[117] - xx[44] - xx[42] - xx[205];
  xx[80] = 0.9664900098328829;
  xx[38] = xx[80] + xx[118] - xx[45] - xx[45] - xx[206];
  xx[39] = xx[61] * xx[152] + xx[146] * xx[64] - xx[238] * xx[147];
  xx[40] = xx[152] * xx[78] + xx[38] * xx[146] - xx[238] * xx[225];
  xx[41] = xx[39] * xx[146] - xx[40] * xx[152] + xx[239] * xx[226];
  xx[254] = pm_math_Vector3_dot_ra(xx + 21, xx + 163);
  xx[255] = xx[174];
  xx[256] = xx[4];
  xx[257] = xx[141];
  xx[258] = xx[237];
  xx[259] = xx[151];
  xx[260] = xx[174];
  xx[261] = pm_math_Vector3_dot_ra(xx + 168, xx + 171);
  xx[262] = xx[243];
  xx[263] = xx[244];
  xx[264] = xx[245];
  xx[265] = xx[246];
  xx[266] = xx[4];
  xx[267] = xx[243];
  xx[268] = pm_math_Vector3_dot_ra(xx + 176, xx + 179);
  xx[269] = xx[247];
  xx[270] = xx[222];
  xx[271] = xx[223];
  xx[272] = xx[141];
  xx[273] = xx[244];
  xx[274] = xx[247];
  xx[275] = xx[110] - xx[37] - xx[37] - xx[198] - xx[153] * xx[208] + xx[149] *
    xx[132] - xx[209] * xx[153] + xx[150] * xx[149] + xx[57];
  xx[276] = xx[62];
  xx[277] = xx[63];
  xx[278] = xx[237];
  xx[279] = xx[245];
  xx[280] = xx[222];
  xx[281] = xx[62];
  xx[282] = (xx[61] * xx[146] - xx[152] * xx[64] + xx[226] * xx[147]) * xx[146]
    - (xx[146] * xx[78] - xx[38] * xx[152] + xx[226] * xx[225]) * xx[152] + xx
    [227] * xx[226];
  xx[283] = xx[41];
  xx[284] = xx[151];
  xx[285] = xx[246];
  xx[286] = xx[223];
  xx[287] = xx[63];
  xx[288] = xx[41];
  xx[289] = xx[39] * xx[152] + xx[40] * xx[146] - xx[239] * xx[238];
  ii[0] = factorSymmetricPosDef(xx + 254, 6, xx + 37);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'SatelliteServicing_Mission/ServicingSatellite/SatConfiguration' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[37] = xx[25];
  xx[38] = xx[28];
  xx[39] = - xx[29];
  xx[40] = - xx[32];
  xx[4] = xx[1] * state[11];
  xx[25] = xx[1] * state[12];
  xx[28] = state[11] - (xx[1] * xx[4] - xx[2] * xx[25]) * xx[11];
  xx[29] = state[12] - xx[11] * (xx[2] * xx[4] + xx[1] * xx[25]);
  xx[41] = state[10];
  xx[42] = xx[28];
  xx[43] = xx[29];
  pm_math_Quaternion_inverseXform_ra(xx + 37, xx + 41, xx + 61);
  xx[1] = xx[62] * xx[90];
  xx[2] = xx[61] * xx[90];
  xx[4] = xx[61] + xx[11] * (xx[26] * xx[1] - xx[2] * xx[90]);
  xx[25] = xx[62] - (xx[26] * xx[2] + xx[1] * xx[90]) * xx[11];
  xx[1] = xx[63] + state[14];
  xx[2] = xx[1] + state[16];
  xx[106] = xx[4];
  xx[107] = xx[25];
  xx[108] = xx[2];
  pm_math_Quaternion_inverseXform_ra(xx + 81, xx + 106, xx + 110);
  xx[32] = xx[47] * state[18];
  xx[44] = xx[110] + xx[32];
  xx[45] = xx[35] * state[18];
  xx[64] = xx[111] + xx[45];
  xx[113] = xx[110] + xx[44];
  xx[114] = xx[111] + xx[64];
  xx[115] = xx[112] + xx[112];
  xx[78] = 7.495327930611261e-3;
  xx[88] = 2.646870087460475e-4;
  xx[92] = 0.04303789260844221;
  xx[116] = - (xx[78] * state[18]);
  xx[117] = xx[88] * state[18];
  xx[118] = - (xx[92] * state[18]);
  pm_math_Vector3_cross_ra(xx + 113, xx + 116, xx + 163);
  pm_math_Vector3_cross_ra(xx + 106, xx + 85, xx + 113);
  pm_math_Vector3_cross_ra(xx + 106, xx + 113, xx + 116);
  pm_math_Quaternion_inverseXform_ra(xx + 81, xx + 116, xx + 113);
  xx[96] = 0.3058172512351932;
  xx[102] = (xx[163] + xx[113]) * xx[96];
  xx[103] = 2.094395102393195;
  xx[116] = 0.0;
  xx[117] = state[17] + xx[103];
  if (xx[116] < xx[117])
    xx[117] = xx[116];
  xx[118] = 1.74532925199433e-3;
  xx[120] = - (xx[117] / xx[118]);
  if (xx[0] < xx[120])
    xx[120] = xx[0];
  xx[122] = 3.0;
  xx[127] = 5.729577951308232;
  xx[137] = xx[127] * state[18];
  xx[141] = 5729.577951308232;
  xx[148] = xx[120] * xx[120] * (xx[122] - xx[11] * xx[120]) * ((- xx[117] ==
    xx[116] ? xx[116] : - xx[137]) - xx[141] * xx[117]);
  if (xx[116] > xx[148])
    xx[148] = xx[116];
  xx[117] = state[17] - xx[103];
  if (xx[116] > xx[117])
    xx[117] = xx[116];
  xx[120] = xx[117] / xx[118];
  if (xx[0] < xx[120])
    xx[120] = xx[0];
  xx[150] = (xx[141] * xx[117] + (xx[117] == xx[116] ? xx[116] : xx[137])) * xx
    [120] * xx[120] * (xx[122] - xx[11] * xx[120]);
  if (xx[116] > xx[150])
    xx[150] = xx[116];
  xx[171] = xx[44];
  xx[172] = xx[64];
  xx[173] = xx[112];
  xx[117] = 2.839526886367604e-4;
  xx[120] = 4.060798073014784e-4;
  xx[179] = xx[44] * xx[117];
  xx[180] = xx[64] * xx[120];
  xx[181] = xx[100] * xx[112];
  pm_math_Vector3_cross_ra(xx + 171, xx + 179, xx + 198);
  xx[44] = xx[198] - xx[117] * xx[112] * xx[45];
  xx[64] = xx[199] + xx[120] * xx[112] * xx[32];
  xx[171] = - xx[78];
  xx[172] = xx[88];
  xx[173] = - xx[92];
  xx[78] = (xx[164] + xx[114]) * xx[96];
  xx[88] = (xx[165] + xx[115]) * xx[96];
  xx[112] = xx[102];
  xx[113] = xx[78];
  xx[114] = xx[88];
  xx[92] = (input[2] + xx[148] - xx[150] - (xx[47] * xx[44] + xx[64] * xx[35] +
             pm_math_Vector3_dot_ra(xx + 171, xx + 112))) / 9.895830416998717e-4;
  xx[112] = xx[102] - 2.292200584845905e-3 * xx[92];
  xx[113] = xx[78] + 8.09458534523818e-5 * xx[92];
  xx[114] = xx[88] - 0.01316173001646924 * xx[92];
  pm_math_Quaternion_xform_ra(xx + 81, xx + 112, xx + 163);
  xx[35] = xx[25] * state[16];
  xx[47] = xx[4] * state[16];
  xx[213] = xx[54] + xx[66];
  xx[214] = xx[67];
  xx[215] = xx[68];
  xx[216] = xx[69];
  xx[217] = xx[65];
  xx[218] = xx[71];
  xx[219] = xx[72];
  xx[220] = xx[73];
  xx[221] = xx[54] + xx[74];
  xx[65] = xx[61];
  xx[66] = xx[62];
  xx[67] = xx[1];
  xx[71] = - (xx[1] * xx[99]);
  xx[72] = xx[1] * xx[126];
  xx[73] = - (xx[126] * xx[62] - xx[61] * xx[99]);
  pm_math_Vector3_cross_ra(xx + 65, xx + 71, xx + 112);
  xx[68] = xx[113] * xx[90];
  xx[69] = xx[112] * xx[90];
  xx[71] = xx[46] * state[16];
  xx[72] = xx[112] + xx[11] * (xx[26] * xx[68] - xx[69] * xx[90]) - (xx[1] + xx
    [2]) * xx[71];
  xx[73] = xx[113] - (xx[26] * xx[69] + xx[68] * xx[90]) * xx[11];
  xx[68] = (xx[4] + xx[4]) * xx[71] + xx[114];
  xx[112] = xx[72];
  xx[113] = xx[73];
  xx[114] = xx[68];
  pm_math_Matrix3x3_xform_ra(xx + 213, xx + 112, xx + 171);
  xx[69] = state[15] + xx[103];
  if (xx[116] < xx[69])
    xx[69] = xx[116];
  xx[71] = - (xx[69] / xx[118]);
  if (xx[0] < xx[71])
    xx[71] = xx[0];
  xx[74] = xx[127] * state[16];
  xx[78] = xx[71] * xx[71] * (xx[122] - xx[11] * xx[71]) * ((- xx[69] == xx[116]
    ? xx[116] : - xx[74]) - xx[141] * xx[69]);
  if (xx[116] > xx[78])
    xx[78] = xx[116];
  xx[69] = state[15] - xx[103];
  if (xx[116] > xx[69])
    xx[69] = xx[116];
  xx[71] = xx[69] / xx[118];
  if (xx[0] < xx[71])
    xx[71] = xx[0];
  xx[88] = (xx[141] * xx[69] + (xx[69] == xx[116] ? xx[116] : xx[74])) * xx[71] *
    xx[71] * (xx[122] - xx[11] * xx[71]);
  if (xx[116] > xx[88])
    xx[88] = xx[116];
  xx[179] = xx[4] * xx[234];
  xx[180] = xx[241] * xx[25];
  xx[181] = xx[2] * xx[51];
  pm_math_Vector3_cross_ra(xx + 106, xx + 179, xx + 201);
  xx[106] = xx[44] + 1.002114503742193e-5 * xx[92];
  xx[107] = xx[64] + 4.05826842896534e-4 * xx[92];
  xx[108] = xx[200] + xx[100] * (xx[110] * xx[45] - xx[111] * xx[32]);
  pm_math_Quaternion_xform_ra(xx + 81, xx + 106, xx + 179);
  pm_math_Vector3_cross_ra(xx + 85, xx + 163, xx + 106);
  xx[213] = xx[14];
  xx[214] = xx[52];
  xx[215] = xx[195];
  xx[216] = xx[182];
  xx[217] = xx[89];
  xx[218] = xx[94];
  xx[219] = xx[30];
  xx[220] = xx[48];
  xx[221] = xx[131];
  pm_math_Matrix3x3_xform_ra(xx + 213, xx + 112, xx + 198);
  xx[2] = xx[203] + xx[181] + xx[108] + xx[35] * xx[196] - xx[47] * xx[56] + xx
    [200];
  xx[4] = xx[164] + xx[35] * xx[52] - xx[47] * xx[89] + xx[172];
  xx[25] = (input[1] + xx[78] - xx[88] - (xx[2] + xx[4] * xx[46])) / xx[75];
  xx[30] = xx[163] + xx[35] * xx[14] - xx[47] * xx[182] + xx[171] + xx[49] * xx
    [25];
  xx[14] = xx[4] + xx[70] * xx[25];
  xx[4] = xx[14] * xx[90];
  xx[32] = xx[30] * xx[90];
  xx[44] = xx[30] - (xx[26] * xx[4] + xx[32] * xx[90]) * xx[11];
  xx[30] = xx[62] * state[14];
  xx[45] = xx[61] * state[14];
  xx[213] = xx[54] + xx[121];
  xx[214] = xx[97];
  xx[215] = xx[135];
  xx[216] = xx[77];
  xx[217] = xx[98];
  xx[218] = xx[143];
  xx[219] = xx[139];
  xx[220] = xx[133];
  xx[221] = xx[54] + xx[134];
  pm_math_Vector3_cross_ra(xx + 41, xx + 210, xx + 69);
  pm_math_Vector3_cross_ra(xx + 41, xx + 69, xx + 96);
  pm_math_Quaternion_inverseXform_ra(xx + 37, xx + 96, xx + 69);
  xx[48] = xx[46] * state[14];
  xx[49] = xx[69] - (xx[63] + xx[1]) * xx[48];
  xx[51] = (xx[61] + xx[61]) * xx[48] + xx[71];
  xx[96] = xx[49];
  xx[97] = xx[70];
  xx[98] = xx[51];
  pm_math_Matrix3x3_xform_ra(xx + 213, xx + 96, xx + 110);
  xx[48] = state[13] + xx[103];
  if (xx[116] < xx[48])
    xx[48] = xx[116];
  xx[52] = - (xx[48] / xx[118]);
  if (xx[0] < xx[52])
    xx[52] = xx[0];
  xx[54] = xx[127] * state[14];
  xx[56] = xx[52] * xx[52] * (xx[122] - xx[11] * xx[52]) * ((- xx[48] == xx[116]
    ? xx[116] : - xx[54]) - xx[141] * xx[48]);
  if (xx[116] > xx[56])
    xx[56] = xx[116];
  xx[48] = state[13] - xx[103];
  if (xx[116] > xx[48])
    xx[48] = xx[116];
  xx[52] = xx[48] / xx[118];
  if (xx[0] < xx[52])
    xx[52] = xx[0];
  xx[0] = (xx[141] * xx[48] + (xx[48] == xx[116] ? xx[116] : xx[54])) * xx[52] *
    xx[52] * (xx[122] - xx[11] * xx[52]);
  if (xx[116] > xx[0])
    xx[0] = xx[116];
  xx[113] = xx[224] * xx[61];
  xx[114] = xx[95] * xx[62];
  xx[115] = xx[1] * xx[129];
  pm_math_Vector3_cross_ra(xx + 65, xx + 113, xx + 61);
  xx[1] = xx[14] + xx[11] * (xx[26] * xx[32] - xx[4] * xx[90]);
  xx[213] = xx[187];
  xx[214] = xx[194];
  xx[215] = xx[197];
  xx[216] = xx[184];
  xx[217] = xx[190];
  xx[218] = xx[50];
  xx[219] = xx[125];
  xx[220] = xx[36];
  xx[221] = xx[138];
  pm_math_Matrix3x3_xform_ra(xx + 213, xx + 96, xx + 64);
  xx[4] = xx[63] + xx[2] + xx[27] * xx[25] + xx[1] * xx[126] - xx[99] * xx[44] +
    xx[30] * xx[58] - xx[45] * xx[59] + xx[66];
  xx[2] = xx[1] + xx[30] * xx[194] - xx[45] * xx[190] + xx[111];
  xx[1] = (input[0] + xx[56] - xx[0] - (xx[4] + xx[2] * xx[46])) / xx[123];
  xx[0] = xx[165] + xx[35] * xx[195] - xx[47] * xx[94] + xx[173] + xx[53] * xx
    [25];
  xx[52] = xx[44] + xx[30] * xx[187] - xx[45] * xx[184] + xx[110] + xx[128] *
    xx[1];
  xx[53] = xx[2] + xx[119] * xx[1];
  xx[54] = xx[0] + xx[30] * xx[197] - xx[45] * xx[50] + xx[112] + xx[140] * xx[1];
  pm_math_Quaternion_xform_ra(xx + 37, xx + 52, xx + 94);
  xx[110] = xx[13];
  xx[111] = xx[15];
  xx[112] = xx[3];
  xx[113] = - xx[5];
  xx[13] = state[7];
  xx[14] = state[8];
  xx[15] = state[9];
  pm_math_Quaternion_inverseXform_ra(xx + 110, xx + 13, xx + 52);
  xx[13] = xx[52] + xx[153] * xx[28] - xx[29] * xx[149];
  xx[14] = xx[53] - xx[153] * state[10];
  xx[15] = xx[54] + xx[149] * state[10];
  pm_math_Vector3_cross_ra(xx + 41, xx + 13, xx + 110);
  xx[13] = - xx[52];
  xx[14] = - xx[53];
  xx[15] = - xx[54];
  pm_math_Vector3_cross_ra(xx + 41, xx + 13, xx + 52);
  xx[2] = xx[110] + xx[52];
  xx[3] = xx[111] + xx[53];
  xx[5] = xx[112] + xx[54];
  xx[13] = xx[2];
  xx[14] = xx[3];
  xx[15] = xx[5];
  pm_math_Matrix3x3_xform_ra(xx + 154, xx + 13, xx + 52);
  xx[27] = xx[94] + xx[52];
  xx[32] = xx[95] + xx[53];
  xx[36] = xx[96] + xx[54];
  xx[52] = xx[27];
  xx[53] = xx[32];
  xx[54] = xx[36];
  xx[110] = xx[57] * state[10];
  xx[111] = xx[60] * xx[28];
  xx[112] = xx[29] * xx[80];
  pm_math_Vector3_cross_ra(xx + 41, xx + 110, xx + 56);
  xx[28] = xx[201] + xx[179] + xx[106] + xx[235] * xx[35] - xx[47] * xx[240] +
    xx[198] + xx[55] * xx[25];
  xx[29] = xx[202] + xx[180] + xx[107] + xx[35] * xx[249] - xx[101] * xx[47] +
    xx[199] + xx[33] * xx[25];
  xx[33] = xx[29] * xx[90];
  xx[41] = xx[28] * xx[90];
  xx[42] = xx[61] + xx[28] - (xx[26] * xx[33] + xx[41] * xx[90]) * xx[11] + xx[0]
    * xx[99] + xx[109] * xx[30] - xx[242] * xx[45] + xx[64] + xx[91] * xx[1];
  xx[43] = xx[62] + xx[29] + xx[11] * (xx[26] * xx[41] - xx[33] * xx[90]) - xx[0]
    * xx[126] + xx[253] * xx[30] - xx[104] * xx[45] + xx[65] + xx[192] * xx[1];
  xx[44] = xx[4] + xx[79] * xx[1];
  pm_math_Quaternion_xform_ra(xx + 37, xx + 42, xx + 59);
  pm_math_Vector3_cross_ra(xx + 210, xx + 94, xx + 41);
  xx[106] = xx[145];
  xx[107] = xx[208];
  xx[108] = xx[132];
  xx[109] = xx[147];
  xx[110] = xx[228];
  xx[111] = xx[231];
  xx[112] = xx[225];
  xx[113] = xx[229];
  xx[114] = xx[232];
  pm_math_Matrix3x3_xform_ra(xx + 106, xx + 13, xx + 62);
  xx[0] = xx[57] + xx[60] + xx[42] + xx[63];
  xx[4] = xx[58] + xx[61] + xx[43] + xx[64];
  xx[106] = - pm_math_Vector3_dot_ra(xx + 21, xx + 52);
  xx[107] = - pm_math_Vector3_dot_ra(xx + 168, xx + 52);
  xx[108] = - pm_math_Vector3_dot_ra(xx + 176, xx + 52);
  xx[109] = - (xx[56] + xx[59] + xx[41] + xx[62] + xx[36] * xx[149] - xx[32] *
               xx[153]);
  xx[110] = - (xx[0] * xx[146] - xx[4] * xx[152] + xx[27] * xx[226]);
  xx[111] = - (xx[0] * xx[152] + xx[4] * xx[146] - xx[27] * xx[238]);
  solveSymmetricPosDef(xx + 254, xx + 106, 6, 1, xx + 52, xx + 58);
  xx[13] = xx[105];
  xx[14] = xx[34];
  xx[15] = xx[31];
  xx[21] = xx[55];
  xx[22] = xx[146] * xx[56] + xx[152] * xx[57];
  xx[23] = xx[146] * xx[57] - xx[152] * xx[56];
  pm_math_Quaternion_inverseXform_ra(xx + 37, xx + 21, xx + 27);
  xx[31] = xx[124];
  xx[32] = xx[142];
  xx[33] = xx[144];
  pm_math_Vector3_cross_ra(xx + 21, xx + 210, xx + 41);
  xx[21] = xx[52] * xx[12] + xx[11] * xx[53] * xx[24] - xx[11] * xx[175] * xx[54]
    + xx[226] * xx[56] - xx[238] * xx[57] + xx[2] + xx[41];
  xx[22] = xx[11] * xx[17] * xx[52] + xx[53] * xx[16] + xx[11] * xx[54] * xx[18]
    - xx[153] * xx[55] + xx[3] + xx[42];
  xx[23] = xx[11] * xx[52] * xx[20] - xx[11] * xx[167] * xx[53] + xx[54] * xx[6]
    + xx[149] * xx[55] + xx[5] + xx[43];
  pm_math_Quaternion_inverseXform_ra(xx + 37, xx + 21, xx + 2);
  xx[0] = xx[1] - (pm_math_Vector3_dot_ra(xx + 13, xx + 27) +
                   pm_math_Vector3_dot_ra(xx + 31, xx + 2));
  xx[12] = xx[188];
  xx[13] = xx[19];
  xx[14] = xx[130];
  xx[1] = xx[27] + xx[30];
  xx[5] = xx[28] - xx[45];
  xx[6] = xx[90] * xx[5];
  xx[15] = xx[1] * xx[90];
  xx[16] = xx[1] + xx[11] * (xx[26] * xx[6] - xx[15] * xx[90]);
  xx[17] = xx[5] - (xx[26] * xx[15] + xx[6] * xx[90]) * xx[11];
  xx[6] = xx[29] + xx[0];
  xx[18] = xx[16];
  xx[19] = xx[17];
  xx[20] = xx[6];
  xx[21] = xx[76];
  xx[22] = xx[93];
  xx[23] = xx[136];
  xx[15] = xx[2] + xx[49] - xx[6] * xx[99];
  xx[2] = xx[3] + xx[46] * xx[0] + xx[70] + xx[6] * xx[126];
  xx[3] = xx[2] * xx[90];
  xx[24] = xx[15] * xx[90];
  xx[27] = xx[15] + xx[11] * (xx[26] * xx[3] - xx[24] * xx[90]);
  xx[15] = xx[2] - (xx[26] * xx[24] + xx[3] * xx[90]) * xx[11];
  xx[2] = xx[4] + xx[51] - (xx[126] * xx[5] - xx[1] * xx[99]);
  xx[3] = xx[27];
  xx[4] = xx[15];
  xx[5] = xx[2];
  xx[1] = xx[25] - (pm_math_Vector3_dot_ra(xx + 12, xx + 18) +
                    pm_math_Vector3_dot_ra(xx + 21, xx + 3));
  xx[3] = xx[16] + xx[35];
  xx[4] = xx[17] - xx[47];
  xx[5] = xx[6] + xx[1];
  pm_math_Quaternion_inverseXform_ra(xx + 81, xx + 3, xx + 11);
  xx[16] = - 2.316329694684785;
  xx[17] = 0.08179793917379162;
  xx[18] = - 13.30027846259417;
  pm_math_Vector3_cross_ra(xx + 3, xx + 85, xx + 19);
  xx[3] = xx[27] + xx[72] + xx[19];
  xx[4] = xx[15] + xx[46] * xx[1] + xx[73] + xx[20];
  xx[5] = xx[2] + xx[68] + xx[21];
  pm_math_Quaternion_inverseXform_ra(xx + 81, xx + 3, xx + 13);
  deriv[0] = state[7];
  deriv[1] = state[8];
  deriv[2] = state[9];
  deriv[3] = xx[7];
  deriv[4] = xx[8];
  deriv[5] = xx[9];
  deriv[6] = xx[10];
  deriv[7] = xx[52];
  deriv[8] = xx[53];
  deriv[9] = xx[54];
  deriv[10] = xx[55];
  deriv[11] = xx[56];
  deriv[12] = xx[57];
  deriv[13] = state[14];
  deriv[14] = xx[0];
  deriv[15] = state[16];
  deriv[16] = xx[1];
  deriv[17] = state[18];
  deriv[18] = xx[92] - (0.01012663375901021 * xx[11] + 0.41009882525818 * xx[12]
                        + pm_math_Vector3_dot_ra(xx + 16, xx + 13));
  errorResult[0] = xx[116];
  return NULL;
}

PmfMessageId SatelliteServicing_Mission_acc66beb_1_numJacPerturbLoBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 1.0e-9;
  xx[1] = 1.0e-8;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[1];
  bounds[4] = xx[1];
  bounds[5] = xx[1];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[0];
  bounds[9] = xx[0];
  bounds[10] = xx[1];
  bounds[11] = xx[1];
  bounds[12] = xx[1];
  bounds[13] = xx[1];
  bounds[14] = xx[1];
  bounds[15] = xx[1];
  bounds[16] = xx[1];
  bounds[17] = xx[1];
  bounds[18] = xx[1];
  errorResult[0] = 0.0;
  return NULL;
}

PmfMessageId SatelliteServicing_Mission_acc66beb_1_numJacPerturbHiBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[3];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = +pmf_get_inf();
  xx[1] = 0.1;
  xx[2] = 1.0;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[1];
  bounds[4] = xx[1];
  bounds[5] = xx[1];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[0];
  bounds[9] = xx[0];
  bounds[10] = xx[0];
  bounds[11] = xx[0];
  bounds[12] = xx[0];
  bounds[13] = xx[2];
  bounds[14] = xx[0];
  bounds[15] = xx[2];
  bounds[16] = xx[0];
  bounds[17] = xx[2];
  bounds[18] = xx[0];
  errorResult[0] = 0.0;
  return NULL;
}
