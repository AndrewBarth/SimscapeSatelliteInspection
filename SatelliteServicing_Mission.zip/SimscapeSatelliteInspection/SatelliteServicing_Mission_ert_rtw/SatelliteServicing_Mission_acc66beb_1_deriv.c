/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "SatelliteServicing_Mission_acc66beb_1_geometries.h"

PmfMessageId SatelliteServicing_Mission_acc66beb_1_compDerivs(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *deriv, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  int ii[1];
  double xx[95];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  xx[4] = state[10];
  xx[5] = state[11];
  xx[6] = state[12];
  pm_math_Quaternion_compDeriv_ra(xx + 0, xx + 4, xx + 7);
  xx[11] = 1.0;
  xx[12] = 0.5;
  xx[13] = - xx[12];
  xx[14] = xx[13];
  xx[15] = xx[12];
  xx[16] = xx[12];
  xx[17] = xx[13];
  pm_math_Quaternion_composeInverse_ra(xx + 0, xx + 14, xx + 18);
  xx[0] = xx[20] * xx[20];
  xx[1] = xx[21] * xx[21];
  xx[2] = 2.0;
  xx[3] = xx[11] - (xx[0] + xx[1]) * xx[2];
  xx[13] = xx[19] * xx[20];
  xx[22] = xx[18] * xx[21];
  xx[23] = xx[2] * (xx[13] - xx[22]);
  xx[24] = xx[18] * xx[20];
  xx[25] = xx[19] * xx[21];
  xx[26] = (xx[24] + xx[25]) * xx[2];
  xx[27] = xx[3];
  xx[28] = xx[23];
  xx[29] = xx[26];
  xx[30] = 452.4999999999999;
  xx[31] = xx[30] * xx[3];
  xx[32] = xx[30] * xx[23];
  xx[33] = xx[30] * xx[26];
  xx[34] = (xx[22] + xx[13]) * xx[2];
  xx[13] = xx[19] * xx[19];
  xx[22] = xx[11] - (xx[1] + xx[13]) * xx[2];
  xx[1] = xx[20] * xx[21];
  xx[35] = xx[18] * xx[19];
  xx[36] = xx[2] * (xx[1] - xx[35]);
  xx[37] = xx[30] * xx[34];
  xx[38] = xx[30] * xx[22];
  xx[39] = xx[30] * xx[36];
  xx[40] = pm_math_Vector3_dot_ra(xx + 27, xx + 37);
  xx[41] = xx[2] * (xx[25] - xx[24]);
  xx[24] = (xx[35] + xx[1]) * xx[2];
  xx[1] = xx[11] - (xx[13] + xx[0]) * xx[2];
  xx[42] = xx[30] * xx[41];
  xx[43] = xx[30] * xx[24];
  xx[44] = xx[30] * xx[1];
  xx[0] = pm_math_Vector3_dot_ra(xx + 27, xx + 42);
  xx[11] = 1.942890293094814e-16;
  xx[13] = xx[11] * xx[26];
  xx[25] = 5.023759186428833e-14;
  xx[35] = xx[11] * xx[23] - xx[25] * xx[3];
  xx[3] = xx[25] * xx[26];
  xx[45] = xx[34];
  xx[46] = xx[22];
  xx[47] = xx[36];
  xx[23] = pm_math_Vector3_dot_ra(xx + 45, xx + 42);
  xx[26] = xx[11] * xx[36];
  xx[48] = xx[11] * xx[22] - xx[25] * xx[34];
  xx[22] = xx[25] * xx[36];
  xx[49] = xx[41];
  xx[50] = xx[24];
  xx[51] = xx[1];
  xx[34] = xx[11] * xx[1];
  xx[36] = xx[11] * xx[24] - xx[25] * xx[41];
  xx[11] = xx[25] * xx[1];
  xx[1] = 141.5794617906537;
  xx[24] = 0.0;
  xx[25] = 2.157041537714581e-32;
  xx[41] = 118.885022412572;
  xx[52] = 146.2582106219183;
  xx[53] = pm_math_Vector3_dot_ra(xx + 27, xx + 31);
  xx[54] = xx[40];
  xx[55] = xx[0];
  xx[56] = xx[13];
  xx[57] = xx[35];
  xx[58] = xx[3];
  xx[59] = xx[40];
  xx[60] = pm_math_Vector3_dot_ra(xx + 45, xx + 37);
  xx[61] = xx[23];
  xx[62] = xx[26];
  xx[63] = xx[48];
  xx[64] = xx[22];
  xx[65] = xx[0];
  xx[66] = xx[23];
  xx[67] = pm_math_Vector3_dot_ra(xx + 49, xx + 42);
  xx[68] = xx[34];
  xx[69] = xx[36];
  xx[70] = xx[11];
  xx[71] = xx[13];
  xx[72] = xx[26];
  xx[73] = xx[34];
  xx[74] = xx[1];
  xx[75] = xx[24];
  xx[76] = xx[25];
  xx[77] = xx[35];
  xx[78] = xx[48];
  xx[79] = xx[36];
  xx[80] = xx[24];
  xx[81] = xx[41];
  xx[82] = xx[24];
  xx[83] = xx[3];
  xx[84] = xx[22];
  xx[85] = xx[11];
  xx[86] = xx[25];
  xx[87] = xx[24];
  xx[88] = xx[52];
  ii[0] = factorSymmetricPosDef(xx + 53, 6, xx + 31);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'SatelliteServicing_Mission/ServicingSatellite/SatConfiguration' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  pm_math_Quaternion_xform_ra(xx + 14, xx + 4, xx + 31);
  xx[3] = state[7];
  xx[4] = state[8];
  xx[5] = state[9];
  pm_math_Quaternion_inverseXform_ra(xx + 18, xx + 3, xx + 34);
  xx[0] = 1.110223024625157e-16;
  xx[3] = 4.293680205734395e-19;
  xx[4] = xx[34] + xx[0] * xx[33];
  xx[5] = xx[35] - xx[3] * xx[33];
  xx[6] = xx[36] + xx[3] * xx[32] - xx[0] * xx[31];
  pm_math_Vector3_cross_ra(xx + 31, xx + 4, xx + 18);
  xx[4] = - xx[34];
  xx[5] = - xx[35];
  xx[6] = - xx[36];
  pm_math_Vector3_cross_ra(xx + 31, xx + 4, xx + 21);
  xx[4] = xx[12] * xx[12] * input[0];
  xx[5] = xx[2] * (xx[4] - xx[4]);
  xx[6] = xx[12] * xx[12] * input[1];
  xx[11] = (xx[6] + xx[6]) * xx[2];
  xx[13] = input[1] - xx[11];
  xx[25] = xx[12] * xx[12] * input[2];
  xx[12] = (xx[18] + xx[21]) * xx[30] - (xx[5] + xx[13] - (xx[25] + xx[25]) *
    xx[2]);
  xx[26] = input[0] - (xx[4] + xx[4]) * xx[2];
  xx[34] = xx[2] * (xx[25] - xx[25]);
  xx[35] = (xx[19] + xx[22]) * xx[30] - (xx[26] + xx[11] + xx[34]);
  xx[11] = xx[2] * (xx[6] - xx[6]);
  xx[6] = input[2] - (xx[25] + xx[25]) * xx[2];
  xx[18] = (xx[20] + xx[23]) * xx[30] - (xx[11] - (xx[4] + xx[4]) * xx[2] + xx[6]);
  xx[19] = xx[12];
  xx[20] = xx[35];
  xx[21] = xx[18];
  xx[36] = xx[52] * xx[31];
  xx[37] = xx[1] * xx[32];
  xx[38] = xx[41] * xx[33];
  pm_math_Vector3_cross_ra(xx + 31, xx + 36, xx + 39);
  xx[1] = 0.75;
  xx[2] = 0.6929096493834649;
  xx[30] = input[3];
  xx[31] = input[4];
  xx[32] = input[5];
  pm_math_Quaternion_xform_ra(xx + 14, xx + 30, xx + 36);
  xx[4] = 0.692909649383465;
  xx[89] = - pm_math_Vector3_dot_ra(xx + 27, xx + 19);
  xx[90] = - pm_math_Vector3_dot_ra(xx + 45, xx + 19);
  xx[91] = - pm_math_Vector3_dot_ra(xx + 49, xx + 19);
  xx[92] = - (xx[40] - xx[1] * xx[5] + xx[2] * xx[6] - xx[37] + xx[3] * xx[18]);
  xx[93] = xx[41] - xx[4] * xx[13] - xx[2] * xx[34] - xx[38] - (xx[3] * xx[35] -
    xx[0] * xx[12]);
  xx[94] = xx[39] + xx[1] * xx[26] + xx[4] * xx[11] - xx[36] - xx[0] * xx[18];
  solveSymmetricPosDef(xx + 53, xx + 89, 6, 1, xx + 0, xx + 11);
  deriv[0] = state[7];
  deriv[1] = state[8];
  deriv[2] = state[9];
  deriv[3] = xx[7];
  deriv[4] = xx[8];
  deriv[5] = xx[9];
  deriv[6] = xx[10];
  deriv[7] = xx[0];
  deriv[8] = xx[1];
  deriv[9] = xx[2];
  deriv[10] = xx[3];
  deriv[11] = xx[4];
  deriv[12] = xx[5];
  errorResult[0] = xx[24];
  return NULL;
}

PmfMessageId SatelliteServicing_Mission_acc66beb_1_numJacPerturbLoBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 1.0e-9;
  xx[1] = 1.0e-8;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[1];
  bounds[4] = xx[1];
  bounds[5] = xx[1];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[0];
  bounds[9] = xx[0];
  bounds[10] = xx[1];
  bounds[11] = xx[1];
  bounds[12] = xx[1];
  errorResult[0] = 0.0;
  return NULL;
}

PmfMessageId SatelliteServicing_Mission_acc66beb_1_numJacPerturbHiBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = +pmf_get_inf();
  xx[1] = 0.1;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[1];
  bounds[4] = xx[1];
  bounds[5] = xx[1];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[0];
  bounds[9] = xx[0];
  bounds[10] = xx[0];
  bounds[11] = xx[0];
  bounds[12] = xx[0];
  errorResult[0] = 0.0;
  return NULL;
}
