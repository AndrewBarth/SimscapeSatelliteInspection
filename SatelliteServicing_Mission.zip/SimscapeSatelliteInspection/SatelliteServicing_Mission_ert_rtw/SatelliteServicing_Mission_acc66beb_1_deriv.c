/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "SatelliteServicing_Mission_acc66beb_1_geometries.h"

PmfMessageId SatelliteServicing_Mission_acc66beb_1_compDerivs(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *deriv, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  int ii[1];
  double xx[89];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  xx[4] = state[10];
  xx[5] = state[11];
  xx[6] = state[12];
  pm_math_Quaternion_compDeriv_ra(xx + 0, xx + 4, xx + 7);
  xx[11] = 1.0;
  xx[12] = 0.5;
  xx[13] = - xx[12];
  xx[14] = xx[13];
  xx[15] = xx[12];
  xx[16] = xx[12];
  xx[17] = xx[13];
  pm_math_Quaternion_composeInverse_ra(xx + 0, xx + 14, xx + 18);
  xx[0] = xx[20] * xx[20];
  xx[1] = xx[21] * xx[21];
  xx[2] = 2.0;
  xx[3] = xx[11] - (xx[0] + xx[1]) * xx[2];
  xx[12] = xx[19] * xx[20];
  xx[13] = xx[18] * xx[21];
  xx[22] = xx[2] * (xx[12] - xx[13]);
  xx[23] = xx[18] * xx[20];
  xx[24] = xx[19] * xx[21];
  xx[25] = (xx[23] + xx[24]) * xx[2];
  xx[26] = xx[3];
  xx[27] = xx[22];
  xx[28] = xx[25];
  xx[29] = 21.0;
  xx[30] = xx[29] * xx[3];
  xx[31] = xx[29] * xx[22];
  xx[32] = xx[29] * xx[25];
  xx[33] = (xx[13] + xx[12]) * xx[2];
  xx[12] = xx[19] * xx[19];
  xx[13] = xx[11] - (xx[1] + xx[12]) * xx[2];
  xx[1] = xx[20] * xx[21];
  xx[34] = xx[18] * xx[19];
  xx[35] = xx[2] * (xx[1] - xx[34]);
  xx[36] = xx[29] * xx[33];
  xx[37] = xx[29] * xx[13];
  xx[38] = xx[29] * xx[35];
  xx[39] = pm_math_Vector3_dot_ra(xx + 26, xx + 36);
  xx[40] = xx[2] * (xx[24] - xx[23]);
  xx[23] = (xx[34] + xx[1]) * xx[2];
  xx[1] = xx[11] - (xx[12] + xx[0]) * xx[2];
  xx[41] = xx[29] * xx[40];
  xx[42] = xx[29] * xx[23];
  xx[43] = xx[29] * xx[1];
  xx[0] = pm_math_Vector3_dot_ra(xx + 26, xx + 41);
  xx[2] = 4.163336342344364e-17;
  xx[11] = - (xx[2] * xx[25]);
  xx[12] = 5.828670879282072e-16;
  xx[24] = xx[12] * xx[3] - xx[2] * xx[22];
  xx[3] = - (xx[12] * xx[25]);
  xx[44] = xx[33];
  xx[45] = xx[13];
  xx[46] = xx[35];
  xx[22] = pm_math_Vector3_dot_ra(xx + 44, xx + 41);
  xx[25] = - (xx[2] * xx[35]);
  xx[34] = xx[12] * xx[33] - xx[2] * xx[13];
  xx[13] = - (xx[12] * xx[35]);
  xx[47] = xx[40];
  xx[48] = xx[23];
  xx[49] = xx[1];
  xx[33] = - (xx[2] * xx[1]);
  xx[35] = xx[12] * xx[40] - xx[2] * xx[23];
  xx[23] = - (xx[12] * xx[1]);
  xx[1] = 0.7024163313735985;
  xx[40] = 0.0;
  xx[50] = 1.155557966632349e-33;
  xx[51] = 0.7482314200091527;
  xx[52] = 0.8866567553022207;
  xx[53] = pm_math_Vector3_dot_ra(xx + 26, xx + 30);
  xx[54] = xx[39];
  xx[55] = xx[0];
  xx[56] = xx[11];
  xx[57] = xx[24];
  xx[58] = xx[3];
  xx[59] = xx[39];
  xx[60] = pm_math_Vector3_dot_ra(xx + 44, xx + 36);
  xx[61] = xx[22];
  xx[62] = xx[25];
  xx[63] = xx[34];
  xx[64] = xx[13];
  xx[65] = xx[0];
  xx[66] = xx[22];
  xx[67] = pm_math_Vector3_dot_ra(xx + 47, xx + 41);
  xx[68] = xx[33];
  xx[69] = xx[35];
  xx[70] = xx[23];
  xx[71] = xx[11];
  xx[72] = xx[25];
  xx[73] = xx[33];
  xx[74] = xx[1];
  xx[75] = xx[40];
  xx[76] = xx[50];
  xx[77] = xx[24];
  xx[78] = xx[34];
  xx[79] = xx[35];
  xx[80] = xx[40];
  xx[81] = xx[51];
  xx[82] = xx[40];
  xx[83] = xx[3];
  xx[84] = xx[13];
  xx[85] = xx[23];
  xx[86] = xx[50];
  xx[87] = xx[40];
  xx[88] = xx[52];
  ii[0] = factorSymmetricPosDef(xx + 53, 6, xx + 30);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'SatelliteServicing_Mission/ServicingSatellite/SatConfiguration' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  pm_math_Quaternion_xform_ra(xx + 14, xx + 4, xx + 22);
  xx[3] = state[7];
  xx[4] = state[8];
  xx[5] = state[9];
  pm_math_Quaternion_inverseXform_ra(xx + 18, xx + 3, xx + 13);
  xx[0] = 2.775557561562891e-17;
  xx[3] = 1.982541115402078e-18;
  xx[4] = xx[13] - xx[0] * xx[24];
  xx[5] = xx[14] + xx[3] * xx[24];
  xx[6] = xx[15] + xx[0] * xx[22] - xx[3] * xx[23];
  pm_math_Vector3_cross_ra(xx + 22, xx + 4, xx + 16);
  xx[4] = - xx[13];
  xx[5] = - xx[14];
  xx[6] = - xx[15];
  pm_math_Vector3_cross_ra(xx + 22, xx + 4, xx + 13);
  xx[4] = xx[16] + xx[13];
  xx[5] = xx[17] + xx[14];
  xx[6] = (xx[18] + xx[15]) * xx[29];
  xx[13] = xx[4] * xx[29];
  xx[14] = xx[5] * xx[29];
  xx[15] = xx[6];
  xx[16] = xx[52] * xx[22];
  xx[17] = xx[1] * xx[23];
  xx[18] = xx[51] * xx[24];
  pm_math_Vector3_cross_ra(xx + 22, xx + 16, xx + 19);
  xx[29] = - pm_math_Vector3_dot_ra(xx + 26, xx + 13);
  xx[30] = - pm_math_Vector3_dot_ra(xx + 44, xx + 13);
  xx[31] = - pm_math_Vector3_dot_ra(xx + 47, xx + 13);
  xx[32] = - (xx[20] - xx[3] * xx[6]);
  xx[33] = xx[21] - (xx[4] * xx[12] - xx[5] * xx[2]);
  xx[34] = xx[19] + xx[0] * xx[6];
  solveSymmetricPosDef(xx + 53, xx + 29, 6, 1, xx + 0, xx + 11);
  deriv[0] = state[7];
  deriv[1] = state[8];
  deriv[2] = state[9];
  deriv[3] = xx[7];
  deriv[4] = xx[8];
  deriv[5] = xx[9];
  deriv[6] = xx[10];
  deriv[7] = xx[0];
  deriv[8] = xx[1];
  deriv[9] = xx[2];
  deriv[10] = xx[3];
  deriv[11] = xx[4];
  deriv[12] = xx[5];
  errorResult[0] = xx[40];
  return NULL;
}

PmfMessageId SatelliteServicing_Mission_acc66beb_1_numJacPerturbLoBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 1.0e-9;
  xx[1] = 1.0e-8;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[1];
  bounds[4] = xx[1];
  bounds[5] = xx[1];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[0];
  bounds[9] = xx[0];
  bounds[10] = xx[1];
  bounds[11] = xx[1];
  bounds[12] = xx[1];
  errorResult[0] = 0.0;
  return NULL;
}

PmfMessageId SatelliteServicing_Mission_acc66beb_1_numJacPerturbHiBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = +pmf_get_inf();
  xx[1] = 0.1;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[1];
  bounds[4] = xx[1];
  bounds[5] = xx[1];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[0];
  bounds[9] = xx[0];
  bounds[10] = xx[0];
  bounds[11] = xx[0];
  bounds[12] = xx[0];
  errorResult[0] = 0.0;
  return NULL;
}
