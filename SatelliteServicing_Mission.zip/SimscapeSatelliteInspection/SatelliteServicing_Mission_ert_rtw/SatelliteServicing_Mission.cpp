//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.52
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri May  3 16:01:12 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "SatelliteServicing_Mission.h"
#include "rtwtypes.h"
#include "SatelliteServicing_Mission_private.h"
#include <cstring>
#include <cmath>
#include "norm_NaTV2q6x.h"
#include "svd_jndSmZ1I.h"
#include <stddef.h>

extern "C"
{

#include "rt_nonfinite.h"

}

// Projection for root system: '<Root>'
void SatelliteServicing_Mission_projection(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M)
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  NeslSimulationData *simulationData;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  char *msg;
  real_T tmp_0[72];
  real_T time;
  int32_T tmp_2;
  int_T tmp_1[19];
  boolean_T tmp;

  // Projection for SimscapeExecutionBlock: '<S256>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData);
  time = SatelliteServicing_Mission_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 78;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionClien[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
    (SatelliteServicing_Mission_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
    (SatelliteServicing_Mission_M->solverInfo);
  tmp_1[0] = 0;
  tmp_0[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
  tmp_0[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
  tmp_0[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
  tmp_0[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
  tmp_1[1] = 4;
  tmp_0[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
  tmp_0[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
  tmp_0[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
  tmp_0[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
  tmp_1[2] = 8;
  tmp_0[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
  tmp_0[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
  tmp_0[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
  tmp_0[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
  tmp_1[3] = 12;
  tmp_0[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
  tmp_0[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
  tmp_0[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
  tmp_0[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
  tmp_1[4] = 16;
  tmp_0[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
  tmp_0[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
  tmp_0[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
  tmp_0[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
  tmp_1[5] = 20;
  tmp_0[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
  tmp_0[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
  tmp_0[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
  tmp_0[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
  tmp_1[6] = 24;
  tmp_0[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
  tmp_0[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
  tmp_0[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
  tmp_0[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
  tmp_1[7] = 28;
  tmp_0[28] = SatelliteServicing_Mission_B->INPUT_8_1_1[0];
  tmp_0[29] = SatelliteServicing_Mission_B->INPUT_8_1_1[1];
  tmp_0[30] = SatelliteServicing_Mission_B->INPUT_8_1_1[2];
  tmp_0[31] = SatelliteServicing_Mission_B->INPUT_8_1_1[3];
  tmp_1[8] = 32;
  tmp_0[32] = SatelliteServicing_Mission_B->INPUT_9_1_1[0];
  tmp_0[33] = SatelliteServicing_Mission_B->INPUT_9_1_1[1];
  tmp_0[34] = SatelliteServicing_Mission_B->INPUT_9_1_1[2];
  tmp_0[35] = SatelliteServicing_Mission_B->INPUT_9_1_1[3];
  tmp_1[9] = 36;
  tmp_0[36] = SatelliteServicing_Mission_B->INPUT_10_1_1[0];
  tmp_0[37] = SatelliteServicing_Mission_B->INPUT_10_1_1[1];
  tmp_0[38] = SatelliteServicing_Mission_B->INPUT_10_1_1[2];
  tmp_0[39] = SatelliteServicing_Mission_B->INPUT_10_1_1[3];
  tmp_1[10] = 40;
  tmp_0[40] = SatelliteServicing_Mission_B->INPUT_11_1_1[0];
  tmp_0[41] = SatelliteServicing_Mission_B->INPUT_11_1_1[1];
  tmp_0[42] = SatelliteServicing_Mission_B->INPUT_11_1_1[2];
  tmp_0[43] = SatelliteServicing_Mission_B->INPUT_11_1_1[3];
  tmp_1[11] = 44;
  tmp_0[44] = SatelliteServicing_Mission_B->INPUT_12_1_1[0];
  tmp_0[45] = SatelliteServicing_Mission_B->INPUT_12_1_1[1];
  tmp_0[46] = SatelliteServicing_Mission_B->INPUT_12_1_1[2];
  tmp_0[47] = SatelliteServicing_Mission_B->INPUT_12_1_1[3];
  tmp_1[12] = 48;
  tmp_0[48] = SatelliteServicing_Mission_B->INPUT_13_1_1[0];
  tmp_0[49] = SatelliteServicing_Mission_B->INPUT_13_1_1[1];
  tmp_0[50] = SatelliteServicing_Mission_B->INPUT_13_1_1[2];
  tmp_0[51] = SatelliteServicing_Mission_B->INPUT_13_1_1[3];
  tmp_1[13] = 52;
  tmp_0[52] = SatelliteServicing_Mission_B->INPUT_14_1_1[0];
  tmp_0[53] = SatelliteServicing_Mission_B->INPUT_14_1_1[1];
  tmp_0[54] = SatelliteServicing_Mission_B->INPUT_14_1_1[2];
  tmp_0[55] = SatelliteServicing_Mission_B->INPUT_14_1_1[3];
  tmp_1[14] = 56;
  tmp_0[56] = SatelliteServicing_Mission_B->INPUT_15_1_1[0];
  tmp_0[57] = SatelliteServicing_Mission_B->INPUT_15_1_1[1];
  tmp_0[58] = SatelliteServicing_Mission_B->INPUT_15_1_1[2];
  tmp_0[59] = SatelliteServicing_Mission_B->INPUT_15_1_1[3];
  tmp_1[15] = 60;
  tmp_0[60] = SatelliteServicing_Mission_B->INPUT_16_1_1[0];
  tmp_0[61] = SatelliteServicing_Mission_B->INPUT_16_1_1[1];
  tmp_0[62] = SatelliteServicing_Mission_B->INPUT_16_1_1[2];
  tmp_0[63] = SatelliteServicing_Mission_B->INPUT_16_1_1[3];
  tmp_1[16] = 64;
  tmp_0[64] = SatelliteServicing_Mission_B->INPUT_16_1_2[0];
  tmp_0[65] = SatelliteServicing_Mission_B->INPUT_16_1_2[1];
  tmp_0[66] = SatelliteServicing_Mission_B->INPUT_16_1_2[2];
  tmp_0[67] = SatelliteServicing_Mission_B->INPUT_16_1_2[3];
  tmp_1[17] = 68;
  tmp_0[68] = SatelliteServicing_Mission_B->INPUT_16_1_3[0];
  tmp_0[69] = SatelliteServicing_Mission_B->INPUT_16_1_3[1];
  tmp_0[70] = SatelliteServicing_Mission_B->INPUT_16_1_3[2];
  tmp_0[71] = SatelliteServicing_Mission_B->INPUT_16_1_3[3];
  tmp_1[18] = 72;
  simulationData->mData->mInputValues.mN = 72;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 19;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_PROJECTION,
    simulationData, diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
    }
  }

  // End of Projection for SimscapeExecutionBlock: '<S256>/STATE_1'
}

//
// This function updates continuous states using the ODE3 fixed-step
// solver algorithm
//
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si ,
  RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M, real_T
  SatelliteServicing_Mission_Y_Observations[282])
{
  // Solver Matrices
  static const real_T rt_ODE3_A[3]{
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3]{
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t { rtsiGetT(si) };

  time_T tnew { rtsiGetSolverStopTime(si) };

  time_T h { rtsiGetStepSize(si) };

  real_T *x { rtsiGetContStates(si) };

  ODE3_IntgData *id { static_cast<ODE3_IntgData *>(rtsiGetSolverData(si)) };

  real_T *y { id->y };

  real_T *f0 { id->f[0] };

  real_T *f1 { id->f[1] };

  real_T *f2 { id->f[2] };

  real_T hB[3];
  int_T i;
  int_T nXc { 78 };

  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*));
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_Y_Observations);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*));
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_Y_Observations);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // tnew = t + hA(3);
  // ynew = y + f*hB(:,3);
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_Y_Observations);
  SatelliteServicing_Mission_projection(SatelliteServicing_Mission_M);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

//
// Output and update for atomic system:
//    '<S5>/Reorder_to_XYZ'
//    '<S6>/Reorder_to_XYZ'
//    '<S211>/Reorder_to_XYZ'
//
void SatelliteServici_Reorder_to_XYZ(const real_T rtu_Euler_in[3], real_T
  rty_Euler_out[3])
{
  rty_Euler_out[0] = rtu_Euler_in[2];
  rty_Euler_out[1] = rtu_Euler_in[1];
  rty_Euler_out[2] = rtu_Euler_in[0];
}

//
// Termination for atomic system:
//    '<S5>/Reorder_to_XYZ'
//    '<S6>/Reorder_to_XYZ'
//    '<S211>/Reorder_to_XYZ'
//
void SatelliteSe_Reorder_to_XYZ_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S5>/formPoseMat'
//    '<S6>/formPoseMat'
//    '<S211>/formPoseMat'
//
void SatelliteServicing__formPoseMat(const real_T rtu_rotMat[9], const real_T
  rtu_posVec[3], real_T rty_mat[16])
{
  for (int32_T i{0}; i < 3; i++) {
    int32_T tmp;
    tmp = i << 2;
    rty_mat[tmp] = rtu_rotMat[3 * i];
    rty_mat[tmp + 1] = rtu_rotMat[3 * i + 1];
    rty_mat[tmp + 2] = rtu_rotMat[3 * i + 2];
  }

  rty_mat[12] = rtu_posVec[0];
  rty_mat[13] = rtu_posVec[1];
  rty_mat[14] = rtu_posVec[2];
  rty_mat[3] = 0.0;
  rty_mat[7] = 0.0;
  rty_mat[11] = 0.0;
  rty_mat[15] = 1.0;
}

//
// Termination for atomic system:
//    '<S5>/formPoseMat'
//    '<S6>/formPoseMat'
//    '<S211>/formPoseMat'
//
void SatelliteServi_formPoseMat_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S5>/positiveQuat'
//    '<S6>/positiveQuat'
//    '<S211>/positiveQuat'
//
void SatelliteServicing_positiveQuat(const real_T rtu_qIn[4], real_T rty_qOut[4])
{
  if (rtu_qIn[0] < 0.0) {
    rty_qOut[0] = -rtu_qIn[0];
    rty_qOut[1] = -rtu_qIn[1];
    rty_qOut[2] = -rtu_qIn[2];
    rty_qOut[3] = -rtu_qIn[3];
  } else {
    rty_qOut[0] = rtu_qIn[0];
    rty_qOut[1] = rtu_qIn[1];
    rty_qOut[2] = rtu_qIn[2];
    rty_qOut[3] = rtu_qIn[3];
  }
}

//
// Termination for atomic system:
//    '<S5>/positiveQuat'
//    '<S6>/positiveQuat'
//    '<S211>/positiveQuat'
//
void SatelliteServ_positiveQuat_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S5>/quat2MRP'
//    '<S6>/quat2MRP'
//    '<S211>/quat2MRP'
//
void SatelliteServicing_Mis_quat2MRP(const real_T rtu_q[4], real_T rty_mrp[3])
{
  rty_mrp[0] = rtu_q[1] / (rtu_q[0] + 1.0);
  rty_mrp[1] = rtu_q[2] / (rtu_q[0] + 1.0);
  rty_mrp[2] = rtu_q[3] / (rtu_q[0] + 1.0);
}

//
// Termination for atomic system:
//    '<S5>/quat2MRP'
//    '<S6>/quat2MRP'
//    '<S211>/quat2MRP'
//
void SatelliteServicin_quat2MRP_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S94>/MATLAB Function'
//    '<S121>/MATLAB Function'
//    '<S148>/MATLAB Function'
//    '<S175>/MATLAB Function'
//
void SatelliteServici_MATLABFunction(const real_T rtu_position[3], const real_T
  rtu_velocity[3], real_T rtu_mean_motion, real_T rty_acceleration[3])
{
  real_T tmp;
  tmp = rtu_mean_motion * rtu_mean_motion;
  rty_acceleration[0] = tmp * 3.0 * rtu_position[0] + 2.0 * rtu_mean_motion *
    rtu_velocity[1];
  rty_acceleration[1] = -2.0 * rtu_mean_motion * rtu_velocity[0];
  rty_acceleration[2] = -tmp * rtu_position[2];
}

//
// Termination for atomic system:
//    '<S94>/MATLAB Function'
//    '<S121>/MATLAB Function'
//    '<S148>/MATLAB Function'
//    '<S175>/MATLAB Function'
//
void SatelliteSe_MATLABFunction_Term(void)
{
}

// Model step function
void SatelliteServicing_Mission_step(RT_MODEL_SatelliteServicing_M_T *const
  SatelliteServicing_Mission_M, real_T
  SatelliteServicing_Mission_Y_Observations[282])
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  // local block i/o variables
  real_T rtb_OUTPUT_1_0[99];
  real_T rtb_qOut[4];
  real_T rtb_qOut_d[4];
  real_T rtb_qOut_f[4];
  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    // set solver stop time
    rtsiSetSolverStopTime(SatelliteServicing_Mission_M->solverInfo,
                          ((SatelliteServicing_Mission_M->Timing.clockTick0+1)*
      SatelliteServicing_Mission_M->Timing.stepSize0));
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep(SatelliteServicing_Mission_M)) {
    SatelliteServicing_Mission_M->Timing.t[0] = rtsiGetT
      (SatelliteServicing_Mission_M->solverInfo);
  }

  {
    NeParameterBundle expl_temp;
    NeslSimulationData *simulationData;
    NeuDiagnosticManager *diag;
    NeuDiagnosticTree *diagTree;
    NeuDiagnosticTree *diagnosticTree;
    NeuDiagnosticTree *diagnosticTree_0;
    NeuDiagnosticTree *diagnosticTree_1;
    char *msg;
    char *msg_0;
    char *msg_1;
    char *msg_2;
    real_T tmp_4[150];
    real_T tmp_6[150];
    real_T tmp_1[72];
    real_T rtb_Reshape[36];
    real_T rtb_OUTPUT_1_1[30];
    real_T tmp[24];
    real_T rtb_mat_h[16];
    real_T b_x[9];
    real_T position[3];
    real_T rtb_acceleration[3];
    real_T tmp_8[3];
    real_T absx;
    real_T absxk;
    real_T absxk_tmp;
    real_T absxk_tmp_0;
    real_T absxk_tmp_1;
    real_T centerDist;
    real_T fov_radius;
    real_T nparams;
    real_T scale;
    real_T t;
    real_T time;
    real_T time_0;
    real_T time_1;
    real_T time_2;
    real_T time_3;
    real_T time_4;
    real_T time_tmp;
    real_T time_tmp_0;
    real_T *parameterBundle_mRealParameters;
    int32_T b;
    int32_T b_ii;
    int32_T b_j;
    int32_T b_x_tmp;
    int32_T i;
    int32_T idx;
    int_T tmp_5[20];
    int_T tmp_7[20];
    int_T tmp_2[19];
    int16_T ii_data[282];
    int16_T ii;
    boolean_T exitg1;
    boolean_T ok;
    boolean_T tmp_0;
    boolean_T tmp_3;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // SimscapeRtp: '<S4>/RTP_1' incorporates:
      //   Constant: '<S121>/Subsystem_around_RTP_517418D9_PxPositionTargetValue'
      //   Constant: '<S121>/Subsystem_around_RTP_517418D9_PxVelocityTargetValue'
      //   Constant: '<S121>/Subsystem_around_RTP_517418D9_PyPositionTargetValue'
      //   Constant: '<S121>/Subsystem_around_RTP_517418D9_PyVelocityTargetValue'
      //   Constant: '<S121>/Subsystem_around_RTP_517418D9_PzPositionTargetValue'
      //   Constant: '<S121>/Subsystem_around_RTP_517418D9_PzVelocityTargetValue'
      //   Constant: '<S148>/Subsystem_around_RTP_6835F894_PxPositionTargetValue'
      //   Constant: '<S148>/Subsystem_around_RTP_6835F894_PxVelocityTargetValue'
      //   Constant: '<S148>/Subsystem_around_RTP_6835F894_PyPositionTargetValue'
      //   Constant: '<S148>/Subsystem_around_RTP_6835F894_PyVelocityTargetValue'
      //   Constant: '<S148>/Subsystem_around_RTP_6835F894_PzPositionTargetValue'
      //   Constant: '<S148>/Subsystem_around_RTP_6835F894_PzVelocityTargetValue'
      //   Constant: '<S175>/Subsystem_around_RTP_84B5FE6B_PxPositionTargetValue'
      //   Constant: '<S175>/Subsystem_around_RTP_84B5FE6B_PxVelocityTargetValue'
      //   Constant: '<S175>/Subsystem_around_RTP_84B5FE6B_PyPositionTargetValue'
      //   Constant: '<S175>/Subsystem_around_RTP_84B5FE6B_PyVelocityTargetValue'
      //   Constant: '<S175>/Subsystem_around_RTP_84B5FE6B_PzPositionTargetValue'
      //   Constant: '<S175>/Subsystem_around_RTP_84B5FE6B_PzVelocityTargetValue'
      //   Constant: '<S94>/Subsystem_around_RTP_5F0325A4_PxPositionTargetValue'
      //   Constant: '<S94>/Subsystem_around_RTP_5F0325A4_PxVelocityTargetValue'
      //   Constant: '<S94>/Subsystem_around_RTP_5F0325A4_PyPositionTargetValue'
      //   Constant: '<S94>/Subsystem_around_RTP_5F0325A4_PyVelocityTargetValue'
      //   Constant: '<S94>/Subsystem_around_RTP_5F0325A4_PzPositionTargetValue'
      //   Constant: '<S94>/Subsystem_around_RTP_5F0325A4_PzVelocityTargetValue'

      if (SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded) {
        tmp[0] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_position[0];
        tmp[1] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_velocity[0];
        tmp[2] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_position[1];
        tmp[3] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_velocity[1];
        tmp[4] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_position[2];
        tmp[5] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_velocity[2];
        tmp[6] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_position[0];
        tmp[7] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_velocity[0];
        tmp[8] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_position[1];
        tmp[9] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_velocity[1];
        tmp[10] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_position[2];
        tmp[11] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_velocity[2];
        tmp[12] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_position[0];
        tmp[13] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_velocity[0];
        tmp[14] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_position[1];
        tmp[15] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_velocity[1];
        tmp[16] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_position[2];
        tmp[17] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_velocity[2];
        tmp[18] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_position[0];
        tmp[19] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_velocity[0];
        tmp[20] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_position[1];
        tmp[21] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_velocity[1];
        tmp[22] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_position[2];
        tmp[23] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_velocity[2];
        parameterBundle_mRealParameters = &tmp[0];
        diag = rtw_create_diagnostics();
        diagTree = neu_diagnostic_manager_get_initial_tree(diag);
        expl_temp.mRealParameters.mN = 24;
        expl_temp.mRealParameters.mX = parameterBundle_mRealParameters;
        expl_temp.mLogicalParameters.mN = 0;
        expl_temp.mLogicalParameters.mX = nullptr;
        expl_temp.mIntegerParameters.mN = 0;
        expl_temp.mIntegerParameters.mX = nullptr;
        expl_temp.mIndexParameters.mN = 0;
        expl_temp.mIndexParameters.mX = nullptr;
        ok = nesl_rtp_manager_set_rtps(static_cast<NeslRtpManager *>
          (SatelliteServicing_Mission_DW->RTP_1_RtpManager),
          SatelliteServicing_Mission_M->Timing.t[0], expl_temp, diag);
        if (!ok) {
          ok = error_buffer_is_empty(rtmGetErrorStatus
            (SatelliteServicing_Mission_M));
          if (ok) {
            msg = rtw_diagnostics_msg(diagTree);
            rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
          }
        }
      }

      SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded = false;

      // End of SimscapeRtp: '<S4>/RTP_1'
    }

    // SimscapeExecutionBlock: '<S256>/STATE_1' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_1'

    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData);
    time_tmp = SatelliteServicing_Mission_M->Timing.t[0];
    time = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 78;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionClien[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    ok = rtmIsMajorTimeStep(SatelliteServicing_Mission_M);
    simulationData->mData->mIsMajorTimeStep = ok;
    tmp_0 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_0;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp_0 = rtsiIsSolverComputingJacobian
      (SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp_0;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_0 = rtsiIsModeUpdateTimeStep(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_2[0] = 0;
    tmp_1[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_1[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_1[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_1[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_2[1] = 4;
    tmp_1[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_1[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_1[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_1[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_2[2] = 8;
    tmp_1[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_1[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_1[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_1[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_2[3] = 12;
    tmp_1[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_1[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_1[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_1[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_2[4] = 16;
    tmp_1[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
    tmp_1[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
    tmp_1[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
    tmp_1[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
    tmp_2[5] = 20;
    tmp_1[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
    tmp_1[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
    tmp_1[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
    tmp_1[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
    tmp_2[6] = 24;
    tmp_1[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
    tmp_1[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
    tmp_1[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
    tmp_1[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
    tmp_2[7] = 28;
    tmp_1[28] = SatelliteServicing_Mission_B->INPUT_8_1_1[0];
    tmp_1[29] = SatelliteServicing_Mission_B->INPUT_8_1_1[1];
    tmp_1[30] = SatelliteServicing_Mission_B->INPUT_8_1_1[2];
    tmp_1[31] = SatelliteServicing_Mission_B->INPUT_8_1_1[3];
    tmp_2[8] = 32;
    tmp_1[32] = SatelliteServicing_Mission_B->INPUT_9_1_1[0];
    tmp_1[33] = SatelliteServicing_Mission_B->INPUT_9_1_1[1];
    tmp_1[34] = SatelliteServicing_Mission_B->INPUT_9_1_1[2];
    tmp_1[35] = SatelliteServicing_Mission_B->INPUT_9_1_1[3];
    tmp_2[9] = 36;
    tmp_1[36] = SatelliteServicing_Mission_B->INPUT_10_1_1[0];
    tmp_1[37] = SatelliteServicing_Mission_B->INPUT_10_1_1[1];
    tmp_1[38] = SatelliteServicing_Mission_B->INPUT_10_1_1[2];
    tmp_1[39] = SatelliteServicing_Mission_B->INPUT_10_1_1[3];
    tmp_2[10] = 40;
    tmp_1[40] = SatelliteServicing_Mission_B->INPUT_11_1_1[0];
    tmp_1[41] = SatelliteServicing_Mission_B->INPUT_11_1_1[1];
    tmp_1[42] = SatelliteServicing_Mission_B->INPUT_11_1_1[2];
    tmp_1[43] = SatelliteServicing_Mission_B->INPUT_11_1_1[3];
    tmp_2[11] = 44;
    tmp_1[44] = SatelliteServicing_Mission_B->INPUT_12_1_1[0];
    tmp_1[45] = SatelliteServicing_Mission_B->INPUT_12_1_1[1];
    tmp_1[46] = SatelliteServicing_Mission_B->INPUT_12_1_1[2];
    tmp_1[47] = SatelliteServicing_Mission_B->INPUT_12_1_1[3];
    tmp_2[12] = 48;
    tmp_1[48] = SatelliteServicing_Mission_B->INPUT_13_1_1[0];
    tmp_1[49] = SatelliteServicing_Mission_B->INPUT_13_1_1[1];
    tmp_1[50] = SatelliteServicing_Mission_B->INPUT_13_1_1[2];
    tmp_1[51] = SatelliteServicing_Mission_B->INPUT_13_1_1[3];
    tmp_2[13] = 52;
    tmp_1[52] = SatelliteServicing_Mission_B->INPUT_14_1_1[0];
    tmp_1[53] = SatelliteServicing_Mission_B->INPUT_14_1_1[1];
    tmp_1[54] = SatelliteServicing_Mission_B->INPUT_14_1_1[2];
    tmp_1[55] = SatelliteServicing_Mission_B->INPUT_14_1_1[3];
    tmp_2[14] = 56;
    tmp_1[56] = SatelliteServicing_Mission_B->INPUT_15_1_1[0];
    tmp_1[57] = SatelliteServicing_Mission_B->INPUT_15_1_1[1];
    tmp_1[58] = SatelliteServicing_Mission_B->INPUT_15_1_1[2];
    tmp_1[59] = SatelliteServicing_Mission_B->INPUT_15_1_1[3];
    tmp_2[15] = 60;
    tmp_1[60] = SatelliteServicing_Mission_B->INPUT_16_1_1[0];
    tmp_1[61] = SatelliteServicing_Mission_B->INPUT_16_1_1[1];
    tmp_1[62] = SatelliteServicing_Mission_B->INPUT_16_1_1[2];
    tmp_1[63] = SatelliteServicing_Mission_B->INPUT_16_1_1[3];
    tmp_2[16] = 64;
    tmp_1[64] = SatelliteServicing_Mission_B->INPUT_16_1_2[0];
    tmp_1[65] = SatelliteServicing_Mission_B->INPUT_16_1_2[1];
    tmp_1[66] = SatelliteServicing_Mission_B->INPUT_16_1_2[2];
    tmp_1[67] = SatelliteServicing_Mission_B->INPUT_16_1_2[3];
    tmp_2[17] = 68;
    tmp_1[68] = SatelliteServicing_Mission_B->INPUT_16_1_3[0];
    tmp_1[69] = SatelliteServicing_Mission_B->INPUT_16_1_3[1];
    tmp_1[70] = SatelliteServicing_Mission_B->INPUT_16_1_3[2];
    tmp_1[71] = SatelliteServicing_Mission_B->INPUT_16_1_3[3];
    tmp_2[18] = 72;
    simulationData->mData->mInputValues.mN = 72;
    simulationData->mData->mInputValues.mX = &tmp_1[0];
    simulationData->mData->mInputOffsets.mN = 19;
    simulationData->mData->mInputOffsets.mX = &tmp_2[0];
    simulationData->mData->mOutputs.mN = 78;
    simulationData->mData->mOutputs.mX = &SatelliteServicing_Mission_B->STATE_1
      [0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_tmp_0 = SatelliteServicing_Mission_M->Timing.t[0];
    time_0 = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diag = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diag);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diag);
    if (i != 0) {
      tmp_3 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_3) {
        msg_0 = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
      }
    }

    // End of SimscapeExecutionBlock: '<S256>/STATE_1'

    // SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData);
    time_1 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_1;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Modes;
    tmp_3 = false;
    simulationData->mData->mFoundZcEvents = tmp_3;
    simulationData->mData->mIsMajorTimeStep = ok;
    tmp_3 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_3;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_5[0] = 0;
    tmp_4[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_4[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_4[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_4[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_5[1] = 4;
    tmp_4[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_4[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_4[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_4[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_5[2] = 8;
    tmp_4[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_4[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_4[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_4[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_5[3] = 12;
    tmp_4[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_4[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_4[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_4[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_5[4] = 16;
    tmp_4[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
    tmp_4[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
    tmp_4[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
    tmp_4[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
    tmp_5[5] = 20;
    tmp_4[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
    tmp_4[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
    tmp_4[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
    tmp_4[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
    tmp_5[6] = 24;
    tmp_4[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
    tmp_4[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
    tmp_4[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
    tmp_4[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
    tmp_5[7] = 28;
    tmp_4[28] = SatelliteServicing_Mission_B->INPUT_8_1_1[0];
    tmp_4[29] = SatelliteServicing_Mission_B->INPUT_8_1_1[1];
    tmp_4[30] = SatelliteServicing_Mission_B->INPUT_8_1_1[2];
    tmp_4[31] = SatelliteServicing_Mission_B->INPUT_8_1_1[3];
    tmp_5[8] = 32;
    tmp_4[32] = SatelliteServicing_Mission_B->INPUT_9_1_1[0];
    tmp_4[33] = SatelliteServicing_Mission_B->INPUT_9_1_1[1];
    tmp_4[34] = SatelliteServicing_Mission_B->INPUT_9_1_1[2];
    tmp_4[35] = SatelliteServicing_Mission_B->INPUT_9_1_1[3];
    tmp_5[9] = 36;
    tmp_4[36] = SatelliteServicing_Mission_B->INPUT_10_1_1[0];
    tmp_4[37] = SatelliteServicing_Mission_B->INPUT_10_1_1[1];
    tmp_4[38] = SatelliteServicing_Mission_B->INPUT_10_1_1[2];
    tmp_4[39] = SatelliteServicing_Mission_B->INPUT_10_1_1[3];
    tmp_5[10] = 40;
    tmp_4[40] = SatelliteServicing_Mission_B->INPUT_11_1_1[0];
    tmp_4[41] = SatelliteServicing_Mission_B->INPUT_11_1_1[1];
    tmp_4[42] = SatelliteServicing_Mission_B->INPUT_11_1_1[2];
    tmp_4[43] = SatelliteServicing_Mission_B->INPUT_11_1_1[3];
    tmp_5[11] = 44;
    tmp_4[44] = SatelliteServicing_Mission_B->INPUT_12_1_1[0];
    tmp_4[45] = SatelliteServicing_Mission_B->INPUT_12_1_1[1];
    tmp_4[46] = SatelliteServicing_Mission_B->INPUT_12_1_1[2];
    tmp_4[47] = SatelliteServicing_Mission_B->INPUT_12_1_1[3];
    tmp_5[12] = 48;
    tmp_4[48] = SatelliteServicing_Mission_B->INPUT_13_1_1[0];
    tmp_4[49] = SatelliteServicing_Mission_B->INPUT_13_1_1[1];
    tmp_4[50] = SatelliteServicing_Mission_B->INPUT_13_1_1[2];
    tmp_4[51] = SatelliteServicing_Mission_B->INPUT_13_1_1[3];
    tmp_5[13] = 52;
    tmp_4[52] = SatelliteServicing_Mission_B->INPUT_14_1_1[0];
    tmp_4[53] = SatelliteServicing_Mission_B->INPUT_14_1_1[1];
    tmp_4[54] = SatelliteServicing_Mission_B->INPUT_14_1_1[2];
    tmp_4[55] = SatelliteServicing_Mission_B->INPUT_14_1_1[3];
    tmp_5[14] = 56;
    tmp_4[56] = SatelliteServicing_Mission_B->INPUT_15_1_1[0];
    tmp_4[57] = SatelliteServicing_Mission_B->INPUT_15_1_1[1];
    tmp_4[58] = SatelliteServicing_Mission_B->INPUT_15_1_1[2];
    tmp_4[59] = SatelliteServicing_Mission_B->INPUT_15_1_1[3];
    tmp_5[15] = 60;
    tmp_4[60] = SatelliteServicing_Mission_B->INPUT_16_1_1[0];
    tmp_4[61] = SatelliteServicing_Mission_B->INPUT_16_1_1[1];
    tmp_4[62] = SatelliteServicing_Mission_B->INPUT_16_1_1[2];
    tmp_4[63] = SatelliteServicing_Mission_B->INPUT_16_1_1[3];
    tmp_5[16] = 64;
    tmp_4[64] = SatelliteServicing_Mission_B->INPUT_16_1_2[0];
    tmp_4[65] = SatelliteServicing_Mission_B->INPUT_16_1_2[1];
    tmp_4[66] = SatelliteServicing_Mission_B->INPUT_16_1_2[2];
    tmp_4[67] = SatelliteServicing_Mission_B->INPUT_16_1_2[3];
    tmp_5[17] = 68;
    tmp_4[68] = SatelliteServicing_Mission_B->INPUT_16_1_3[0];
    tmp_4[69] = SatelliteServicing_Mission_B->INPUT_16_1_3[1];
    tmp_4[70] = SatelliteServicing_Mission_B->INPUT_16_1_3[2];
    tmp_4[71] = SatelliteServicing_Mission_B->INPUT_16_1_3[3];
    tmp_5[18] = 72;
    std::memcpy(&tmp_4[72], &SatelliteServicing_Mission_B->STATE_1[0], 78U *
                sizeof(real_T));
    tmp_5[19] = 150;
    simulationData->mData->mInputValues.mN = 150;
    simulationData->mData->mInputValues.mX = &tmp_4[0];
    simulationData->mData->mInputOffsets.mN = 20;
    simulationData->mData->mInputOffsets.mX = &tmp_5[0];
    simulationData->mData->mOutputs.mN = 99;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_2 = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_2;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diag = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr);
    diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diag);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diag);
    if (i != 0) {
      tmp_3 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_3) {
        msg_1 = rtw_diagnostics_msg(diagnosticTree_0);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
      }
    }

    // MATLAB Function: '<S94>/MATLAB Function' incorporates:
    //   Constant: '<S88>/Constant1'
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[50], &rtb_OUTPUT_1_0[53],
      SatelliteServicing_Mission_P.orbit.mean_motion, &rtb_qOut_f[0]);

    // MATLAB Function: '<S121>/MATLAB Function' incorporates:
    //   Constant: '<S88>/Constant1'
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[56], &rtb_OUTPUT_1_0[59],
      SatelliteServicing_Mission_P.orbit.mean_motion, &rtb_qOut_d[0]);

    // MATLAB Function: '<S148>/MATLAB Function' incorporates:
    //   Constant: '<S88>/Constant1'
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[62], &rtb_OUTPUT_1_0[65],
      SatelliteServicing_Mission_P.orbit.mean_motion, rtb_acceleration);

    // MATLAB Function: '<S175>/MATLAB Function' incorporates:
    //   Constant: '<S88>/Constant1'
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[68], &rtb_OUTPUT_1_0[71],
      SatelliteServicing_Mission_P.orbit.mean_motion, &rtb_qOut[0]);

    // Reshape: '<S89>/Reshape'
    for (i = 0; i < 6; i++) {
      rtb_Reshape[i] = rtb_OUTPUT_1_0[i + 50];
    }

    rtb_Reshape[6] = rtb_qOut_f[0];
    rtb_Reshape[7] = rtb_qOut_f[1];
    rtb_Reshape[8] = rtb_qOut_f[2];
    for (i = 0; i < 6; i++) {
      rtb_Reshape[i + 9] = rtb_OUTPUT_1_0[i + 56];
    }

    rtb_Reshape[15] = rtb_qOut_d[0];
    rtb_Reshape[16] = rtb_qOut_d[1];
    rtb_Reshape[17] = rtb_qOut_d[2];
    for (i = 0; i < 6; i++) {
      rtb_Reshape[i + 18] = rtb_OUTPUT_1_0[i + 62];
    }

    rtb_Reshape[24] = rtb_acceleration[0];
    rtb_Reshape[25] = rtb_acceleration[1];
    rtb_Reshape[26] = rtb_acceleration[2];
    for (i = 0; i < 6; i++) {
      rtb_Reshape[i + 27] = rtb_OUTPUT_1_0[i + 68];
    }

    rtb_Reshape[33] = rtb_qOut[0];
    rtb_Reshape[34] = rtb_qOut[1];
    rtb_Reshape[35] = rtb_qOut[2];

    // End of Reshape: '<S89>/Reshape'
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      for (i = 0; i < 282; i++) {
        // Delay: '<S89>/Delay' incorporates:
        //   Constant: '<S89>/Constant4'

        if (SatelliteServicing_Mission_DW->icLoad) {
          SatelliteServicing_Mission_DW->Delay_DSTATE[i] =
            SatelliteServicing_Mission_P.Constant4_Value[i];
        }

        // Delay: '<S89>/Delay'
        SatelliteServicing_Mission_B->Delay[i] =
          SatelliteServicing_Mission_DW->Delay_DSTATE[i];

        // Delay: '<S89>/Delay1' incorporates:
        //   Constant: '<S89>/Constant4'

        if (SatelliteServicing_Mission_DW->icLoad_d) {
          SatelliteServicing_Mission_DW->Delay1_DSTATE[i] =
            SatelliteServicing_Mission_P.Constant4_Value[i];
        }

        // Delay: '<S89>/Delay1'
        SatelliteServicing_Mission_B->Delay1[i] =
          SatelliteServicing_Mission_DW->Delay1_DSTATE[i];
      }
    }

    // MATLAB Function: '<S89>/computeCoverage' incorporates:
    //   Constant: '<S89>/Constant1'
    //   Constant: '<S89>/Constant2'
    //   Constant: '<S89>/Constant3'
    //   Constant: '<S89>/Constant5'
    //   Constant: '<S89>/Constant6'
    //   Reshape: '<S89>/Reshape'

    std::memcpy(&SatelliteServicing_Mission_B->coverage_out[0],
                &SatelliteServicing_Mission_B->Delay[0], 282U * sizeof(real_T));
    std::memcpy(&SatelliteServicing_Mission_B->credit_out[0],
                &SatelliteServicing_Mission_B->Delay1[0], 282U * sizeof(real_T));
    nparams = std::round(36.0 / SatelliteServicing_Mission_P.nsat);
    b = static_cast<int32_T>(SatelliteServicing_Mission_P.nsat);
    for (i = 0; i < b; i++) {
      fov_radius = ((static_cast<real_T>(i) + 1.0) - 1.0) * nparams;
      position[0] = rtb_Reshape[static_cast<int32_T>(fov_radius + 1.0) - 1];
      position[1] = rtb_Reshape[static_cast<int32_T>(fov_radius + 2.0) - 1];
      position[2] = rtb_Reshape[static_cast<int32_T>(fov_radius + 3.0) - 1];
      fov_radius = norm_NaTV2q6x(position);
      position[0] = position[0] / fov_radius *
        SatelliteServicing_Mission_P.Constant6_Value;
      position[1] = position[1] / fov_radius *
        SatelliteServicing_Mission_P.Constant6_Value;
      position[2] = position[2] / fov_radius *
        SatelliteServicing_Mission_P.Constant6_Value;
      fov_radius = (fov_radius - SatelliteServicing_Mission_P.Constant6_Value) *
        std::tan(SatelliteServicing_Mission_P.Constant2_Value / 2.0);
      idx = 0;
      b_ii = 0;
      exitg1 = false;
      while ((!exitg1) && (b_ii < 282)) {
        if (!(SatelliteServicing_Mission_B->coverage_out[b_ii] != 0.0)) {
          idx++;
          ii_data[idx - 1] = static_cast<int16_T>(b_ii + 1);
          if (idx >= 282) {
            exitg1 = true;
          } else {
            b_ii++;
          }
        } else {
          b_ii++;
        }
      }

      if (idx < 1) {
        idx = 0;
      }

      for (b_ii = 0; b_ii < idx; b_ii++) {
        ii = ii_data[b_ii];
        centerDist = 0.0;
        scale = position[0];
        absxk = position[1];
        t = position[2];
        for (b_j = 0; b_j < 3; b_j++) {
          b_x_tmp = (282 * b_j + ii) - 1;
          absx = SatelliteServicing_Mission_P.Constant3_Value[b_x_tmp] - scale;
          b_x[3 * b_j] = absx;
          absx = std::abs(absx);
          if (std::isnan(absx)) {
            centerDist = (rtNaN);
          } else if (absx > centerDist) {
            centerDist = absx;
          }

          absx = SatelliteServicing_Mission_P.Constant3_Value[b_x_tmp] - absxk;
          b_x[3 * b_j + 1] = absx;
          absx = std::abs(absx);
          if (std::isnan(absx)) {
            centerDist = (rtNaN);
          } else if (absx > centerDist) {
            centerDist = absx;
          }

          absx = SatelliteServicing_Mission_P.Constant3_Value[b_x_tmp] - t;
          b_x[3 * b_j + 2] = absx;
          absx = std::abs(absx);
          if (std::isnan(absx)) {
            centerDist = (rtNaN);
          } else if (absx > centerDist) {
            centerDist = absx;
          }
        }

        if ((!std::isinf(centerDist)) && (!std::isnan(centerDist))) {
          svd_jndSmZ1I(b_x, tmp_8);
          centerDist = tmp_8[0];
        }

        scale = 3.3121686421112381E-170;
        absxk_tmp = SatelliteServicing_Mission_P.Constant3_Value[ii - 1];
        absxk = std::abs(absxk_tmp);
        if (absxk > 3.3121686421112381E-170) {
          absx = 1.0;
          scale = absxk;
        } else {
          t = absxk / 3.3121686421112381E-170;
          absx = t * t;
        }

        absxk_tmp_0 = SatelliteServicing_Mission_P.Constant3_Value[ii + 281];
        absxk = std::abs(absxk_tmp_0);
        if (absxk > scale) {
          t = scale / absxk;
          absx = absx * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          absx += t * t;
        }

        absxk_tmp_1 = SatelliteServicing_Mission_P.Constant3_Value[ii + 563];
        absxk = std::abs(absxk_tmp_1);
        if (absxk > scale) {
          t = scale / absxk;
          absx = absx * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          absx += t * t;
        }

        absx = scale * std::sqrt(absx);
        scale = SatelliteServicing_Mission_P.Constant5_Value[ii - 1];
        if ((fov_radius >= scale + centerDist) && (std::acos(((absxk_tmp *
                position[0] + absxk_tmp_0 * position[1]) + absxk_tmp_1 *
               position[2]) / (absx * norm_NaTV2q6x(position))) <
             1.5707963267948966 - scale /
             SatelliteServicing_Mission_P.Constant6_Value)) {
          SatelliteServicing_Mission_B->coverage_out[ii - 1] = 1.0;
          SatelliteServicing_Mission_B->credit_out[ii - 1] = static_cast<real_T>
            (i) + 1.0;
        }
      }
    }

    // End of MATLAB Function: '<S89>/computeCoverage'

    // Outport: '<Root>/Observations'
    std::memcpy(&SatelliteServicing_Mission_Y_Observations[0],
                &SatelliteServicing_Mission_B->credit_out[0], 282U * sizeof
                (real_T));

    // SimscapeInputBlock: '<S256>/INPUT_1_1_1' incorporates:
    //   Constant: '<S88>/Constant'
    //   Constant: '<S94>/Constant1'
    //   Product: '<S94>/Product'
    //   Sum: '<S94>/Add'

    SatelliteServicing_Mission_B->INPUT_1_1_1[0] = rtb_qOut_f[0] *
      SatelliteServicing_Mission_P.cubesat[0].mass +
      SatelliteServicing_Mission_P.Constant_Value[0];
    SatelliteServicing_Mission_B->INPUT_1_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_2_1_1' incorporates:
    //   Constant: '<S88>/Constant'
    //   Constant: '<S94>/Constant1'
    //   Product: '<S94>/Product'
    //   Sum: '<S94>/Add'

    SatelliteServicing_Mission_B->INPUT_2_1_1[0] = rtb_qOut_f[1] *
      SatelliteServicing_Mission_P.cubesat[0].mass +
      SatelliteServicing_Mission_P.Constant_Value[1];
    SatelliteServicing_Mission_B->INPUT_2_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_3_1_1' incorporates:
    //   Constant: '<S88>/Constant'
    //   Constant: '<S94>/Constant1'
    //   Product: '<S94>/Product'
    //   Sum: '<S94>/Add'

    SatelliteServicing_Mission_B->INPUT_3_1_1[0] = rtb_qOut_f[2] *
      SatelliteServicing_Mission_P.cubesat[0].mass +
      SatelliteServicing_Mission_P.Constant_Value[2];
    SatelliteServicing_Mission_B->INPUT_3_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_4_1_1'
    SatelliteServicing_Mission_B->INPUT_4_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_5_1_1'
    SatelliteServicing_Mission_B->INPUT_5_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_5_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_5_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_6_1_1'
    SatelliteServicing_Mission_B->INPUT_6_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_6_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_6_1_1[3] = 0.0;

    // Sum: '<S148>/Add' incorporates:
    //   Constant: '<S148>/Constant1'
    //   Constant: '<S88>/Constant'
    //   Product: '<S148>/Product'
    //   Sum: '<S121>/Add'

    rtb_acceleration[0] = rtb_acceleration[0] *
      SatelliteServicing_Mission_P.cubesat[2].mass +
      SatelliteServicing_Mission_P.Constant_Value[0];
    rtb_acceleration[1] = rtb_acceleration[1] *
      SatelliteServicing_Mission_P.cubesat[2].mass +
      SatelliteServicing_Mission_P.Constant_Value[1];
    rtb_acceleration[2] = rtb_acceleration[2] *
      SatelliteServicing_Mission_P.cubesat[2].mass +
      SatelliteServicing_Mission_P.Constant_Value[2];

    // SimscapeInputBlock: '<S256>/INPUT_4_1_1' incorporates:
    //   Constant: '<S121>/Constant1'
    //   Constant: '<S88>/Constant'
    //   Product: '<S121>/Product'
    //   Sum: '<S121>/Add'

    SatelliteServicing_Mission_B->INPUT_4_1_1[0] = rtb_qOut_d[0] *
      SatelliteServicing_Mission_P.cubesat[1].mass +
      SatelliteServicing_Mission_P.Constant_Value[0];

    // SimscapeInputBlock: '<S256>/INPUT_5_1_1' incorporates:
    //   Constant: '<S121>/Constant1'
    //   Constant: '<S88>/Constant'
    //   Product: '<S121>/Product'
    //   Sum: '<S121>/Add'

    SatelliteServicing_Mission_B->INPUT_5_1_1[0] = rtb_qOut_d[1] *
      SatelliteServicing_Mission_P.cubesat[1].mass +
      SatelliteServicing_Mission_P.Constant_Value[1];

    // SimscapeInputBlock: '<S256>/INPUT_6_1_1' incorporates:
    //   Constant: '<S121>/Constant1'
    //   Constant: '<S88>/Constant'
    //   Product: '<S121>/Product'
    //   Sum: '<S121>/Add'

    SatelliteServicing_Mission_B->INPUT_6_1_1[0] = rtb_qOut_d[2] *
      SatelliteServicing_Mission_P.cubesat[1].mass +
      SatelliteServicing_Mission_P.Constant_Value[2];

    // SimscapeInputBlock: '<S256>/INPUT_7_1_1'
    SatelliteServicing_Mission_B->INPUT_7_1_1[0] = rtb_acceleration[0];
    SatelliteServicing_Mission_B->INPUT_7_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_7_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_7_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_8_1_1'
    SatelliteServicing_Mission_B->INPUT_8_1_1[0] = rtb_acceleration[1];
    SatelliteServicing_Mission_B->INPUT_8_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_8_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_8_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_9_1_1'
    SatelliteServicing_Mission_B->INPUT_9_1_1[0] = rtb_acceleration[2];
    SatelliteServicing_Mission_B->INPUT_9_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_9_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_9_1_1[3] = 0.0;

    // Sum: '<S175>/Add' incorporates:
    //   Constant: '<S175>/Constant1'
    //   Constant: '<S88>/Constant'
    //   Product: '<S175>/Product'

    rtb_acceleration[0] = rtb_qOut[0] * SatelliteServicing_Mission_P.cubesat[3].
      mass + SatelliteServicing_Mission_P.Constant_Value[0];
    rtb_acceleration[1] = rtb_qOut[1] * SatelliteServicing_Mission_P.cubesat[3].
      mass + SatelliteServicing_Mission_P.Constant_Value[1];
    rtb_acceleration[2] = rtb_qOut[2] * SatelliteServicing_Mission_P.cubesat[3].
      mass + SatelliteServicing_Mission_P.Constant_Value[2];

    // SimscapeInputBlock: '<S256>/INPUT_10_1_1'
    SatelliteServicing_Mission_B->INPUT_10_1_1[0] = rtb_acceleration[0];
    SatelliteServicing_Mission_B->INPUT_10_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_10_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_10_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_11_1_1'
    SatelliteServicing_Mission_B->INPUT_11_1_1[0] = rtb_acceleration[1];
    SatelliteServicing_Mission_B->INPUT_11_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_11_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_11_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_12_1_1'
    SatelliteServicing_Mission_B->INPUT_12_1_1[0] = rtb_acceleration[2];
    SatelliteServicing_Mission_B->INPUT_12_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_12_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_12_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S256>/INPUT_13_1_1'
    SatelliteServicing_Mission_B->INPUT_13_1_1[0] = 0.0;
    SatelliteServicing_Mission_B->INPUT_13_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_13_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      SatelliteServicing_Mission_DW->INPUT_13_1_1_Discrete[0] =
        !(SatelliteServicing_Mission_B->INPUT_13_1_1[0] ==
          SatelliteServicing_Mission_DW->INPUT_13_1_1_Discrete[1]);
      SatelliteServicing_Mission_DW->INPUT_13_1_1_Discrete[1] =
        SatelliteServicing_Mission_B->INPUT_13_1_1[0];
    }

    SatelliteServicing_Mission_B->INPUT_13_1_1[0] =
      SatelliteServicing_Mission_DW->INPUT_13_1_1_Discrete[1];
    SatelliteServicing_Mission_B->INPUT_13_1_1[3] =
      SatelliteServicing_Mission_DW->INPUT_13_1_1_Discrete[0];

    // End of SimscapeInputBlock: '<S256>/INPUT_13_1_1'

    // SimscapeInputBlock: '<S256>/INPUT_14_1_1'
    SatelliteServicing_Mission_B->INPUT_14_1_1[0] = 0.0;
    SatelliteServicing_Mission_B->INPUT_14_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_14_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      SatelliteServicing_Mission_DW->INPUT_14_1_1_Discrete[0] =
        !(SatelliteServicing_Mission_B->INPUT_14_1_1[0] ==
          SatelliteServicing_Mission_DW->INPUT_14_1_1_Discrete[1]);
      SatelliteServicing_Mission_DW->INPUT_14_1_1_Discrete[1] =
        SatelliteServicing_Mission_B->INPUT_14_1_1[0];
    }

    SatelliteServicing_Mission_B->INPUT_14_1_1[0] =
      SatelliteServicing_Mission_DW->INPUT_14_1_1_Discrete[1];
    SatelliteServicing_Mission_B->INPUT_14_1_1[3] =
      SatelliteServicing_Mission_DW->INPUT_14_1_1_Discrete[0];

    // End of SimscapeInputBlock: '<S256>/INPUT_14_1_1'

    // SimscapeInputBlock: '<S256>/INPUT_15_1_1'
    SatelliteServicing_Mission_B->INPUT_15_1_1[0] = 0.0;
    SatelliteServicing_Mission_B->INPUT_15_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_15_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      SatelliteServicing_Mission_DW->INPUT_15_1_1_Discrete[0] =
        !(SatelliteServicing_Mission_B->INPUT_15_1_1[0] ==
          SatelliteServicing_Mission_DW->INPUT_15_1_1_Discrete[1]);
      SatelliteServicing_Mission_DW->INPUT_15_1_1_Discrete[1] =
        SatelliteServicing_Mission_B->INPUT_15_1_1[0];
    }

    SatelliteServicing_Mission_B->INPUT_15_1_1[0] =
      SatelliteServicing_Mission_DW->INPUT_15_1_1_Discrete[1];
    SatelliteServicing_Mission_B->INPUT_15_1_1[3] =
      SatelliteServicing_Mission_DW->INPUT_15_1_1_Discrete[0];

    // End of SimscapeInputBlock: '<S256>/INPUT_15_1_1'

    // SimscapeInputBlock: '<S256>/INPUT_16_1_1'
    SatelliteServicing_Mission_B->INPUT_16_1_1[0] = 0.0;
    SatelliteServicing_Mission_B->INPUT_16_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_16_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      SatelliteServicing_Mission_DW->INPUT_16_1_1_Discrete[0] =
        !(SatelliteServicing_Mission_B->INPUT_16_1_1[0] ==
          SatelliteServicing_Mission_DW->INPUT_16_1_1_Discrete[1]);
      SatelliteServicing_Mission_DW->INPUT_16_1_1_Discrete[1] =
        SatelliteServicing_Mission_B->INPUT_16_1_1[0];
    }

    SatelliteServicing_Mission_B->INPUT_16_1_1[0] =
      SatelliteServicing_Mission_DW->INPUT_16_1_1_Discrete[1];
    SatelliteServicing_Mission_B->INPUT_16_1_1[3] =
      SatelliteServicing_Mission_DW->INPUT_16_1_1_Discrete[0];

    // End of SimscapeInputBlock: '<S256>/INPUT_16_1_1'

    // SimscapeInputBlock: '<S256>/INPUT_16_1_2'
    SatelliteServicing_Mission_B->INPUT_16_1_2[0] = 0.0;
    SatelliteServicing_Mission_B->INPUT_16_1_2[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_16_1_2[2] = 0.0;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      SatelliteServicing_Mission_DW->INPUT_16_1_2_Discrete[0] =
        !(SatelliteServicing_Mission_B->INPUT_16_1_2[0] ==
          SatelliteServicing_Mission_DW->INPUT_16_1_2_Discrete[1]);
      SatelliteServicing_Mission_DW->INPUT_16_1_2_Discrete[1] =
        SatelliteServicing_Mission_B->INPUT_16_1_2[0];
    }

    SatelliteServicing_Mission_B->INPUT_16_1_2[0] =
      SatelliteServicing_Mission_DW->INPUT_16_1_2_Discrete[1];
    SatelliteServicing_Mission_B->INPUT_16_1_2[3] =
      SatelliteServicing_Mission_DW->INPUT_16_1_2_Discrete[0];

    // End of SimscapeInputBlock: '<S256>/INPUT_16_1_2'

    // SimscapeInputBlock: '<S256>/INPUT_16_1_3'
    SatelliteServicing_Mission_B->INPUT_16_1_3[0] = 0.0;
    SatelliteServicing_Mission_B->INPUT_16_1_3[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_16_1_3[2] = 0.0;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      SatelliteServicing_Mission_DW->INPUT_16_1_3_Discrete[0] =
        !(SatelliteServicing_Mission_B->INPUT_16_1_3[0] ==
          SatelliteServicing_Mission_DW->INPUT_16_1_3_Discrete[1]);
      SatelliteServicing_Mission_DW->INPUT_16_1_3_Discrete[1] =
        SatelliteServicing_Mission_B->INPUT_16_1_3[0];
    }

    SatelliteServicing_Mission_B->INPUT_16_1_3[0] =
      SatelliteServicing_Mission_DW->INPUT_16_1_3_Discrete[1];
    SatelliteServicing_Mission_B->INPUT_16_1_3[3] =
      SatelliteServicing_Mission_DW->INPUT_16_1_3_Discrete[0];

    // End of SimscapeInputBlock: '<S256>/INPUT_16_1_3'

    // SimscapeExecutionBlock: '<S256>/OUTPUT_1_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData);
    time_3 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_3;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Modes;
    tmp_3 = false;
    simulationData->mData->mFoundZcEvents = tmp_3;
    simulationData->mData->mIsMajorTimeStep = ok;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_7[0] = 0;
    tmp_6[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_6[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_6[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_6[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_7[1] = 4;
    tmp_6[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_6[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_6[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_6[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_7[2] = 8;
    tmp_6[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_6[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_6[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_6[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_7[3] = 12;
    tmp_6[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_6[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_6[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_6[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_7[4] = 16;
    tmp_6[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
    tmp_6[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
    tmp_6[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
    tmp_6[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
    tmp_7[5] = 20;
    tmp_6[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
    tmp_6[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
    tmp_6[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
    tmp_6[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
    tmp_7[6] = 24;
    tmp_6[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
    tmp_6[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
    tmp_6[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
    tmp_6[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
    tmp_7[7] = 28;
    tmp_6[28] = SatelliteServicing_Mission_B->INPUT_8_1_1[0];
    tmp_6[29] = SatelliteServicing_Mission_B->INPUT_8_1_1[1];
    tmp_6[30] = SatelliteServicing_Mission_B->INPUT_8_1_1[2];
    tmp_6[31] = SatelliteServicing_Mission_B->INPUT_8_1_1[3];
    tmp_7[8] = 32;
    tmp_6[32] = SatelliteServicing_Mission_B->INPUT_9_1_1[0];
    tmp_6[33] = SatelliteServicing_Mission_B->INPUT_9_1_1[1];
    tmp_6[34] = SatelliteServicing_Mission_B->INPUT_9_1_1[2];
    tmp_6[35] = SatelliteServicing_Mission_B->INPUT_9_1_1[3];
    tmp_7[9] = 36;
    tmp_6[36] = SatelliteServicing_Mission_B->INPUT_10_1_1[0];
    tmp_6[37] = SatelliteServicing_Mission_B->INPUT_10_1_1[1];
    tmp_6[38] = SatelliteServicing_Mission_B->INPUT_10_1_1[2];
    tmp_6[39] = SatelliteServicing_Mission_B->INPUT_10_1_1[3];
    tmp_7[10] = 40;
    tmp_6[40] = SatelliteServicing_Mission_B->INPUT_11_1_1[0];
    tmp_6[41] = SatelliteServicing_Mission_B->INPUT_11_1_1[1];
    tmp_6[42] = SatelliteServicing_Mission_B->INPUT_11_1_1[2];
    tmp_6[43] = SatelliteServicing_Mission_B->INPUT_11_1_1[3];
    tmp_7[11] = 44;
    tmp_6[44] = SatelliteServicing_Mission_B->INPUT_12_1_1[0];
    tmp_6[45] = SatelliteServicing_Mission_B->INPUT_12_1_1[1];
    tmp_6[46] = SatelliteServicing_Mission_B->INPUT_12_1_1[2];
    tmp_6[47] = SatelliteServicing_Mission_B->INPUT_12_1_1[3];
    tmp_7[12] = 48;
    tmp_6[48] = SatelliteServicing_Mission_B->INPUT_13_1_1[0];
    tmp_6[49] = SatelliteServicing_Mission_B->INPUT_13_1_1[1];
    tmp_6[50] = SatelliteServicing_Mission_B->INPUT_13_1_1[2];
    tmp_6[51] = SatelliteServicing_Mission_B->INPUT_13_1_1[3];
    tmp_7[13] = 52;
    tmp_6[52] = SatelliteServicing_Mission_B->INPUT_14_1_1[0];
    tmp_6[53] = SatelliteServicing_Mission_B->INPUT_14_1_1[1];
    tmp_6[54] = SatelliteServicing_Mission_B->INPUT_14_1_1[2];
    tmp_6[55] = SatelliteServicing_Mission_B->INPUT_14_1_1[3];
    tmp_7[14] = 56;
    tmp_6[56] = SatelliteServicing_Mission_B->INPUT_15_1_1[0];
    tmp_6[57] = SatelliteServicing_Mission_B->INPUT_15_1_1[1];
    tmp_6[58] = SatelliteServicing_Mission_B->INPUT_15_1_1[2];
    tmp_6[59] = SatelliteServicing_Mission_B->INPUT_15_1_1[3];
    tmp_7[15] = 60;
    tmp_6[60] = SatelliteServicing_Mission_B->INPUT_16_1_1[0];
    tmp_6[61] = SatelliteServicing_Mission_B->INPUT_16_1_1[1];
    tmp_6[62] = SatelliteServicing_Mission_B->INPUT_16_1_1[2];
    tmp_6[63] = SatelliteServicing_Mission_B->INPUT_16_1_1[3];
    tmp_7[16] = 64;
    tmp_6[64] = SatelliteServicing_Mission_B->INPUT_16_1_2[0];
    tmp_6[65] = SatelliteServicing_Mission_B->INPUT_16_1_2[1];
    tmp_6[66] = SatelliteServicing_Mission_B->INPUT_16_1_2[2];
    tmp_6[67] = SatelliteServicing_Mission_B->INPUT_16_1_2[3];
    tmp_7[17] = 68;
    tmp_6[68] = SatelliteServicing_Mission_B->INPUT_16_1_3[0];
    tmp_6[69] = SatelliteServicing_Mission_B->INPUT_16_1_3[1];
    tmp_6[70] = SatelliteServicing_Mission_B->INPUT_16_1_3[2];
    tmp_6[71] = SatelliteServicing_Mission_B->INPUT_16_1_3[3];
    tmp_7[18] = 72;
    std::memcpy(&tmp_6[72], &SatelliteServicing_Mission_B->STATE_1[0], 78U *
                sizeof(real_T));
    tmp_7[19] = 150;
    simulationData->mData->mInputValues.mN = 150;
    simulationData->mData->mInputValues.mX = &tmp_6[0];
    simulationData->mData->mInputOffsets.mN = 20;
    simulationData->mData->mInputOffsets.mX = &tmp_7[0];
    simulationData->mData->mOutputs.mN = 30;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_1[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_4 = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_4;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diag = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr);
    diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diag);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diag);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_2 = rtw_diagnostics_msg(diagnosticTree_1);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_2);
      }
    }

    // MATLAB Function: '<S5>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(&rtb_OUTPUT_1_0[4], &rtb_OUTPUT_1_0[19],
      rtb_mat_h);

    // MATLAB Function: '<S6>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(&rtb_OUTPUT_1_0[29], &rtb_OUTPUT_1_0[44],
      rtb_mat_h);

    // MATLAB Function: '<S211>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(&rtb_OUTPUT_1_0[78], &rtb_OUTPUT_1_0[93],
      rtb_mat_h);

    // MATLAB Function: '<S5>/positiveQuat' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServicing_positiveQuat(&rtb_OUTPUT_1_0[0], rtb_qOut_d);

    // MATLAB Function: '<S6>/positiveQuat' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServicing_positiveQuat(&rtb_OUTPUT_1_0[25], rtb_qOut_f);

    // MATLAB Function: '<S211>/positiveQuat' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServicing_positiveQuat(&rtb_OUTPUT_1_0[74], rtb_qOut);

    // MATLAB Function: '<S211>/quat2MRP'
    SatelliteServicing_Mis_quat2MRP(rtb_qOut, rtb_acceleration);

    // MATLAB Function: '<S6>/quat2MRP'
    SatelliteServicing_Mis_quat2MRP(rtb_qOut_f, rtb_acceleration);

    // MATLAB Function: '<S5>/quat2MRP'
    SatelliteServicing_Mis_quat2MRP(rtb_qOut_d, rtb_acceleration);

    // MATLAB Function: '<S5>/Reorder_to_XYZ' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServici_Reorder_to_XYZ(&rtb_OUTPUT_1_0[13], rtb_acceleration);

    // MATLAB Function: '<S6>/Reorder_to_XYZ' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServici_Reorder_to_XYZ(&rtb_OUTPUT_1_0[38], rtb_acceleration);

    // MATLAB Function: '<S211>/Reorder_to_XYZ' incorporates:
    //   SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    SatelliteServici_Reorder_to_XYZ(&rtb_OUTPUT_1_0[87], rtb_acceleration);
  }

  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    NeslSimulationData *simulationData;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    char *msg;
    real_T tmp_0[72];
    real_T time;
    int32_T i;
    int_T tmp_1[19];
    boolean_T tmp;

    // Update for SimscapeExecutionBlock: '<S256>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData);
    time = SatelliteServicing_Mission_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 78;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionClien[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (SatelliteServicing_Mission_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
      (SatelliteServicing_Mission_M->solverInfo);
    tmp_1[0] = 0;
    tmp_0[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_0[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_0[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_0[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_1[1] = 4;
    tmp_0[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_0[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_0[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_0[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_1[2] = 8;
    tmp_0[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_0[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_0[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_0[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_1[3] = 12;
    tmp_0[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_0[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_0[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_0[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_1[4] = 16;
    tmp_0[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
    tmp_0[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
    tmp_0[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
    tmp_0[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
    tmp_1[5] = 20;
    tmp_0[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
    tmp_0[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
    tmp_0[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
    tmp_0[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
    tmp_1[6] = 24;
    tmp_0[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
    tmp_0[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
    tmp_0[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
    tmp_0[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
    tmp_1[7] = 28;
    tmp_0[28] = SatelliteServicing_Mission_B->INPUT_8_1_1[0];
    tmp_0[29] = SatelliteServicing_Mission_B->INPUT_8_1_1[1];
    tmp_0[30] = SatelliteServicing_Mission_B->INPUT_8_1_1[2];
    tmp_0[31] = SatelliteServicing_Mission_B->INPUT_8_1_1[3];
    tmp_1[8] = 32;
    tmp_0[32] = SatelliteServicing_Mission_B->INPUT_9_1_1[0];
    tmp_0[33] = SatelliteServicing_Mission_B->INPUT_9_1_1[1];
    tmp_0[34] = SatelliteServicing_Mission_B->INPUT_9_1_1[2];
    tmp_0[35] = SatelliteServicing_Mission_B->INPUT_9_1_1[3];
    tmp_1[9] = 36;
    tmp_0[36] = SatelliteServicing_Mission_B->INPUT_10_1_1[0];
    tmp_0[37] = SatelliteServicing_Mission_B->INPUT_10_1_1[1];
    tmp_0[38] = SatelliteServicing_Mission_B->INPUT_10_1_1[2];
    tmp_0[39] = SatelliteServicing_Mission_B->INPUT_10_1_1[3];
    tmp_1[10] = 40;
    tmp_0[40] = SatelliteServicing_Mission_B->INPUT_11_1_1[0];
    tmp_0[41] = SatelliteServicing_Mission_B->INPUT_11_1_1[1];
    tmp_0[42] = SatelliteServicing_Mission_B->INPUT_11_1_1[2];
    tmp_0[43] = SatelliteServicing_Mission_B->INPUT_11_1_1[3];
    tmp_1[11] = 44;
    tmp_0[44] = SatelliteServicing_Mission_B->INPUT_12_1_1[0];
    tmp_0[45] = SatelliteServicing_Mission_B->INPUT_12_1_1[1];
    tmp_0[46] = SatelliteServicing_Mission_B->INPUT_12_1_1[2];
    tmp_0[47] = SatelliteServicing_Mission_B->INPUT_12_1_1[3];
    tmp_1[12] = 48;
    tmp_0[48] = SatelliteServicing_Mission_B->INPUT_13_1_1[0];
    tmp_0[49] = SatelliteServicing_Mission_B->INPUT_13_1_1[1];
    tmp_0[50] = SatelliteServicing_Mission_B->INPUT_13_1_1[2];
    tmp_0[51] = SatelliteServicing_Mission_B->INPUT_13_1_1[3];
    tmp_1[13] = 52;
    tmp_0[52] = SatelliteServicing_Mission_B->INPUT_14_1_1[0];
    tmp_0[53] = SatelliteServicing_Mission_B->INPUT_14_1_1[1];
    tmp_0[54] = SatelliteServicing_Mission_B->INPUT_14_1_1[2];
    tmp_0[55] = SatelliteServicing_Mission_B->INPUT_14_1_1[3];
    tmp_1[14] = 56;
    tmp_0[56] = SatelliteServicing_Mission_B->INPUT_15_1_1[0];
    tmp_0[57] = SatelliteServicing_Mission_B->INPUT_15_1_1[1];
    tmp_0[58] = SatelliteServicing_Mission_B->INPUT_15_1_1[2];
    tmp_0[59] = SatelliteServicing_Mission_B->INPUT_15_1_1[3];
    tmp_1[15] = 60;
    tmp_0[60] = SatelliteServicing_Mission_B->INPUT_16_1_1[0];
    tmp_0[61] = SatelliteServicing_Mission_B->INPUT_16_1_1[1];
    tmp_0[62] = SatelliteServicing_Mission_B->INPUT_16_1_1[2];
    tmp_0[63] = SatelliteServicing_Mission_B->INPUT_16_1_1[3];
    tmp_1[16] = 64;
    tmp_0[64] = SatelliteServicing_Mission_B->INPUT_16_1_2[0];
    tmp_0[65] = SatelliteServicing_Mission_B->INPUT_16_1_2[1];
    tmp_0[66] = SatelliteServicing_Mission_B->INPUT_16_1_2[2];
    tmp_0[67] = SatelliteServicing_Mission_B->INPUT_16_1_2[3];
    tmp_1[17] = 68;
    tmp_0[68] = SatelliteServicing_Mission_B->INPUT_16_1_3[0];
    tmp_0[69] = SatelliteServicing_Mission_B->INPUT_16_1_3[1];
    tmp_0[70] = SatelliteServicing_Mission_B->INPUT_16_1_3[2];
    tmp_0[71] = SatelliteServicing_Mission_B->INPUT_16_1_3[3];
    tmp_1[18] = 72;
    simulationData->mData->mInputValues.mN = 72;
    simulationData->mData->mInputValues.mX = &tmp_0[0];
    simulationData->mData->mInputOffsets.mN = 19;
    simulationData->mData->mInputOffsets.mX = &tmp_1[0];
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_UPDATE,
      simulationData, diagnosticManager);
    if (i != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
      }
    }

    // End of Update for SimscapeExecutionBlock: '<S256>/STATE_1'
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // Update for Delay: '<S89>/Delay'
      SatelliteServicing_Mission_DW->icLoad = false;

      // Update for Delay: '<S89>/Delay1'
      SatelliteServicing_Mission_DW->icLoad_d = false;

      // Update for Delay: '<S89>/Delay'
      std::memcpy(&SatelliteServicing_Mission_DW->Delay_DSTATE[0],
                  &SatelliteServicing_Mission_B->coverage_out[0], 282U * sizeof
                  (real_T));

      // Update for Delay: '<S89>/Delay1'
      std::memcpy(&SatelliteServicing_Mission_DW->Delay1_DSTATE[0],
                  &SatelliteServicing_Mission_B->credit_out[0], 282U * sizeof
                  (real_T));
    }
  }                                    // end MajorTimeStep

  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    rt_ertODEUpdateContinuousStates(SatelliteServicing_Mission_M->solverInfo,
      SatelliteServicing_Mission_M, SatelliteServicing_Mission_Y_Observations);

    // Update absolute time for base rate
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.

    ++SatelliteServicing_Mission_M->Timing.clockTick0;
    SatelliteServicing_Mission_M->Timing.t[0] = rtsiGetSolverStopTime
      (SatelliteServicing_Mission_M->solverInfo);

    {
      // Update absolute timer for sample time: [0.001s, 0.0s]
      // The "clockTick1" counts the number of times the code of this task has
      //  been executed. The resolution of this integer timer is 0.001, which is the step size
      //  of the task. Size of "clockTick1" ensures timer will not overflow during the
      //  application lifespan selected.

      SatelliteServicing_Mission_M->Timing.clockTick1++;
    }
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void SatelliteServicing_Mission_derivatives(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M)
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  NeslSimulationData *simulationData;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  XDot_SatelliteServicing_Missi_T *_rtXdot;
  char *msg;
  real_T tmp_0[72];
  real_T time;
  int32_T tmp_2;
  int_T tmp_1[19];
  boolean_T tmp;
  _rtXdot = ((XDot_SatelliteServicing_Missi_T *)
             SatelliteServicing_Mission_M->derivs);

  // Derivatives for SimscapeExecutionBlock: '<S256>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData);
  time = SatelliteServicing_Mission_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 78;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionClien[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
    (SatelliteServicing_Mission_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
    (SatelliteServicing_Mission_M->solverInfo);
  tmp_1[0] = 0;
  tmp_0[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
  tmp_0[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
  tmp_0[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
  tmp_0[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
  tmp_1[1] = 4;
  tmp_0[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
  tmp_0[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
  tmp_0[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
  tmp_0[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
  tmp_1[2] = 8;
  tmp_0[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
  tmp_0[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
  tmp_0[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
  tmp_0[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
  tmp_1[3] = 12;
  tmp_0[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
  tmp_0[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
  tmp_0[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
  tmp_0[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
  tmp_1[4] = 16;
  tmp_0[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
  tmp_0[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
  tmp_0[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
  tmp_0[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
  tmp_1[5] = 20;
  tmp_0[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
  tmp_0[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
  tmp_0[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
  tmp_0[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
  tmp_1[6] = 24;
  tmp_0[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
  tmp_0[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
  tmp_0[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
  tmp_0[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
  tmp_1[7] = 28;
  tmp_0[28] = SatelliteServicing_Mission_B->INPUT_8_1_1[0];
  tmp_0[29] = SatelliteServicing_Mission_B->INPUT_8_1_1[1];
  tmp_0[30] = SatelliteServicing_Mission_B->INPUT_8_1_1[2];
  tmp_0[31] = SatelliteServicing_Mission_B->INPUT_8_1_1[3];
  tmp_1[8] = 32;
  tmp_0[32] = SatelliteServicing_Mission_B->INPUT_9_1_1[0];
  tmp_0[33] = SatelliteServicing_Mission_B->INPUT_9_1_1[1];
  tmp_0[34] = SatelliteServicing_Mission_B->INPUT_9_1_1[2];
  tmp_0[35] = SatelliteServicing_Mission_B->INPUT_9_1_1[3];
  tmp_1[9] = 36;
  tmp_0[36] = SatelliteServicing_Mission_B->INPUT_10_1_1[0];
  tmp_0[37] = SatelliteServicing_Mission_B->INPUT_10_1_1[1];
  tmp_0[38] = SatelliteServicing_Mission_B->INPUT_10_1_1[2];
  tmp_0[39] = SatelliteServicing_Mission_B->INPUT_10_1_1[3];
  tmp_1[10] = 40;
  tmp_0[40] = SatelliteServicing_Mission_B->INPUT_11_1_1[0];
  tmp_0[41] = SatelliteServicing_Mission_B->INPUT_11_1_1[1];
  tmp_0[42] = SatelliteServicing_Mission_B->INPUT_11_1_1[2];
  tmp_0[43] = SatelliteServicing_Mission_B->INPUT_11_1_1[3];
  tmp_1[11] = 44;
  tmp_0[44] = SatelliteServicing_Mission_B->INPUT_12_1_1[0];
  tmp_0[45] = SatelliteServicing_Mission_B->INPUT_12_1_1[1];
  tmp_0[46] = SatelliteServicing_Mission_B->INPUT_12_1_1[2];
  tmp_0[47] = SatelliteServicing_Mission_B->INPUT_12_1_1[3];
  tmp_1[12] = 48;
  tmp_0[48] = SatelliteServicing_Mission_B->INPUT_13_1_1[0];
  tmp_0[49] = SatelliteServicing_Mission_B->INPUT_13_1_1[1];
  tmp_0[50] = SatelliteServicing_Mission_B->INPUT_13_1_1[2];
  tmp_0[51] = SatelliteServicing_Mission_B->INPUT_13_1_1[3];
  tmp_1[13] = 52;
  tmp_0[52] = SatelliteServicing_Mission_B->INPUT_14_1_1[0];
  tmp_0[53] = SatelliteServicing_Mission_B->INPUT_14_1_1[1];
  tmp_0[54] = SatelliteServicing_Mission_B->INPUT_14_1_1[2];
  tmp_0[55] = SatelliteServicing_Mission_B->INPUT_14_1_1[3];
  tmp_1[14] = 56;
  tmp_0[56] = SatelliteServicing_Mission_B->INPUT_15_1_1[0];
  tmp_0[57] = SatelliteServicing_Mission_B->INPUT_15_1_1[1];
  tmp_0[58] = SatelliteServicing_Mission_B->INPUT_15_1_1[2];
  tmp_0[59] = SatelliteServicing_Mission_B->INPUT_15_1_1[3];
  tmp_1[15] = 60;
  tmp_0[60] = SatelliteServicing_Mission_B->INPUT_16_1_1[0];
  tmp_0[61] = SatelliteServicing_Mission_B->INPUT_16_1_1[1];
  tmp_0[62] = SatelliteServicing_Mission_B->INPUT_16_1_1[2];
  tmp_0[63] = SatelliteServicing_Mission_B->INPUT_16_1_1[3];
  tmp_1[16] = 64;
  tmp_0[64] = SatelliteServicing_Mission_B->INPUT_16_1_2[0];
  tmp_0[65] = SatelliteServicing_Mission_B->INPUT_16_1_2[1];
  tmp_0[66] = SatelliteServicing_Mission_B->INPUT_16_1_2[2];
  tmp_0[67] = SatelliteServicing_Mission_B->INPUT_16_1_2[3];
  tmp_1[17] = 68;
  tmp_0[68] = SatelliteServicing_Mission_B->INPUT_16_1_3[0];
  tmp_0[69] = SatelliteServicing_Mission_B->INPUT_16_1_3[1];
  tmp_0[70] = SatelliteServicing_Mission_B->INPUT_16_1_3[2];
  tmp_0[71] = SatelliteServicing_Mission_B->INPUT_16_1_3[3];
  tmp_1[18] = 72;
  simulationData->mData->mInputValues.mN = 72;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 19;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  simulationData->mData->mDx.mN = 78;
  simulationData->mData->mDx.mX = &_rtXdot->SatelliteServicing_MissionClien[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_DERIVATIVES,
    simulationData, diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
    }
  }

  // End of Derivatives for SimscapeExecutionBlock: '<S256>/STATE_1'
}

// Model initialize function
void SatelliteServicing_Mission_initialize(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M, real_T
  *SatelliteServicing_Mission_Y_ControlError)
{
  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  {
    NeModelParameters modelParameters;
    NeModelParameters modelParameters_0;
    NeModelParameters modelParameters_1;
    NeslRtpManager *manager;
    NeslRtpManager *manager_0;
    NeslSimulationData *tmp_1;
    NeslSimulator *tmp_0;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    NeuDiagnosticTree *diagnosticTree_0;
    NeuDiagnosticTree *diagnosticTree_1;
    char *msg;
    char *msg_0;
    char *msg_1;
    real_T tmp_2;
    int32_T tmp_3;
    boolean_T tmp;

    // Start for SimscapeRtp: '<S4>/RTP_1'
    manager_0 = nesl_lease_rtp_manager(
      "SatelliteServicing_Mission/Solver Configuration_1", 0);
    manager = manager_0;
    tmp = pointer_is_null(manager_0);
    if (tmp) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      manager = nesl_lease_rtp_manager(
        "SatelliteServicing_Mission/Solver Configuration_1", 0);
    }

    SatelliteServicing_Mission_DW->RTP_1_RtpManager = (void *)manager;
    SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded = true;

    // End of Start for SimscapeRtp: '<S4>/RTP_1'

    // Start for SimscapeExecutionBlock: '<S256>/STATE_1'
    tmp_0 = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 0, 0);
    SatelliteServicing_Mission_DW->STATE_1_Simulator = (void *)tmp_0;
    tmp = pointer_is_null(SatelliteServicing_Mission_DW->STATE_1_Simulator);
    if (tmp) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp_0 = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 0, 0);
      SatelliteServicing_Mission_DW->STATE_1_Simulator = (void *)tmp_0;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->STATE_1_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->STATE_1_DiagMgr = (void *)diagnosticManager;
    modelParameters.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters.mSolverAbsTol = 0.001;
    modelParameters.mSolverRelTol = 0.001;
    modelParameters.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters.mStartTime = 0.0;
    modelParameters.mLoadInitialState = false;
    modelParameters.mUseSimState = false;
    modelParameters.mLinTrimCompile = false;
    modelParameters.mLoggingMode = SSC_LOGGING_ON;
    modelParameters.mRTWModifiedTimeStamp = 6.3666722E+8;
    modelParameters.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters.mSolverTolerance = tmp_2;
    tmp_2 = 0.001;
    modelParameters.mFixedStepSize = tmp_2;
    tmp = false;
    modelParameters.mVariableStepSolver = tmp;
    tmp = false;
    modelParameters.mIsUsingODEN = tmp;
    modelParameters.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), &modelParameters,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S256>/STATE_1'

    // Start for SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'
    tmp_0 = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 1, 0);
    SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator = (void *)tmp_0;
    tmp = pointer_is_null(SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator);
    if (tmp) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp_0 = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 1, 0);
      SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator = (void *)tmp_0;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr = (void *)
      diagnosticManager;
    modelParameters_0.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_0.mSolverAbsTol = 0.001;
    modelParameters_0.mSolverRelTol = 0.001;
    modelParameters_0.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_0.mStartTime = 0.0;
    modelParameters_0.mLoadInitialState = false;
    modelParameters_0.mUseSimState = false;
    modelParameters_0.mLinTrimCompile = false;
    modelParameters_0.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_0.mRTWModifiedTimeStamp = 6.3666722E+8;
    modelParameters_0.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_0.mSolverTolerance = tmp_2;
    tmp_2 = 0.001;
    modelParameters_0.mFixedStepSize = tmp_2;
    tmp = false;
    modelParameters_0.mVariableStepSolver = tmp;
    tmp = false;
    modelParameters_0.mIsUsingODEN = tmp;
    modelParameters_0.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr);
    diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator), &modelParameters_0,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg_0 = rtw_diagnostics_msg(diagnosticTree_0);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'

    // Start for SimscapeExecutionBlock: '<S256>/OUTPUT_1_1'
    tmp_0 = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 1, 1);
    SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator = (void *)tmp_0;
    tmp = pointer_is_null(SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator);
    if (tmp) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp_0 = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 1, 1);
      SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator = (void *)tmp_0;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr = (void *)
      diagnosticManager;
    modelParameters_1.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_1.mSolverAbsTol = 0.001;
    modelParameters_1.mSolverRelTol = 0.001;
    modelParameters_1.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_1.mStartTime = 0.0;
    modelParameters_1.mLoadInitialState = false;
    modelParameters_1.mUseSimState = false;
    modelParameters_1.mLinTrimCompile = false;
    modelParameters_1.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_1.mRTWModifiedTimeStamp = 6.3666722E+8;
    modelParameters_1.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_1.mSolverTolerance = tmp_2;
    tmp_2 = 0.001;
    modelParameters_1.mFixedStepSize = tmp_2;
    tmp = false;
    modelParameters_1.mVariableStepSolver = tmp;
    tmp = false;
    modelParameters_1.mIsUsingODEN = tmp;
    modelParameters_1.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr);
    diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator), &modelParameters_1,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg_1 = rtw_diagnostics_msg(diagnosticTree_1);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S256>/OUTPUT_1_1'

    // InitializeConditions for Delay: '<S89>/Delay'
    SatelliteServicing_Mission_DW->icLoad = true;

    // InitializeConditions for Delay: '<S89>/Delay1'
    SatelliteServicing_Mission_DW->icLoad_d = true;

    // ConstCode for Outport: '<Root>/ControlError'
    *SatelliteServicing_Mission_Y_ControlError = 0.0;
  }
}

// Model terminate function
void SatelliteServicing_Mission_terminate(RT_MODEL_SatelliteServicing_M_T
  * SatelliteServicing_Mission_M)
{
  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  // Terminate for SimscapeExecutionBlock: '<S256>/STATE_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S256>/OUTPUT_1_0'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S256>/OUTPUT_1_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();
  rt_FREE(SatelliteServicing_Mission_M->solverInfo);

  // model code
  rt_FREE(SatelliteServicing_Mission_M->blockIO);
  rt_FREE(SatelliteServicing_Mission_M->contStates);
  rt_FREE(SatelliteServicing_Mission_M->dwork);
  delete SatelliteServicing_Mission_M;
}

// Model data allocation function
RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission(real_T
  SatelliteServicing_Mission_U_ManipulatorActions[3], real_T
  SatelliteServicing_Mission_Y_Observations[282], real_T
  *SatelliteServicing_Mission_Y_ControlError)
{
  RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission_M;
  SatelliteServicing_Mission_M = new RT_MODEL_SatelliteServicing_M_T();
  if (SatelliteServicing_Mission_M == (nullptr)) {
    return (nullptr);
  }

  {
    // Setup solver object
    RTWSolverInfo *rt_SolverInfo{ (RTWSolverInfo *) malloc(sizeof(RTWSolverInfo))
    };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,rt_SolverInfo);
    SatelliteServicing_Mission_M->solverInfo = (rt_SolverInfo);
    rtsiSetSimTimeStepPtr(SatelliteServicing_Mission_M->solverInfo,
                          &SatelliteServicing_Mission_M->Timing.simTimeStep);
    rtsiSetTPtr(SatelliteServicing_Mission_M->solverInfo, &rtmGetTPtr
                (SatelliteServicing_Mission_M));
    rtsiSetStepSizePtr(SatelliteServicing_Mission_M->solverInfo,
                       &SatelliteServicing_Mission_M->Timing.stepSize0);
    rtsiSetdXPtr(SatelliteServicing_Mission_M->solverInfo,
                 &SatelliteServicing_Mission_M->derivs);
    rtsiSetContStatesPtr(SatelliteServicing_Mission_M->solverInfo, (real_T **)
                         &SatelliteServicing_Mission_M->contStates);
    rtsiSetNumContStatesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(SatelliteServicing_Mission_M->solverInfo,
                          (&rtmGetErrorStatus(SatelliteServicing_Mission_M)));
    rtsiSetRTModelPtr(SatelliteServicing_Mission_M->solverInfo,
                      SatelliteServicing_Mission_M);
  }

  rtsiSetSolverName(SatelliteServicing_Mission_M->solverInfo,"ode3");

  // block I/O
  {
    B_SatelliteServicing_Mission_T *b{ (B_SatelliteServicing_Mission_T *) malloc
      (sizeof(B_SatelliteServicing_Mission_T)) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,b);
    SatelliteServicing_Mission_M->blockIO = (b);
  }

  // states (continuous)
  {
    X_SatelliteServicing_Mission_T *x{ (X_SatelliteServicing_Mission_T *) malloc
      (sizeof(X_SatelliteServicing_Mission_T)) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,x);
    SatelliteServicing_Mission_M->contStates = (x);
  }

  // states (dwork)
  {
    DW_SatelliteServicing_Mission_T *dwork{ static_cast<
      DW_SatelliteServicing_Mission_T *>(malloc(sizeof
      (DW_SatelliteServicing_Mission_T))) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,dwork);
    SatelliteServicing_Mission_M->dwork = (dwork);
  }

  {
    B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
      SatelliteServicing_Mission_M->blockIO };

    DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
      SatelliteServicing_Mission_M->dwork };

    X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
      SatelliteServicing_Mission_M->contStates };

    // initialize non-finites
    rt_InitInfAndNaN(sizeof(real_T));
    rtsiSetSimTimeStep(SatelliteServicing_Mission_M->solverInfo, MAJOR_TIME_STEP);
    SatelliteServicing_Mission_M->intgData.y =
      SatelliteServicing_Mission_M->odeY;
    SatelliteServicing_Mission_M->intgData.f[0] =
      SatelliteServicing_Mission_M->odeF[0];
    SatelliteServicing_Mission_M->intgData.f[1] =
      SatelliteServicing_Mission_M->odeF[1];
    SatelliteServicing_Mission_M->intgData.f[2] =
      SatelliteServicing_Mission_M->odeF[2];
    SatelliteServicing_Mission_M->contStates = ((X_SatelliteServicing_Mission_T *)
      SatelliteServicing_Mission_X);
    rtsiSetSolverData(SatelliteServicing_Mission_M->solverInfo, static_cast<void
                      *>(&SatelliteServicing_Mission_M->intgData));
    rtsiSetIsMinorTimeStepWithModeChange
      (SatelliteServicing_Mission_M->solverInfo, false);
    rtmSetTPtr(SatelliteServicing_Mission_M,
               &SatelliteServicing_Mission_M->Timing.tArray[0]);
    SatelliteServicing_Mission_M->Timing.stepSize0 = 0.001;

    // block I/O
    (void) std::memset((static_cast<void *>(SatelliteServicing_Mission_B)), 0,
                       sizeof(B_SatelliteServicing_Mission_T));

    // states (continuous)
    {
      (void) std::memset(static_cast<void *>(SatelliteServicing_Mission_X), 0,
                         sizeof(X_SatelliteServicing_Mission_T));
    }

    // states (dwork)
    (void) std::memset(static_cast<void *>(SatelliteServicing_Mission_DW), 0,
                       sizeof(DW_SatelliteServicing_Mission_T));

    // external inputs
    (void)std::memset(&SatelliteServicing_Mission_U_ManipulatorActions[0], 0, 3U
                      * sizeof(real_T));

    // external outputs
    (void)std::memset(&SatelliteServicing_Mission_Y_Observations[0], 0, 282U *
                      sizeof(real_T));
    *SatelliteServicing_Mission_Y_ControlError = 0.0;
  }

  return SatelliteServicing_Mission_M;
}

//
// File trailer for generated code.
//
// [EOF]
//
