//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.5
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Mon Nov 13 10:47:25 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "SatelliteServicing_Mission.h"
#include "rtwtypes.h"
#include "SatelliteServicing_Mission_private.h"
#include <cmath>
#include "rt_atan2d_snf.h"
#include <cstring>
#include <emmintrin.h>
#include "norm_NaTV2q6x.h"
#include <stddef.h>
#include "plook_u32d_bincka.h"

extern "C"
{

#include "rt_nonfinite.h"

}

// Projection for root system: '<Root>'
void SatelliteServicing_Mission_projection(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M)
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  NeslSimulationData *simulationData;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  char *msg;
  real_T tmp_0[36];
  real_T time;
  int32_T tmp_2;
  int_T tmp_1[10];
  boolean_T tmp;

  // Projection for SimscapeExecutionBlock: '<S285>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData);
  time = SatelliteServicing_Mission_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 32;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionServi[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
    (SatelliteServicing_Mission_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
    (SatelliteServicing_Mission_M->solverInfo);
  tmp_1[0] = 0;
  tmp_0[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
  tmp_0[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
  tmp_0[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
  tmp_0[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
  tmp_1[1] = 4;
  tmp_0[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
  tmp_0[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
  tmp_0[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
  tmp_0[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
  tmp_1[2] = 8;
  tmp_0[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
  tmp_0[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
  tmp_0[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
  tmp_0[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
  tmp_1[3] = 12;
  tmp_0[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
  tmp_0[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
  tmp_0[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
  tmp_0[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
  tmp_1[4] = 16;
  tmp_0[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
  tmp_0[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
  tmp_0[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
  tmp_0[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
  tmp_1[5] = 20;
  tmp_0[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
  tmp_0[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
  tmp_0[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
  tmp_0[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
  tmp_1[6] = 24;
  tmp_0[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
  tmp_0[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
  tmp_0[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
  tmp_0[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
  tmp_1[7] = 28;
  tmp_0[28] = SatelliteServicing_Mission_B->INPUT_7_1_2[0];
  tmp_0[29] = SatelliteServicing_Mission_B->INPUT_7_1_2[1];
  tmp_0[30] = SatelliteServicing_Mission_B->INPUT_7_1_2[2];
  tmp_0[31] = SatelliteServicing_Mission_B->INPUT_7_1_2[3];
  tmp_1[8] = 32;
  tmp_0[32] = SatelliteServicing_Mission_B->INPUT_7_1_3[0];
  tmp_0[33] = SatelliteServicing_Mission_B->INPUT_7_1_3[1];
  tmp_0[34] = SatelliteServicing_Mission_B->INPUT_7_1_3[2];
  tmp_0[35] = SatelliteServicing_Mission_B->INPUT_7_1_3[3];
  tmp_1[9] = 36;
  simulationData->mData->mInputValues.mN = 36;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 10;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_PROJECTION,
    simulationData, diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
    }
  }

  // End of Projection for SimscapeExecutionBlock: '<S285>/STATE_1'
}

//
// This function updates continuous states using the ODE3 fixed-step
// solver algorithm
//
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si ,
  RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M,
  ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
  ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y)
{
  // Solver Matrices
  static const real_T rt_ODE3_A[3]{
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3]{
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t { rtsiGetT(si) };

  time_T tnew { rtsiGetSolverStopTime(si) };

  time_T h { rtsiGetStepSize(si) };

  real_T *x { rtsiGetContStates(si) };

  ODE3_IntgData *id { static_cast<ODE3_IntgData *>(rtsiGetSolverData(si)) };

  real_T *y { id->y };

  real_T *f0 { id->f[0] };

  real_T *f1 { id->f[1] };

  real_T *f2 { id->f[2] };

  real_T hB[3];
  int_T i;
  int_T nXc { 38 };

  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*));
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_U, SatelliteServicing_Mission_Y);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*));
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_U, SatelliteServicing_Mission_Y);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // tnew = t + hA(3);
  // ynew = y + f*hB(:,3);
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_U, SatelliteServicing_Mission_Y);
  SatelliteServicing_Mission_projection(SatelliteServicing_Mission_M);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

//
// Output and update for atomic system:
//    '<S7>/MATLAB Function'
//    '<S8>/MATLAB Function'
//    '<S95>/MATLAB Function'
//    '<S96>/MATLAB Function'
//    '<S243>/MATLAB Function'
//
void SatelliteServici_MATLABFunction(const real_T rtu_qin[4], real_T rty_qout[4])
{
  rty_qout[0] = rtu_qin[0];
  rty_qout[1] = -rtu_qin[1];
  rty_qout[2] = -rtu_qin[2];
  rty_qout[3] = -rtu_qin[3];
}

//
// Termination for atomic system:
//    '<S7>/MATLAB Function'
//    '<S8>/MATLAB Function'
//    '<S95>/MATLAB Function'
//    '<S96>/MATLAB Function'
//    '<S243>/MATLAB Function'
//
void SatelliteSe_MATLABFunction_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S7>/QuatToDCM'
//    '<S8>/QuatToDCM'
//    '<S95>/QuatToDCM'
//    '<S96>/QuatToDCM'
//    '<S243>/QuatToDCM'
//
void SatelliteServicing_Mi_QuatToDCM(const real_T rtu_q[4], real_T rty_mat[9])
{
  real_T tmp;
  real_T tmp_0;
  real_T tmp_1;
  real_T tmp_2;
  real_T tmp_3;
  real_T tmp_4;
  real_T tmp_5;
  real_T tmp_6;
  tmp_1 = rtu_q[0] * rtu_q[0];
  tmp_2 = rtu_q[1] * rtu_q[1];
  tmp_3 = rtu_q[2] * rtu_q[2];
  tmp_4 = rtu_q[3] * rtu_q[3];
  rty_mat[0] = ((tmp_1 + tmp_2) - tmp_3) - tmp_4;
  tmp = rtu_q[1] * rtu_q[2];
  tmp_0 = rtu_q[0] * rtu_q[3];
  rty_mat[3] = (tmp + tmp_0) * 2.0;
  tmp_5 = rtu_q[1] * rtu_q[3];
  tmp_6 = rtu_q[0] * rtu_q[2];
  rty_mat[6] = (tmp_5 - tmp_6) * 2.0;
  rty_mat[1] = (tmp - tmp_0) * 2.0;
  tmp_1 -= tmp_2;
  rty_mat[4] = (tmp_1 + tmp_3) - tmp_4;
  tmp_2 = rtu_q[2] * rtu_q[3];
  tmp = rtu_q[0] * rtu_q[1];
  rty_mat[7] = (tmp_2 + tmp) * 2.0;
  rty_mat[2] = (tmp_5 + tmp_6) * 2.0;
  rty_mat[5] = (tmp_2 - tmp) * 2.0;
  rty_mat[8] = (tmp_1 - tmp_3) + tmp_4;
}

//
// Termination for atomic system:
//    '<S7>/QuatToDCM'
//    '<S8>/QuatToDCM'
//    '<S95>/QuatToDCM'
//    '<S96>/QuatToDCM'
//    '<S243>/QuatToDCM'
//
void SatelliteServici_QuatToDCM_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S7>/QuatToEuler321'
//    '<S8>/QuatToEuler321'
//    '<S95>/QuatToEuler321'
//    '<S96>/QuatToEuler321'
//    '<S243>/QuatToEuler321'
//
void SatelliteServici_QuatToEuler321(const real_T rtu_q[4], real_T rty_euler[3])
{
  real_T cPcR;
  real_T cPcR_tmp;
  real_T cPsR_tmp;
  real_T sin_theta;
  sin_theta = (rtu_q[1] * rtu_q[3] + rtu_q[0] * rtu_q[2]) * -2.0;
  if (sin_theta > 1.0) {
    sin_theta = 1.0;
  } else if (sin_theta < -1.0) {
    sin_theta = -1.0;
  }

  cPsR_tmp = (rtu_q[2] * rtu_q[3] - rtu_q[0] * rtu_q[1]) * 2.0;
  cPcR_tmp = rtu_q[3] * rtu_q[3];
  cPcR = (rtu_q[0] * rtu_q[0] + cPcR_tmp) * 2.0 - 1.0;
  rty_euler[1] = rt_atan2d_snf(sin_theta, std::sqrt(cPsR_tmp * cPsR_tmp + cPcR *
    cPcR));
  if (std::sqrt(1.0 - sin_theta * sin_theta) >= 0.00048281) {
    sin_theta = rtu_q[2] * rtu_q[2];
    rty_euler[0] = rt_atan2d_snf(cPsR_tmp, 1.0 - (rtu_q[1] * rtu_q[1] +
      sin_theta) * 2.0);
    rty_euler[2] = rt_atan2d_snf((rtu_q[1] * rtu_q[2] - rtu_q[0] * rtu_q[3]) *
      2.0, 1.0 - (sin_theta + cPcR_tmp) * 2.0);
  } else {
    rty_euler[0] = 0.0;
    rty_euler[2] = rt_atan2d_snf((rtu_q[1] * rtu_q[2] - rtu_q[0] * rtu_q[3]) *
      2.0, 1.0 - (rtu_q[1] * rtu_q[1] + cPcR_tmp) * 2.0);
  }
}

//
// Termination for atomic system:
//    '<S7>/QuatToEuler321'
//    '<S8>/QuatToEuler321'
//    '<S95>/QuatToEuler321'
//    '<S96>/QuatToEuler321'
//    '<S243>/QuatToEuler321'
//
void SatelliteSe_QuatToEuler321_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S7>/formPoseMat'
//    '<S8>/formPoseMat'
//    '<S95>/formPoseMat'
//    '<S96>/formPoseMat'
//    '<S243>/formPoseMat'
//
void SatelliteServicing__formPoseMat(const real_T rtu_rotMat[9], const real_T
  rtu_posVec[3], real_T rty_mat[16])
{
  for (int32_T i{0}; i < 3; i++) {
    int32_T tmp;
    tmp = i << 2;
    rty_mat[tmp] = rtu_rotMat[3 * i];
    rty_mat[tmp + 1] = rtu_rotMat[3 * i + 1];
    rty_mat[tmp + 2] = rtu_rotMat[3 * i + 2];
    rty_mat[i + 12] = rtu_posVec[i];
  }

  rty_mat[3] = 0.0;
  rty_mat[7] = 0.0;
  rty_mat[11] = 0.0;
  rty_mat[15] = 1.0;
}

//
// Termination for atomic system:
//    '<S7>/formPoseMat'
//    '<S8>/formPoseMat'
//    '<S95>/formPoseMat'
//    '<S96>/formPoseMat'
//    '<S243>/formPoseMat'
//
void SatelliteServi_formPoseMat_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S7>/quat2MRP'
//    '<S8>/quat2MRP'
//    '<S95>/quat2MRP'
//    '<S96>/quat2MRP'
//    '<S243>/quat2MRP'
//
void SatelliteServicing_Mis_quat2MRP(const real_T rtu_q[4], real_T rty_mrp[3])
{
  rty_mrp[0] = rtu_q[1] / (rtu_q[0] + 1.0);
  rty_mrp[1] = rtu_q[2] / (rtu_q[0] + 1.0);
  rty_mrp[2] = rtu_q[3] / (rtu_q[0] + 1.0);
}

//
// Termination for atomic system:
//    '<S7>/quat2MRP'
//    '<S8>/quat2MRP'
//    '<S95>/quat2MRP'
//    '<S96>/quat2MRP'
//    '<S243>/quat2MRP'
//
void SatelliteServicin_quat2MRP_Term(void)
{
}

//
// Termination for atomic system:
//    '<S214>/quat2MPR1'
//    '<S214>/quat2MRP'
//
void SatelliteServici_quat2MPR1_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S210>/positiveQuat'
//    '<S212>/positiveQuat'
//
void SatelliteServicing_positiveQuat(const real_T rtu_qIn[4], real_T rty_qOut[4])
{
  if (rtu_qIn[0] < 0.0) {
    rty_qOut[0] = -rtu_qIn[0];
    rty_qOut[1] = -rtu_qIn[1];
    rty_qOut[2] = -rtu_qIn[2];
    rty_qOut[3] = -rtu_qIn[3];
  } else {
    rty_qOut[0] = rtu_qIn[0];
    rty_qOut[1] = rtu_qIn[1];
    rty_qOut[2] = rtu_qIn[2];
    rty_qOut[3] = rtu_qIn[3];
  }
}

//
// Termination for atomic system:
//    '<S210>/positiveQuat'
//    '<S212>/positiveQuat'
//
void SatelliteServ_positiveQuat_Term(void)
{
}

// Model step function
void SatelliteServicing_Mission_step(RT_MODEL_SatelliteServicing_M_T *const
  SatelliteServicing_Mission_M, ExtU_SatelliteServicing_Missi_T
  *SatelliteServicing_Mission_U, ExtY_SatelliteServicing_Missi_T
  *SatelliteServicing_Mission_Y)
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  // local block i/o variables
  real_T rtb_OUTPUT_1_0[71];
  real_T rtb_euler[3];
  real_T rtb_euler_c[3];
  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    // set solver stop time
    rtsiSetSolverStopTime(SatelliteServicing_Mission_M->solverInfo,
                          ((SatelliteServicing_Mission_M->Timing.clockTick0+1)*
      SatelliteServicing_Mission_M->Timing.stepSize0));
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep(SatelliteServicing_Mission_M)) {
    SatelliteServicing_Mission_M->Timing.t[0] = rtsiGetT
      (SatelliteServicing_Mission_M->solverInfo);
  }

  {
    static const int8_T d[3]{ 0, 0, 1 };

    __m128d tmp_7;
    __m128d tmp_8;
    __m128d tmp_9;
    __m128d tmp_a;
    __m128d tmp_b;
    NeParameterBundle expl_temp;
    NeslSimulationData *simulationData;
    NeuDiagnosticManager *diag;
    NeuDiagnosticTree *diagTree;
    NeuDiagnosticTree *diagnosticTree;
    NeuDiagnosticTree *diagnosticTree_0;
    NeuDiagnosticTree *diagnosticTree_1;
    char *msg;
    char *msg_0;
    char *msg_1;
    char *msg_2;
    real_T tmp_3[68];
    real_T tmp_5[68];
    real_T rtb_OUTPUT_1_1[42];
    real_T tmp_0[36];
    real_T rtb_Product[16];
    real_T rtb_mat[16];
    real_T rtb_mat_b[16];
    real_T rtb_Selector[12];
    real_T b[9];
    real_T rtb_mat_by[9];
    real_T rtb_mat_j_tmp[9];
    real_T rtb_mat_j_tmp_0[9];
    real_T rtb_q[4];
    real_T rtb_qOut_f[4];
    real_T rtb_qout[4];
    real_T rtb_qout_gi[4];
    real_T rtb_qout_n[4];
    real_T rtb_MRPError[3];
    real_T rtb_Sum1_i[3];
    real_T rtb_controlErrorECEF_l[3];
    real_T rtb_mrp_g[3];
    real_T rtb_Reshape2_idx_10;
    real_T rtb_Reshape2_idx_11;
    real_T rtb_Reshape2_idx_6;
    real_T rtb_Reshape2_idx_7;
    real_T rtb_Reshape2_idx_8;
    real_T rtb_Reshape2_idx_9;
    real_T rtb_q_l_idx_0;
    real_T rtb_q_l_idx_1;
    real_T rtb_q_l_idx_2;
    real_T rtb_q_l_idx_3;
    real_T time;
    real_T time_0;
    real_T time_1;
    real_T time_2;
    real_T time_3;
    real_T time_4;
    real_T u0;
    real_T *parameterBundle_mRealParameters;
    int32_T i;
    int32_T i_0;
    int32_T rtb_Reshape2_idx_7_tmp;
    int_T tmp_4[11];
    int_T tmp_6[11];
    int_T tmp_1[10];
    uint32_T rtb_Bias;
    boolean_T ok;
    boolean_T tmp;
    boolean_T tmp_2;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // SimscapeRtp: '<S6>/RTP_1' incorporates:
      //   Constant: '<S84>/Subsystem_around_RTP_3768B6F2_PositionTargetValue'

      if (SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded) {
        rtb_MRPError[0] =
          SatelliteServicing_Mission_P.RTP_3768B6F2_PositionTargetValu;
        rtb_MRPError[1] =
          SatelliteServicing_Mission_P.RTP_406F8664_PositionTargetValu;
        rtb_MRPError[2] =
          SatelliteServicing_Mission_P.RTP_AE61E748_PositionTargetValu;
        parameterBundle_mRealParameters = &rtb_MRPError[0];
        diag = rtw_create_diagnostics();
        diagTree = neu_diagnostic_manager_get_initial_tree(diag);
        expl_temp.mRealParameters.mN = 3;
        expl_temp.mRealParameters.mX = parameterBundle_mRealParameters;
        expl_temp.mLogicalParameters.mN = 0;
        expl_temp.mLogicalParameters.mX = nullptr;
        expl_temp.mIntegerParameters.mN = 0;
        expl_temp.mIntegerParameters.mX = nullptr;
        expl_temp.mIndexParameters.mN = 0;
        expl_temp.mIndexParameters.mX = nullptr;
        ok = nesl_rtp_manager_set_rtps(static_cast<NeslRtpManager *>
          (SatelliteServicing_Mission_DW->RTP_1_RtpManager),
          SatelliteServicing_Mission_M->Timing.t[0], expl_temp, diag);
        if (!ok) {
          ok = error_buffer_is_empty(rtmGetErrorStatus
            (SatelliteServicing_Mission_M));
          if (ok) {
            msg = rtw_diagnostics_msg(diagTree);
            rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
          }
        }
      }

      SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded = false;

      // End of SimscapeRtp: '<S6>/RTP_1'
    }

    // SimscapeExecutionBlock: '<S285>/STATE_1' incorporates:
    //   Clock: '<Root>/Clock'
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_1'

    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData);
    rtb_q_l_idx_0 = SatelliteServicing_Mission_M->Timing.t[0];
    time = rtb_q_l_idx_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 32;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionServi[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    ok = rtmIsMajorTimeStep(SatelliteServicing_Mission_M);
    simulationData->mData->mIsMajorTimeStep = ok;
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp = rtsiIsModeUpdateTimeStep(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsModeUpdateTimeStep = tmp;
    tmp_1[0] = 0;
    tmp_0[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_0[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_0[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_0[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_1[1] = 4;
    tmp_0[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_0[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_0[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_0[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_1[2] = 8;
    tmp_0[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_0[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_0[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_0[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_1[3] = 12;
    tmp_0[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_0[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_0[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_0[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_1[4] = 16;
    tmp_0[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
    tmp_0[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
    tmp_0[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
    tmp_0[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
    tmp_1[5] = 20;
    tmp_0[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
    tmp_0[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
    tmp_0[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
    tmp_0[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
    tmp_1[6] = 24;
    tmp_0[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
    tmp_0[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
    tmp_0[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
    tmp_0[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
    tmp_1[7] = 28;
    tmp_0[28] = SatelliteServicing_Mission_B->INPUT_7_1_2[0];
    tmp_0[29] = SatelliteServicing_Mission_B->INPUT_7_1_2[1];
    tmp_0[30] = SatelliteServicing_Mission_B->INPUT_7_1_2[2];
    tmp_0[31] = SatelliteServicing_Mission_B->INPUT_7_1_2[3];
    tmp_1[8] = 32;
    tmp_0[32] = SatelliteServicing_Mission_B->INPUT_7_1_3[0];
    tmp_0[33] = SatelliteServicing_Mission_B->INPUT_7_1_3[1];
    tmp_0[34] = SatelliteServicing_Mission_B->INPUT_7_1_3[2];
    tmp_0[35] = SatelliteServicing_Mission_B->INPUT_7_1_3[3];
    tmp_1[9] = 36;
    simulationData->mData->mInputValues.mN = 36;
    simulationData->mData->mInputValues.mX = &tmp_0[0];
    simulationData->mData->mInputOffsets.mN = 10;
    simulationData->mData->mInputOffsets.mX = &tmp_1[0];
    simulationData->mData->mOutputs.mN = 32;
    simulationData->mData->mOutputs.mX = &SatelliteServicing_Mission_B->STATE_1
      [0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    rtb_q_l_idx_2 = SatelliteServicing_Mission_M->Timing.t[0];
    time_0 = rtb_q_l_idx_2;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diag = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diag);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diag);
    if (i != 0) {
      tmp_2 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_2) {
        msg_0 = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
      }
    }

    // End of SimscapeExecutionBlock: '<S285>/STATE_1'

    // SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData);
    time_1 = rtb_q_l_idx_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_1;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Modes;
    tmp_2 = false;
    simulationData->mData->mFoundZcEvents = tmp_2;
    simulationData->mData->mIsMajorTimeStep = ok;
    tmp_2 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_2;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp;
    tmp_4[0] = 0;
    tmp_3[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_3[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_3[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_3[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_4[1] = 4;
    tmp_3[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_3[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_3[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_3[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_4[2] = 8;
    tmp_3[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_3[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_3[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_3[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_4[3] = 12;
    tmp_3[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_3[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_3[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_3[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_4[4] = 16;
    tmp_3[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
    tmp_3[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
    tmp_3[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
    tmp_3[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
    tmp_4[5] = 20;
    tmp_3[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
    tmp_3[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
    tmp_3[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
    tmp_3[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
    tmp_4[6] = 24;
    tmp_3[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
    tmp_3[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
    tmp_3[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
    tmp_3[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
    tmp_4[7] = 28;
    tmp_3[28] = SatelliteServicing_Mission_B->INPUT_7_1_2[0];
    tmp_3[29] = SatelliteServicing_Mission_B->INPUT_7_1_2[1];
    tmp_3[30] = SatelliteServicing_Mission_B->INPUT_7_1_2[2];
    tmp_3[31] = SatelliteServicing_Mission_B->INPUT_7_1_2[3];
    tmp_4[8] = 32;
    tmp_3[32] = SatelliteServicing_Mission_B->INPUT_7_1_3[0];
    tmp_3[33] = SatelliteServicing_Mission_B->INPUT_7_1_3[1];
    tmp_3[34] = SatelliteServicing_Mission_B->INPUT_7_1_3[2];
    tmp_3[35] = SatelliteServicing_Mission_B->INPUT_7_1_3[3];
    tmp_4[9] = 36;
    std::memcpy(&tmp_3[36], &SatelliteServicing_Mission_B->STATE_1[0], sizeof
                (real_T) << 5U);
    tmp_4[10] = 68;
    simulationData->mData->mInputValues.mN = 68;
    simulationData->mData->mInputValues.mX = &tmp_3[0];
    simulationData->mData->mInputOffsets.mN = 11;
    simulationData->mData->mInputOffsets.mX = &tmp_4[0];
    simulationData->mData->mOutputs.mN = 71;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_2 = rtb_q_l_idx_2;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_2;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diag = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr);
    diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diag);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diag);
    if (i != 0) {
      tmp_2 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_2) {
        msg_1 = rtw_diagnostics_msg(diagnosticTree_0);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
      }
    }

    // MATLAB Function: '<S243>/MATLAB Function' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[58], rtb_qout);

    // MATLAB Function: '<S243>/QuatToEuler321'
    SatelliteServici_QuatToEuler321(rtb_qout, rtb_euler);

    // MATLAB Function: '<S96>/quat2MRP' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing_Mis_quat2MRP(&rtb_OUTPUT_1_0[45], rtb_mrp_g);

    // MATLAB Function: '<S243>/QuatToDCM'
    SatelliteServicing_Mi_QuatToDCM(rtb_qout, rtb_mat_by);

    // MATLAB Function: '<S243>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(rtb_mat_by, &rtb_OUTPUT_1_0[65], rtb_mat);

    // Bias: '<S201>/Bias' incorporates:
    //   Constant: '<S4>/Constant1'
    //   PreLookup: '<S201>/Prelookup'

    rtb_Bias = plook_u32d_bincka(rtb_q_l_idx_0,
      SatelliteServicing_Mission_P.jointControlData.refTime, 4U) +
      SatelliteServicing_Mission_P.Bias_Bias;

    // Selector: '<S201>/Selector' incorporates:
    //   Bias: '<S201>/Bias'
    //   Clock: '<Root>/Clock'
    //   Constant: '<S4>/Constant1'
    //   MATLAB Function: '<S227>/formRotMat'
    //   PreLookup: '<S201>/Prelookup'

    i = static_cast<int32_T>(plook_u32d_bincka
      (SatelliteServicing_Mission_M->Timing.t[0],
       SatelliteServicing_Mission_P.jointControlData.refTime, 4U) +
      SatelliteServicing_Mission_P.Bias_Bias);
    for (i_0 = 0; i_0 < 12; i_0++) {
      rtb_Selector[i_0] =
        SatelliteServicing_Mission_P.jointControlData.eeRefTraj[(5 * i_0 + i) -
        1];
    }

    rtb_Reshape2_idx_9 =
      SatelliteServicing_Mission_P.jointControlData.eeRefTraj
      [static_cast<int32_T>(rtb_Bias) + 14];

    // MATLAB Function: '<S227>/formRotMat' incorporates:
    //   Constant: '<S4>/Constant1'
    //   Selector: '<S201>/Selector'

    rtb_Reshape2_idx_6 = std::sin(rtb_Reshape2_idx_9);
    rtb_Reshape2_idx_9 = std::cos(rtb_Reshape2_idx_9);

    // Selector: '<S201>/Selector' incorporates:
    //   Constant: '<S4>/Constant1'
    //   MATLAB Function: '<S227>/formRotMat'

    rtb_Reshape2_idx_10 =
      SatelliteServicing_Mission_P.jointControlData.eeRefTraj
      [static_cast<int32_T>(rtb_Bias) + 19];

    // MATLAB Function: '<S227>/formRotMat' incorporates:
    //   Constant: '<S4>/Constant1'
    //   Selector: '<S201>/Selector'

    rtb_Reshape2_idx_7 = std::sin(rtb_Reshape2_idx_10);
    rtb_Reshape2_idx_10 = std::cos(rtb_Reshape2_idx_10);

    // Selector: '<S201>/Selector' incorporates:
    //   Constant: '<S4>/Constant1'
    //   MATLAB Function: '<S227>/formRotMat'

    rtb_Reshape2_idx_11 =
      SatelliteServicing_Mission_P.jointControlData.eeRefTraj
      [static_cast<int32_T>(rtb_Bias) + 24];

    // MATLAB Function: '<S227>/formRotMat' incorporates:
    //   Constant: '<S4>/Constant1'
    //   Selector: '<S201>/Selector'

    rtb_Reshape2_idx_8 = std::sin(rtb_Reshape2_idx_11);
    rtb_Reshape2_idx_11 = std::cos(rtb_Reshape2_idx_11);
    rtb_mat_by[1] = 0.0;
    rtb_mat_by[4] = rtb_Reshape2_idx_9;
    rtb_mat_by[7] = -rtb_Reshape2_idx_6;
    rtb_mat_by[2] = 0.0;
    rtb_mat_by[5] = rtb_Reshape2_idx_6;
    rtb_mat_by[8] = rtb_Reshape2_idx_9;
    rtb_mat_j_tmp[0] = rtb_Reshape2_idx_10;
    rtb_mat_j_tmp[3] = 0.0;
    rtb_mat_j_tmp[6] = rtb_Reshape2_idx_7;
    rtb_mat_by[0] = 1.0;
    rtb_mat_j_tmp[1] = 0.0;
    rtb_mat_by[3] = 0.0;
    rtb_mat_j_tmp[4] = 1.0;
    rtb_mat_by[6] = 0.0;
    rtb_mat_j_tmp[7] = 0.0;
    rtb_mat_j_tmp[2] = -rtb_Reshape2_idx_7;
    rtb_mat_j_tmp[5] = 0.0;
    rtb_mat_j_tmp[8] = rtb_Reshape2_idx_10;
    rtb_mat_j_tmp_0[0] = rtb_Reshape2_idx_11;
    rtb_mat_j_tmp_0[3] = -rtb_Reshape2_idx_8;
    rtb_mat_j_tmp_0[6] = 0.0;
    rtb_mat_j_tmp_0[1] = rtb_Reshape2_idx_8;
    rtb_mat_j_tmp_0[4] = rtb_Reshape2_idx_11;
    rtb_mat_j_tmp_0[7] = 0.0;
    for (i = 0; i < 3; i++) {
      rtb_Reshape2_idx_6 = rtb_mat_j_tmp[3 * i + 1];
      rtb_Reshape2_idx_9 = rtb_mat_j_tmp[3 * i];
      rtb_Reshape2_idx_7_tmp = 3 * i + 2;
      rtb_Reshape2_idx_7 = rtb_mat_j_tmp[rtb_Reshape2_idx_7_tmp];
      for (i_0 = 0; i_0 <= 0; i_0 += 2) {
        tmp_9 = _mm_loadu_pd(&rtb_mat_by[i_0 + 3]);
        tmp_a = _mm_loadu_pd(&rtb_mat_by[i_0]);
        tmp_b = _mm_loadu_pd(&rtb_mat_by[i_0 + 6]);
        _mm_storeu_pd(&b[i_0 + 3 * i], _mm_add_pd(_mm_add_pd(_mm_mul_pd
          (_mm_set1_pd(rtb_Reshape2_idx_6), tmp_9), _mm_mul_pd(_mm_set1_pd
          (rtb_Reshape2_idx_9), tmp_a)), _mm_mul_pd(_mm_set1_pd
          (rtb_Reshape2_idx_7), tmp_b)));
      }

      for (i_0 = 2; i_0 < 3; i_0++) {
        b[i_0 + 3 * i] = (rtb_mat_by[i_0 + 3] * rtb_Reshape2_idx_6 +
                          rtb_Reshape2_idx_9 * rtb_mat_by[i_0]) + rtb_mat_by[i_0
          + 6] * rtb_Reshape2_idx_7;
      }

      rtb_mat_j_tmp_0[rtb_Reshape2_idx_7_tmp] = d[i];
    }

    for (i = 0; i < 3; i++) {
      rtb_Reshape2_idx_6 = rtb_mat_j_tmp_0[3 * i + 1];
      rtb_Reshape2_idx_9 = rtb_mat_j_tmp_0[3 * i];
      rtb_Reshape2_idx_7 = rtb_mat_j_tmp_0[3 * i + 2];
      for (i_0 = 0; i_0 <= 0; i_0 += 2) {
        tmp_9 = _mm_loadu_pd(&b[i_0 + 3]);
        tmp_a = _mm_loadu_pd(&b[i_0]);
        tmp_b = _mm_loadu_pd(&b[i_0 + 6]);
        _mm_storeu_pd(&rtb_mat_by[i_0 + 3 * i], _mm_add_pd(_mm_add_pd(_mm_mul_pd
          (_mm_set1_pd(rtb_Reshape2_idx_6), tmp_9), _mm_mul_pd(_mm_set1_pd
          (rtb_Reshape2_idx_9), tmp_a)), _mm_mul_pd(_mm_set1_pd
          (rtb_Reshape2_idx_7), tmp_b)));
      }

      for (i_0 = 2; i_0 < 3; i_0++) {
        rtb_mat_by[i_0 + 3 * i] = (b[i_0 + 3] * rtb_Reshape2_idx_6 +
          rtb_Reshape2_idx_9 * b[i_0]) + b[i_0 + 6] * rtb_Reshape2_idx_7;
      }
    }

    // MATLAB Function: '<S227>/formPoseMat'
    for (i = 0; i < 3; i++) {
      rtb_Reshape2_idx_7_tmp = i << 2;
      rtb_mat_b[rtb_Reshape2_idx_7_tmp] = rtb_mat_by[3 * i];
      rtb_mat_b[rtb_Reshape2_idx_7_tmp + 1] = rtb_mat_by[3 * i + 1];
      rtb_mat_b[rtb_Reshape2_idx_7_tmp + 2] = rtb_mat_by[3 * i + 2];
      rtb_mat_b[i + 12] = rtb_Selector[i];
    }

    rtb_mat_b[3] = 0.0;
    rtb_mat_b[7] = 0.0;
    rtb_mat_b[11] = 0.0;
    rtb_mat_b[15] = 1.0;

    // End of MATLAB Function: '<S227>/formPoseMat'

    // Product: '<S227>/Product'
    for (i = 0; i < 4; i++) {
      rtb_Reshape2_idx_7_tmp = i << 2;
      rtb_Reshape2_idx_6 = rtb_mat_b[rtb_Reshape2_idx_7_tmp + 1];
      rtb_Reshape2_idx_9 = rtb_mat_b[rtb_Reshape2_idx_7_tmp];
      rtb_Reshape2_idx_7 = rtb_mat_b[rtb_Reshape2_idx_7_tmp + 2];
      rtb_Reshape2_idx_10 = rtb_mat_b[rtb_Reshape2_idx_7_tmp + 3];
      for (i_0 = 0; i_0 <= 2; i_0 += 2) {
        tmp_9 = _mm_loadu_pd(&rtb_mat[i_0 + 4]);
        tmp_a = _mm_loadu_pd(&rtb_mat[i_0]);
        tmp_b = _mm_loadu_pd(&rtb_mat[i_0 + 8]);
        tmp_8 = _mm_loadu_pd(&rtb_mat[i_0 + 12]);
        _mm_storeu_pd(&rtb_Product[i_0 + rtb_Reshape2_idx_7_tmp], _mm_add_pd
                      (_mm_add_pd(_mm_add_pd(_mm_mul_pd(_mm_set1_pd
          (rtb_Reshape2_idx_6), tmp_9), _mm_mul_pd(_mm_set1_pd
          (rtb_Reshape2_idx_9), tmp_a)), _mm_mul_pd(_mm_set1_pd
          (rtb_Reshape2_idx_7), tmp_b)), _mm_mul_pd(_mm_set1_pd
          (rtb_Reshape2_idx_10), tmp_8)));
      }
    }

    // End of Product: '<S227>/Product'

    // Sum: '<S227>/Sum1' incorporates:
    //   Product: '<S227>/Product1'

    rtb_Reshape2_idx_6 = rtb_Selector[7];
    rtb_Reshape2_idx_9 = rtb_Selector[6];
    rtb_Reshape2_idx_7 = rtb_Selector[8];
    for (i = 0; i <= 0; i += 2) {
      // Sum: '<S227>/Sum1' incorporates:
      //   Product: '<S227>/Product1'
      //   Sum: '<S212>/Sum1'

      tmp_9 = _mm_loadu_pd(&rtb_mat_by[i + 3]);
      tmp_a = _mm_loadu_pd(&rtb_mat_by[i]);
      tmp_b = _mm_loadu_pd(&rtb_mat_by[i + 6]);
      tmp_8 = _mm_loadu_pd(&rtb_OUTPUT_1_0[i + 68]);
      _mm_storeu_pd(&rtb_controlErrorECEF_l[i], _mm_sub_pd(tmp_8, _mm_add_pd
        (_mm_add_pd(_mm_mul_pd(tmp_9, _mm_set1_pd(rtb_Reshape2_idx_6)),
                    _mm_mul_pd(tmp_a, _mm_set1_pd(rtb_Reshape2_idx_9))),
         _mm_mul_pd(tmp_b, _mm_set1_pd(rtb_Reshape2_idx_7)))));
    }

    // Sum: '<S227>/Sum1' incorporates:
    //   Product: '<S227>/Product1'
    //   Sum: '<S212>/Sum1'

    for (i = 2; i < 3; i++) {
      rtb_controlErrorECEF_l[i] = rtb_OUTPUT_1_0[i + 68] - ((rtb_mat_by[i + 3] *
        rtb_Reshape2_idx_6 + rtb_mat_by[i] * rtb_Reshape2_idx_9) + rtb_mat_by[i
        + 6] * rtb_Reshape2_idx_7);
    }

    // Sum: '<S227>/Sum2' incorporates:
    //   Product: '<S227>/Product2'

    rtb_Reshape2_idx_6 = rtb_Selector[10];
    rtb_Reshape2_idx_9 = rtb_Selector[9];
    rtb_Reshape2_idx_7 = rtb_Selector[11];
    for (i = 0; i <= 0; i += 2) {
      // Sum: '<S227>/Sum2' incorporates:
      //   Product: '<S227>/Product2'
      //   Sum: '<S211>/Sum1'

      tmp_9 = _mm_loadu_pd(&rtb_mat_by[i + 3]);
      tmp_a = _mm_loadu_pd(&rtb_mat_by[i]);
      tmp_b = _mm_loadu_pd(&rtb_mat_by[i + 6]);
      tmp_8 = _mm_loadu_pd(&rtb_OUTPUT_1_0[i + 62]);

      // Sum: '<S211>/Sum1' incorporates:
      //   Product: '<S227>/Product2'
      //   Sum: '<S227>/Sum2'

      _mm_storeu_pd(&rtb_Sum1_i[i], _mm_sub_pd(tmp_8, _mm_add_pd(_mm_add_pd
        (_mm_mul_pd(tmp_9, _mm_set1_pd(rtb_Reshape2_idx_6)), _mm_mul_pd(tmp_a,
        _mm_set1_pd(rtb_Reshape2_idx_9))), _mm_mul_pd(tmp_b, _mm_set1_pd
        (rtb_Reshape2_idx_7)))));
    }

    for (i = 2; i < 3; i++) {
      // Sum: '<S211>/Sum1' incorporates:
      //   Product: '<S227>/Product2'
      //   Sum: '<S227>/Sum2'

      rtb_Sum1_i[i] = rtb_OUTPUT_1_0[i + 62] - ((rtb_mat_by[i + 3] *
        rtb_Reshape2_idx_6 + rtb_mat_by[i] * rtb_Reshape2_idx_9) + rtb_mat_by[i
        + 6] * rtb_Reshape2_idx_7);
    }

    // Reshape: '<S227>/Reshape2'
    rtb_Reshape2_idx_6 = rtb_controlErrorECEF_l[0];
    rtb_Reshape2_idx_9 = rtb_Sum1_i[0];
    rtb_Reshape2_idx_7 = rtb_controlErrorECEF_l[1];
    rtb_Reshape2_idx_10 = rtb_Sum1_i[1];
    rtb_Reshape2_idx_8 = rtb_controlErrorECEF_l[2];
    rtb_Reshape2_idx_11 = rtb_Sum1_i[2];

    // Sum: '<S211>/Sum1' incorporates:
    //   MATLAB Function: '<S200>/Check_Angle_Limits'
    //   SignalConversion generated from: '<S204>/ SFunction '

    rtb_Sum1_i[0] = rtb_OUTPUT_1_0[0];
    rtb_Sum1_i[1] = rtb_OUTPUT_1_0[2];
    rtb_Sum1_i[2] = rtb_OUTPUT_1_0[4];

    // MATLAB Function: '<S200>/Check_Angle_Limits' incorporates:
    //   Constant: '<S4>/Constant1'
    //   SignalConversion generated from: '<S4>/Bus Assignment'

    if (rtb_Sum1_i[0] < 0.0) {
      if (rtb_Sum1_i[0] /
          SatelliteServicing_Mission_P.jointControlData.angleLimit[0] > 0.95) {
        if (SatelliteServicing_Mission_U->ManipulatorActions[0] < 0.0) {
          rtb_controlErrorECEF_l[0] = 0.0;
        } else {
          rtb_controlErrorECEF_l[0] =
            SatelliteServicing_Mission_U->ManipulatorActions[0];
        }
      } else {
        rtb_controlErrorECEF_l[0] =
          SatelliteServicing_Mission_U->ManipulatorActions[0];
      }
    } else if (rtb_Sum1_i[0] /
               SatelliteServicing_Mission_P.jointControlData.angleLimit[3] >
               0.95) {
      if (SatelliteServicing_Mission_U->ManipulatorActions[0] > 0.0) {
        rtb_controlErrorECEF_l[0] = 0.0;
      } else {
        rtb_controlErrorECEF_l[0] =
          SatelliteServicing_Mission_U->ManipulatorActions[0];
      }
    } else {
      rtb_controlErrorECEF_l[0] =
        SatelliteServicing_Mission_U->ManipulatorActions[0];
    }

    if (rtb_Sum1_i[1] < 0.0) {
      if (rtb_Sum1_i[1] /
          SatelliteServicing_Mission_P.jointControlData.angleLimit[1] > 0.95) {
        if (SatelliteServicing_Mission_U->ManipulatorActions[1] < 0.0) {
          rtb_controlErrorECEF_l[1] = 0.0;
        } else {
          rtb_controlErrorECEF_l[1] =
            SatelliteServicing_Mission_U->ManipulatorActions[1];
        }
      } else {
        rtb_controlErrorECEF_l[1] =
          SatelliteServicing_Mission_U->ManipulatorActions[1];
      }
    } else if (rtb_Sum1_i[1] /
               SatelliteServicing_Mission_P.jointControlData.angleLimit[4] >
               0.95) {
      if (SatelliteServicing_Mission_U->ManipulatorActions[1] > 0.0) {
        rtb_controlErrorECEF_l[1] = 0.0;
      } else {
        rtb_controlErrorECEF_l[1] =
          SatelliteServicing_Mission_U->ManipulatorActions[1];
      }
    } else {
      rtb_controlErrorECEF_l[1] =
        SatelliteServicing_Mission_U->ManipulatorActions[1];
    }

    if (rtb_Sum1_i[2] < 0.0) {
      if (rtb_Sum1_i[2] /
          SatelliteServicing_Mission_P.jointControlData.angleLimit[2] > 0.95) {
        if (SatelliteServicing_Mission_U->ManipulatorActions[2] < 0.0) {
          rtb_controlErrorECEF_l[2] = 0.0;
        } else {
          rtb_controlErrorECEF_l[2] =
            SatelliteServicing_Mission_U->ManipulatorActions[2];
        }
      } else {
        rtb_controlErrorECEF_l[2] =
          SatelliteServicing_Mission_U->ManipulatorActions[2];
      }
    } else if (rtb_Sum1_i[2] /
               SatelliteServicing_Mission_P.jointControlData.angleLimit[5] >
               0.95) {
      if (SatelliteServicing_Mission_U->ManipulatorActions[2] > 0.0) {
        rtb_controlErrorECEF_l[2] = 0.0;
      } else {
        rtb_controlErrorECEF_l[2] =
          SatelliteServicing_Mission_U->ManipulatorActions[2];
      }
    } else {
      rtb_controlErrorECEF_l[2] =
        SatelliteServicing_Mission_U->ManipulatorActions[2];
    }

    // Sum: '<S211>/Sum1' incorporates:
    //   MATLAB Function: '<S200>/Check_Rate_Limits'
    //   SignalConversion generated from: '<S205>/ SFunction '

    rtb_Sum1_i[0] = rtb_OUTPUT_1_0[1];
    rtb_Sum1_i[1] = rtb_OUTPUT_1_0[3];
    rtb_Sum1_i[2] = rtb_OUTPUT_1_0[5];

    // MATLAB Function: '<S200>/Check_Rate_Limits' incorporates:
    //   Constant: '<S4>/Constant1'
    //   SignalConversion generated from: '<S4>/Bus Assignment'

    if (rtb_Sum1_i[0] < 0.0) {
      if (std::abs(rtb_Sum1_i[0]) >=
          SatelliteServicing_Mission_P.jointControlData.rateLimit[0]) {
        if (rtb_controlErrorECEF_l[0] < 0.0) {
          SatelliteServicing_Mission_B->joint_torque_out[0] = 0.0;
        } else {
          SatelliteServicing_Mission_B->joint_torque_out[0] =
            rtb_controlErrorECEF_l[0];
        }
      } else {
        SatelliteServicing_Mission_B->joint_torque_out[0] =
          rtb_controlErrorECEF_l[0];
      }
    } else if (rtb_Sum1_i[0] >=
               SatelliteServicing_Mission_P.jointControlData.rateLimit[0]) {
      if (rtb_controlErrorECEF_l[0] > 0.0) {
        SatelliteServicing_Mission_B->joint_torque_out[0] = 0.0;
      } else {
        SatelliteServicing_Mission_B->joint_torque_out[0] =
          rtb_controlErrorECEF_l[0];
      }
    } else {
      SatelliteServicing_Mission_B->joint_torque_out[0] =
        rtb_controlErrorECEF_l[0];
    }

    if (rtb_Sum1_i[1] < 0.0) {
      if (std::abs(rtb_Sum1_i[1]) >=
          SatelliteServicing_Mission_P.jointControlData.rateLimit[1]) {
        if (rtb_controlErrorECEF_l[1] < 0.0) {
          SatelliteServicing_Mission_B->joint_torque_out[1] = 0.0;
        } else {
          SatelliteServicing_Mission_B->joint_torque_out[1] =
            rtb_controlErrorECEF_l[1];
        }
      } else {
        SatelliteServicing_Mission_B->joint_torque_out[1] =
          rtb_controlErrorECEF_l[1];
      }
    } else if (rtb_Sum1_i[1] >=
               SatelliteServicing_Mission_P.jointControlData.rateLimit[1]) {
      if (rtb_controlErrorECEF_l[1] > 0.0) {
        SatelliteServicing_Mission_B->joint_torque_out[1] = 0.0;
      } else {
        SatelliteServicing_Mission_B->joint_torque_out[1] =
          rtb_controlErrorECEF_l[1];
      }
    } else {
      SatelliteServicing_Mission_B->joint_torque_out[1] =
        rtb_controlErrorECEF_l[1];
    }

    if (rtb_Sum1_i[2] < 0.0) {
      if (std::abs(rtb_Sum1_i[2]) >=
          SatelliteServicing_Mission_P.jointControlData.rateLimit[2]) {
        if (rtb_controlErrorECEF_l[2] < 0.0) {
          SatelliteServicing_Mission_B->joint_torque_out[2] = 0.0;
        } else {
          SatelliteServicing_Mission_B->joint_torque_out[2] =
            rtb_controlErrorECEF_l[2];
        }
      } else {
        SatelliteServicing_Mission_B->joint_torque_out[2] =
          rtb_controlErrorECEF_l[2];
      }
    } else if (rtb_Sum1_i[2] >=
               SatelliteServicing_Mission_P.jointControlData.rateLimit[2]) {
      if (rtb_controlErrorECEF_l[2] > 0.0) {
        SatelliteServicing_Mission_B->joint_torque_out[2] = 0.0;
      } else {
        SatelliteServicing_Mission_B->joint_torque_out[2] =
          rtb_controlErrorECEF_l[2];
      }
    } else {
      SatelliteServicing_Mission_B->joint_torque_out[2] =
        rtb_controlErrorECEF_l[2];
    }

    // Outport: '<Root>/Observations'
    SatelliteServicing_Mission_Y->Observations[0] = rtb_OUTPUT_1_0[65];
    SatelliteServicing_Mission_Y->Observations[1] = rtb_OUTPUT_1_0[66];
    SatelliteServicing_Mission_Y->Observations[2] = rtb_OUTPUT_1_0[67];
    SatelliteServicing_Mission_Y->Observations[3] = rtb_euler[0];
    SatelliteServicing_Mission_Y->Observations[4] = rtb_euler[1];
    SatelliteServicing_Mission_Y->Observations[5] = rtb_euler[2];
    SatelliteServicing_Mission_Y->Observations[6] = rtb_OUTPUT_1_0[68];
    SatelliteServicing_Mission_Y->Observations[7] = rtb_OUTPUT_1_0[69];
    SatelliteServicing_Mission_Y->Observations[8] = rtb_OUTPUT_1_0[70];
    SatelliteServicing_Mission_Y->Observations[9] = rtb_OUTPUT_1_0[62];
    SatelliteServicing_Mission_Y->Observations[10] = rtb_OUTPUT_1_0[63];
    SatelliteServicing_Mission_Y->Observations[11] = rtb_OUTPUT_1_0[64];
    SatelliteServicing_Mission_Y->Observations[12] = rtb_OUTPUT_1_0[52];
    SatelliteServicing_Mission_Y->Observations[13] = rtb_OUTPUT_1_0[53];
    SatelliteServicing_Mission_Y->Observations[14] = rtb_OUTPUT_1_0[54];
    SatelliteServicing_Mission_Y->Observations[15] = rtb_mrp_g[0];
    SatelliteServicing_Mission_Y->Observations[16] = rtb_mrp_g[1];
    SatelliteServicing_Mission_Y->Observations[17] = rtb_mrp_g[2];
    SatelliteServicing_Mission_Y->Observations[18] = rtb_OUTPUT_1_0[55];
    SatelliteServicing_Mission_Y->Observations[19] = rtb_OUTPUT_1_0[56];
    SatelliteServicing_Mission_Y->Observations[20] = rtb_OUTPUT_1_0[57];
    SatelliteServicing_Mission_Y->Observations[21] = rtb_OUTPUT_1_0[49];
    SatelliteServicing_Mission_Y->Observations[22] = rtb_OUTPUT_1_0[50];
    SatelliteServicing_Mission_Y->Observations[23] = rtb_OUTPUT_1_0[51];
    SatelliteServicing_Mission_Y->Observations[24] = rtb_OUTPUT_1_0[0];
    SatelliteServicing_Mission_Y->Observations[25] = rtb_OUTPUT_1_0[2];
    SatelliteServicing_Mission_Y->Observations[26] = rtb_OUTPUT_1_0[4];
    SatelliteServicing_Mission_Y->Observations[27] = rtb_OUTPUT_1_0[1];
    SatelliteServicing_Mission_Y->Observations[28] = rtb_OUTPUT_1_0[3];
    SatelliteServicing_Mission_Y->Observations[29] = rtb_OUTPUT_1_0[5];
    SatelliteServicing_Mission_Y->Observations[30] =
      SatelliteServicing_Mission_B->joint_torque_out[0];
    SatelliteServicing_Mission_Y->Observations[31] =
      SatelliteServicing_Mission_B->joint_torque_out[1];
    SatelliteServicing_Mission_Y->Observations[32] =
      SatelliteServicing_Mission_B->joint_torque_out[2];

    // SimscapeInputBlock: '<S285>/INPUT_1_1_1'
    if (SatelliteServicing_Mission_DW->INPUT_1_1_1_FirstOutput == 0.0) {
      SatelliteServicing_Mission_DW->INPUT_1_1_1_FirstOutput = 1.0;
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[0] =
        SatelliteServicing_Mission_B->joint_torque_out[0];
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[1] = 0.0;
    }

    SatelliteServicing_Mission_B->INPUT_1_1_1[0] =
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[0];
    SatelliteServicing_Mission_B->INPUT_1_1_1[1] =
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[1];
    SatelliteServicing_Mission_B->INPUT_1_1_1[2] =
      ((SatelliteServicing_Mission_B->joint_torque_out[0] -
        SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[0]) *
       1000.0 - 2.0 *
       SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[1]) *
      1000.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1[3] = 0.0;

    // End of SimscapeInputBlock: '<S285>/INPUT_1_1_1'

    // SimscapeInputBlock: '<S285>/INPUT_2_1_1'
    if (SatelliteServicing_Mission_DW->INPUT_2_1_1_FirstOutput == 0.0) {
      SatelliteServicing_Mission_DW->INPUT_2_1_1_FirstOutput = 1.0;
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[0] =
        SatelliteServicing_Mission_B->joint_torque_out[1];
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[1] = 0.0;
    }

    SatelliteServicing_Mission_B->INPUT_2_1_1[0] =
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[0];
    SatelliteServicing_Mission_B->INPUT_2_1_1[1] =
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[1];
    SatelliteServicing_Mission_B->INPUT_2_1_1[2] =
      ((SatelliteServicing_Mission_B->joint_torque_out[1] -
        SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[0]) *
       1000.0 - 2.0 *
       SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[1]) *
      1000.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1[3] = 0.0;

    // End of SimscapeInputBlock: '<S285>/INPUT_2_1_1'

    // SimscapeInputBlock: '<S285>/INPUT_3_1_1'
    if (SatelliteServicing_Mission_DW->INPUT_3_1_1_FirstOutput == 0.0) {
      SatelliteServicing_Mission_DW->INPUT_3_1_1_FirstOutput = 1.0;
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[0] =
        SatelliteServicing_Mission_B->joint_torque_out[2];
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[1] = 0.0;
    }

    SatelliteServicing_Mission_B->INPUT_3_1_1[0] =
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[0];
    SatelliteServicing_Mission_B->INPUT_3_1_1[1] =
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[1];
    SatelliteServicing_Mission_B->INPUT_3_1_1[2] =
      ((SatelliteServicing_Mission_B->joint_torque_out[2] -
        SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[0]) *
       1000.0 - 2.0 *
       SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[1]) *
      1000.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1[3] = 0.0;

    // End of SimscapeInputBlock: '<S285>/INPUT_3_1_1'
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // Product: '<S226>/Product5' incorporates:
      //   Constant: '<S200>/Constant1'
      //   DiscreteIntegrator: '<S226>/Discrete-Time Integrator1'

      SatelliteServicing_Mission_B->Product5[0] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[0] *
        SatelliteServicing_Mission_P.satControlData_Trans.Ki[0];
      SatelliteServicing_Mission_B->Product5[1] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[1] *
        SatelliteServicing_Mission_P.satControlData_Trans.Ki[1];
      SatelliteServicing_Mission_B->Product5[2] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[2] *
        SatelliteServicing_Mission_P.satControlData_Trans.Ki[2];
    }

    for (i = 0; i <= 4; i += 2) {
      // Sum: '<S202>/Add'
      tmp_9 = _mm_loadu_pd(&rtb_OUTPUT_1_0[i + 26]);
      tmp_a = _mm_loadu_pd(&rtb_OUTPUT_1_0[i + 65]);
      _mm_storeu_pd(&rtb_mat_by[i], _mm_sub_pd(tmp_9, tmp_a));
    }

    // Sum: '<S226>/Sum1' incorporates:
    //   Constant: '<S200>/Constant1'

    SatelliteServicing_Mission_B->controlErrorECEF[0] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdPos[0] - rtb_mat_by[0];
    SatelliteServicing_Mission_B->controlErrorECEF[3] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdVel[0] - rtb_mat_by[3];

    // Gain: '<S226>/Gain1' incorporates:
    //   Constant: '<S200>/Constant1'
    //   Product: '<S226>/Product3'
    //   Product: '<S226>/Product4'
    //   Product: '<S226>/Product5'
    //   Sum: '<S226>/Add1'

    rtb_q_l_idx_3 = ((SatelliteServicing_Mission_B->controlErrorECEF[0] *
                      SatelliteServicing_Mission_P.satControlData_Trans.Kp[0] +
                      SatelliteServicing_Mission_B->Product5[0]) +
                     SatelliteServicing_Mission_P.satControlData_Trans.Kd[0] *
                     SatelliteServicing_Mission_B->controlErrorECEF[3]) *
      SatelliteServicing_Mission_P.Gain1_Gain;

    // Sum: '<S226>/Sum1' incorporates:
    //   Constant: '<S200>/Constant1'

    SatelliteServicing_Mission_B->controlErrorECEF[1] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdPos[1] - rtb_mat_by[1];
    SatelliteServicing_Mission_B->controlErrorECEF[4] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdVel[1] - rtb_mat_by[4];

    // Gain: '<S226>/Gain1' incorporates:
    //   Constant: '<S200>/Constant1'
    //   Product: '<S226>/Product3'
    //   Product: '<S226>/Product4'
    //   Product: '<S226>/Product5'
    //   Sum: '<S226>/Add1'

    rtb_q_l_idx_1 = ((SatelliteServicing_Mission_B->controlErrorECEF[1] *
                      SatelliteServicing_Mission_P.satControlData_Trans.Kp[1] +
                      SatelliteServicing_Mission_B->Product5[1]) +
                     SatelliteServicing_Mission_P.satControlData_Trans.Kd[1] *
                     SatelliteServicing_Mission_B->controlErrorECEF[4]) *
      SatelliteServicing_Mission_P.Gain1_Gain;

    // Sum: '<S226>/Sum1' incorporates:
    //   Constant: '<S200>/Constant1'

    SatelliteServicing_Mission_B->controlErrorECEF[2] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdPos[2] - rtb_mat_by[2];
    SatelliteServicing_Mission_B->controlErrorECEF[5] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdVel[2] - rtb_mat_by[5];

    // Gain: '<S226>/Gain1' incorporates:
    //   Constant: '<S200>/Constant1'
    //   Product: '<S226>/Product3'
    //   Product: '<S226>/Product4'
    //   Product: '<S226>/Product5'
    //   Sum: '<S226>/Add1'

    u0 = ((SatelliteServicing_Mission_B->controlErrorECEF[2] *
           SatelliteServicing_Mission_P.satControlData_Trans.Kp[2] +
           SatelliteServicing_Mission_B->Product5[2]) +
          SatelliteServicing_Mission_P.satControlData_Trans.Kd[2] *
          SatelliteServicing_Mission_B->controlErrorECEF[5]) *
      SatelliteServicing_Mission_P.Gain1_Gain;

    // Saturate: '<S207>/Saturation1'
    if (rtb_q_l_idx_1 >
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_4_1_1'
      SatelliteServicing_Mission_B->INPUT_4_1_1[0] =
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else if (rtb_q_l_idx_1 <
               -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_4_1_1'
      SatelliteServicing_Mission_B->INPUT_4_1_1[0] =
        -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else {
      // SimscapeInputBlock: '<S285>/INPUT_4_1_1'
      SatelliteServicing_Mission_B->INPUT_4_1_1[0] = rtb_q_l_idx_1;
    }

    // SimscapeInputBlock: '<S285>/INPUT_4_1_1'
    SatelliteServicing_Mission_B->INPUT_4_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_1[3] = 0.0;

    // Saturate: '<S207>/Saturation1'
    if (rtb_q_l_idx_3 >
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_5_1_1'
      SatelliteServicing_Mission_B->INPUT_5_1_1[0] =
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else if (rtb_q_l_idx_3 <
               -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_5_1_1'
      SatelliteServicing_Mission_B->INPUT_5_1_1[0] =
        -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else {
      // SimscapeInputBlock: '<S285>/INPUT_5_1_1'
      SatelliteServicing_Mission_B->INPUT_5_1_1[0] = rtb_q_l_idx_3;
    }

    // SimscapeInputBlock: '<S285>/INPUT_5_1_1'
    SatelliteServicing_Mission_B->INPUT_5_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_5_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_5_1_1[3] = 0.0;

    // Saturate: '<S207>/Saturation1'
    if (u0 > SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_6_1_1'
      SatelliteServicing_Mission_B->INPUT_6_1_1[0] =
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else if (u0 <
               -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_6_1_1'
      SatelliteServicing_Mission_B->INPUT_6_1_1[0] =
        -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else {
      // SimscapeInputBlock: '<S285>/INPUT_6_1_1'
      SatelliteServicing_Mission_B->INPUT_6_1_1[0] = u0;
    }

    // SimscapeInputBlock: '<S285>/INPUT_6_1_1'
    SatelliteServicing_Mission_B->INPUT_6_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_6_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_6_1_1[3] = 0.0;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // Product: '<S225>/Product5' incorporates:
      //   Constant: '<S200>/Constant2'
      //   DiscreteIntegrator: '<S225>/Discrete-Time Integrator1'

      SatelliteServicing_Mission_B->Product5_j[0] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[0] *
        SatelliteServicing_Mission_P.satControlData_Rot.Ki[0];
      SatelliteServicing_Mission_B->Product5_j[1] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[1] *
        SatelliteServicing_Mission_P.satControlData_Rot.Ki[1];
      SatelliteServicing_Mission_B->Product5_j[2] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[2] *
        SatelliteServicing_Mission_P.satControlData_Rot.Ki[2];
    }

    // MATLAB Function: '<S8>/MATLAB Function' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[19], rtb_qout);

    // MATLAB Function: '<S8>/QuatToEuler321'
    SatelliteServici_QuatToEuler321(rtb_qout, rtb_euler_c);

    // Sum: '<S202>/Add1'
    rtb_mat_by[0] = rtb_euler_c[0] - rtb_euler[0];
    rtb_mat_by[1] = rtb_euler_c[1] - rtb_euler[1];
    rtb_mat_by[2] = rtb_euler_c[2] - rtb_euler[2];
    rtb_mat_by[3] = rtb_OUTPUT_1_0[23] - rtb_OUTPUT_1_0[62];
    rtb_mat_by[4] = rtb_OUTPUT_1_0[24] - rtb_OUTPUT_1_0[63];
    rtb_mat_by[5] = rtb_OUTPUT_1_0[25] - rtb_OUTPUT_1_0[64];

    // Sum: '<S225>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'

    rtb_q_l_idx_3 = SatelliteServicing_Mission_P.satControlData_Rot.cmdAngle[0]
      - rtb_mat_by[0];
    SatelliteServicing_Mission_B->controlErrorECEF_n[0] = rtb_q_l_idx_3;
    rtb_q_l_idx_1 = SatelliteServicing_Mission_P.satControlData_Rot.cmdRate[0] -
      rtb_mat_by[3];
    SatelliteServicing_Mission_B->controlErrorECEF_n[3] = rtb_q_l_idx_1;

    // Sum: '<S213>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'
    //   Product: '<S225>/Product4'

    rtb_q_l_idx_1 *= SatelliteServicing_Mission_P.satControlData_Rot.Kd[0];
    rtb_mrp_g[0] = rtb_q_l_idx_1;

    // Sum: '<S211>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'
    //   Gain: '<S225>/Gain1'
    //   Product: '<S225>/Product3'
    //   Product: '<S225>/Product5'
    //   Sum: '<S213>/Sum1'
    //   Sum: '<S225>/Add1'

    rtb_q_l_idx_3 = ((rtb_q_l_idx_3 *
                      SatelliteServicing_Mission_P.satControlData_Rot.Kp[0] +
                      SatelliteServicing_Mission_B->Product5_j[0]) +
                     rtb_q_l_idx_1) * SatelliteServicing_Mission_P.Gain1_Gain_l;

    // Saturate: '<S206>/Saturation1' incorporates:
    //   Sum: '<S211>/Sum1'

    if (rtb_q_l_idx_3 >
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_7_1_1' incorporates:
      //   Saturate: '<S206>/Saturation1'

      SatelliteServicing_Mission_B->INPUT_7_1_1[0] =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;

      // Saturate: '<S206>/Saturation1'
      rtb_Sum1_i[0] =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else if (rtb_q_l_idx_3 <
               -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_7_1_1' incorporates:
      //   Saturate: '<S206>/Saturation1'

      SatelliteServicing_Mission_B->INPUT_7_1_1[0] =
        -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;

      // Saturate: '<S206>/Saturation1'
      rtb_Sum1_i[0] =
        -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else {
      // SimscapeInputBlock: '<S285>/INPUT_7_1_1' incorporates:
      //   Saturate: '<S206>/Saturation1'

      SatelliteServicing_Mission_B->INPUT_7_1_1[0] = rtb_q_l_idx_3;

      // Saturate: '<S206>/Saturation1'
      rtb_Sum1_i[0] = rtb_q_l_idx_3;
    }

    // Sum: '<S225>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'

    rtb_q_l_idx_3 = SatelliteServicing_Mission_P.satControlData_Rot.cmdAngle[1]
      - rtb_mat_by[1];
    SatelliteServicing_Mission_B->controlErrorECEF_n[1] = rtb_q_l_idx_3;
    rtb_q_l_idx_1 = SatelliteServicing_Mission_P.satControlData_Rot.cmdRate[1] -
      rtb_mat_by[4];
    SatelliteServicing_Mission_B->controlErrorECEF_n[4] = rtb_q_l_idx_1;

    // Sum: '<S213>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'
    //   Product: '<S225>/Product4'

    rtb_q_l_idx_1 *= SatelliteServicing_Mission_P.satControlData_Rot.Kd[1];
    rtb_mrp_g[1] = rtb_q_l_idx_1;

    // Sum: '<S211>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'
    //   Gain: '<S225>/Gain1'
    //   Product: '<S225>/Product3'
    //   Product: '<S225>/Product5'
    //   Sum: '<S213>/Sum1'
    //   Sum: '<S225>/Add1'

    rtb_q_l_idx_3 = ((rtb_q_l_idx_3 *
                      SatelliteServicing_Mission_P.satControlData_Rot.Kp[1] +
                      SatelliteServicing_Mission_B->Product5_j[1]) +
                     rtb_q_l_idx_1) * SatelliteServicing_Mission_P.Gain1_Gain_l;

    // Saturate: '<S206>/Saturation1' incorporates:
    //   Sum: '<S211>/Sum1'

    if (rtb_q_l_idx_3 >
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_7_1_2' incorporates:
      //   Saturate: '<S206>/Saturation1'

      SatelliteServicing_Mission_B->INPUT_7_1_2[0] =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;

      // Saturate: '<S206>/Saturation1'
      rtb_Sum1_i[1] =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else if (rtb_q_l_idx_3 <
               -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // SimscapeInputBlock: '<S285>/INPUT_7_1_2' incorporates:
      //   Saturate: '<S206>/Saturation1'

      SatelliteServicing_Mission_B->INPUT_7_1_2[0] =
        -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;

      // Saturate: '<S206>/Saturation1'
      rtb_Sum1_i[1] =
        -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else {
      // SimscapeInputBlock: '<S285>/INPUT_7_1_2' incorporates:
      //   Saturate: '<S206>/Saturation1'

      SatelliteServicing_Mission_B->INPUT_7_1_2[0] = rtb_q_l_idx_3;

      // Saturate: '<S206>/Saturation1'
      rtb_Sum1_i[1] = rtb_q_l_idx_3;
    }

    // Sum: '<S225>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'

    rtb_q_l_idx_3 = SatelliteServicing_Mission_P.satControlData_Rot.cmdAngle[2]
      - rtb_mat_by[2];
    SatelliteServicing_Mission_B->controlErrorECEF_n[2] = rtb_q_l_idx_3;
    rtb_q_l_idx_1 = SatelliteServicing_Mission_P.satControlData_Rot.cmdRate[2] -
      rtb_mat_by[5];
    SatelliteServicing_Mission_B->controlErrorECEF_n[5] = rtb_q_l_idx_1;

    // Sum: '<S213>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'
    //   Product: '<S225>/Product4'

    rtb_q_l_idx_1 *= SatelliteServicing_Mission_P.satControlData_Rot.Kd[2];
    rtb_mrp_g[2] = rtb_q_l_idx_1;

    // Sum: '<S211>/Sum1' incorporates:
    //   Constant: '<S200>/Constant2'
    //   Gain: '<S225>/Gain1'
    //   Product: '<S225>/Product3'
    //   Product: '<S225>/Product5'
    //   Sum: '<S213>/Sum1'
    //   Sum: '<S225>/Add1'

    rtb_q_l_idx_3 = ((rtb_q_l_idx_3 *
                      SatelliteServicing_Mission_P.satControlData_Rot.Kp[2] +
                      SatelliteServicing_Mission_B->Product5_j[2]) +
                     rtb_q_l_idx_1) * SatelliteServicing_Mission_P.Gain1_Gain_l;

    // Saturate: '<S206>/Saturation1' incorporates:
    //   Sum: '<S211>/Sum1'

    if (rtb_q_l_idx_3 >
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // Saturate: '<S206>/Saturation1'
      rtb_q_l_idx_3 =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else if (rtb_q_l_idx_3 <
               -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // Saturate: '<S206>/Saturation1'
      rtb_q_l_idx_3 =
        -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    }

    // Saturate: '<S206>/Saturation1' incorporates:
    //   Sum: '<S211>/Sum1'

    rtb_Sum1_i[2] = rtb_q_l_idx_3;

    // SimscapeInputBlock: '<S285>/INPUT_7_1_1'
    SatelliteServicing_Mission_B->INPUT_7_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_7_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_7_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S285>/INPUT_7_1_2'
    SatelliteServicing_Mission_B->INPUT_7_1_2[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_7_1_2[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_7_1_2[3] = 0.0;

    // SimscapeInputBlock: '<S285>/INPUT_7_1_3' incorporates:
    //   Saturate: '<S206>/Saturation1'

    SatelliteServicing_Mission_B->INPUT_7_1_3[0] = rtb_q_l_idx_3;
    SatelliteServicing_Mission_B->INPUT_7_1_3[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_7_1_3[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_7_1_3[3] = 0.0;

    // SimscapeExecutionBlock: '<S285>/OUTPUT_1_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData);
    time_3 = rtb_q_l_idx_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_3;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Modes;
    tmp_2 = false;
    simulationData->mData->mFoundZcEvents = tmp_2;
    simulationData->mData->mIsMajorTimeStep = ok;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp;
    tmp_6[0] = 0;
    tmp_5[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_5[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_5[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_5[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_6[1] = 4;
    tmp_5[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_5[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_5[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_5[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_6[2] = 8;
    tmp_5[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_5[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_5[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_5[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_6[3] = 12;
    tmp_5[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_5[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_5[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_5[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_6[4] = 16;
    tmp_5[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
    tmp_5[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
    tmp_5[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
    tmp_5[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
    tmp_6[5] = 20;
    tmp_5[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
    tmp_5[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
    tmp_5[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
    tmp_5[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
    tmp_6[6] = 24;
    tmp_5[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
    tmp_5[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
    tmp_5[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
    tmp_5[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
    tmp_6[7] = 28;
    tmp_5[28] = SatelliteServicing_Mission_B->INPUT_7_1_2[0];
    tmp_5[29] = SatelliteServicing_Mission_B->INPUT_7_1_2[1];
    tmp_5[30] = SatelliteServicing_Mission_B->INPUT_7_1_2[2];
    tmp_5[31] = SatelliteServicing_Mission_B->INPUT_7_1_2[3];
    tmp_6[8] = 32;
    tmp_5[32] = SatelliteServicing_Mission_B->INPUT_7_1_3[0];
    tmp_5[33] = SatelliteServicing_Mission_B->INPUT_7_1_3[1];
    tmp_5[34] = SatelliteServicing_Mission_B->INPUT_7_1_3[2];
    tmp_5[35] = SatelliteServicing_Mission_B->INPUT_7_1_3[3];
    tmp_6[9] = 36;
    std::memcpy(&tmp_5[36], &SatelliteServicing_Mission_B->STATE_1[0], sizeof
                (real_T) << 5U);
    tmp_6[10] = 68;
    simulationData->mData->mInputValues.mN = 68;
    simulationData->mData->mInputValues.mX = &tmp_5[0];
    simulationData->mData->mInputOffsets.mN = 11;
    simulationData->mData->mInputOffsets.mX = &tmp_6[0];
    simulationData->mData->mOutputs.mN = 42;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_1[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_4 = rtb_q_l_idx_2;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_4;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diag = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr);
    diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diag);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diag);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_2 = rtw_diagnostics_msg(diagnosticTree_1);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_2);
      }
    }

    // MATLAB Function: '<S7>/MATLAB Function' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[6], rtb_qout_n);

    // MATLAB Function: '<S7>/QuatToDCM'
    SatelliteServicing_Mi_QuatToDCM(rtb_qout_n, rtb_mat_by);

    // MATLAB Function: '<S7>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(rtb_mat_by, &rtb_OUTPUT_1_0[13], rtb_mat);

    // MATLAB Function: '<S8>/QuatToDCM'
    SatelliteServicing_Mi_QuatToDCM(rtb_qout, rtb_mat_by);

    // MATLAB Function: '<S8>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(rtb_mat_by, &rtb_OUTPUT_1_0[26], rtb_mat);

    // MATLAB Function: '<S96>/MATLAB Function' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[45], rtb_qout_gi);

    // MATLAB Function: '<S96>/QuatToDCM'
    SatelliteServicing_Mi_QuatToDCM(rtb_qout_gi, rtb_mat_by);

    // MATLAB Function: '<S96>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(rtb_mat_by, &rtb_OUTPUT_1_0[52], rtb_mat);

    // MATLAB Function: '<S95>/MATLAB Function' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServici_MATLABFunction(&rtb_OUTPUT_1_0[32], rtb_qout);

    // MATLAB Function: '<S95>/QuatToDCM'
    SatelliteServicing_Mi_QuatToDCM(rtb_qout, rtb_mat_by);

    // MATLAB Function: '<S95>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(rtb_mat_by, &rtb_OUTPUT_1_0[39], rtb_mat);

    // MATLAB Function: '<S210>/positiveQuat' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing_positiveQuat(&rtb_OUTPUT_1_0[45], rtb_qOut_f);

    // MATLAB Function: '<S214>/quat2MRP'
    SatelliteServicing_Mis_quat2MRP(rtb_qOut_f, rtb_Sum1_i);

    // MATLAB Function: '<S227>/MATLAB Function'
    rtb_qOut_f[0] = std::cos(rtb_Selector[5] / 2.0);
    rtb_qOut_f[3] = std::sin(rtb_Selector[5] / 2.0);
    rtb_q_l_idx_0 = std::cos(rtb_Selector[4] / 2.0);
    rtb_q_l_idx_2 = std::sin(rtb_Selector[4] / 2.0);
    rtb_q_l_idx_1 = std::cos(rtb_Selector[3] / 2.0);
    u0 = std::sin(rtb_Selector[3] / 2.0);
    rtb_q_l_idx_3 = (rtb_q_l_idx_0 * u0 + rtb_q_l_idx_1 * 0.0) + rtb_q_l_idx_2 *
      0.0;
    rtb_q[1] = rtb_q_l_idx_3;
    time = 0.0 * rtb_q_l_idx_3;
    rtb_q_l_idx_3 = (rtb_q_l_idx_0 * 0.0 + rtb_q_l_idx_1 * rtb_q_l_idx_2) + 0.0 *
      u0;
    rtb_q[2] = rtb_q_l_idx_3;
    time += 0.0 * rtb_q_l_idx_3;
    rtb_q_l_idx_3 = (rtb_q_l_idx_0 * 0.0 + rtb_q_l_idx_1 * 0.0) + (0.0 -
      rtb_q_l_idx_2 * u0);
    rtb_q[0] = rtb_q_l_idx_0 * rtb_q_l_idx_1 - (0.0 * u0 + rtb_q_l_idx_2 * 0.0);
    rtb_q_l_idx_0 = rtb_qOut_f[0] * rtb_q[0] - (rtb_qOut_f[3] * rtb_q_l_idx_3 +
      time);
    rtb_q_l_idx_1 = (rtb_qOut_f[0] * rtb_q[1] + rtb_q[0] * 0.0) + (0.0 *
      rtb_q_l_idx_3 - rtb_q[2] * rtb_qOut_f[3]);
    rtb_q_l_idx_2 = (rtb_qOut_f[0] * rtb_q[2] + rtb_q[0] * 0.0) + (rtb_q[1] *
      rtb_qOut_f[3] - 0.0 * rtb_q_l_idx_3);
    rtb_q_l_idx_3 = (rtb_qOut_f[0] * rtb_q_l_idx_3 + rtb_q[0] * rtb_qOut_f[3]) +
      (0.0 * rtb_q[2] - rtb_q[1] * 0.0);

    // MATLAB Function: '<S227>/quatconj'
    rtb_qOut_f[0] = rtb_OUTPUT_1_0[58];
    rtb_qOut_f[1] = -rtb_OUTPUT_1_0[59];
    rtb_qOut_f[2] = -rtb_OUTPUT_1_0[60];
    rtb_qOut_f[3] = -rtb_OUTPUT_1_0[61];

    // MATLAB Function: '<S227>/formRotMat4'
    rtb_q[1] = (rtb_q_l_idx_0 * rtb_qOut_f[1] + rtb_qOut_f[0] * rtb_q_l_idx_1) +
      (rtb_q_l_idx_2 * rtb_qOut_f[3] - rtb_qOut_f[2] * rtb_q_l_idx_3);
    rtb_q[2] = (rtb_q_l_idx_0 * rtb_qOut_f[2] + rtb_qOut_f[0] * rtb_q_l_idx_2) +
      (rtb_qOut_f[1] * rtb_q_l_idx_3 - rtb_q_l_idx_1 * rtb_qOut_f[3]);
    rtb_q[3] = (rtb_q_l_idx_0 * rtb_qOut_f[3] + rtb_qOut_f[0] * rtb_q_l_idx_3) +
      (rtb_q_l_idx_1 * rtb_qOut_f[2] - rtb_qOut_f[1] * rtb_q_l_idx_2);
    rtb_q[0] = rtb_q_l_idx_0 * rtb_qOut_f[0] - ((rtb_q_l_idx_1 * rtb_qOut_f[1] +
      rtb_q_l_idx_2 * rtb_qOut_f[2]) + rtb_q_l_idx_3 * rtb_qOut_f[3]);

    // MATLAB Function: '<S214>/quat2MPR1'
    SatelliteServicing_Mis_quat2MRP(rtb_q, rtb_mrp_g);

    // MATLAB Function: '<S214>/errorMRP'
    rtb_q_l_idx_0 = norm_NaTV2q6x(rtb_Sum1_i);
    rtb_q_l_idx_0 *= rtb_q_l_idx_0;
    rtb_q_l_idx_2 = norm_NaTV2q6x(rtb_mrp_g);
    rtb_q_l_idx_2 *= rtb_q_l_idx_2;
    rtb_q_l_idx_3 = (rtb_q_l_idx_2 * rtb_q_l_idx_0 + 1.0) - ((2.0 * rtb_mrp_g[0]
      * rtb_Sum1_i[0] + 2.0 * rtb_mrp_g[1] * rtb_Sum1_i[1]) + 2.0 * rtb_mrp_g[2]
      * rtb_Sum1_i[2]);
    b[0] = 0.0;
    b[3] = 2.0 * -rtb_mrp_g[2];
    b[6] = 2.0 * rtb_mrp_g[1];
    b[1] = 2.0 * rtb_mrp_g[2];
    b[4] = 0.0;
    b[7] = 2.0 * -rtb_mrp_g[0];
    b[2] = 2.0 * -rtb_mrp_g[1];
    b[5] = 2.0 * rtb_mrp_g[0];
    b[8] = 0.0;
    for (i = 0; i <= 0; i += 2) {
      // MATLAB Function: '<S214>/errorMRP'
      tmp_9 = _mm_loadu_pd(&rtb_mrp_g[i]);
      tmp_a = _mm_loadu_pd(&rtb_Sum1_i[i]);
      tmp_b = _mm_loadu_pd(&b[i + 3]);
      tmp_8 = _mm_loadu_pd(&b[i]);
      tmp_7 = _mm_loadu_pd(&b[i + 6]);
      _mm_storeu_pd(&rtb_MRPError[i], _mm_div_pd(_mm_sub_pd(_mm_sub_pd
        (_mm_mul_pd(_mm_set1_pd(1.0 - rtb_q_l_idx_0), tmp_9), _mm_mul_pd
         (_mm_set1_pd(1.0 - rtb_q_l_idx_2), tmp_a)), _mm_add_pd(_mm_add_pd
        (_mm_mul_pd(tmp_b, _mm_set1_pd(rtb_Sum1_i[1])), _mm_mul_pd(tmp_8,
        _mm_set1_pd(rtb_Sum1_i[0]))), _mm_mul_pd(tmp_7, _mm_set1_pd(rtb_Sum1_i[2])))),
        _mm_set1_pd(rtb_q_l_idx_3)));
    }

    // MATLAB Function: '<S214>/errorMRP'
    for (i = 2; i < 3; i++) {
      rtb_MRPError[i] = (((1.0 - rtb_q_l_idx_0) * rtb_mrp_g[i] - (1.0 -
        rtb_q_l_idx_2) * rtb_Sum1_i[i]) - ((b[i + 3] * rtb_Sum1_i[1] + b[i] *
        rtb_Sum1_i[0]) + b[i + 6] * rtb_Sum1_i[2])) / rtb_q_l_idx_3;
    }

    // MATLAB Function: '<S212>/positiveQuat' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing_positiveQuat(&rtb_OUTPUT_1_0[45], rtb_qOut_f);

    // Sum: '<S211>/Sum1' incorporates:
    //   Product: '<S227>/Product'
    //   Selector: '<S227>/Selector4'

    rtb_Sum1_i[0] = rtb_Product[12] - rtb_OUTPUT_1_0[52];
    rtb_Sum1_i[1] = rtb_Product[13] - rtb_OUTPUT_1_0[53];
    rtb_Sum1_i[2] = rtb_Product[14] - rtb_OUTPUT_1_0[54];

    // Sum: '<S213>/Sum1' incorporates:
    //   BusAssignment: '<S4>/Bus Assignment'
    //   Reshape: '<S227>/Reshape2'

    rtb_mrp_g[0] = rtb_Reshape2_idx_6 - rtb_OUTPUT_1_0[55];
    rtb_mrp_g[1] = rtb_Reshape2_idx_7 - rtb_OUTPUT_1_0[56];
    rtb_mrp_g[2] = rtb_Reshape2_idx_8 - rtb_OUTPUT_1_0[57];

    // Sum: '<S212>/Sum1' incorporates:
    //   BusAssignment: '<S4>/Bus Assignment'
    //   Reshape: '<S227>/Reshape2'

    rtb_controlErrorECEF_l[0] = rtb_Reshape2_idx_9 - rtb_OUTPUT_1_0[49];
    rtb_controlErrorECEF_l[1] = rtb_Reshape2_idx_10 - rtb_OUTPUT_1_0[50];
    rtb_controlErrorECEF_l[2] = rtb_Reshape2_idx_11 - rtb_OUTPUT_1_0[51];

    // Outport: '<Root>/ControlError'
    SatelliteServicing_Mission_Y->ControlError[0] = rtb_Sum1_i[0];
    SatelliteServicing_Mission_Y->ControlError[1] = rtb_Sum1_i[1];
    SatelliteServicing_Mission_Y->ControlError[2] = rtb_Sum1_i[2];
    SatelliteServicing_Mission_Y->ControlError[3] = rtb_MRPError[0];
    SatelliteServicing_Mission_Y->ControlError[4] = rtb_MRPError[1];
    SatelliteServicing_Mission_Y->ControlError[5] = rtb_MRPError[2];
    SatelliteServicing_Mission_Y->ControlError[6] = rtb_mrp_g[0];
    SatelliteServicing_Mission_Y->ControlError[9] = rtb_controlErrorECEF_l[0];
    SatelliteServicing_Mission_Y->ControlError[7] = rtb_mrp_g[1];
    SatelliteServicing_Mission_Y->ControlError[10] = rtb_controlErrorECEF_l[1];
    SatelliteServicing_Mission_Y->ControlError[8] = rtb_mrp_g[2];
    SatelliteServicing_Mission_Y->ControlError[11] = rtb_controlErrorECEF_l[2];

    // MATLAB Function: '<S95>/QuatToEuler321'
    SatelliteServici_QuatToEuler321(rtb_qout, rtb_MRPError);

    // MATLAB Function: '<S96>/QuatToEuler321'
    SatelliteServici_QuatToEuler321(rtb_qout_gi, rtb_MRPError);

    // MATLAB Function: '<S7>/QuatToEuler321'
    SatelliteServici_QuatToEuler321(rtb_qout_n, rtb_MRPError);

    // MATLAB Function: '<S7>/quat2MRP' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing_Mis_quat2MRP(&rtb_OUTPUT_1_0[6], rtb_MRPError);

    // MATLAB Function: '<S8>/quat2MRP' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing_Mis_quat2MRP(&rtb_OUTPUT_1_0[19], rtb_MRPError);

    // MATLAB Function: '<S95>/quat2MRP' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing_Mis_quat2MRP(&rtb_OUTPUT_1_0[32], rtb_MRPError);

    // MATLAB Function: '<S243>/quat2MRP' incorporates:
    //   SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    SatelliteServicing_Mis_quat2MRP(&rtb_OUTPUT_1_0[58], rtb_MRPError);
  }

  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    NeslSimulationData *simulationData;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    char *msg;
    real_T tmp_0[36];
    real_T time;
    int32_T tmp_2;
    int_T tmp_1[10];
    boolean_T tmp;

    // Update for SimscapeExecutionBlock: '<S285>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData);
    time = SatelliteServicing_Mission_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 32;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionServi[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (SatelliteServicing_Mission_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
      (SatelliteServicing_Mission_M->solverInfo);
    tmp_1[0] = 0;
    tmp_0[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_0[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_0[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_0[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_1[1] = 4;
    tmp_0[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_0[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_0[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_0[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_1[2] = 8;
    tmp_0[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_0[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_0[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_0[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_1[3] = 12;
    tmp_0[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_0[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_0[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_0[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_1[4] = 16;
    tmp_0[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
    tmp_0[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
    tmp_0[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
    tmp_0[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
    tmp_1[5] = 20;
    tmp_0[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
    tmp_0[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
    tmp_0[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
    tmp_0[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
    tmp_1[6] = 24;
    tmp_0[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
    tmp_0[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
    tmp_0[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
    tmp_0[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
    tmp_1[7] = 28;
    tmp_0[28] = SatelliteServicing_Mission_B->INPUT_7_1_2[0];
    tmp_0[29] = SatelliteServicing_Mission_B->INPUT_7_1_2[1];
    tmp_0[30] = SatelliteServicing_Mission_B->INPUT_7_1_2[2];
    tmp_0[31] = SatelliteServicing_Mission_B->INPUT_7_1_2[3];
    tmp_1[8] = 32;
    tmp_0[32] = SatelliteServicing_Mission_B->INPUT_7_1_3[0];
    tmp_0[33] = SatelliteServicing_Mission_B->INPUT_7_1_3[1];
    tmp_0[34] = SatelliteServicing_Mission_B->INPUT_7_1_3[2];
    tmp_0[35] = SatelliteServicing_Mission_B->INPUT_7_1_3[3];
    tmp_1[9] = 36;
    simulationData->mData->mInputValues.mN = 36;
    simulationData->mData->mInputValues.mX = &tmp_0[0];
    simulationData->mData->mInputOffsets.mN = 10;
    simulationData->mData->mInputOffsets.mX = &tmp_1[0];
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_UPDATE,
      simulationData, diagnosticManager);
    if (tmp_2 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
      }
    }

    // End of Update for SimscapeExecutionBlock: '<S285>/STATE_1'
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // Update for DiscreteIntegrator: '<S226>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[0] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainval *
        SatelliteServicing_Mission_B->controlErrorECEF[0];

      // Update for DiscreteIntegrator: '<S225>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[0] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainv_f *
        SatelliteServicing_Mission_B->controlErrorECEF_n[0];

      // Update for DiscreteIntegrator: '<S226>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[1] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainval *
        SatelliteServicing_Mission_B->controlErrorECEF[1];

      // Update for DiscreteIntegrator: '<S225>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[1] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainv_f *
        SatelliteServicing_Mission_B->controlErrorECEF_n[1];

      // Update for DiscreteIntegrator: '<S226>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[2] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainval *
        SatelliteServicing_Mission_B->controlErrorECEF[2];

      // Update for DiscreteIntegrator: '<S225>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[2] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainv_f *
        SatelliteServicing_Mission_B->controlErrorECEF_n[2];
    }
  }                                    // end MajorTimeStep

  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    rt_ertODEUpdateContinuousStates(SatelliteServicing_Mission_M->solverInfo,
      SatelliteServicing_Mission_M, SatelliteServicing_Mission_U,
      SatelliteServicing_Mission_Y);

    // Update absolute time for base rate
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.

    ++SatelliteServicing_Mission_M->Timing.clockTick0;
    SatelliteServicing_Mission_M->Timing.t[0] = rtsiGetSolverStopTime
      (SatelliteServicing_Mission_M->solverInfo);

    {
      // Update absolute timer for sample time: [0.001s, 0.0s]
      // The "clockTick1" counts the number of times the code of this task has
      //  been executed. The resolution of this integer timer is 0.001, which is the step size
      //  of the task. Size of "clockTick1" ensures timer will not overflow during the
      //  application lifespan selected.

      SatelliteServicing_Mission_M->Timing.clockTick1++;
    }
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void SatelliteServicing_Mission_derivatives(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M)
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  NeslSimulationData *simulationData;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  XDot_SatelliteServicing_Missi_T *_rtXdot;
  char *msg;
  real_T tmp_0[36];
  real_T time;
  int32_T tmp_2;
  int_T tmp_1[10];
  boolean_T tmp;
  _rtXdot = ((XDot_SatelliteServicing_Missi_T *)
             SatelliteServicing_Mission_M->derivs);

  // Derivatives for SimscapeExecutionBlock: '<S285>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData);
  time = SatelliteServicing_Mission_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 32;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionServi[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
    (SatelliteServicing_Mission_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
    (SatelliteServicing_Mission_M->solverInfo);
  tmp_1[0] = 0;
  tmp_0[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
  tmp_0[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
  tmp_0[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
  tmp_0[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
  tmp_1[1] = 4;
  tmp_0[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
  tmp_0[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
  tmp_0[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
  tmp_0[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
  tmp_1[2] = 8;
  tmp_0[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
  tmp_0[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
  tmp_0[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
  tmp_0[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
  tmp_1[3] = 12;
  tmp_0[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
  tmp_0[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
  tmp_0[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
  tmp_0[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
  tmp_1[4] = 16;
  tmp_0[16] = SatelliteServicing_Mission_B->INPUT_5_1_1[0];
  tmp_0[17] = SatelliteServicing_Mission_B->INPUT_5_1_1[1];
  tmp_0[18] = SatelliteServicing_Mission_B->INPUT_5_1_1[2];
  tmp_0[19] = SatelliteServicing_Mission_B->INPUT_5_1_1[3];
  tmp_1[5] = 20;
  tmp_0[20] = SatelliteServicing_Mission_B->INPUT_6_1_1[0];
  tmp_0[21] = SatelliteServicing_Mission_B->INPUT_6_1_1[1];
  tmp_0[22] = SatelliteServicing_Mission_B->INPUT_6_1_1[2];
  tmp_0[23] = SatelliteServicing_Mission_B->INPUT_6_1_1[3];
  tmp_1[6] = 24;
  tmp_0[24] = SatelliteServicing_Mission_B->INPUT_7_1_1[0];
  tmp_0[25] = SatelliteServicing_Mission_B->INPUT_7_1_1[1];
  tmp_0[26] = SatelliteServicing_Mission_B->INPUT_7_1_1[2];
  tmp_0[27] = SatelliteServicing_Mission_B->INPUT_7_1_1[3];
  tmp_1[7] = 28;
  tmp_0[28] = SatelliteServicing_Mission_B->INPUT_7_1_2[0];
  tmp_0[29] = SatelliteServicing_Mission_B->INPUT_7_1_2[1];
  tmp_0[30] = SatelliteServicing_Mission_B->INPUT_7_1_2[2];
  tmp_0[31] = SatelliteServicing_Mission_B->INPUT_7_1_2[3];
  tmp_1[8] = 32;
  tmp_0[32] = SatelliteServicing_Mission_B->INPUT_7_1_3[0];
  tmp_0[33] = SatelliteServicing_Mission_B->INPUT_7_1_3[1];
  tmp_0[34] = SatelliteServicing_Mission_B->INPUT_7_1_3[2];
  tmp_0[35] = SatelliteServicing_Mission_B->INPUT_7_1_3[3];
  tmp_1[9] = 36;
  simulationData->mData->mInputValues.mN = 36;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 10;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  simulationData->mData->mDx.mN = 32;
  simulationData->mData->mDx.mX = &_rtXdot->SatelliteServicing_MissionServi[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_DERIVATIVES,
    simulationData, diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
    }
  }

  // End of Derivatives for SimscapeExecutionBlock: '<S285>/STATE_1'

  // Derivatives for SimscapeInputBlock: '<S285>/INPUT_1_1_1'
  _rtXdot->SatelliteServicing_MissionRobot[0] =
    SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[1];
  _rtXdot->SatelliteServicing_MissionRobot[1] =
    ((SatelliteServicing_Mission_B->joint_torque_out[0] -
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[0]) * 1000.0
     - 2.0 * SatelliteServicing_Mission_X->SatelliteServicing_MissionRobot[1]) *
    1000.0;

  // Derivatives for SimscapeInputBlock: '<S285>/INPUT_2_1_1'
  _rtXdot->SatelliteServicing_MissionRob_j[0] =
    SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[1];
  _rtXdot->SatelliteServicing_MissionRob_j[1] =
    ((SatelliteServicing_Mission_B->joint_torque_out[1] -
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[0]) * 1000.0
     - 2.0 * SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_j[1]) *
    1000.0;

  // Derivatives for SimscapeInputBlock: '<S285>/INPUT_3_1_1'
  _rtXdot->SatelliteServicing_MissionRob_k[0] =
    SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[1];
  _rtXdot->SatelliteServicing_MissionRob_k[1] =
    ((SatelliteServicing_Mission_B->joint_torque_out[2] -
      SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[0]) * 1000.0
     - 2.0 * SatelliteServicing_Mission_X->SatelliteServicing_MissionRob_k[1]) *
    1000.0;
}

// Model initialize function
void SatelliteServicing_Mission_initialize(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M)
{
  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  {
    NeModelParameters modelParameters;
    NeModelParameters modelParameters_0;
    NeModelParameters modelParameters_1;
    NeslRtpManager *manager;
    NeslRtpManager *manager_0;
    NeslSimulationData *tmp_1;
    NeslSimulator *tmp_0;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    NeuDiagnosticTree *diagnosticTree_0;
    NeuDiagnosticTree *diagnosticTree_1;
    char *msg;
    char *msg_0;
    char *msg_1;
    real_T tmp_2;
    int32_T tmp_3;
    boolean_T tmp;

    // Start for SimscapeRtp: '<S6>/RTP_1'
    manager_0 = nesl_lease_rtp_manager(
      "SatelliteServicing_Mission/Solver Configuration_1", 0);
    manager = manager_0;
    tmp = pointer_is_null(manager_0);
    if (tmp) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      manager = nesl_lease_rtp_manager(
        "SatelliteServicing_Mission/Solver Configuration_1", 0);
    }

    SatelliteServicing_Mission_DW->RTP_1_RtpManager = (void *)manager;
    SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded = true;

    // End of Start for SimscapeRtp: '<S6>/RTP_1'

    // Start for SimscapeExecutionBlock: '<S285>/STATE_1'
    tmp_0 = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 0, 0);
    SatelliteServicing_Mission_DW->STATE_1_Simulator = (void *)tmp_0;
    tmp = pointer_is_null(SatelliteServicing_Mission_DW->STATE_1_Simulator);
    if (tmp) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp_0 = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 0, 0);
      SatelliteServicing_Mission_DW->STATE_1_Simulator = (void *)tmp_0;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->STATE_1_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->STATE_1_DiagMgr = (void *)diagnosticManager;
    modelParameters.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters.mSolverAbsTol = 0.001;
    modelParameters.mSolverRelTol = 0.001;
    modelParameters.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters.mStartTime = 0.0;
    modelParameters.mLoadInitialState = false;
    modelParameters.mUseSimState = false;
    modelParameters.mLinTrimCompile = false;
    modelParameters.mLoggingMode = SSC_LOGGING_ON;
    modelParameters.mRTWModifiedTimeStamp = 6.21790268E+8;
    modelParameters.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters.mSolverTolerance = tmp_2;
    tmp_2 = 0.001;
    modelParameters.mFixedStepSize = tmp_2;
    tmp = false;
    modelParameters.mVariableStepSolver = tmp;
    tmp = false;
    modelParameters.mIsUsingODEN = tmp;
    modelParameters.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), &modelParameters,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S285>/STATE_1'

    // Start for SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'
    tmp_0 = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 1, 0);
    SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator = (void *)tmp_0;
    tmp = pointer_is_null(SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator);
    if (tmp) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp_0 = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 1, 0);
      SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator = (void *)tmp_0;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr = (void *)
      diagnosticManager;
    modelParameters_0.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_0.mSolverAbsTol = 0.001;
    modelParameters_0.mSolverRelTol = 0.001;
    modelParameters_0.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_0.mStartTime = 0.0;
    modelParameters_0.mLoadInitialState = false;
    modelParameters_0.mUseSimState = false;
    modelParameters_0.mLinTrimCompile = false;
    modelParameters_0.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_0.mRTWModifiedTimeStamp = 6.21790268E+8;
    modelParameters_0.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_0.mSolverTolerance = tmp_2;
    tmp_2 = 0.001;
    modelParameters_0.mFixedStepSize = tmp_2;
    tmp = false;
    modelParameters_0.mVariableStepSolver = tmp;
    tmp = false;
    modelParameters_0.mIsUsingODEN = tmp;
    modelParameters_0.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr);
    diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator), &modelParameters_0,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg_0 = rtw_diagnostics_msg(diagnosticTree_0);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'

    // Start for SimscapeExecutionBlock: '<S285>/OUTPUT_1_1'
    tmp_0 = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 1, 1);
    SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator = (void *)tmp_0;
    tmp = pointer_is_null(SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator);
    if (tmp) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp_0 = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 1, 1);
      SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator = (void *)tmp_0;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr = (void *)
      diagnosticManager;
    modelParameters_1.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_1.mSolverAbsTol = 0.001;
    modelParameters_1.mSolverRelTol = 0.001;
    modelParameters_1.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_1.mStartTime = 0.0;
    modelParameters_1.mLoadInitialState = false;
    modelParameters_1.mUseSimState = false;
    modelParameters_1.mLinTrimCompile = false;
    modelParameters_1.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_1.mRTWModifiedTimeStamp = 6.21790268E+8;
    modelParameters_1.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_1.mSolverTolerance = tmp_2;
    tmp_2 = 0.001;
    modelParameters_1.mFixedStepSize = tmp_2;
    tmp = false;
    modelParameters_1.mVariableStepSolver = tmp;
    tmp = false;
    modelParameters_1.mIsUsingODEN = tmp;
    modelParameters_1.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr);
    diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator), &modelParameters_1,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg_1 = rtw_diagnostics_msg(diagnosticTree_1);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S285>/OUTPUT_1_1'

    // InitializeConditions for DiscreteIntegrator: '<S226>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[0] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC;

    // InitializeConditions for DiscreteIntegrator: '<S225>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[0] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC_l;

    // InitializeConditions for DiscreteIntegrator: '<S226>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[1] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC;

    // InitializeConditions for DiscreteIntegrator: '<S225>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[1] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC_l;

    // InitializeConditions for DiscreteIntegrator: '<S226>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[2] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC;

    // InitializeConditions for DiscreteIntegrator: '<S225>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_n[2] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC_l;
  }
}

// Model terminate function
void SatelliteServicing_Mission_terminate(RT_MODEL_SatelliteServicing_M_T
  * SatelliteServicing_Mission_M)
{
  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  // Terminate for SimscapeExecutionBlock: '<S285>/STATE_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S285>/OUTPUT_1_0'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S285>/OUTPUT_1_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();
  rt_FREE(SatelliteServicing_Mission_M->solverInfo);

  // model code
  rt_FREE(SatelliteServicing_Mission_M->blockIO);
  rt_FREE(SatelliteServicing_Mission_M->contStates);
  rt_FREE(SatelliteServicing_Mission_M->dwork);
  delete SatelliteServicing_Mission_M;
}

// Model data allocation function
RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission
  (ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
   ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y)
{
  RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission_M;
  SatelliteServicing_Mission_M = new RT_MODEL_SatelliteServicing_M_T();
  if (SatelliteServicing_Mission_M == (nullptr)) {
    return (nullptr);
  }

  {
    // Setup solver object
    RTWSolverInfo *rt_SolverInfo{ (RTWSolverInfo *) malloc(sizeof(RTWSolverInfo))
    };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,rt_SolverInfo);
    SatelliteServicing_Mission_M->solverInfo = (rt_SolverInfo);
    rtsiSetSimTimeStepPtr(SatelliteServicing_Mission_M->solverInfo,
                          &SatelliteServicing_Mission_M->Timing.simTimeStep);
    rtsiSetTPtr(SatelliteServicing_Mission_M->solverInfo, &rtmGetTPtr
                (SatelliteServicing_Mission_M));
    rtsiSetStepSizePtr(SatelliteServicing_Mission_M->solverInfo,
                       &SatelliteServicing_Mission_M->Timing.stepSize0);
    rtsiSetdXPtr(SatelliteServicing_Mission_M->solverInfo,
                 &SatelliteServicing_Mission_M->derivs);
    rtsiSetContStatesPtr(SatelliteServicing_Mission_M->solverInfo, (real_T **)
                         &SatelliteServicing_Mission_M->contStates);
    rtsiSetNumContStatesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(SatelliteServicing_Mission_M->solverInfo,
                          (&rtmGetErrorStatus(SatelliteServicing_Mission_M)));
    rtsiSetRTModelPtr(SatelliteServicing_Mission_M->solverInfo,
                      SatelliteServicing_Mission_M);
  }

  rtsiSetSolverName(SatelliteServicing_Mission_M->solverInfo,"ode3");

  // block I/O
  {
    B_SatelliteServicing_Mission_T *b{ (B_SatelliteServicing_Mission_T *) malloc
      (sizeof(B_SatelliteServicing_Mission_T)) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,b);
    SatelliteServicing_Mission_M->blockIO = (b);
  }

  // states (continuous)
  {
    X_SatelliteServicing_Mission_T *x{ (X_SatelliteServicing_Mission_T *) malloc
      (sizeof(X_SatelliteServicing_Mission_T)) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,x);
    SatelliteServicing_Mission_M->contStates = (x);
  }

  // states (dwork)
  {
    DW_SatelliteServicing_Mission_T *dwork{ static_cast<
      DW_SatelliteServicing_Mission_T *>(malloc(sizeof
      (DW_SatelliteServicing_Mission_T))) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,dwork);
    SatelliteServicing_Mission_M->dwork = (dwork);
  }

  {
    B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
      SatelliteServicing_Mission_M->blockIO };

    DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
      SatelliteServicing_Mission_M->dwork };

    X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
      SatelliteServicing_Mission_M->contStates };

    // initialize non-finites
    rt_InitInfAndNaN(sizeof(real_T));
    rtsiSetSimTimeStep(SatelliteServicing_Mission_M->solverInfo, MAJOR_TIME_STEP);
    SatelliteServicing_Mission_M->intgData.y =
      SatelliteServicing_Mission_M->odeY;
    SatelliteServicing_Mission_M->intgData.f[0] =
      SatelliteServicing_Mission_M->odeF[0];
    SatelliteServicing_Mission_M->intgData.f[1] =
      SatelliteServicing_Mission_M->odeF[1];
    SatelliteServicing_Mission_M->intgData.f[2] =
      SatelliteServicing_Mission_M->odeF[2];
    SatelliteServicing_Mission_M->contStates = ((X_SatelliteServicing_Mission_T *)
      SatelliteServicing_Mission_X);
    rtsiSetSolverData(SatelliteServicing_Mission_M->solverInfo, static_cast<void
                      *>(&SatelliteServicing_Mission_M->intgData));
    rtsiSetIsMinorTimeStepWithModeChange
      (SatelliteServicing_Mission_M->solverInfo, false);
    rtmSetTPtr(SatelliteServicing_Mission_M,
               &SatelliteServicing_Mission_M->Timing.tArray[0]);
    SatelliteServicing_Mission_M->Timing.stepSize0 = 0.001;

    // block I/O
    (void) std::memset((static_cast<void *>(SatelliteServicing_Mission_B)), 0,
                       sizeof(B_SatelliteServicing_Mission_T));

    // states (continuous)
    {
      (void) std::memset(static_cast<void *>(SatelliteServicing_Mission_X), 0,
                         sizeof(X_SatelliteServicing_Mission_T));
    }

    // states (dwork)
    (void) std::memset(static_cast<void *>(SatelliteServicing_Mission_DW), 0,
                       sizeof(DW_SatelliteServicing_Mission_T));

    // external inputs
    (void)std::memset(SatelliteServicing_Mission_U, 0, sizeof
                      (ExtU_SatelliteServicing_Missi_T));

    // external outputs
    (void)std::memset(SatelliteServicing_Mission_Y, 0, sizeof
                      (ExtY_SatelliteServicing_Missi_T));
  }

  return SatelliteServicing_Mission_M;
}

//
// File trailer for generated code.
//
// [EOF]
//
