//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.126
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Thu Aug 29 11:41:51 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "SatelliteServicing_Mission.h"
#include "rtwtypes.h"
#include "SatelliteServicing_Mission_private.h"
#include <cstring>
#include <emmintrin.h>
#include <cmath>
#include "norm_NaTV2q6x.h"
#include "svd_jndSmZ1I.h"
#include <stddef.h>

extern "C"
{

#include "rt_nonfinite.h"

}

// Projection for root system: '<Root>'
void SatelliteServicing_Mission_projection(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M)
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  NeslSimulationData *simulationData;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  NeuDiagnosticTree *diagnosticTree_0;
  NeuDiagnosticTree *diagnosticTree_1;
  NeuDiagnosticTree *diagnosticTree_2;
  NeuDiagnosticTree *diagnosticTree_3;
  char *msg;
  char *msg_0;
  char *msg_1;
  char *msg_2;
  char *msg_3;
  real_T tmp_1[24];
  real_T tmp_5[12];
  real_T tmp_7[12];
  real_T tmp_9[12];
  real_T tmp_b[12];
  real_T time;
  real_T time_0;
  real_T time_1;
  real_T time_2;
  real_T time_3;
  real_T time_tmp;
  int32_T tmp_3;
  int_T tmp_2[7];
  int_T tmp_6[4];
  int_T tmp_8[4];
  int_T tmp_a[4];
  int_T tmp_c[4];
  boolean_T tmp;
  boolean_T tmp_0;
  boolean_T tmp_4;

  // Projection for SimscapeExecutionBlock: '<S300>/STATE_1' incorporates:
  //   SimscapeExecutionBlock: '<S148>/STATE_1'
  //   SimscapeExecutionBlock: '<S178>/STATE_1'
  //   SimscapeExecutionBlock: '<S208>/STATE_1'
  //   SimscapeExecutionBlock: '<S238>/STATE_1'

  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData);
  time_tmp = SatelliteServicing_Mission_M->Timing.t[0];
  time = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionServi[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  tmp = rtmIsMajorTimeStep(SatelliteServicing_Mission_M);
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp_0 = false;
  simulationData->mData->mIsSolverAssertCheck = tmp_0;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp_0 = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp_0;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_0 = rtsiIsModeUpdateTimeStep(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_2[0] = 0;
  tmp_1[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
  tmp_1[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
  tmp_1[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
  tmp_1[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
  tmp_2[1] = 4;
  tmp_1[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
  tmp_1[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
  tmp_1[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
  tmp_1[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
  tmp_2[2] = 8;
  tmp_1[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
  tmp_1[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
  tmp_1[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
  tmp_1[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
  tmp_2[3] = 12;
  tmp_1[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
  tmp_1[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
  tmp_1[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
  tmp_1[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
  tmp_2[4] = 16;
  tmp_1[16] = SatelliteServicing_Mission_B->INPUT_4_1_2[0];
  tmp_1[17] = SatelliteServicing_Mission_B->INPUT_4_1_2[1];
  tmp_1[18] = SatelliteServicing_Mission_B->INPUT_4_1_2[2];
  tmp_1[19] = SatelliteServicing_Mission_B->INPUT_4_1_2[3];
  tmp_2[5] = 20;
  tmp_1[20] = SatelliteServicing_Mission_B->INPUT_4_1_3[0];
  tmp_1[21] = SatelliteServicing_Mission_B->INPUT_4_1_3[1];
  tmp_1[22] = SatelliteServicing_Mission_B->INPUT_4_1_3[2];
  tmp_1[23] = SatelliteServicing_Mission_B->INPUT_4_1_3[3];
  tmp_2[6] = 24;
  simulationData->mData->mInputValues.mN = 24;
  simulationData->mData->mInputValues.mX = &tmp_1[0];
  simulationData->mData->mInputOffsets.mN = 7;
  simulationData->mData->mInputOffsets.mX = &tmp_2[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_PROJECTION,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp_4 = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp_4) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
    }
  }

  // End of Projection for SimscapeExecutionBlock: '<S300>/STATE_1'

  // Projection for SimscapeExecutionBlock: '<S148>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_g);
  time_0 = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_0;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionMissi[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete_k;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes_l;
  tmp_4 = false;
  simulationData->mData->mFoundZcEvents = tmp_4;
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp_4 = false;
  simulationData->mData->mIsSolverAssertCheck = tmp_4;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp_4 = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp_4;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_6[0] = 0;
  tmp_5[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[0];
  tmp_5[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[1];
  tmp_5[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[2];
  tmp_5[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[3];
  tmp_6[1] = 4;
  tmp_5[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[0];
  tmp_5[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[1];
  tmp_5[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[2];
  tmp_5[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[3];
  tmp_6[2] = 8;
  tmp_5[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[0];
  tmp_5[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[1];
  tmp_5[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[2];
  tmp_5[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[3];
  tmp_6[3] = 12;
  simulationData->mData->mInputValues.mN = 12;
  simulationData->mData->mInputValues.mX = &tmp_5[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_6[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_a);
  diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator_i), NESL_SIM_PROJECTION,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp_4 = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp_4) {
      msg_0 = rtw_diagnostics_msg(diagnosticTree_0);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
    }
  }

  // Projection for SimscapeExecutionBlock: '<S178>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_f);
  time_1 = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_1;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_m[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete_l;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes_l0;
  tmp_4 = false;
  simulationData->mData->mFoundZcEvents = tmp_4;
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp_4 = false;
  simulationData->mData->mIsSolverAssertCheck = tmp_4;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp_4 = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp_4;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_8[0] = 0;
  tmp_7[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[0];
  tmp_7[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[1];
  tmp_7[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[2];
  tmp_7[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[3];
  tmp_8[1] = 4;
  tmp_7[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[0];
  tmp_7[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[1];
  tmp_7[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[2];
  tmp_7[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[3];
  tmp_8[2] = 8;
  tmp_7[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[0];
  tmp_7[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[1];
  tmp_7[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[2];
  tmp_7[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[3];
  tmp_8[3] = 12;
  simulationData->mData->mInputValues.mN = 12;
  simulationData->mData->mInputValues.mX = &tmp_7[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_8[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_p);
  diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator_n), NESL_SIM_PROJECTION,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp_4 = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp_4) {
      msg_1 = rtw_diagnostics_msg(diagnosticTree_1);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
    }
  }

  // Projection for SimscapeExecutionBlock: '<S208>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_k);
  time_2 = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_2;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_k[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete_k5;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes_j;
  tmp_4 = false;
  simulationData->mData->mFoundZcEvents = tmp_4;
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp_4 = false;
  simulationData->mData->mIsSolverAssertCheck = tmp_4;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp_4 = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp_4;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_a[0] = 0;
  tmp_9[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[0];
  tmp_9[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[1];
  tmp_9[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[2];
  tmp_9[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[3];
  tmp_a[1] = 4;
  tmp_9[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[0];
  tmp_9[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[1];
  tmp_9[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[2];
  tmp_9[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[3];
  tmp_a[2] = 8;
  tmp_9[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[0];
  tmp_9[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[1];
  tmp_9[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[2];
  tmp_9[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[3];
  tmp_a[3] = 12;
  simulationData->mData->mInputValues.mN = 12;
  simulationData->mData->mInputValues.mX = &tmp_9[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_a[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_pq);
  diagnosticTree_2 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator_l), NESL_SIM_PROJECTION,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp_4 = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp_4) {
      msg_2 = rtw_diagnostics_msg(diagnosticTree_2);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_2);
    }
  }

  // Projection for SimscapeExecutionBlock: '<S238>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_m);
  time_3 = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_3;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_n[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete_h;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes_h;
  tmp_4 = false;
  simulationData->mData->mFoundZcEvents = tmp_4;
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_c[0] = 0;
  tmp_b[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[0];
  tmp_b[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[1];
  tmp_b[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[2];
  tmp_b[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[3];
  tmp_c[1] = 4;
  tmp_b[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[0];
  tmp_b[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[1];
  tmp_b[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[2];
  tmp_b[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[3];
  tmp_c[2] = 8;
  tmp_b[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[0];
  tmp_b[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[1];
  tmp_b[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[2];
  tmp_b[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[3];
  tmp_c[3] = 12;
  simulationData->mData->mInputValues.mN = 12;
  simulationData->mData->mInputValues.mX = &tmp_b[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_c[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_i);
  diagnosticTree_3 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator_j), NESL_SIM_PROJECTION,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp) {
      msg_3 = rtw_diagnostics_msg(diagnosticTree_3);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_3);
    }
  }
}

//
// This function updates continuous states using the ODE3 fixed-step
// solver algorithm
//
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si ,
  RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M,
  ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y)
{
  // Solver Matrices
  static const real_T rt_ODE3_A[3]{
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3]{
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t { rtsiGetT(si) };

  time_T tnew { rtsiGetSolverStopTime(si) };

  time_T h { rtsiGetStepSize(si) };

  real_T *x { rtsiGetContStates(si) };

  ODE3_IntgData *id { static_cast<ODE3_IntgData *>(rtsiGetSolverData(si)) };

  real_T *y { id->y };

  real_T *f0 { id->f[0] };

  real_T *f1 { id->f[1] };

  real_T *f2 { id->f[2] };

  real_T hB[3];
  int_T i;
  int_T nXc { 65 };

  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*));
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_Y);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*));
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_Y);
  SatelliteServicing_Mission_derivatives(SatelliteServicing_Mission_M);

  // tnew = t + hA(3);
  // ynew = y + f*hB(:,3);
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  SatelliteServicing_Mission_step(SatelliteServicing_Mission_M,
    SatelliteServicing_Mission_Y);
  SatelliteServicing_Mission_projection(SatelliteServicing_Mission_M);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

//
// Output and update for atomic system:
//    '<S6>/Reorder_to_XYZ'
//    '<S7>/Reorder_to_XYZ'
//    '<S248>/Reorder_to_XYZ'
//
void SatelliteServici_Reorder_to_XYZ(const real_T rtu_Euler_in[3], real_T
  rty_Euler_out[3])
{
  rty_Euler_out[0] = rtu_Euler_in[2];
  rty_Euler_out[1] = rtu_Euler_in[1];
  rty_Euler_out[2] = rtu_Euler_in[0];
}

//
// Termination for atomic system:
//    '<S6>/Reorder_to_XYZ'
//    '<S7>/Reorder_to_XYZ'
//    '<S248>/Reorder_to_XYZ'
//
void SatelliteSe_Reorder_to_XYZ_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S6>/formPoseMat'
//    '<S7>/formPoseMat'
//    '<S248>/formPoseMat'
//
void SatelliteServicing__formPoseMat(const real_T rtu_rotMat[9], const real_T
  rtu_posVec[3], real_T rty_mat[16])
{
  for (int32_T i{0}; i < 3; i++) {
    int32_T tmp;
    tmp = i << 2;
    rty_mat[tmp] = rtu_rotMat[3 * i];
    rty_mat[tmp + 1] = rtu_rotMat[3 * i + 1];
    rty_mat[tmp + 2] = rtu_rotMat[3 * i + 2];
  }

  rty_mat[12] = rtu_posVec[0];
  rty_mat[13] = rtu_posVec[1];
  rty_mat[14] = rtu_posVec[2];
  rty_mat[3] = 0.0;
  rty_mat[7] = 0.0;
  rty_mat[11] = 0.0;
  rty_mat[15] = 1.0;
}

//
// Termination for atomic system:
//    '<S6>/formPoseMat'
//    '<S7>/formPoseMat'
//    '<S248>/formPoseMat'
//
void SatelliteServi_formPoseMat_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S6>/positiveQuat'
//    '<S7>/positiveQuat'
//    '<S248>/positiveQuat'
//
void SatelliteServicing_positiveQuat(const real_T rtu_qIn[4], real_T rty_qOut[4])
{
  if (rtu_qIn[0] < 0.0) {
    rty_qOut[0] = -rtu_qIn[0];
    rty_qOut[1] = -rtu_qIn[1];
    rty_qOut[2] = -rtu_qIn[2];
    rty_qOut[3] = -rtu_qIn[3];
  } else {
    rty_qOut[0] = rtu_qIn[0];
    rty_qOut[1] = rtu_qIn[1];
    rty_qOut[2] = rtu_qIn[2];
    rty_qOut[3] = rtu_qIn[3];
  }
}

//
// Termination for atomic system:
//    '<S6>/positiveQuat'
//    '<S7>/positiveQuat'
//    '<S248>/positiveQuat'
//
void SatelliteServ_positiveQuat_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S6>/quat2MRP'
//    '<S7>/quat2MRP'
//    '<S248>/quat2MRP'
//
void SatelliteServicing_Mis_quat2MRP(const real_T rtu_q[4], real_T rty_mrp[3])
{
  rty_mrp[0] = rtu_q[1] / (rtu_q[0] + 1.0);
  rty_mrp[1] = rtu_q[2] / (rtu_q[0] + 1.0);
  rty_mrp[2] = rtu_q[3] / (rtu_q[0] + 1.0);
}

//
// Termination for atomic system:
//    '<S6>/quat2MRP'
//    '<S7>/quat2MRP'
//    '<S248>/quat2MRP'
//
void SatelliteServicin_quat2MRP_Term(void)
{
}

//
// Output and update for atomic system:
//    '<S120>/CW_Equations'
//    '<S150>/CW_Equations'
//    '<S180>/CW_Equations'
//    '<S210>/CW_Equations'
//
void SatelliteServicing_CW_Equations(const real_T rtu_position[3], const real_T
  rtu_velocity[3], real_T rtu_mean_motion, real_T rty_acceleration[3])
{
  real_T tmp;
  tmp = rtu_mean_motion * rtu_mean_motion;
  rty_acceleration[0] = tmp * 3.0 * rtu_position[0] + 2.0 * rtu_mean_motion *
    rtu_velocity[1];
  rty_acceleration[1] = -2.0 * rtu_mean_motion * rtu_velocity[0];
  rty_acceleration[2] = -tmp * rtu_position[2];
}

//
// Termination for atomic system:
//    '<S120>/CW_Equations'
//    '<S150>/CW_Equations'
//    '<S180>/CW_Equations'
//    '<S210>/CW_Equations'
//
void SatelliteServ_CW_Equations_Term(void)
{
}

// Model step function
void SatelliteServicing_Mission_step(RT_MODEL_SatelliteServicing_M_T *const
  SatelliteServicing_Mission_M, ExtY_SatelliteServicing_Missi_T
  *SatelliteServicing_Mission_Y)
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  // local block i/o variables
  real_T rtb_OUTPUT_1_0[75];
  real_T rtb_OUTPUT_1_0_n[6];
  real_T rtb_OUTPUT_1_0_b[6];
  real_T rtb_OUTPUT_1_0_g[6];
  real_T rtb_OUTPUT_1_0_f[6];
  real_T rtb_Euler_out[3];
  real_T rtb_Euler_out_h[3];
  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    // set solver stop time
    rtsiSetSolverStopTime(SatelliteServicing_Mission_M->solverInfo,
                          ((SatelliteServicing_Mission_M->Timing.clockTick0+1)*
      SatelliteServicing_Mission_M->Timing.stepSize0));
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep(SatelliteServicing_Mission_M)) {
    SatelliteServicing_Mission_M->Timing.t[0] = rtsiGetT
      (SatelliteServicing_Mission_M->solverInfo);
  }

  {
    __m128d tmp_10;
    __m128d tmp_z;
    NeParameterBundle expl_temp;
    NeParameterBundle expl_temp_0;
    NeParameterBundle expl_temp_1;
    NeParameterBundle expl_temp_2;
    NeslSimulationData *simulationData;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagTree;
    NeuDiagnosticTree *diagTree_0;
    NeuDiagnosticTree *diagTree_1;
    NeuDiagnosticTree *diagTree_2;
    NeuDiagnosticTree *diagnosticTree;
    NeuDiagnosticTree *diagnosticTree_0;
    NeuDiagnosticTree *diagnosticTree_1;
    NeuDiagnosticTree *diagnosticTree_2;
    NeuDiagnosticTree *diagnosticTree_3;
    NeuDiagnosticTree *diagnosticTree_4;
    NeuDiagnosticTree *diagnosticTree_5;
    NeuDiagnosticTree *diagnosticTree_6;
    NeuDiagnosticTree *diagnosticTree_7;
    NeuDiagnosticTree *diagnosticTree_8;
    NeuDiagnosticTree *diagnosticTree_9;
    NeuDiagnosticTree *diagnosticTree_a;
    NeuDiagnosticTree *diagnosticTree_b;
    NeuDiagnosticTree *diagnosticTree_c;
    NeuDiagnosticTree *diagnosticTree_d;
    char *msg;
    char *msg_0;
    char *msg_1;
    char *msg_2;
    char *msg_3;
    char *msg_4;
    char *msg_5;
    char *msg_6;
    char *msg_7;
    char *msg_8;
    char *msg_9;
    char *msg_a;
    char *msg_b;
    char *msg_c;
    char *msg_d;
    char *msg_e;
    char *msg_f;
    char *msg_g;
    char *msg_h;
    real_T rtb_OUTPUT_1_1[98];
    real_T tmp_3[37];
    real_T tmp_5[37];
    real_T rtb_Reshape[36];
    real_T tmp_a[25];
    real_T tmp_f[25];
    real_T tmp_k[25];
    real_T tmp_p[25];
    real_T tmp_r[25];
    real_T tmp_t[25];
    real_T tmp_v[25];
    real_T tmp_x[25];
    real_T tmp_1[24];
    real_T rtb_mat_h[16];
    real_T tmp_8[12];
    real_T tmp_d[12];
    real_T tmp_i[12];
    real_T tmp_n[12];
    real_T b_x[9];
    real_T rtb_Add1_b[6];
    real_T tmp_7[6];
    real_T tmp_c[6];
    real_T tmp_h[6];
    real_T tmp_m[6];
    real_T rtb_qOut[4];
    real_T rtb_qOut_l[4];
    real_T rtb_qOut_o[4];
    real_T Saturation1[3];
    real_T position[3];
    real_T rtb_OUTPUT_1_1_h[3];
    real_T rtb_OUTPUT_1_1_l[3];
    real_T rtb_OUTPUT_1_1_p[3];
    real_T rtb_OUTPUT_1_1_ph[3];
    real_T rtb_acceleration[3];
    real_T rtb_acceleration_k[3];
    real_T rtb_acceleration_kn[3];
    real_T tmp_11[3];
    real_T absx;
    real_T absxk;
    real_T absxk_tmp;
    real_T absxk_tmp_0;
    real_T absxk_tmp_1;
    real_T centerDist;
    real_T fov_radius;
    real_T nparams;
    real_T scale;
    real_T t;
    real_T time;
    real_T time_0;
    real_T time_1;
    real_T time_2;
    real_T time_3;
    real_T time_4;
    real_T time_5;
    real_T time_6;
    real_T time_7;
    real_T time_8;
    real_T time_9;
    real_T time_a;
    real_T time_b;
    real_T time_c;
    real_T time_d;
    real_T time_e;
    real_T time_f;
    real_T time_g;
    real_T time_h;
    real_T time_i;
    real_T time_j;
    real_T time_k;
    real_T time_l;
    real_T time_m;
    real_T time_n;
    real_T time_o;
    real_T time_p;
    real_T time_q;
    real_T time_r;
    real_T time_s;
    real_T time_tmp;
    real_T time_tmp_0;
    real_T *parameterBundle_mRealParameters;
    int32_T b;
    int32_T b_ii;
    int32_T b_j;
    int32_T b_x_tmp;
    int32_T i;
    int32_T idx;
    int_T tmp_4[8];
    int_T tmp_6[8];
    int_T tmp_2[7];
    int_T tmp_b[5];
    int_T tmp_g[5];
    int_T tmp_l[5];
    int_T tmp_q[5];
    int_T tmp_s[5];
    int_T tmp_u[5];
    int_T tmp_w[5];
    int_T tmp_y[5];
    int_T tmp_9[4];
    int_T tmp_e[4];
    int_T tmp_j[4];
    int_T tmp_o[4];
    int8_T ii_data[32];
    int8_T ii;
    boolean_T exitg1;
    boolean_T ok;
    boolean_T tmp;
    boolean_T tmp_0;

    // SimscapeExecutionBlock: '<S300>/STATE_1' incorporates:
    //   SimscapeExecutionBlock: '<S148>/OUTPUT_1_0'
    //   SimscapeExecutionBlock: '<S148>/OUTPUT_1_1'
    //   SimscapeExecutionBlock: '<S148>/STATE_1'
    //   SimscapeExecutionBlock: '<S178>/OUTPUT_1_0'
    //   SimscapeExecutionBlock: '<S178>/OUTPUT_1_1'
    //   SimscapeExecutionBlock: '<S178>/STATE_1'
    //   SimscapeExecutionBlock: '<S208>/OUTPUT_1_0'
    //   SimscapeExecutionBlock: '<S208>/OUTPUT_1_1'
    //   SimscapeExecutionBlock: '<S208>/STATE_1'
    //   SimscapeExecutionBlock: '<S238>/OUTPUT_1_0'
    //   SimscapeExecutionBlock: '<S238>/OUTPUT_1_1'
    //   SimscapeExecutionBlock: '<S238>/STATE_1'
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_1'

    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData);
    time_tmp = SatelliteServicing_Mission_M->Timing.t[0];
    time = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionServi[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    tmp = rtmIsMajorTimeStep(SatelliteServicing_Mission_M);
    simulationData->mData->mIsMajorTimeStep = tmp;
    tmp_0 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_0;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp_0 = rtsiIsSolverComputingJacobian
      (SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp_0;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_0 = rtsiIsModeUpdateTimeStep(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_2[0] = 0;
    tmp_1[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_1[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_1[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_1[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_2[1] = 4;
    tmp_1[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_1[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_1[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_1[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_2[2] = 8;
    tmp_1[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_1[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_1[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_1[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_2[3] = 12;
    tmp_1[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_1[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_1[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_1[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_2[4] = 16;
    tmp_1[16] = SatelliteServicing_Mission_B->INPUT_4_1_2[0];
    tmp_1[17] = SatelliteServicing_Mission_B->INPUT_4_1_2[1];
    tmp_1[18] = SatelliteServicing_Mission_B->INPUT_4_1_2[2];
    tmp_1[19] = SatelliteServicing_Mission_B->INPUT_4_1_2[3];
    tmp_2[5] = 20;
    tmp_1[20] = SatelliteServicing_Mission_B->INPUT_4_1_3[0];
    tmp_1[21] = SatelliteServicing_Mission_B->INPUT_4_1_3[1];
    tmp_1[22] = SatelliteServicing_Mission_B->INPUT_4_1_3[2];
    tmp_1[23] = SatelliteServicing_Mission_B->INPUT_4_1_3[3];
    tmp_2[6] = 24;
    simulationData->mData->mInputValues.mN = 24;
    simulationData->mData->mInputValues.mX = &tmp_1[0];
    simulationData->mData->mInputOffsets.mN = 7;
    simulationData->mData->mInputOffsets.mX = &tmp_2[0];
    simulationData->mData->mOutputs.mN = 13;
    simulationData->mData->mOutputs.mX = &SatelliteServicing_Mission_B->STATE_1
      [0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_tmp_0 = SatelliteServicing_Mission_M->Timing.t[0];
    time_0 = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
      }
    }

    // End of SimscapeExecutionBlock: '<S300>/STATE_1'
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // Product: '<S255>/Product5' incorporates:
      //   Constant: '<S249>/Constant1'
      //   DiscreteIntegrator: '<S255>/Discrete-Time Integrator1'

      SatelliteServicing_Mission_B->Product5[0] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[0] *
        SatelliteServicing_Mission_P.satControlData_Trans.Ki[0];
      SatelliteServicing_Mission_B->Product5[1] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[1] *
        SatelliteServicing_Mission_P.satControlData_Trans.Ki[1];
      SatelliteServicing_Mission_B->Product5[2] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[2] *
        SatelliteServicing_Mission_P.satControlData_Trans.Ki[2];
    }

    // SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData);
    time_1 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_1;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Modes;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_4[0] = 0;
    tmp_3[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_3[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_3[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_3[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_4[1] = 4;
    tmp_3[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_3[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_3[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_3[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_4[2] = 8;
    tmp_3[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_3[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_3[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_3[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_4[3] = 12;
    tmp_3[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_3[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_3[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_3[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_4[4] = 16;
    tmp_3[16] = SatelliteServicing_Mission_B->INPUT_4_1_2[0];
    tmp_3[17] = SatelliteServicing_Mission_B->INPUT_4_1_2[1];
    tmp_3[18] = SatelliteServicing_Mission_B->INPUT_4_1_2[2];
    tmp_3[19] = SatelliteServicing_Mission_B->INPUT_4_1_2[3];
    tmp_4[5] = 20;
    tmp_3[20] = SatelliteServicing_Mission_B->INPUT_4_1_3[0];
    tmp_3[21] = SatelliteServicing_Mission_B->INPUT_4_1_3[1];
    tmp_3[22] = SatelliteServicing_Mission_B->INPUT_4_1_3[2];
    tmp_3[23] = SatelliteServicing_Mission_B->INPUT_4_1_3[3];
    tmp_4[6] = 24;
    std::memcpy(&tmp_3[24], &SatelliteServicing_Mission_B->STATE_1[0], 13U *
                sizeof(real_T));
    tmp_4[7] = 37;
    simulationData->mData->mInputValues.mN = 37;
    simulationData->mData->mInputValues.mX = &tmp_3[0];
    simulationData->mData->mInputOffsets.mN = 8;
    simulationData->mData->mInputOffsets.mX = &tmp_4[0];
    simulationData->mData->mOutputs.mN = 75;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_2 = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_2;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr);
    diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_0 = rtw_diagnostics_msg(diagnosticTree_0);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
      }
    }

    for (i = 0; i <= 4; i += 2) {
      // Sum: '<S251>/Add'
      tmp_z = _mm_loadu_pd(&rtb_OUTPUT_1_0[i + 44]);
      tmp_10 = _mm_loadu_pd(&rtb_OUTPUT_1_0[i + 69]);
      _mm_storeu_pd(&rtb_Add1_b[i], _mm_sub_pd(tmp_z, tmp_10));
    }

    // Sum: '<S255>/Sum1' incorporates:
    //   Constant: '<S250>/Constant1'

    SatelliteServicing_Mission_B->controlErrorECEF[0] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdPos[0] - rtb_Add1_b[0];
    SatelliteServicing_Mission_B->controlErrorECEF[3] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdVel[0] - rtb_Add1_b[3];

    // Gain: '<S255>/Gain1' incorporates:
    //   Constant: '<S249>/Constant1'
    //   Product: '<S255>/Product3'
    //   Product: '<S255>/Product4'
    //   Product: '<S255>/Product5'
    //   Sum: '<S255>/Add1'

    nparams = ((SatelliteServicing_Mission_B->controlErrorECEF[0] *
                SatelliteServicing_Mission_P.satControlData_Trans.Kp[0] +
                SatelliteServicing_Mission_B->Product5[0]) +
               SatelliteServicing_Mission_P.satControlData_Trans.Kd[0] *
               SatelliteServicing_Mission_B->controlErrorECEF[3]) *
      SatelliteServicing_Mission_P.Gain1_Gain;

    // Sum: '<S255>/Sum1' incorporates:
    //   Constant: '<S250>/Constant1'

    SatelliteServicing_Mission_B->controlErrorECEF[1] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdPos[1] - rtb_Add1_b[1];
    SatelliteServicing_Mission_B->controlErrorECEF[4] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdVel[1] - rtb_Add1_b[4];

    // Gain: '<S255>/Gain1' incorporates:
    //   Constant: '<S249>/Constant1'
    //   Product: '<S255>/Product3'
    //   Product: '<S255>/Product4'
    //   Product: '<S255>/Product5'
    //   Sum: '<S255>/Add1'

    fov_radius = ((SatelliteServicing_Mission_B->controlErrorECEF[1] *
                   SatelliteServicing_Mission_P.satControlData_Trans.Kp[1] +
                   SatelliteServicing_Mission_B->Product5[1]) +
                  SatelliteServicing_Mission_P.satControlData_Trans.Kd[1] *
                  SatelliteServicing_Mission_B->controlErrorECEF[4]) *
      SatelliteServicing_Mission_P.Gain1_Gain;

    // Sum: '<S255>/Sum1' incorporates:
    //   Constant: '<S250>/Constant1'

    SatelliteServicing_Mission_B->controlErrorECEF[2] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdPos[2] - rtb_Add1_b[2];
    SatelliteServicing_Mission_B->controlErrorECEF[5] =
      SatelliteServicing_Mission_P.satControlData_Trans.cmdVel[2] - rtb_Add1_b[5];

    // Gain: '<S255>/Gain1' incorporates:
    //   Constant: '<S249>/Constant1'
    //   Product: '<S255>/Product3'
    //   Product: '<S255>/Product4'
    //   Product: '<S255>/Product5'
    //   Sum: '<S255>/Add1'

    centerDist = ((SatelliteServicing_Mission_B->controlErrorECEF[2] *
                   SatelliteServicing_Mission_P.satControlData_Trans.Kp[2] +
                   SatelliteServicing_Mission_B->Product5[2]) +
                  SatelliteServicing_Mission_P.satControlData_Trans.Kd[2] *
                  SatelliteServicing_Mission_B->controlErrorECEF[5]) *
      SatelliteServicing_Mission_P.Gain1_Gain;

    // Saturate: '<S253>/Saturation1'
    if (fov_radius >
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S300>/INPUT_1_1_1'
      SatelliteServicing_Mission_B->INPUT_1_1_1[0] =
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else if (fov_radius <
               -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S300>/INPUT_1_1_1'
      SatelliteServicing_Mission_B->INPUT_1_1_1[0] =
        -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else {
      // SimscapeInputBlock: '<S300>/INPUT_1_1_1'
      SatelliteServicing_Mission_B->INPUT_1_1_1[0] = fov_radius;
    }

    // SimscapeInputBlock: '<S300>/INPUT_1_1_1'
    SatelliteServicing_Mission_B->INPUT_1_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1[3] = 0.0;

    // Saturate: '<S253>/Saturation1'
    if (nparams > SatelliteServicing_Mission_P.satControlData_Trans.forceLimit)
    {
      // SimscapeInputBlock: '<S300>/INPUT_2_1_1'
      SatelliteServicing_Mission_B->INPUT_2_1_1[0] =
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else if (nparams <
               -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S300>/INPUT_2_1_1'
      SatelliteServicing_Mission_B->INPUT_2_1_1[0] =
        -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else {
      // SimscapeInputBlock: '<S300>/INPUT_2_1_1'
      SatelliteServicing_Mission_B->INPUT_2_1_1[0] = nparams;
    }

    // SimscapeInputBlock: '<S300>/INPUT_2_1_1'
    SatelliteServicing_Mission_B->INPUT_2_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1[3] = 0.0;

    // Saturate: '<S253>/Saturation1'
    if (centerDist >
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S300>/INPUT_3_1_1'
      SatelliteServicing_Mission_B->INPUT_3_1_1[0] =
        SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else if (centerDist <
               -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit) {
      // SimscapeInputBlock: '<S300>/INPUT_3_1_1'
      SatelliteServicing_Mission_B->INPUT_3_1_1[0] =
        -SatelliteServicing_Mission_P.satControlData_Trans.forceLimit;
    } else {
      // SimscapeInputBlock: '<S300>/INPUT_3_1_1'
      SatelliteServicing_Mission_B->INPUT_3_1_1[0] = centerDist;
    }

    // SimscapeInputBlock: '<S300>/INPUT_3_1_1'
    SatelliteServicing_Mission_B->INPUT_3_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1[3] = 0.0;
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // Product: '<S254>/Product5' incorporates:
      //   Constant: '<S249>/Constant2'
      //   DiscreteIntegrator: '<S254>/Discrete-Time Integrator1'

      SatelliteServicing_Mission_B->Product5_b[0] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[0] *
        SatelliteServicing_Mission_P.satControlData_Rot.Ki[0];
      SatelliteServicing_Mission_B->Product5_b[1] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[1] *
        SatelliteServicing_Mission_P.satControlData_Rot.Ki[1];
      SatelliteServicing_Mission_B->Product5_b[2] =
        SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[2] *
        SatelliteServicing_Mission_P.satControlData_Rot.Ki[2];
    }

    // MATLAB Function: '<S7>/Reorder_to_XYZ' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServici_Reorder_to_XYZ(&rtb_OUTPUT_1_0[38], rtb_Euler_out_h);

    // MATLAB Function: '<S248>/Reorder_to_XYZ' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServici_Reorder_to_XYZ(&rtb_OUTPUT_1_0[63], rtb_Euler_out);

    // Sum: '<S251>/Add1'
    rtb_Add1_b[3] = rtb_OUTPUT_1_0[41] - rtb_OUTPUT_1_0[66];
    rtb_Add1_b[4] = rtb_OUTPUT_1_0[42] - rtb_OUTPUT_1_0[67];
    rtb_Add1_b[5] = rtb_OUTPUT_1_0[43] - rtb_OUTPUT_1_0[68];

    // Sum: '<S254>/Sum1' incorporates:
    //   Constant: '<S250>/Constant2'
    //   Sum: '<S251>/Add1'

    nparams = SatelliteServicing_Mission_P.satControlData_Rot.cmdAngle[0] -
      (rtb_Euler_out_h[0] - rtb_Euler_out[0]);
    SatelliteServicing_Mission_B->controlErrorECEF_l[0] = nparams;
    fov_radius = SatelliteServicing_Mission_P.satControlData_Rot.cmdRate[0] -
      rtb_Add1_b[3];
    SatelliteServicing_Mission_B->controlErrorECEF_l[3] = fov_radius;

    // Gain: '<S254>/Gain1' incorporates:
    //   Constant: '<S249>/Constant2'
    //   Product: '<S254>/Product3'
    //   Product: '<S254>/Product4'
    //   Product: '<S254>/Product5'
    //   Sum: '<S254>/Add1'

    nparams = ((nparams * SatelliteServicing_Mission_P.satControlData_Rot.Kp[0]
                + SatelliteServicing_Mission_B->Product5_b[0]) + fov_radius *
               SatelliteServicing_Mission_P.satControlData_Rot.Kd[0]) *
      SatelliteServicing_Mission_P.Gain1_Gain_m;
    rtb_acceleration_kn[0] = nparams;

    // Saturate: '<S252>/Saturation1'
    if (nparams > SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // Saturate: '<S252>/Saturation1'
      Saturation1[0] =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else if (nparams <
               -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // Saturate: '<S252>/Saturation1'
      Saturation1[0] =
        -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else {
      // Saturate: '<S252>/Saturation1'
      Saturation1[0] = nparams;
    }

    // Sum: '<S254>/Sum1' incorporates:
    //   Constant: '<S250>/Constant2'
    //   Sum: '<S251>/Add1'

    nparams = SatelliteServicing_Mission_P.satControlData_Rot.cmdAngle[1] -
      (rtb_Euler_out_h[1] - rtb_Euler_out[1]);
    SatelliteServicing_Mission_B->controlErrorECEF_l[1] = nparams;
    fov_radius = SatelliteServicing_Mission_P.satControlData_Rot.cmdRate[1] -
      rtb_Add1_b[4];
    SatelliteServicing_Mission_B->controlErrorECEF_l[4] = fov_radius;

    // Gain: '<S254>/Gain1' incorporates:
    //   Constant: '<S249>/Constant2'
    //   Product: '<S254>/Product3'
    //   Product: '<S254>/Product4'
    //   Product: '<S254>/Product5'
    //   Sum: '<S254>/Add1'

    nparams = ((nparams * SatelliteServicing_Mission_P.satControlData_Rot.Kp[1]
                + SatelliteServicing_Mission_B->Product5_b[1]) + fov_radius *
               SatelliteServicing_Mission_P.satControlData_Rot.Kd[1]) *
      SatelliteServicing_Mission_P.Gain1_Gain_m;
    rtb_acceleration_kn[1] = nparams;

    // Saturate: '<S252>/Saturation1'
    if (nparams > SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // Saturate: '<S252>/Saturation1'
      Saturation1[1] =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else if (nparams <
               -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // Saturate: '<S252>/Saturation1'
      Saturation1[1] =
        -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else {
      // Saturate: '<S252>/Saturation1'
      Saturation1[1] = nparams;
    }

    // Sum: '<S254>/Sum1' incorporates:
    //   Constant: '<S250>/Constant2'
    //   Sum: '<S251>/Add1'

    nparams = SatelliteServicing_Mission_P.satControlData_Rot.cmdAngle[2] -
      (rtb_Euler_out_h[2] - rtb_Euler_out[2]);
    SatelliteServicing_Mission_B->controlErrorECEF_l[2] = nparams;
    fov_radius = SatelliteServicing_Mission_P.satControlData_Rot.cmdRate[2] -
      rtb_Add1_b[5];
    SatelliteServicing_Mission_B->controlErrorECEF_l[5] = fov_radius;

    // Gain: '<S254>/Gain1' incorporates:
    //   Constant: '<S249>/Constant2'
    //   Product: '<S254>/Product3'
    //   Product: '<S254>/Product4'
    //   Product: '<S254>/Product5'
    //   Sum: '<S254>/Add1'

    nparams = ((nparams * SatelliteServicing_Mission_P.satControlData_Rot.Kp[2]
                + SatelliteServicing_Mission_B->Product5_b[2]) + fov_radius *
               SatelliteServicing_Mission_P.satControlData_Rot.Kd[2]) *
      SatelliteServicing_Mission_P.Gain1_Gain_m;
    rtb_acceleration_kn[2] = nparams;

    // Saturate: '<S252>/Saturation1'
    if (nparams > SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit) {
      // Saturate: '<S252>/Saturation1'
      Saturation1[2] =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;

      // SimscapeInputBlock: '<S300>/INPUT_4_1_3'
      SatelliteServicing_Mission_B->INPUT_4_1_3[0] =
        SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
    } else {
      if (nparams < -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit)
      {
        // Saturate: '<S252>/Saturation1'
        Saturation1[2] =
          -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
      } else {
        // Saturate: '<S252>/Saturation1'
        Saturation1[2] = nparams;
      }

      if (nparams < -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit)
      {
        // SimscapeInputBlock: '<S300>/INPUT_4_1_3'
        SatelliteServicing_Mission_B->INPUT_4_1_3[0] =
          -SatelliteServicing_Mission_P.satControlData_Rot.torqueLimit;
      } else {
        // SimscapeInputBlock: '<S300>/INPUT_4_1_3'
        SatelliteServicing_Mission_B->INPUT_4_1_3[0] = nparams;
      }
    }

    // SimscapeInputBlock: '<S300>/INPUT_4_1_1'
    SatelliteServicing_Mission_B->INPUT_4_1_1[0] = Saturation1[0];
    SatelliteServicing_Mission_B->INPUT_4_1_1[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_1[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_1[3] = 0.0;

    // SimscapeInputBlock: '<S300>/INPUT_4_1_2'
    SatelliteServicing_Mission_B->INPUT_4_1_2[0] = Saturation1[1];
    SatelliteServicing_Mission_B->INPUT_4_1_2[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_2[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_2[3] = 0.0;

    // SimscapeInputBlock: '<S300>/INPUT_4_1_3'
    SatelliteServicing_Mission_B->INPUT_4_1_3[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_3[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_4_1_3[3] = 0.0;

    // SimscapeExecutionBlock: '<S300>/OUTPUT_1_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData);
    time_3 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_3;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Modes;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_6[0] = 0;
    tmp_5[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_5[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_5[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_5[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_6[1] = 4;
    tmp_5[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_5[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_5[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_5[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_6[2] = 8;
    tmp_5[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_5[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_5[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_5[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_6[3] = 12;
    tmp_5[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_5[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_5[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_5[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_6[4] = 16;
    tmp_5[16] = SatelliteServicing_Mission_B->INPUT_4_1_2[0];
    tmp_5[17] = SatelliteServicing_Mission_B->INPUT_4_1_2[1];
    tmp_5[18] = SatelliteServicing_Mission_B->INPUT_4_1_2[2];
    tmp_5[19] = SatelliteServicing_Mission_B->INPUT_4_1_2[3];
    tmp_6[5] = 20;
    tmp_5[20] = SatelliteServicing_Mission_B->INPUT_4_1_3[0];
    tmp_5[21] = SatelliteServicing_Mission_B->INPUT_4_1_3[1];
    tmp_5[22] = SatelliteServicing_Mission_B->INPUT_4_1_3[2];
    tmp_5[23] = SatelliteServicing_Mission_B->INPUT_4_1_3[3];
    tmp_6[6] = 24;
    std::memcpy(&tmp_5[24], &SatelliteServicing_Mission_B->STATE_1[0], 13U *
                sizeof(real_T));
    tmp_6[7] = 37;
    simulationData->mData->mInputValues.mN = 37;
    simulationData->mData->mInputValues.mX = &tmp_5[0];
    simulationData->mData->mInputOffsets.mN = 8;
    simulationData->mData->mInputOffsets.mX = &tmp_6[0];
    simulationData->mData->mOutputs.mN = 98;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_1[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_4 = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_4;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr);
    diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_1 = rtw_diagnostics_msg(diagnosticTree_1);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
      }
    }

    // MATLAB Function: '<S6>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(&rtb_OUTPUT_1_0[4], &rtb_OUTPUT_1_0[19],
      rtb_mat_h);

    // MATLAB Function: '<S7>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(&rtb_OUTPUT_1_0[29], &rtb_OUTPUT_1_0[44],
      rtb_mat_h);

    // MATLAB Function: '<S248>/formPoseMat' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServicing__formPoseMat(&rtb_OUTPUT_1_0[54], &rtb_OUTPUT_1_0[69],
      rtb_mat_h);

    // MATLAB Function: '<S6>/positiveQuat' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServicing_positiveQuat(&rtb_OUTPUT_1_0[0], rtb_qOut_l);

    // MATLAB Function: '<S7>/positiveQuat' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServicing_positiveQuat(&rtb_OUTPUT_1_0[25], rtb_qOut_o);

    // MATLAB Function: '<S248>/positiveQuat' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServicing_positiveQuat(&rtb_OUTPUT_1_0[50], rtb_qOut);

    // MATLAB Function: '<S248>/quat2MRP'
    SatelliteServicing_Mis_quat2MRP(rtb_qOut, Saturation1);

    // MATLAB Function: '<S7>/quat2MRP'
    SatelliteServicing_Mis_quat2MRP(rtb_qOut_o, Saturation1);

    // MATLAB Function: '<S6>/quat2MRP'
    SatelliteServicing_Mis_quat2MRP(rtb_qOut_l, Saturation1);

    // MATLAB Function: '<S6>/Reorder_to_XYZ' incorporates:
    //   SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    SatelliteServici_Reorder_to_XYZ(&rtb_OUTPUT_1_0[13], Saturation1);
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // SimscapeRtp: '<S125>/RTP_1' incorporates:
      //   Constant: '<S119>/Subsystem_around_RTP_5F0325A4_PxPositionTargetValue'
      //   Constant: '<S119>/Subsystem_around_RTP_5F0325A4_PxVelocityTargetValue'
      //   Constant: '<S119>/Subsystem_around_RTP_5F0325A4_PyPositionTargetValue'
      //   Constant: '<S119>/Subsystem_around_RTP_5F0325A4_PyVelocityTargetValue'
      //   Constant: '<S119>/Subsystem_around_RTP_5F0325A4_PzPositionTargetValue'
      //   Constant: '<S119>/Subsystem_around_RTP_5F0325A4_PzVelocityTargetValue'

      if (SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded) {
        tmp_7[0] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_position[0];
        tmp_7[1] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_velocity[0];
        tmp_7[2] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_position[1];
        tmp_7[3] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_velocity[1];
        tmp_7[4] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_position[2];
        tmp_7[5] = SatelliteServicing_Mission_P.cubesat[0].IC.rel_velocity[2];
        parameterBundle_mRealParameters = &tmp_7[0];
        diagnosticManager = rtw_create_diagnostics();
        diagTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
        expl_temp.mRealParameters.mN = 6;
        expl_temp.mRealParameters.mX = parameterBundle_mRealParameters;
        expl_temp.mLogicalParameters.mN = 0;
        expl_temp.mLogicalParameters.mX = nullptr;
        expl_temp.mIntegerParameters.mN = 0;
        expl_temp.mIntegerParameters.mX = nullptr;
        expl_temp.mIndexParameters.mN = 0;
        expl_temp.mIndexParameters.mX = nullptr;
        ok = nesl_rtp_manager_set_rtps(static_cast<NeslRtpManager *>
          (SatelliteServicing_Mission_DW->RTP_1_RtpManager),
          SatelliteServicing_Mission_M->Timing.t[0], expl_temp,
          diagnosticManager);
        if (!ok) {
          ok = error_buffer_is_empty(rtmGetErrorStatus
            (SatelliteServicing_Mission_M));
          if (ok) {
            msg_2 = rtw_diagnostics_msg(diagTree);
            rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_2);
          }
        }
      }

      SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded = false;

      // End of SimscapeRtp: '<S125>/RTP_1'
    }

    // SimscapeExecutionBlock: '<S148>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData_g);
    time_5 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_5;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionMissi[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete_k;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes_l;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    ok = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = ok;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_9[0] = 0;
    tmp_8[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[0];
    tmp_8[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[1];
    tmp_8[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[2];
    tmp_8[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[3];
    tmp_9[1] = 4;
    tmp_8[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[0];
    tmp_8[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[1];
    tmp_8[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[2];
    tmp_8[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[3];
    tmp_9[2] = 8;
    tmp_8[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[0];
    tmp_8[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[1];
    tmp_8[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[2];
    tmp_8[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[3];
    tmp_9[3] = 12;
    simulationData->mData->mInputValues.mN = 12;
    simulationData->mData->mInputValues.mX = &tmp_8[0];
    simulationData->mData->mInputOffsets.mN = 4;
    simulationData->mData->mInputOffsets.mX = &tmp_9[0];
    simulationData->mData->mOutputs.mN = 13;
    simulationData->mData->mOutputs.mX =
      &SatelliteServicing_Mission_B->STATE_1_o[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_6 = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_6;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_a);
    diagnosticTree_2 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_i), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_3 = rtw_diagnostics_msg(diagnosticTree_2);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_3);
      }
    }

    // SimscapeExecutionBlock: '<S148>/OUTPUT_1_0'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_b);
    time_7 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_7;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Discrete_c;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Modes_j;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_b[0] = 0;
    tmp_a[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[0];
    tmp_a[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[1];
    tmp_a[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[2];
    tmp_a[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[3];
    tmp_b[1] = 4;
    tmp_a[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[0];
    tmp_a[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[1];
    tmp_a[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[2];
    tmp_a[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[3];
    tmp_b[2] = 8;
    tmp_a[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[0];
    tmp_a[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[1];
    tmp_a[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[2];
    tmp_a[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[3];
    tmp_b[3] = 12;
    std::memcpy(&tmp_a[12], &SatelliteServicing_Mission_B->STATE_1_o[0], 13U *
                sizeof(real_T));
    tmp_b[4] = 25;
    simulationData->mData->mInputValues.mN = 25;
    simulationData->mData->mInputValues.mX = &tmp_a[0];
    simulationData->mData->mInputOffsets.mN = 5;
    simulationData->mData->mInputOffsets.mX = &tmp_b[0];
    simulationData->mData->mOutputs.mN = 6;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0_n[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_8 = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_8;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_g);
    diagnosticTree_3 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_j), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_4 = rtw_diagnostics_msg(diagnosticTree_3);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_4);
      }
    }

    // MATLAB Function: '<S120>/CW_Equations' incorporates:
    //   Constant: '<S113>/Constant1'
    //   SimscapeExecutionBlock: '<S148>/OUTPUT_1_0'

    SatelliteServicing_CW_Equations(&rtb_OUTPUT_1_0_n[0], &rtb_OUTPUT_1_0_n[3],
      SatelliteServicing_Mission_P.orbit.mean_motion, rtb_acceleration_k);
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // SimscapeRtp: '<S155>/RTP_1' incorporates:
      //   Constant: '<S149>/Subsystem_around_RTP_517418D9_PxPositionTargetValue'
      //   Constant: '<S149>/Subsystem_around_RTP_517418D9_PxVelocityTargetValue'
      //   Constant: '<S149>/Subsystem_around_RTP_517418D9_PyPositionTargetValue'
      //   Constant: '<S149>/Subsystem_around_RTP_517418D9_PyVelocityTargetValue'
      //   Constant: '<S149>/Subsystem_around_RTP_517418D9_PzPositionTargetValue'
      //   Constant: '<S149>/Subsystem_around_RTP_517418D9_PzVelocityTargetValue'

      if (SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_k) {
        tmp_c[0] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_position[0];
        tmp_c[1] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_velocity[0];
        tmp_c[2] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_position[1];
        tmp_c[3] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_velocity[1];
        tmp_c[4] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_position[2];
        tmp_c[5] = SatelliteServicing_Mission_P.cubesat[1].IC.rel_velocity[2];
        parameterBundle_mRealParameters = &tmp_c[0];
        diagnosticManager = rtw_create_diagnostics();
        diagTree_0 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
        expl_temp_0.mRealParameters.mN = 6;
        expl_temp_0.mRealParameters.mX = parameterBundle_mRealParameters;
        expl_temp_0.mLogicalParameters.mN = 0;
        expl_temp_0.mLogicalParameters.mX = nullptr;
        expl_temp_0.mIntegerParameters.mN = 0;
        expl_temp_0.mIntegerParameters.mX = nullptr;
        expl_temp_0.mIndexParameters.mN = 0;
        expl_temp_0.mIndexParameters.mX = nullptr;
        ok = nesl_rtp_manager_set_rtps(static_cast<NeslRtpManager *>
          (SatelliteServicing_Mission_DW->RTP_1_RtpManager_k),
          SatelliteServicing_Mission_M->Timing.t[0], expl_temp_0,
          diagnosticManager);
        if (!ok) {
          ok = error_buffer_is_empty(rtmGetErrorStatus
            (SatelliteServicing_Mission_M));
          if (ok) {
            msg_5 = rtw_diagnostics_msg(diagTree_0);
            rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_5);
          }
        }
      }

      SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_k = false;

      // End of SimscapeRtp: '<S155>/RTP_1'
    }

    // SimscapeExecutionBlock: '<S178>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData_f);
    time_9 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_9;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_m[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete_l;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes_l0;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    ok = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = ok;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_e[0] = 0;
    tmp_d[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[0];
    tmp_d[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[1];
    tmp_d[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[2];
    tmp_d[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[3];
    tmp_e[1] = 4;
    tmp_d[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[0];
    tmp_d[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[1];
    tmp_d[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[2];
    tmp_d[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[3];
    tmp_e[2] = 8;
    tmp_d[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[0];
    tmp_d[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[1];
    tmp_d[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[2];
    tmp_d[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[3];
    tmp_e[3] = 12;
    simulationData->mData->mInputValues.mN = 12;
    simulationData->mData->mInputValues.mX = &tmp_d[0];
    simulationData->mData->mInputOffsets.mN = 4;
    simulationData->mData->mInputOffsets.mX = &tmp_e[0];
    simulationData->mData->mOutputs.mN = 13;
    simulationData->mData->mOutputs.mX =
      &SatelliteServicing_Mission_B->STATE_1_n[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_a = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_a;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_p);
    diagnosticTree_4 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_n), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_6 = rtw_diagnostics_msg(diagnosticTree_4);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_6);
      }
    }

    // SimscapeExecutionBlock: '<S178>/OUTPUT_1_0'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_n);
    time_b = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_b;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Discrete_cj;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Modes_m;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_g[0] = 0;
    tmp_f[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[0];
    tmp_f[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[1];
    tmp_f[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[2];
    tmp_f[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[3];
    tmp_g[1] = 4;
    tmp_f[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[0];
    tmp_f[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[1];
    tmp_f[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[2];
    tmp_f[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[3];
    tmp_g[2] = 8;
    tmp_f[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[0];
    tmp_f[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[1];
    tmp_f[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[2];
    tmp_f[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[3];
    tmp_g[3] = 12;
    std::memcpy(&tmp_f[12], &SatelliteServicing_Mission_B->STATE_1_n[0], 13U *
                sizeof(real_T));
    tmp_g[4] = 25;
    simulationData->mData->mInputValues.mN = 25;
    simulationData->mData->mInputValues.mX = &tmp_f[0];
    simulationData->mData->mInputOffsets.mN = 5;
    simulationData->mData->mInputOffsets.mX = &tmp_g[0];
    simulationData->mData->mOutputs.mN = 6;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0_b[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_c = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_c;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_m);
    diagnosticTree_5 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_g), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_7 = rtw_diagnostics_msg(diagnosticTree_5);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_7);
      }
    }

    // MATLAB Function: '<S150>/CW_Equations' incorporates:
    //   Constant: '<S113>/Constant1'
    //   SimscapeExecutionBlock: '<S178>/OUTPUT_1_0'

    SatelliteServicing_CW_Equations(&rtb_OUTPUT_1_0_b[0], &rtb_OUTPUT_1_0_b[3],
      SatelliteServicing_Mission_P.orbit.mean_motion, rtb_acceleration);
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // SimscapeRtp: '<S185>/RTP_1' incorporates:
      //   Constant: '<S179>/Subsystem_around_RTP_6835F894_PxPositionTargetValue'
      //   Constant: '<S179>/Subsystem_around_RTP_6835F894_PxVelocityTargetValue'
      //   Constant: '<S179>/Subsystem_around_RTP_6835F894_PyPositionTargetValue'
      //   Constant: '<S179>/Subsystem_around_RTP_6835F894_PyVelocityTargetValue'
      //   Constant: '<S179>/Subsystem_around_RTP_6835F894_PzPositionTargetValue'
      //   Constant: '<S179>/Subsystem_around_RTP_6835F894_PzVelocityTargetValue'

      if (SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_a) {
        tmp_h[0] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_position[0];
        tmp_h[1] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_velocity[0];
        tmp_h[2] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_position[1];
        tmp_h[3] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_velocity[1];
        tmp_h[4] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_position[2];
        tmp_h[5] = SatelliteServicing_Mission_P.cubesat[2].IC.rel_velocity[2];
        parameterBundle_mRealParameters = &tmp_h[0];
        diagnosticManager = rtw_create_diagnostics();
        diagTree_1 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
        expl_temp_1.mRealParameters.mN = 6;
        expl_temp_1.mRealParameters.mX = parameterBundle_mRealParameters;
        expl_temp_1.mLogicalParameters.mN = 0;
        expl_temp_1.mLogicalParameters.mX = nullptr;
        expl_temp_1.mIntegerParameters.mN = 0;
        expl_temp_1.mIntegerParameters.mX = nullptr;
        expl_temp_1.mIndexParameters.mN = 0;
        expl_temp_1.mIndexParameters.mX = nullptr;
        ok = nesl_rtp_manager_set_rtps(static_cast<NeslRtpManager *>
          (SatelliteServicing_Mission_DW->RTP_1_RtpManager_a),
          SatelliteServicing_Mission_M->Timing.t[0], expl_temp_1,
          diagnosticManager);
        if (!ok) {
          ok = error_buffer_is_empty(rtmGetErrorStatus
            (SatelliteServicing_Mission_M));
          if (ok) {
            msg_8 = rtw_diagnostics_msg(diagTree_1);
            rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_8);
          }
        }
      }

      SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_a = false;

      // End of SimscapeRtp: '<S185>/RTP_1'
    }

    // SimscapeExecutionBlock: '<S208>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData_k);
    time_d = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_d;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_k[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete_k5;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes_j;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    ok = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = ok;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_j[0] = 0;
    tmp_i[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[0];
    tmp_i[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[1];
    tmp_i[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[2];
    tmp_i[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[3];
    tmp_j[1] = 4;
    tmp_i[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[0];
    tmp_i[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[1];
    tmp_i[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[2];
    tmp_i[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[3];
    tmp_j[2] = 8;
    tmp_i[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[0];
    tmp_i[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[1];
    tmp_i[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[2];
    tmp_i[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[3];
    tmp_j[3] = 12;
    simulationData->mData->mInputValues.mN = 12;
    simulationData->mData->mInputValues.mX = &tmp_i[0];
    simulationData->mData->mInputOffsets.mN = 4;
    simulationData->mData->mInputOffsets.mX = &tmp_j[0];
    simulationData->mData->mOutputs.mN = 13;
    simulationData->mData->mOutputs.mX =
      &SatelliteServicing_Mission_B->STATE_1_b[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_e = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_e;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_pq);
    diagnosticTree_6 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_l), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_9 = rtw_diagnostics_msg(diagnosticTree_6);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_9);
      }
    }

    // SimscapeExecutionBlock: '<S208>/OUTPUT_1_0'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_g);
    time_f = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_f;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Discrete_h;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Modes_n;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_l[0] = 0;
    tmp_k[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[0];
    tmp_k[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[1];
    tmp_k[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[2];
    tmp_k[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[3];
    tmp_l[1] = 4;
    tmp_k[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[0];
    tmp_k[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[1];
    tmp_k[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[2];
    tmp_k[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[3];
    tmp_l[2] = 8;
    tmp_k[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[0];
    tmp_k[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[1];
    tmp_k[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[2];
    tmp_k[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[3];
    tmp_l[3] = 12;
    std::memcpy(&tmp_k[12], &SatelliteServicing_Mission_B->STATE_1_b[0], 13U *
                sizeof(real_T));
    tmp_l[4] = 25;
    simulationData->mData->mInputValues.mN = 25;
    simulationData->mData->mInputValues.mX = &tmp_k[0];
    simulationData->mData->mInputOffsets.mN = 5;
    simulationData->mData->mInputOffsets.mX = &tmp_l[0];
    simulationData->mData->mOutputs.mN = 6;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0_g[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_g = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_g;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_a);
    diagnosticTree_7 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_jb), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_a = rtw_diagnostics_msg(diagnosticTree_7);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_a);
      }
    }

    // MATLAB Function: '<S180>/CW_Equations' incorporates:
    //   Constant: '<S113>/Constant1'
    //   SimscapeExecutionBlock: '<S208>/OUTPUT_1_0'

    SatelliteServicing_CW_Equations(&rtb_OUTPUT_1_0_g[0], &rtb_OUTPUT_1_0_g[3],
      SatelliteServicing_Mission_P.orbit.mean_motion, Saturation1);
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // SimscapeRtp: '<S215>/RTP_1' incorporates:
      //   Constant: '<S209>/Subsystem_around_RTP_84B5FE6B_PxPositionTargetValue'
      //   Constant: '<S209>/Subsystem_around_RTP_84B5FE6B_PxVelocityTargetValue'
      //   Constant: '<S209>/Subsystem_around_RTP_84B5FE6B_PyPositionTargetValue'
      //   Constant: '<S209>/Subsystem_around_RTP_84B5FE6B_PyVelocityTargetValue'
      //   Constant: '<S209>/Subsystem_around_RTP_84B5FE6B_PzPositionTargetValue'
      //   Constant: '<S209>/Subsystem_around_RTP_84B5FE6B_PzVelocityTargetValue'

      if (SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_l) {
        tmp_m[0] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_position[0];
        tmp_m[1] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_velocity[0];
        tmp_m[2] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_position[1];
        tmp_m[3] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_velocity[1];
        tmp_m[4] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_position[2];
        tmp_m[5] = SatelliteServicing_Mission_P.cubesat[3].IC.rel_velocity[2];
        parameterBundle_mRealParameters = &tmp_m[0];
        diagnosticManager = rtw_create_diagnostics();
        diagTree_2 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
        expl_temp_2.mRealParameters.mN = 6;
        expl_temp_2.mRealParameters.mX = parameterBundle_mRealParameters;
        expl_temp_2.mLogicalParameters.mN = 0;
        expl_temp_2.mLogicalParameters.mX = nullptr;
        expl_temp_2.mIntegerParameters.mN = 0;
        expl_temp_2.mIntegerParameters.mX = nullptr;
        expl_temp_2.mIndexParameters.mN = 0;
        expl_temp_2.mIndexParameters.mX = nullptr;
        ok = nesl_rtp_manager_set_rtps(static_cast<NeslRtpManager *>
          (SatelliteServicing_Mission_DW->RTP_1_RtpManager_n),
          SatelliteServicing_Mission_M->Timing.t[0], expl_temp_2,
          diagnosticManager);
        if (!ok) {
          ok = error_buffer_is_empty(rtmGetErrorStatus
            (SatelliteServicing_Mission_M));
          if (ok) {
            msg_b = rtw_diagnostics_msg(diagTree_2);
            rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_b);
          }
        }
      }

      SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_l = false;

      // End of SimscapeRtp: '<S215>/RTP_1'
    }

    // SimscapeExecutionBlock: '<S238>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData_m);
    time_h = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_h;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_n[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete_h;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes_h;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    ok = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = ok;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_o[0] = 0;
    tmp_n[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[0];
    tmp_n[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[1];
    tmp_n[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[2];
    tmp_n[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[3];
    tmp_o[1] = 4;
    tmp_n[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[0];
    tmp_n[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[1];
    tmp_n[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[2];
    tmp_n[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[3];
    tmp_o[2] = 8;
    tmp_n[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[0];
    tmp_n[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[1];
    tmp_n[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[2];
    tmp_n[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[3];
    tmp_o[3] = 12;
    simulationData->mData->mInputValues.mN = 12;
    simulationData->mData->mInputValues.mX = &tmp_n[0];
    simulationData->mData->mInputOffsets.mN = 4;
    simulationData->mData->mInputOffsets.mX = &tmp_o[0];
    simulationData->mData->mOutputs.mN = 13;
    simulationData->mData->mOutputs.mX =
      &SatelliteServicing_Mission_B->STATE_1_l[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_i = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_i;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_i);
    diagnosticTree_8 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_j), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_c = rtw_diagnostics_msg(diagnosticTree_8);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_c);
      }
    }

    // SimscapeExecutionBlock: '<S238>/OUTPUT_1_0'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_o);
    time_j = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_j;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Discrete_f;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_0_Modes_p;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_q[0] = 0;
    tmp_p[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[0];
    tmp_p[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[1];
    tmp_p[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[2];
    tmp_p[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[3];
    tmp_q[1] = 4;
    tmp_p[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[0];
    tmp_p[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[1];
    tmp_p[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[2];
    tmp_p[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[3];
    tmp_q[2] = 8;
    tmp_p[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[0];
    tmp_p[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[1];
    tmp_p[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[2];
    tmp_p[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[3];
    tmp_q[3] = 12;
    std::memcpy(&tmp_p[12], &SatelliteServicing_Mission_B->STATE_1_l[0], 13U *
                sizeof(real_T));
    tmp_q[4] = 25;
    simulationData->mData->mInputValues.mN = 25;
    simulationData->mData->mInputValues.mX = &tmp_p[0];
    simulationData->mData->mInputOffsets.mN = 5;
    simulationData->mData->mInputOffsets.mX = &tmp_q[0];
    simulationData->mData->mOutputs.mN = 6;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0_f[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_k = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_k;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_i);
    diagnosticTree_9 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_a), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_d = rtw_diagnostics_msg(diagnosticTree_9);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_d);
      }
    }

    // MATLAB Function: '<S210>/CW_Equations' incorporates:
    //   Constant: '<S113>/Constant1'
    //   SimscapeExecutionBlock: '<S238>/OUTPUT_1_0'

    SatelliteServicing_CW_Equations(&rtb_OUTPUT_1_0_f[0], &rtb_OUTPUT_1_0_f[3],
      SatelliteServicing_Mission_P.orbit.mean_motion, rtb_acceleration_kn);

    // Reshape: '<S114>/Reshape'
    for (i = 0; i < 6; i++) {
      rtb_Reshape[i] = rtb_OUTPUT_1_0_n[i];
    }

    rtb_Reshape[6] = rtb_acceleration_k[0];
    rtb_Reshape[7] = rtb_acceleration_k[1];
    rtb_Reshape[8] = rtb_acceleration_k[2];
    for (i = 0; i < 6; i++) {
      rtb_Reshape[i + 9] = rtb_OUTPUT_1_0_b[i];
    }

    rtb_Reshape[15] = rtb_acceleration[0];
    rtb_Reshape[16] = rtb_acceleration[1];
    rtb_Reshape[17] = rtb_acceleration[2];
    for (i = 0; i < 6; i++) {
      rtb_Reshape[i + 18] = rtb_OUTPUT_1_0_g[i];
    }

    rtb_Reshape[24] = Saturation1[0];
    rtb_Reshape[25] = Saturation1[1];
    rtb_Reshape[26] = Saturation1[2];
    for (i = 0; i < 6; i++) {
      rtb_Reshape[i + 27] = rtb_OUTPUT_1_0_f[i];
    }

    rtb_Reshape[33] = rtb_acceleration_kn[0];
    rtb_Reshape[34] = rtb_acceleration_kn[1];
    rtb_Reshape[35] = rtb_acceleration_kn[2];

    // End of Reshape: '<S114>/Reshape'
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      for (i = 0; i < 32; i++) {
        // Delay: '<S114>/Delay' incorporates:
        //   Constant: '<S114>/Constant4'

        if (SatelliteServicing_Mission_DW->icLoad) {
          SatelliteServicing_Mission_DW->Delay_DSTATE[i] =
            SatelliteServicing_Mission_P.Constant4_Value[i];
        }

        // Delay: '<S114>/Delay'
        SatelliteServicing_Mission_B->Delay[i] =
          SatelliteServicing_Mission_DW->Delay_DSTATE[i];

        // Delay: '<S114>/Delay1' incorporates:
        //   Constant: '<S114>/Constant4'

        if (SatelliteServicing_Mission_DW->icLoad_d) {
          SatelliteServicing_Mission_DW->Delay1_DSTATE[i] =
            SatelliteServicing_Mission_P.Constant4_Value[i];
        }

        // Delay: '<S114>/Delay1'
        SatelliteServicing_Mission_B->Delay1[i] =
          SatelliteServicing_Mission_DW->Delay1_DSTATE[i];
      }
    }

    // MATLAB Function: '<S114>/computeCoverage' incorporates:
    //   Constant: '<S114>/Constant1'
    //   Constant: '<S114>/Constant2'
    //   Constant: '<S114>/Constant3'
    //   Constant: '<S114>/Constant5'
    //   Constant: '<S114>/Constant6'
    //   Reshape: '<S114>/Reshape'

    std::memcpy(&SatelliteServicing_Mission_B->coverage_out[0],
                &SatelliteServicing_Mission_B->Delay[0], sizeof(real_T) << 5U);
    std::memcpy(&SatelliteServicing_Mission_B->credit_out[0],
                &SatelliteServicing_Mission_B->Delay1[0], sizeof(real_T) << 5U);
    nparams = std::round(36.0 / SatelliteServicing_Mission_P.nsat);
    b = static_cast<int32_T>(SatelliteServicing_Mission_P.nsat);
    for (i = 0; i < b; i++) {
      fov_radius = ((static_cast<real_T>(i) + 1.0) - 1.0) * nparams;
      position[0] = rtb_Reshape[static_cast<int32_T>(fov_radius + 1.0) - 1];
      position[1] = rtb_Reshape[static_cast<int32_T>(fov_radius + 2.0) - 1];
      position[2] = rtb_Reshape[static_cast<int32_T>(fov_radius + 3.0) - 1];
      fov_radius = norm_NaTV2q6x(position);
      position[0] = position[0] / fov_radius *
        SatelliteServicing_Mission_P.Constant6_Value;
      position[1] = position[1] / fov_radius *
        SatelliteServicing_Mission_P.Constant6_Value;
      position[2] = position[2] / fov_radius *
        SatelliteServicing_Mission_P.Constant6_Value;
      fov_radius = (fov_radius - SatelliteServicing_Mission_P.Constant6_Value) *
        std::tan(SatelliteServicing_Mission_P.Constant2_Value[i] / 2.0);
      idx = 0;
      b_ii = 0;
      exitg1 = false;
      while ((!exitg1) && (b_ii < 32)) {
        if (!(SatelliteServicing_Mission_B->coverage_out[b_ii] != 0.0)) {
          idx++;
          ii_data[idx - 1] = static_cast<int8_T>(b_ii + 1);
          if (idx >= 32) {
            exitg1 = true;
          } else {
            b_ii++;
          }
        } else {
          b_ii++;
        }
      }

      if (idx < 1) {
        idx = 0;
      }

      for (b_ii = 0; b_ii < idx; b_ii++) {
        ii = ii_data[b_ii];
        centerDist = 0.0;
        scale = position[0];
        absxk = position[1];
        t = position[2];
        for (b_j = 0; b_j < 3; b_j++) {
          b_x_tmp = ((b_j << 5) + ii) - 1;
          absx = SatelliteServicing_Mission_P.Constant3_Value[b_x_tmp] - scale;
          b_x[3 * b_j] = absx;
          absx = std::abs(absx);
          if (std::isnan(absx)) {
            centerDist = (rtNaN);
          } else if (absx > centerDist) {
            centerDist = absx;
          }

          absx = SatelliteServicing_Mission_P.Constant3_Value[b_x_tmp] - absxk;
          b_x[3 * b_j + 1] = absx;
          absx = std::abs(absx);
          if (std::isnan(absx)) {
            centerDist = (rtNaN);
          } else if (absx > centerDist) {
            centerDist = absx;
          }

          absx = SatelliteServicing_Mission_P.Constant3_Value[b_x_tmp] - t;
          b_x[3 * b_j + 2] = absx;
          absx = std::abs(absx);
          if (std::isnan(absx)) {
            centerDist = (rtNaN);
          } else if (absx > centerDist) {
            centerDist = absx;
          }
        }

        if ((!std::isinf(centerDist)) && (!std::isnan(centerDist))) {
          svd_jndSmZ1I(b_x, tmp_11);
          centerDist = tmp_11[0];
        }

        scale = 3.3121686421112381E-170;
        absxk_tmp = SatelliteServicing_Mission_P.Constant3_Value[ii - 1];
        absxk = std::abs(absxk_tmp);
        if (absxk > 3.3121686421112381E-170) {
          absx = 1.0;
          scale = absxk;
        } else {
          t = absxk / 3.3121686421112381E-170;
          absx = t * t;
        }

        absxk_tmp_0 = SatelliteServicing_Mission_P.Constant3_Value[ii + 31];
        absxk = std::abs(absxk_tmp_0);
        if (absxk > scale) {
          t = scale / absxk;
          absx = absx * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          absx += t * t;
        }

        absxk_tmp_1 = SatelliteServicing_Mission_P.Constant3_Value[ii + 63];
        absxk = std::abs(absxk_tmp_1);
        if (absxk > scale) {
          t = scale / absxk;
          absx = absx * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          absx += t * t;
        }

        absx = scale * std::sqrt(absx);
        scale = SatelliteServicing_Mission_P.Constant5_Value[ii - 1];
        if ((fov_radius >= scale + centerDist) && (std::acos(((absxk_tmp *
                position[0] + absxk_tmp_0 * position[1]) + absxk_tmp_1 *
               position[2]) / (absx * norm_NaTV2q6x(position))) <
             1.5707963267948966 - scale /
             SatelliteServicing_Mission_P.Constant6_Value)) {
          SatelliteServicing_Mission_B->coverage_out[ii - 1] = 1.0;
          SatelliteServicing_Mission_B->credit_out[ii - 1] = static_cast<real_T>
            (i) + 1.0;
        }
      }
    }

    // End of MATLAB Function: '<S114>/computeCoverage'

    // Outport: '<Root>/ControlError'
    std::memcpy(&SatelliteServicing_Mission_Y->ControlError[0],
                &SatelliteServicing_Mission_B->credit_out[0], sizeof(real_T) <<
                5U);

    // SimscapeInputBlock: '<S238>/INPUT_1_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S209>/Constant1'
    //   Product: '<S209>/Product'
    //   Sum: '<S209>/Add'

    SatelliteServicing_Mission_B->INPUT_1_1_1_d[0] = rtb_acceleration_kn[0] *
      SatelliteServicing_Mission_P.cubesat[3].mass +
      SatelliteServicing_Mission_P.Constant_Value[0];
    SatelliteServicing_Mission_B->INPUT_1_1_1_d[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1_d[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1_d[3] = 0.0;

    // SimscapeInputBlock: '<S238>/INPUT_2_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S209>/Constant1'
    //   Product: '<S209>/Product'
    //   Sum: '<S209>/Add'

    SatelliteServicing_Mission_B->INPUT_2_1_1_k[0] = rtb_acceleration_kn[1] *
      SatelliteServicing_Mission_P.cubesat[3].mass +
      SatelliteServicing_Mission_P.Constant_Value[1];
    SatelliteServicing_Mission_B->INPUT_2_1_1_k[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1_k[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1_k[3] = 0.0;

    // SimscapeInputBlock: '<S238>/INPUT_3_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S209>/Constant1'
    //   Product: '<S209>/Product'
    //   Sum: '<S209>/Add'

    SatelliteServicing_Mission_B->INPUT_3_1_1_c[0] = rtb_acceleration_kn[2] *
      SatelliteServicing_Mission_P.cubesat[3].mass +
      SatelliteServicing_Mission_P.Constant_Value[2];
    SatelliteServicing_Mission_B->INPUT_3_1_1_c[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1_c[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1_c[3] = 0.0;

    // SimscapeInputBlock: '<S208>/INPUT_1_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S179>/Constant1'
    //   Product: '<S179>/Product'
    //   Sum: '<S179>/Add'

    SatelliteServicing_Mission_B->INPUT_1_1_1_p[0] = Saturation1[0] *
      SatelliteServicing_Mission_P.cubesat[2].mass +
      SatelliteServicing_Mission_P.Constant_Value[0];
    SatelliteServicing_Mission_B->INPUT_1_1_1_p[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1_p[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1_p[3] = 0.0;

    // SimscapeInputBlock: '<S208>/INPUT_2_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S179>/Constant1'
    //   Product: '<S179>/Product'
    //   Sum: '<S179>/Add'

    SatelliteServicing_Mission_B->INPUT_2_1_1_h[0] = Saturation1[1] *
      SatelliteServicing_Mission_P.cubesat[2].mass +
      SatelliteServicing_Mission_P.Constant_Value[1];
    SatelliteServicing_Mission_B->INPUT_2_1_1_h[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1_h[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1_h[3] = 0.0;

    // SimscapeInputBlock: '<S208>/INPUT_3_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S179>/Constant1'
    //   Product: '<S179>/Product'
    //   Sum: '<S179>/Add'

    SatelliteServicing_Mission_B->INPUT_3_1_1_n[0] = Saturation1[2] *
      SatelliteServicing_Mission_P.cubesat[2].mass +
      SatelliteServicing_Mission_P.Constant_Value[2];
    SatelliteServicing_Mission_B->INPUT_3_1_1_n[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1_n[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1_n[3] = 0.0;

    // SimscapeInputBlock: '<S178>/INPUT_1_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S149>/Constant1'
    //   Product: '<S149>/Product'
    //   Sum: '<S149>/Add'

    SatelliteServicing_Mission_B->INPUT_1_1_1_n[0] = rtb_acceleration[0] *
      SatelliteServicing_Mission_P.cubesat[1].mass +
      SatelliteServicing_Mission_P.Constant_Value[0];
    SatelliteServicing_Mission_B->INPUT_1_1_1_n[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1_n[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1_n[3] = 0.0;

    // SimscapeInputBlock: '<S178>/INPUT_2_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S149>/Constant1'
    //   Product: '<S149>/Product'
    //   Sum: '<S149>/Add'

    SatelliteServicing_Mission_B->INPUT_2_1_1_c[0] = rtb_acceleration[1] *
      SatelliteServicing_Mission_P.cubesat[1].mass +
      SatelliteServicing_Mission_P.Constant_Value[1];
    SatelliteServicing_Mission_B->INPUT_2_1_1_c[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1_c[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1_c[3] = 0.0;

    // SimscapeInputBlock: '<S178>/INPUT_3_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S149>/Constant1'
    //   Product: '<S149>/Product'
    //   Sum: '<S149>/Add'

    SatelliteServicing_Mission_B->INPUT_3_1_1_b[0] = rtb_acceleration[2] *
      SatelliteServicing_Mission_P.cubesat[1].mass +
      SatelliteServicing_Mission_P.Constant_Value[2];
    SatelliteServicing_Mission_B->INPUT_3_1_1_b[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1_b[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1_b[3] = 0.0;

    // SimscapeInputBlock: '<S148>/INPUT_1_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S119>/Constant1'
    //   Product: '<S119>/Product'
    //   Sum: '<S119>/Add'

    SatelliteServicing_Mission_B->INPUT_1_1_1_h[0] = rtb_acceleration_k[0] *
      SatelliteServicing_Mission_P.cubesat[0].mass +
      SatelliteServicing_Mission_P.Constant_Value[0];
    SatelliteServicing_Mission_B->INPUT_1_1_1_h[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1_h[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_1_1_1_h[3] = 0.0;

    // SimscapeInputBlock: '<S148>/INPUT_2_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S119>/Constant1'
    //   Product: '<S119>/Product'
    //   Sum: '<S119>/Add'

    SatelliteServicing_Mission_B->INPUT_2_1_1_km[0] = rtb_acceleration_k[1] *
      SatelliteServicing_Mission_P.cubesat[0].mass +
      SatelliteServicing_Mission_P.Constant_Value[1];
    SatelliteServicing_Mission_B->INPUT_2_1_1_km[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1_km[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_2_1_1_km[3] = 0.0;

    // SimscapeInputBlock: '<S148>/INPUT_3_1_1' incorporates:
    //   Constant: '<S113>/Constant'
    //   Constant: '<S119>/Constant1'
    //   Product: '<S119>/Product'
    //   Sum: '<S119>/Add'

    SatelliteServicing_Mission_B->INPUT_3_1_1_m[0] = rtb_acceleration_k[2] *
      SatelliteServicing_Mission_P.cubesat[0].mass +
      SatelliteServicing_Mission_P.Constant_Value[2];
    SatelliteServicing_Mission_B->INPUT_3_1_1_m[1] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1_m[2] = 0.0;
    SatelliteServicing_Mission_B->INPUT_3_1_1_m[3] = 0.0;

    // Outport: '<Root>/Observations'
    for (i = 0; i < 6; i++) {
      SatelliteServicing_Mission_Y->Observations[i] = rtb_OUTPUT_1_0_n[i];
    }

    SatelliteServicing_Mission_Y->Observations[6] = rtb_acceleration_k[0];
    SatelliteServicing_Mission_Y->Observations[7] = rtb_acceleration_k[1];
    SatelliteServicing_Mission_Y->Observations[8] = rtb_acceleration_k[2];
    for (i = 0; i < 6; i++) {
      SatelliteServicing_Mission_Y->Observations[i + 9] = rtb_OUTPUT_1_0_b[i];
    }

    SatelliteServicing_Mission_Y->Observations[15] = rtb_acceleration[0];
    SatelliteServicing_Mission_Y->Observations[16] = rtb_acceleration[1];
    SatelliteServicing_Mission_Y->Observations[17] = rtb_acceleration[2];
    for (i = 0; i < 6; i++) {
      SatelliteServicing_Mission_Y->Observations[i + 18] = rtb_OUTPUT_1_0_g[i];
    }

    SatelliteServicing_Mission_Y->Observations[24] = Saturation1[0];
    SatelliteServicing_Mission_Y->Observations[25] = Saturation1[1];
    SatelliteServicing_Mission_Y->Observations[26] = Saturation1[2];
    for (i = 0; i < 6; i++) {
      SatelliteServicing_Mission_Y->Observations[i + 27] = rtb_OUTPUT_1_0_f[i];
    }

    SatelliteServicing_Mission_Y->Observations[33] = rtb_acceleration_kn[0];
    SatelliteServicing_Mission_Y->Observations[34] = rtb_acceleration_kn[1];
    SatelliteServicing_Mission_Y->Observations[35] = rtb_acceleration_kn[2];

    // End of Outport: '<Root>/Observations'

    // SimscapeExecutionBlock: '<S148>/OUTPUT_1_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_f);
    time_l = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_l;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Discrete_p;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Modes_p;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_s[0] = 0;
    tmp_r[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[0];
    tmp_r[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[1];
    tmp_r[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[2];
    tmp_r[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[3];
    tmp_s[1] = 4;
    tmp_r[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[0];
    tmp_r[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[1];
    tmp_r[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[2];
    tmp_r[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[3];
    tmp_s[2] = 8;
    tmp_r[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[0];
    tmp_r[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[1];
    tmp_r[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[2];
    tmp_r[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[3];
    tmp_s[3] = 12;
    std::memcpy(&tmp_r[12], &SatelliteServicing_Mission_B->STATE_1_o[0], 13U *
                sizeof(real_T));
    tmp_s[4] = 25;
    simulationData->mData->mInputValues.mN = 25;
    simulationData->mData->mInputValues.mX = &tmp_r[0];
    simulationData->mData->mInputOffsets.mN = 5;
    simulationData->mData->mInputOffsets.mX = &tmp_s[0];
    simulationData->mData->mOutputs.mN = 3;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_1_l[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_m = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_m;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_e);
    diagnosticTree_a = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_j), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_e = rtw_diagnostics_msg(diagnosticTree_a);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_e);
      }
    }

    // SimscapeExecutionBlock: '<S178>/OUTPUT_1_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_e);
    time_n = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_n;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Discrete_o;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Modes_i;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_u[0] = 0;
    tmp_t[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[0];
    tmp_t[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[1];
    tmp_t[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[2];
    tmp_t[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[3];
    tmp_u[1] = 4;
    tmp_t[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[0];
    tmp_t[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[1];
    tmp_t[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[2];
    tmp_t[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[3];
    tmp_u[2] = 8;
    tmp_t[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[0];
    tmp_t[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[1];
    tmp_t[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[2];
    tmp_t[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[3];
    tmp_u[3] = 12;
    std::memcpy(&tmp_t[12], &SatelliteServicing_Mission_B->STATE_1_n[0], 13U *
                sizeof(real_T));
    tmp_u[4] = 25;
    simulationData->mData->mInputValues.mN = 25;
    simulationData->mData->mInputValues.mX = &tmp_t[0];
    simulationData->mData->mInputOffsets.mN = 5;
    simulationData->mData->mInputOffsets.mX = &tmp_u[0];
    simulationData->mData->mOutputs.mN = 3;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_1_h[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_o = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_o;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_f);
    diagnosticTree_b = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_n), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_f = rtw_diagnostics_msg(diagnosticTree_b);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_f);
      }
    }

    // SimscapeExecutionBlock: '<S208>/OUTPUT_1_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_l);
    time_p = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_p;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Discrete_g;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Modes_pb;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    ok = false;
    simulationData->mData->mIsSolverAssertCheck = ok;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_w[0] = 0;
    tmp_v[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[0];
    tmp_v[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[1];
    tmp_v[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[2];
    tmp_v[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[3];
    tmp_w[1] = 4;
    tmp_v[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[0];
    tmp_v[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[1];
    tmp_v[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[2];
    tmp_v[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[3];
    tmp_w[2] = 8;
    tmp_v[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[0];
    tmp_v[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[1];
    tmp_v[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[2];
    tmp_v[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[3];
    tmp_w[3] = 12;
    std::memcpy(&tmp_v[12], &SatelliteServicing_Mission_B->STATE_1_b[0], 13U *
                sizeof(real_T));
    tmp_w[4] = 25;
    simulationData->mData->mInputValues.mN = 25;
    simulationData->mData->mInputValues.mX = &tmp_v[0];
    simulationData->mData->mInputOffsets.mN = 5;
    simulationData->mData->mInputOffsets.mX = &tmp_w[0];
    simulationData->mData->mOutputs.mN = 3;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_1_p[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_q = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_q;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_h);
    diagnosticTree_c = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_jb), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      ok = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (ok) {
        msg_g = rtw_diagnostics_msg(diagnosticTree_c);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_g);
      }
    }

    // SimscapeExecutionBlock: '<S238>/OUTPUT_1_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_o);
    time_r = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_r;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = nullptr;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Discrete_h;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->OUTPUT_1_1_Modes_o;
    ok = false;
    simulationData->mData->mFoundZcEvents = ok;
    simulationData->mData->mIsMajorTimeStep = tmp;
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_y[0] = 0;
    tmp_x[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[0];
    tmp_x[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[1];
    tmp_x[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[2];
    tmp_x[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[3];
    tmp_y[1] = 4;
    tmp_x[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[0];
    tmp_x[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[1];
    tmp_x[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[2];
    tmp_x[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[3];
    tmp_y[2] = 8;
    tmp_x[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[0];
    tmp_x[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[1];
    tmp_x[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[2];
    tmp_x[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[3];
    tmp_y[3] = 12;
    std::memcpy(&tmp_x[12], &SatelliteServicing_Mission_B->STATE_1_l[0], 13U *
                sizeof(real_T));
    tmp_y[4] = 25;
    simulationData->mData->mInputValues.mN = 25;
    simulationData->mData->mInputValues.mX = &tmp_x[0];
    simulationData->mData->mInputOffsets.mN = 5;
    simulationData->mData->mInputOffsets.mX = &tmp_y[0];
    simulationData->mData->mOutputs.mN = 3;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_1_ph[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = nullptr;
    simulationData->mData->mCstateHasChanged = false;
    time_s = time_tmp_0;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_s;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = nullptr;
    simulationData->mData->mIsFundamentalSampleHit = false;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_a);
    diagnosticTree_d = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_d), NESL_SIM_OUTPUTS,
      simulationData, diagnosticManager);
    if (i != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg_h = rtw_diagnostics_msg(diagnosticTree_d);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_h);
      }
    }
  }

  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    NeslSimulationData *simulationData;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    NeuDiagnosticTree *diagnosticTree_0;
    NeuDiagnosticTree *diagnosticTree_1;
    NeuDiagnosticTree *diagnosticTree_2;
    NeuDiagnosticTree *diagnosticTree_3;
    char *msg;
    char *msg_0;
    char *msg_1;
    char *msg_2;
    char *msg_3;
    real_T tmp_1[24];
    real_T tmp_4[12];
    real_T tmp_6[12];
    real_T tmp_8[12];
    real_T tmp_a[12];
    real_T time;
    real_T time_0;
    real_T time_1;
    real_T time_2;
    real_T time_3;
    real_T time_tmp;
    int32_T i;
    int_T tmp_2[7];
    int_T tmp_5[4];
    int_T tmp_7[4];
    int_T tmp_9[4];
    int_T tmp_b[4];
    boolean_T tmp;
    boolean_T tmp_0;
    boolean_T tmp_3;

    // Update for SimscapeExecutionBlock: '<S300>/STATE_1' incorporates:
    //   SimscapeExecutionBlock: '<S148>/STATE_1'
    //   SimscapeExecutionBlock: '<S178>/STATE_1'
    //   SimscapeExecutionBlock: '<S208>/STATE_1'
    //   SimscapeExecutionBlock: '<S238>/STATE_1'

    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData);
    time_tmp = SatelliteServicing_Mission_M->Timing.t[0];
    time = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionServi[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    tmp = rtmIsMajorTimeStep(SatelliteServicing_Mission_M);
    simulationData->mData->mIsMajorTimeStep = tmp;
    tmp_0 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_0;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp_0 = rtsiIsSolverComputingJacobian
      (SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp_0;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_0 = rtsiIsModeUpdateTimeStep(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_2[0] = 0;
    tmp_1[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
    tmp_1[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
    tmp_1[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
    tmp_1[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
    tmp_2[1] = 4;
    tmp_1[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
    tmp_1[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
    tmp_1[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
    tmp_1[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
    tmp_2[2] = 8;
    tmp_1[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
    tmp_1[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
    tmp_1[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
    tmp_1[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
    tmp_2[3] = 12;
    tmp_1[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
    tmp_1[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
    tmp_1[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
    tmp_1[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
    tmp_2[4] = 16;
    tmp_1[16] = SatelliteServicing_Mission_B->INPUT_4_1_2[0];
    tmp_1[17] = SatelliteServicing_Mission_B->INPUT_4_1_2[1];
    tmp_1[18] = SatelliteServicing_Mission_B->INPUT_4_1_2[2];
    tmp_1[19] = SatelliteServicing_Mission_B->INPUT_4_1_2[3];
    tmp_2[5] = 20;
    tmp_1[20] = SatelliteServicing_Mission_B->INPUT_4_1_3[0];
    tmp_1[21] = SatelliteServicing_Mission_B->INPUT_4_1_3[1];
    tmp_1[22] = SatelliteServicing_Mission_B->INPUT_4_1_3[2];
    tmp_1[23] = SatelliteServicing_Mission_B->INPUT_4_1_3[3];
    tmp_2[6] = 24;
    simulationData->mData->mInputValues.mN = 24;
    simulationData->mData->mInputValues.mX = &tmp_1[0];
    simulationData->mData->mInputOffsets.mN = 7;
    simulationData->mData->mInputOffsets.mX = &tmp_2[0];
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_UPDATE,
      simulationData, diagnosticManager);
    if (i != 0) {
      tmp_3 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_3) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
      }
    }

    // End of Update for SimscapeExecutionBlock: '<S300>/STATE_1'
    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // Update for DiscreteIntegrator: '<S255>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[0] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainval *
        SatelliteServicing_Mission_B->controlErrorECEF[0];

      // Update for DiscreteIntegrator: '<S254>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[0] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainv_b *
        SatelliteServicing_Mission_B->controlErrorECEF_l[0];

      // Update for DiscreteIntegrator: '<S255>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[1] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainval *
        SatelliteServicing_Mission_B->controlErrorECEF[1];

      // Update for DiscreteIntegrator: '<S254>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[1] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainv_b *
        SatelliteServicing_Mission_B->controlErrorECEF_l[1];

      // Update for DiscreteIntegrator: '<S255>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[2] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainval *
        SatelliteServicing_Mission_B->controlErrorECEF[2];

      // Update for DiscreteIntegrator: '<S254>/Discrete-Time Integrator1'
      SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[2] +=
        SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_gainv_b *
        SatelliteServicing_Mission_B->controlErrorECEF_l[2];
    }

    // Update for SimscapeExecutionBlock: '<S148>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData_g);
    time_0 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionMissi[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete_k;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes_l;
    tmp_3 = false;
    simulationData->mData->mFoundZcEvents = tmp_3;
    simulationData->mData->mIsMajorTimeStep = tmp;
    tmp_3 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_3;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp_3 = rtsiIsSolverComputingJacobian
      (SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp_3;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_5[0] = 0;
    tmp_4[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[0];
    tmp_4[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[1];
    tmp_4[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[2];
    tmp_4[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[3];
    tmp_5[1] = 4;
    tmp_4[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[0];
    tmp_4[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[1];
    tmp_4[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[2];
    tmp_4[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[3];
    tmp_5[2] = 8;
    tmp_4[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[0];
    tmp_4[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[1];
    tmp_4[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[2];
    tmp_4[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[3];
    tmp_5[3] = 12;
    simulationData->mData->mInputValues.mN = 12;
    simulationData->mData->mInputValues.mX = &tmp_4[0];
    simulationData->mData->mInputOffsets.mN = 4;
    simulationData->mData->mInputOffsets.mX = &tmp_5[0];
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_a);
    diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_i), NESL_SIM_UPDATE,
      simulationData, diagnosticManager);
    if (i != 0) {
      tmp_3 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_3) {
        msg_0 = rtw_diagnostics_msg(diagnosticTree_0);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
      }
    }

    // Update for SimscapeExecutionBlock: '<S178>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData_f);
    time_1 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_1;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_m[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete_l;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes_l0;
    tmp_3 = false;
    simulationData->mData->mFoundZcEvents = tmp_3;
    simulationData->mData->mIsMajorTimeStep = tmp;
    tmp_3 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_3;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp_3 = rtsiIsSolverComputingJacobian
      (SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp_3;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_7[0] = 0;
    tmp_6[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[0];
    tmp_6[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[1];
    tmp_6[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[2];
    tmp_6[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[3];
    tmp_7[1] = 4;
    tmp_6[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[0];
    tmp_6[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[1];
    tmp_6[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[2];
    tmp_6[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[3];
    tmp_7[2] = 8;
    tmp_6[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[0];
    tmp_6[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[1];
    tmp_6[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[2];
    tmp_6[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[3];
    tmp_7[3] = 12;
    simulationData->mData->mInputValues.mN = 12;
    simulationData->mData->mInputValues.mX = &tmp_6[0];
    simulationData->mData->mInputOffsets.mN = 4;
    simulationData->mData->mInputOffsets.mX = &tmp_7[0];
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_p);
    diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_n), NESL_SIM_UPDATE,
      simulationData, diagnosticManager);
    if (i != 0) {
      tmp_3 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_3) {
        msg_1 = rtw_diagnostics_msg(diagnosticTree_1);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
      }
    }

    // Update for SimscapeExecutionBlock: '<S208>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData_k);
    time_2 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_2;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_k[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete_k5;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes_j;
    tmp_3 = false;
    simulationData->mData->mFoundZcEvents = tmp_3;
    simulationData->mData->mIsMajorTimeStep = tmp;
    tmp_3 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_3;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp_3 = rtsiIsSolverComputingJacobian
      (SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp_3;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_9[0] = 0;
    tmp_8[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[0];
    tmp_8[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[1];
    tmp_8[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[2];
    tmp_8[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[3];
    tmp_9[1] = 4;
    tmp_8[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[0];
    tmp_8[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[1];
    tmp_8[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[2];
    tmp_8[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[3];
    tmp_9[2] = 8;
    tmp_8[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[0];
    tmp_8[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[1];
    tmp_8[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[2];
    tmp_8[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[3];
    tmp_9[3] = 12;
    simulationData->mData->mInputValues.mN = 12;
    simulationData->mData->mInputValues.mX = &tmp_8[0];
    simulationData->mData->mInputOffsets.mN = 4;
    simulationData->mData->mInputOffsets.mX = &tmp_9[0];
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_pq);
    diagnosticTree_2 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_l), NESL_SIM_UPDATE,
      simulationData, diagnosticManager);
    if (i != 0) {
      tmp_3 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_3) {
        msg_2 = rtw_diagnostics_msg(diagnosticTree_2);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_2);
      }
    }

    // Update for SimscapeExecutionBlock: '<S238>/STATE_1'
    simulationData = static_cast<NeslSimulationData *>
      (SatelliteServicing_Mission_DW->STATE_1_SimData_m);
    time_3 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_3;
    simulationData->mData->mContStates.mN = 13;
    simulationData->mData->mContStates.mX =
      &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_n[0];
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Discrete_h;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX =
      &SatelliteServicing_Mission_DW->STATE_1_Modes_h;
    tmp_3 = false;
    simulationData->mData->mFoundZcEvents = tmp_3;
    simulationData->mData->mIsMajorTimeStep = tmp;
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
    tmp_b[0] = 0;
    tmp_a[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[0];
    tmp_a[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[1];
    tmp_a[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[2];
    tmp_a[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[3];
    tmp_b[1] = 4;
    tmp_a[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[0];
    tmp_a[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[1];
    tmp_a[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[2];
    tmp_a[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[3];
    tmp_b[2] = 8;
    tmp_a[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[0];
    tmp_a[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[1];
    tmp_a[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[2];
    tmp_a[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[3];
    tmp_b[3] = 12;
    simulationData->mData->mInputValues.mN = 12;
    simulationData->mData->mInputValues.mX = &tmp_a[0];
    simulationData->mData->mInputOffsets.mN = 4;
    simulationData->mData->mInputOffsets.mX = &tmp_b[0];
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_i);
    diagnosticTree_3 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    i = ne_simulator_method(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_j), NESL_SIM_UPDATE,
      simulationData, diagnosticManager);
    if (i != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
      if (tmp) {
        msg_3 = rtw_diagnostics_msg(diagnosticTree_3);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_3);
      }
    }

    if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
      // Update for Delay: '<S114>/Delay'
      SatelliteServicing_Mission_DW->icLoad = false;

      // Update for Delay: '<S114>/Delay1'
      SatelliteServicing_Mission_DW->icLoad_d = false;

      // Update for Delay: '<S114>/Delay'
      std::memcpy(&SatelliteServicing_Mission_DW->Delay_DSTATE[0],
                  &SatelliteServicing_Mission_B->coverage_out[0], sizeof(real_T)
                  << 5U);

      // Update for Delay: '<S114>/Delay1'
      std::memcpy(&SatelliteServicing_Mission_DW->Delay1_DSTATE[0],
                  &SatelliteServicing_Mission_B->credit_out[0], sizeof(real_T) <<
                  5U);
    }
  }                                    // end MajorTimeStep

  if (rtmIsMajorTimeStep(SatelliteServicing_Mission_M)) {
    rt_ertODEUpdateContinuousStates(SatelliteServicing_Mission_M->solverInfo,
      SatelliteServicing_Mission_M, SatelliteServicing_Mission_Y);

    // Update absolute time for base rate
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.

    ++SatelliteServicing_Mission_M->Timing.clockTick0;
    SatelliteServicing_Mission_M->Timing.t[0] = rtsiGetSolverStopTime
      (SatelliteServicing_Mission_M->solverInfo);

    {
      // Update absolute timer for sample time: [0.5s, 0.0s]
      // The "clockTick1" counts the number of times the code of this task has
      //  been executed. The resolution of this integer timer is 0.5, which is the step size
      //  of the task. Size of "clockTick1" ensures timer will not overflow during the
      //  application lifespan selected.

      SatelliteServicing_Mission_M->Timing.clockTick1++;
    }
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void SatelliteServicing_Mission_derivatives(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M)
{
  B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
    SatelliteServicing_Mission_M->blockIO };

  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
    SatelliteServicing_Mission_M->contStates };

  NeslSimulationData *simulationData;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  NeuDiagnosticTree *diagnosticTree_0;
  NeuDiagnosticTree *diagnosticTree_1;
  NeuDiagnosticTree *diagnosticTree_2;
  NeuDiagnosticTree *diagnosticTree_3;
  XDot_SatelliteServicing_Missi_T *_rtXdot;
  char *msg;
  char *msg_0;
  char *msg_1;
  char *msg_2;
  char *msg_3;
  real_T tmp_1[24];
  real_T tmp_5[12];
  real_T tmp_7[12];
  real_T tmp_9[12];
  real_T tmp_b[12];
  real_T time;
  real_T time_0;
  real_T time_1;
  real_T time_2;
  real_T time_3;
  real_T time_tmp;
  int32_T tmp_3;
  int_T tmp_2[7];
  int_T tmp_6[4];
  int_T tmp_8[4];
  int_T tmp_a[4];
  int_T tmp_c[4];
  boolean_T tmp;
  boolean_T tmp_0;
  boolean_T tmp_4;
  _rtXdot = ((XDot_SatelliteServicing_Missi_T *)
             SatelliteServicing_Mission_M->derivs);

  // Derivatives for SimscapeExecutionBlock: '<S300>/STATE_1' incorporates:
  //   SimscapeExecutionBlock: '<S148>/STATE_1'
  //   SimscapeExecutionBlock: '<S178>/STATE_1'
  //   SimscapeExecutionBlock: '<S208>/STATE_1'
  //   SimscapeExecutionBlock: '<S238>/STATE_1'

  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData);
  time_tmp = SatelliteServicing_Mission_M->Timing.t[0];
  time = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionServi[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes;
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  tmp = rtmIsMajorTimeStep(SatelliteServicing_Mission_M);
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp_0 = false;
  simulationData->mData->mIsSolverAssertCheck = tmp_0;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp_0 = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp_0;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  tmp_0 = rtsiIsModeUpdateTimeStep(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_2[0] = 0;
  tmp_1[0] = SatelliteServicing_Mission_B->INPUT_1_1_1[0];
  tmp_1[1] = SatelliteServicing_Mission_B->INPUT_1_1_1[1];
  tmp_1[2] = SatelliteServicing_Mission_B->INPUT_1_1_1[2];
  tmp_1[3] = SatelliteServicing_Mission_B->INPUT_1_1_1[3];
  tmp_2[1] = 4;
  tmp_1[4] = SatelliteServicing_Mission_B->INPUT_2_1_1[0];
  tmp_1[5] = SatelliteServicing_Mission_B->INPUT_2_1_1[1];
  tmp_1[6] = SatelliteServicing_Mission_B->INPUT_2_1_1[2];
  tmp_1[7] = SatelliteServicing_Mission_B->INPUT_2_1_1[3];
  tmp_2[2] = 8;
  tmp_1[8] = SatelliteServicing_Mission_B->INPUT_3_1_1[0];
  tmp_1[9] = SatelliteServicing_Mission_B->INPUT_3_1_1[1];
  tmp_1[10] = SatelliteServicing_Mission_B->INPUT_3_1_1[2];
  tmp_1[11] = SatelliteServicing_Mission_B->INPUT_3_1_1[3];
  tmp_2[3] = 12;
  tmp_1[12] = SatelliteServicing_Mission_B->INPUT_4_1_1[0];
  tmp_1[13] = SatelliteServicing_Mission_B->INPUT_4_1_1[1];
  tmp_1[14] = SatelliteServicing_Mission_B->INPUT_4_1_1[2];
  tmp_1[15] = SatelliteServicing_Mission_B->INPUT_4_1_1[3];
  tmp_2[4] = 16;
  tmp_1[16] = SatelliteServicing_Mission_B->INPUT_4_1_2[0];
  tmp_1[17] = SatelliteServicing_Mission_B->INPUT_4_1_2[1];
  tmp_1[18] = SatelliteServicing_Mission_B->INPUT_4_1_2[2];
  tmp_1[19] = SatelliteServicing_Mission_B->INPUT_4_1_2[3];
  tmp_2[5] = 20;
  tmp_1[20] = SatelliteServicing_Mission_B->INPUT_4_1_3[0];
  tmp_1[21] = SatelliteServicing_Mission_B->INPUT_4_1_3[1];
  tmp_1[22] = SatelliteServicing_Mission_B->INPUT_4_1_3[2];
  tmp_1[23] = SatelliteServicing_Mission_B->INPUT_4_1_3[3];
  tmp_2[6] = 24;
  simulationData->mData->mInputValues.mN = 24;
  simulationData->mData->mInputValues.mX = &tmp_1[0];
  simulationData->mData->mInputOffsets.mN = 7;
  simulationData->mData->mInputOffsets.mX = &tmp_2[0];
  simulationData->mData->mDx.mN = 13;
  simulationData->mData->mDx.mX = &_rtXdot->SatelliteServicing_MissionServi[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator), NESL_SIM_DERIVATIVES,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp_4 = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp_4) {
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
    }
  }

  // End of Derivatives for SimscapeExecutionBlock: '<S300>/STATE_1'

  // Derivatives for SimscapeExecutionBlock: '<S148>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_g);
  time_0 = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_0;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionMissi[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete_k;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes_l;
  tmp_4 = false;
  simulationData->mData->mFoundZcEvents = tmp_4;
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp_4 = false;
  simulationData->mData->mIsSolverAssertCheck = tmp_4;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp_4 = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp_4;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_6[0] = 0;
  tmp_5[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[0];
  tmp_5[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[1];
  tmp_5[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[2];
  tmp_5[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_h[3];
  tmp_6[1] = 4;
  tmp_5[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[0];
  tmp_5[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[1];
  tmp_5[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[2];
  tmp_5[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_km[3];
  tmp_6[2] = 8;
  tmp_5[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[0];
  tmp_5[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[1];
  tmp_5[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[2];
  tmp_5[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_m[3];
  tmp_6[3] = 12;
  simulationData->mData->mInputValues.mN = 12;
  simulationData->mData->mInputValues.mX = &tmp_5[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_6[0];
  simulationData->mData->mDx.mN = 13;
  simulationData->mData->mDx.mX = &_rtXdot->SatelliteServicing_MissionMissi[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_a);
  diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator_i), NESL_SIM_DERIVATIVES,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp_4 = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp_4) {
      msg_0 = rtw_diagnostics_msg(diagnosticTree_0);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
    }
  }

  // Derivatives for SimscapeExecutionBlock: '<S178>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_f);
  time_1 = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_1;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_m[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete_l;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes_l0;
  tmp_4 = false;
  simulationData->mData->mFoundZcEvents = tmp_4;
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp_4 = false;
  simulationData->mData->mIsSolverAssertCheck = tmp_4;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp_4 = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp_4;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_8[0] = 0;
  tmp_7[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[0];
  tmp_7[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[1];
  tmp_7[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[2];
  tmp_7[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_n[3];
  tmp_8[1] = 4;
  tmp_7[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[0];
  tmp_7[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[1];
  tmp_7[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[2];
  tmp_7[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_c[3];
  tmp_8[2] = 8;
  tmp_7[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[0];
  tmp_7[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[1];
  tmp_7[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[2];
  tmp_7[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_b[3];
  tmp_8[3] = 12;
  simulationData->mData->mInputValues.mN = 12;
  simulationData->mData->mInputValues.mX = &tmp_7[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_8[0];
  simulationData->mData->mDx.mN = 13;
  simulationData->mData->mDx.mX = &_rtXdot->SatelliteServicing_MissionMis_m[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_p);
  diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator_n), NESL_SIM_DERIVATIVES,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp_4 = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp_4) {
      msg_1 = rtw_diagnostics_msg(diagnosticTree_1);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
    }
  }

  // Derivatives for SimscapeExecutionBlock: '<S208>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_k);
  time_2 = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_2;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_k[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete_k5;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes_j;
  tmp_4 = false;
  simulationData->mData->mFoundZcEvents = tmp_4;
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp_4 = false;
  simulationData->mData->mIsSolverAssertCheck = tmp_4;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp_4 = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp_4;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_a[0] = 0;
  tmp_9[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[0];
  tmp_9[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[1];
  tmp_9[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[2];
  tmp_9[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_p[3];
  tmp_a[1] = 4;
  tmp_9[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[0];
  tmp_9[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[1];
  tmp_9[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[2];
  tmp_9[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_h[3];
  tmp_a[2] = 8;
  tmp_9[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[0];
  tmp_9[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[1];
  tmp_9[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[2];
  tmp_9[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_n[3];
  tmp_a[3] = 12;
  simulationData->mData->mInputValues.mN = 12;
  simulationData->mData->mInputValues.mX = &tmp_9[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_a[0];
  simulationData->mData->mDx.mN = 13;
  simulationData->mData->mDx.mX = &_rtXdot->SatelliteServicing_MissionMis_k[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_pq);
  diagnosticTree_2 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator_l), NESL_SIM_DERIVATIVES,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp_4 = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp_4) {
      msg_2 = rtw_diagnostics_msg(diagnosticTree_2);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_2);
    }
  }

  // Derivatives for SimscapeExecutionBlock: '<S238>/STATE_1'
  simulationData = static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_m);
  time_3 = time_tmp;
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time_3;
  simulationData->mData->mContStates.mN = 13;
  simulationData->mData->mContStates.mX =
    &SatelliteServicing_Mission_X->SatelliteServicing_MissionMis_n[0];
  simulationData->mData->mDiscStates.mN = 0;
  simulationData->mData->mDiscStates.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Discrete_h;
  simulationData->mData->mModeVector.mN = 0;
  simulationData->mData->mModeVector.mX =
    &SatelliteServicing_Mission_DW->STATE_1_Modes_h;
  tmp_4 = false;
  simulationData->mData->mFoundZcEvents = tmp_4;
  simulationData->mData->mIsMajorTimeStep = tmp;
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(SatelliteServicing_Mission_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = tmp_0;
  tmp_c[0] = 0;
  tmp_b[0] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[0];
  tmp_b[1] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[1];
  tmp_b[2] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[2];
  tmp_b[3] = SatelliteServicing_Mission_B->INPUT_1_1_1_d[3];
  tmp_c[1] = 4;
  tmp_b[4] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[0];
  tmp_b[5] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[1];
  tmp_b[6] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[2];
  tmp_b[7] = SatelliteServicing_Mission_B->INPUT_2_1_1_k[3];
  tmp_c[2] = 8;
  tmp_b[8] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[0];
  tmp_b[9] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[1];
  tmp_b[10] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[2];
  tmp_b[11] = SatelliteServicing_Mission_B->INPUT_3_1_1_c[3];
  tmp_c[3] = 12;
  simulationData->mData->mInputValues.mN = 12;
  simulationData->mData->mInputValues.mX = &tmp_b[0];
  simulationData->mData->mInputOffsets.mN = 4;
  simulationData->mData->mInputOffsets.mX = &tmp_c[0];
  simulationData->mData->mDx.mN = 13;
  simulationData->mData->mDx.mX = &_rtXdot->SatelliteServicing_MissionMis_n[0];
  diagnosticManager = static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_i);
  diagnosticTree_3 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_3 = ne_simulator_method(static_cast<NeslSimulator *>
    (SatelliteServicing_Mission_DW->STATE_1_Simulator_j), NESL_SIM_DERIVATIVES,
    simulationData, diagnosticManager);
  if (tmp_3 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(SatelliteServicing_Mission_M));
    if (tmp) {
      msg_3 = rtw_diagnostics_msg(diagnosticTree_3);
      rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_3);
    }
  }
}

// Model initialize function
void SatelliteServicing_Mission_initialize(RT_MODEL_SatelliteServicing_M_T *
  const SatelliteServicing_Mission_M)
{
  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  {
    NeModelParameters modelParameters;
    NeModelParameters modelParameters_0;
    NeModelParameters modelParameters_1;
    NeModelParameters modelParameters_2;
    NeModelParameters modelParameters_3;
    NeModelParameters modelParameters_4;
    NeModelParameters modelParameters_5;
    NeModelParameters modelParameters_6;
    NeModelParameters modelParameters_7;
    NeModelParameters modelParameters_8;
    NeModelParameters modelParameters_9;
    NeModelParameters modelParameters_a;
    NeModelParameters modelParameters_b;
    NeModelParameters modelParameters_c;
    NeModelParameters modelParameters_d;
    NeslRtpManager *manager;
    NeslRtpManager *manager_0;
    NeslSimulationData *tmp_1;
    NeslSimulator *tmp;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    NeuDiagnosticTree *diagnosticTree_0;
    NeuDiagnosticTree *diagnosticTree_1;
    NeuDiagnosticTree *diagnosticTree_2;
    NeuDiagnosticTree *diagnosticTree_3;
    NeuDiagnosticTree *diagnosticTree_4;
    NeuDiagnosticTree *diagnosticTree_5;
    NeuDiagnosticTree *diagnosticTree_6;
    NeuDiagnosticTree *diagnosticTree_7;
    NeuDiagnosticTree *diagnosticTree_8;
    NeuDiagnosticTree *diagnosticTree_9;
    NeuDiagnosticTree *diagnosticTree_a;
    NeuDiagnosticTree *diagnosticTree_b;
    NeuDiagnosticTree *diagnosticTree_c;
    NeuDiagnosticTree *diagnosticTree_d;
    char *msg;
    char *msg_0;
    char *msg_1;
    char *msg_2;
    char *msg_3;
    char *msg_4;
    char *msg_5;
    char *msg_6;
    char *msg_7;
    char *msg_8;
    char *msg_9;
    char *msg_a;
    char *msg_b;
    char *msg_c;
    char *msg_d;
    real_T tmp_2;
    int32_T tmp_3;
    boolean_T tmp_0;

    // Start for SimscapeExecutionBlock: '<S300>/STATE_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 0, 0);
    SatelliteServicing_Mission_DW->STATE_1_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(SatelliteServicing_Mission_DW->STATE_1_Simulator);
    if (tmp_0) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 0, 0);
      SatelliteServicing_Mission_DW->STATE_1_Simulator = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->STATE_1_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->STATE_1_DiagMgr = (void *)diagnosticManager;
    modelParameters.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters.mSolverAbsTol = 0.001;
    modelParameters.mSolverRelTol = 0.001;
    modelParameters.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters.mStartTime = 0.0;
    modelParameters.mLoadInitialState = false;
    modelParameters.mUseSimState = false;
    modelParameters.mLinTrimCompile = false;
    modelParameters.mLoggingMode = SSC_LOGGING_ON;
    modelParameters.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters.mIsUsingODEN = tmp_0;
    modelParameters.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr);
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator), &modelParameters,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S300>/STATE_1'

    // Start for SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 1, 0);
    SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator);
    if (tmp_0) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 1, 0);
      SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr = (void *)
      diagnosticManager;
    modelParameters_0.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_0.mSolverAbsTol = 0.001;
    modelParameters_0.mSolverRelTol = 0.001;
    modelParameters_0.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_0.mStartTime = 0.0;
    modelParameters_0.mLoadInitialState = false;
    modelParameters_0.mUseSimState = false;
    modelParameters_0.mLinTrimCompile = false;
    modelParameters_0.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_0.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_0.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_0.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_0.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_0.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_0.mIsUsingODEN = tmp_0;
    modelParameters_0.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr);
    diagnosticTree_0 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator), &modelParameters_0,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_0 = rtw_diagnostics_msg(diagnosticTree_0);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_0);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'

    // Start for SimscapeExecutionBlock: '<S300>/OUTPUT_1_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Solver Configuration_1", 1, 1);
    SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator);
    if (tmp_0) {
      SatelliteServicing_Mission_acc66beb_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Solver Configuration_1", 1, 1);
      SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr = (void *)
      diagnosticManager;
    modelParameters_1.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_1.mSolverAbsTol = 0.001;
    modelParameters_1.mSolverRelTol = 0.001;
    modelParameters_1.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_1.mStartTime = 0.0;
    modelParameters_1.mLoadInitialState = false;
    modelParameters_1.mUseSimState = false;
    modelParameters_1.mLinTrimCompile = false;
    modelParameters_1.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_1.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_1.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_1.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_1.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_1.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_1.mIsUsingODEN = tmp_0;
    modelParameters_1.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr);
    diagnosticTree_1 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator), &modelParameters_1,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_1 = rtw_diagnostics_msg(diagnosticTree_1);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_1);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S300>/OUTPUT_1_1'

    // Start for SimscapeRtp: '<S125>/RTP_1'
    manager_0 = nesl_lease_rtp_manager(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1",
      0);
    manager = manager_0;
    tmp_0 = pointer_is_null(manager_0);
    if (tmp_0) {
      SatelliteServicing_Mission_e7143f6a_1_gateway();
      manager = nesl_lease_rtp_manager(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1",
        0);
    }

    SatelliteServicing_Mission_DW->RTP_1_RtpManager = (void *)manager;
    SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded = true;

    // End of Start for SimscapeRtp: '<S125>/RTP_1'

    // Start for SimscapeExecutionBlock: '<S148>/STATE_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1",
      0, 0);
    SatelliteServicing_Mission_DW->STATE_1_Simulator_i = (void *)tmp;
    tmp_0 = pointer_is_null(SatelliteServicing_Mission_DW->STATE_1_Simulator_i);
    if (tmp_0) {
      SatelliteServicing_Mission_e7143f6a_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1",
        0, 0);
      SatelliteServicing_Mission_DW->STATE_1_Simulator_i = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->STATE_1_SimData_g = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->STATE_1_DiagMgr_a = (void *)diagnosticManager;
    modelParameters_2.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_2.mSolverAbsTol = 0.001;
    modelParameters_2.mSolverRelTol = 0.001;
    modelParameters_2.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_2.mStartTime = 0.0;
    modelParameters_2.mLoadInitialState = false;
    modelParameters_2.mUseSimState = false;
    modelParameters_2.mLinTrimCompile = false;
    modelParameters_2.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_2.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_2.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_2.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_2.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_2.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_2.mIsUsingODEN = tmp_0;
    modelParameters_2.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_a);
    diagnosticTree_2 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_i), &modelParameters_2,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_2 = rtw_diagnostics_msg(diagnosticTree_2);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_2);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S148>/STATE_1'

    // Start for SimscapeExecutionBlock: '<S148>/OUTPUT_1_0'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1",
      1, 0);
    SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_j = (void *)tmp;
    tmp_0 = pointer_is_null
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_j);
    if (tmp_0) {
      SatelliteServicing_Mission_e7143f6a_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1",
        1, 0);
      SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_j = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_b = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_g = (void *)
      diagnosticManager;
    modelParameters_3.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_3.mSolverAbsTol = 0.001;
    modelParameters_3.mSolverRelTol = 0.001;
    modelParameters_3.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_3.mStartTime = 0.0;
    modelParameters_3.mLoadInitialState = false;
    modelParameters_3.mUseSimState = false;
    modelParameters_3.mLinTrimCompile = false;
    modelParameters_3.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_3.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_3.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_3.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_3.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_3.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_3.mIsUsingODEN = tmp_0;
    modelParameters_3.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_g);
    diagnosticTree_3 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_j),
      &modelParameters_3, diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_3 = rtw_diagnostics_msg(diagnosticTree_3);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_3);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S148>/OUTPUT_1_0'

    // Start for SimscapeRtp: '<S155>/RTP_1'
    manager_0 = nesl_lease_rtp_manager(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1",
      0);
    manager = manager_0;
    tmp_0 = pointer_is_null(manager_0);
    if (tmp_0) {
      SatelliteServicing_Mission_587682d_1_gateway();
      manager = nesl_lease_rtp_manager(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1",
        0);
    }

    SatelliteServicing_Mission_DW->RTP_1_RtpManager_k = (void *)manager;
    SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_k = true;

    // End of Start for SimscapeRtp: '<S155>/RTP_1'

    // Start for SimscapeExecutionBlock: '<S178>/STATE_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1",
      0, 0);
    SatelliteServicing_Mission_DW->STATE_1_Simulator_n = (void *)tmp;
    tmp_0 = pointer_is_null(SatelliteServicing_Mission_DW->STATE_1_Simulator_n);
    if (tmp_0) {
      SatelliteServicing_Mission_587682d_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1",
        0, 0);
      SatelliteServicing_Mission_DW->STATE_1_Simulator_n = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->STATE_1_SimData_f = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->STATE_1_DiagMgr_p = (void *)diagnosticManager;
    modelParameters_4.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_4.mSolverAbsTol = 0.001;
    modelParameters_4.mSolverRelTol = 0.001;
    modelParameters_4.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_4.mStartTime = 0.0;
    modelParameters_4.mLoadInitialState = false;
    modelParameters_4.mUseSimState = false;
    modelParameters_4.mLinTrimCompile = false;
    modelParameters_4.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_4.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_4.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_4.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_4.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_4.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_4.mIsUsingODEN = tmp_0;
    modelParameters_4.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_p);
    diagnosticTree_4 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_n), &modelParameters_4,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_4 = rtw_diagnostics_msg(diagnosticTree_4);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_4);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S178>/STATE_1'

    // Start for SimscapeExecutionBlock: '<S178>/OUTPUT_1_0'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1",
      1, 0);
    SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_g = (void *)tmp;
    tmp_0 = pointer_is_null
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_g);
    if (tmp_0) {
      SatelliteServicing_Mission_587682d_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1",
        1, 0);
      SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_g = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_n = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_m = (void *)
      diagnosticManager;
    modelParameters_5.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_5.mSolverAbsTol = 0.001;
    modelParameters_5.mSolverRelTol = 0.001;
    modelParameters_5.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_5.mStartTime = 0.0;
    modelParameters_5.mLoadInitialState = false;
    modelParameters_5.mUseSimState = false;
    modelParameters_5.mLinTrimCompile = false;
    modelParameters_5.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_5.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_5.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_5.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_5.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_5.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_5.mIsUsingODEN = tmp_0;
    modelParameters_5.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_m);
    diagnosticTree_5 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_g),
      &modelParameters_5, diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_5 = rtw_diagnostics_msg(diagnosticTree_5);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_5);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S178>/OUTPUT_1_0'

    // Start for SimscapeRtp: '<S185>/RTP_1'
    manager_0 = nesl_lease_rtp_manager(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1",
      0);
    manager = manager_0;
    tmp_0 = pointer_is_null(manager_0);
    if (tmp_0) {
      SatelliteServicing_Mission_2eaac34_1_gateway();
      manager = nesl_lease_rtp_manager(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1",
        0);
    }

    SatelliteServicing_Mission_DW->RTP_1_RtpManager_a = (void *)manager;
    SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_a = true;

    // End of Start for SimscapeRtp: '<S185>/RTP_1'

    // Start for SimscapeExecutionBlock: '<S208>/STATE_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1",
      0, 0);
    SatelliteServicing_Mission_DW->STATE_1_Simulator_l = (void *)tmp;
    tmp_0 = pointer_is_null(SatelliteServicing_Mission_DW->STATE_1_Simulator_l);
    if (tmp_0) {
      SatelliteServicing_Mission_2eaac34_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1",
        0, 0);
      SatelliteServicing_Mission_DW->STATE_1_Simulator_l = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->STATE_1_SimData_k = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->STATE_1_DiagMgr_pq = (void *)
      diagnosticManager;
    modelParameters_6.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_6.mSolverAbsTol = 0.001;
    modelParameters_6.mSolverRelTol = 0.001;
    modelParameters_6.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_6.mStartTime = 0.0;
    modelParameters_6.mLoadInitialState = false;
    modelParameters_6.mUseSimState = false;
    modelParameters_6.mLinTrimCompile = false;
    modelParameters_6.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_6.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_6.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_6.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_6.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_6.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_6.mIsUsingODEN = tmp_0;
    modelParameters_6.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_pq);
    diagnosticTree_6 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_l), &modelParameters_6,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_6 = rtw_diagnostics_msg(diagnosticTree_6);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_6);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S208>/STATE_1'

    // Start for SimscapeExecutionBlock: '<S208>/OUTPUT_1_0'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1",
      1, 0);
    SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_jb = (void *)tmp;
    tmp_0 = pointer_is_null
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_jb);
    if (tmp_0) {
      SatelliteServicing_Mission_2eaac34_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1",
        1, 0);
      SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_jb = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_g = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_a = (void *)
      diagnosticManager;
    modelParameters_7.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_7.mSolverAbsTol = 0.001;
    modelParameters_7.mSolverRelTol = 0.001;
    modelParameters_7.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_7.mStartTime = 0.0;
    modelParameters_7.mLoadInitialState = false;
    modelParameters_7.mUseSimState = false;
    modelParameters_7.mLinTrimCompile = false;
    modelParameters_7.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_7.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_7.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_7.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_7.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_7.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_7.mIsUsingODEN = tmp_0;
    modelParameters_7.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_a);
    diagnosticTree_7 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_jb),
      &modelParameters_7, diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_7 = rtw_diagnostics_msg(diagnosticTree_7);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_7);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S208>/OUTPUT_1_0'

    // Start for SimscapeRtp: '<S215>/RTP_1'
    manager_0 = nesl_lease_rtp_manager(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1",
      0);
    manager = manager_0;
    tmp_0 = pointer_is_null(manager_0);
    if (tmp_0) {
      SatelliteServicing_Mission_ea4b6336_1_gateway();
      manager = nesl_lease_rtp_manager(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1",
        0);
    }

    SatelliteServicing_Mission_DW->RTP_1_RtpManager_n = (void *)manager;
    SatelliteServicing_Mission_DW->RTP_1_SetParametersNeeded_l = true;

    // End of Start for SimscapeRtp: '<S215>/RTP_1'

    // Start for SimscapeExecutionBlock: '<S238>/STATE_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1",
      0, 0);
    SatelliteServicing_Mission_DW->STATE_1_Simulator_j = (void *)tmp;
    tmp_0 = pointer_is_null(SatelliteServicing_Mission_DW->STATE_1_Simulator_j);
    if (tmp_0) {
      SatelliteServicing_Mission_ea4b6336_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1",
        0, 0);
      SatelliteServicing_Mission_DW->STATE_1_Simulator_j = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->STATE_1_SimData_m = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->STATE_1_DiagMgr_i = (void *)diagnosticManager;
    modelParameters_8.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_8.mSolverAbsTol = 0.001;
    modelParameters_8.mSolverRelTol = 0.001;
    modelParameters_8.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_8.mStartTime = 0.0;
    modelParameters_8.mLoadInitialState = false;
    modelParameters_8.mUseSimState = false;
    modelParameters_8.mLinTrimCompile = false;
    modelParameters_8.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_8.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_8.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_8.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_8.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_8.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_8.mIsUsingODEN = tmp_0;
    modelParameters_8.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_i);
    diagnosticTree_8 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->STATE_1_Simulator_j), &modelParameters_8,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_8 = rtw_diagnostics_msg(diagnosticTree_8);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_8);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S238>/STATE_1'

    // Start for SimscapeExecutionBlock: '<S238>/OUTPUT_1_0'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1",
      1, 0);
    SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_a = (void *)tmp;
    tmp_0 = pointer_is_null
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_a);
    if (tmp_0) {
      SatelliteServicing_Mission_ea4b6336_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1",
        1, 0);
      SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_a = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_o = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_i = (void *)
      diagnosticManager;
    modelParameters_9.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_9.mSolverAbsTol = 0.001;
    modelParameters_9.mSolverRelTol = 0.001;
    modelParameters_9.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_9.mStartTime = 0.0;
    modelParameters_9.mLoadInitialState = false;
    modelParameters_9.mUseSimState = false;
    modelParameters_9.mLinTrimCompile = false;
    modelParameters_9.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_9.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_9.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_9.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_9.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_9.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_9.mIsUsingODEN = tmp_0;
    modelParameters_9.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_i);
    diagnosticTree_9 = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_0_Simulator_a),
      &modelParameters_9, diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_9 = rtw_diagnostics_msg(diagnosticTree_9);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_9);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S238>/OUTPUT_1_0'

    // Start for SimscapeExecutionBlock: '<S148>/OUTPUT_1_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1",
      1, 1);
    SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_j = (void *)tmp;
    tmp_0 = pointer_is_null
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_j);
    if (tmp_0) {
      SatelliteServicing_Mission_e7143f6a_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1",
        1, 1);
      SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_j = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_f = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_e = (void *)
      diagnosticManager;
    modelParameters_a.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_a.mSolverAbsTol = 0.001;
    modelParameters_a.mSolverRelTol = 0.001;
    modelParameters_a.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_a.mStartTime = 0.0;
    modelParameters_a.mLoadInitialState = false;
    modelParameters_a.mUseSimState = false;
    modelParameters_a.mLinTrimCompile = false;
    modelParameters_a.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_a.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_a.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_a.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_a.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_a.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_a.mIsUsingODEN = tmp_0;
    modelParameters_a.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_e);
    diagnosticTree_a = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_j),
      &modelParameters_a, diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_a = rtw_diagnostics_msg(diagnosticTree_a);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_a);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S148>/OUTPUT_1_1'

    // Start for SimscapeExecutionBlock: '<S178>/OUTPUT_1_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1",
      1, 1);
    SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_n = (void *)tmp;
    tmp_0 = pointer_is_null
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_n);
    if (tmp_0) {
      SatelliteServicing_Mission_587682d_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1",
        1, 1);
      SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_n = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_e = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_f = (void *)
      diagnosticManager;
    modelParameters_b.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_b.mSolverAbsTol = 0.001;
    modelParameters_b.mSolverRelTol = 0.001;
    modelParameters_b.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_b.mStartTime = 0.0;
    modelParameters_b.mLoadInitialState = false;
    modelParameters_b.mUseSimState = false;
    modelParameters_b.mLinTrimCompile = false;
    modelParameters_b.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_b.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_b.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_b.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_b.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_b.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_b.mIsUsingODEN = tmp_0;
    modelParameters_b.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_f);
    diagnosticTree_b = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_n),
      &modelParameters_b, diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_b = rtw_diagnostics_msg(diagnosticTree_b);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_b);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S178>/OUTPUT_1_1'

    // Start for SimscapeExecutionBlock: '<S208>/OUTPUT_1_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1",
      1, 1);
    SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_jb = (void *)tmp;
    tmp_0 = pointer_is_null
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_jb);
    if (tmp_0) {
      SatelliteServicing_Mission_2eaac34_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1",
        1, 1);
      SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_jb = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_l = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_h = (void *)
      diagnosticManager;
    modelParameters_c.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_c.mSolverAbsTol = 0.001;
    modelParameters_c.mSolverRelTol = 0.001;
    modelParameters_c.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_c.mStartTime = 0.0;
    modelParameters_c.mLoadInitialState = false;
    modelParameters_c.mUseSimState = false;
    modelParameters_c.mLinTrimCompile = false;
    modelParameters_c.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_c.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_c.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_c.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_c.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_c.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_c.mIsUsingODEN = tmp_0;
    modelParameters_c.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_h);
    diagnosticTree_c = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_jb),
      &modelParameters_c, diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_c = rtw_diagnostics_msg(diagnosticTree_c);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_c);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S208>/OUTPUT_1_1'

    // Start for SimscapeExecutionBlock: '<S238>/OUTPUT_1_1'
    tmp = nesl_lease_simulator(
      "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1",
      1, 1);
    SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_d = (void *)tmp;
    tmp_0 = pointer_is_null
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_d);
    if (tmp_0) {
      SatelliteServicing_Mission_ea4b6336_1_gateway();
      tmp = nesl_lease_simulator(
        "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1",
        1, 1);
      SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_d = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_o = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_a = (void *)
      diagnosticManager;
    modelParameters_d.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters_d.mSolverAbsTol = 0.001;
    modelParameters_d.mSolverRelTol = 0.001;
    modelParameters_d.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters_d.mStartTime = 0.0;
    modelParameters_d.mLoadInitialState = false;
    modelParameters_d.mUseSimState = false;
    modelParameters_d.mLinTrimCompile = false;
    modelParameters_d.mLoggingMode = SSC_LOGGING_ON;
    modelParameters_d.mRTWModifiedTimeStamp = 6.46456831E+8;
    modelParameters_d.mUseModelRefSolver = false;
    tmp_2 = 0.001;
    modelParameters_d.mSolverTolerance = tmp_2;
    tmp_2 = 0.5;
    modelParameters_d.mFixedStepSize = tmp_2;
    tmp_0 = false;
    modelParameters_d.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    modelParameters_d.mIsUsingODEN = tmp_0;
    modelParameters_d.mZcDisabled = true;
    diagnosticManager = static_cast<NeuDiagnosticManager *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_a);
    diagnosticTree_d = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator(static_cast<NeslSimulator *>
      (SatelliteServicing_Mission_DW->OUTPUT_1_1_Simulator_d),
      &modelParameters_d, diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus
        (SatelliteServicing_Mission_M));
      if (tmp_0) {
        msg_d = rtw_diagnostics_msg(diagnosticTree_d);
        rtmSetErrorStatus(SatelliteServicing_Mission_M, msg_d);
      }
    }

    // End of Start for SimscapeExecutionBlock: '<S238>/OUTPUT_1_1'

    // InitializeConditions for DiscreteIntegrator: '<S255>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[0] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC;

    // InitializeConditions for DiscreteIntegrator: '<S254>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[0] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC_f;

    // InitializeConditions for DiscreteIntegrator: '<S255>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[1] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC;

    // InitializeConditions for DiscreteIntegrator: '<S254>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[1] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC_f;

    // InitializeConditions for DiscreteIntegrator: '<S255>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTATE[2] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC;

    // InitializeConditions for DiscreteIntegrator: '<S254>/Discrete-Time Integrator1' 
    SatelliteServicing_Mission_DW->DiscreteTimeIntegrator1_DSTAT_m[2] =
      SatelliteServicing_Mission_P.DiscreteTimeIntegrator1_IC_f;

    // InitializeConditions for Delay: '<S114>/Delay'
    SatelliteServicing_Mission_DW->icLoad = true;

    // InitializeConditions for Delay: '<S114>/Delay1'
    SatelliteServicing_Mission_DW->icLoad_d = true;
  }
}

// Model terminate function
void SatelliteServicing_Mission_terminate(RT_MODEL_SatelliteServicing_M_T
  * SatelliteServicing_Mission_M)
{
  DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
    SatelliteServicing_Mission_M->dwork };

  // Terminate for SimscapeExecutionBlock: '<S300>/STATE_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S300>/OUTPUT_1_0'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S300>/OUTPUT_1_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData));
  nesl_erase_simulator("SatelliteServicing_Mission/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S148>/STATE_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_a));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_g));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S148>/OUTPUT_1_0'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_g));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_b));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S178>/STATE_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_p));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_f));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S178>/OUTPUT_1_0'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_m));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_n));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S208>/STATE_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_pq));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_k));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S208>/OUTPUT_1_0'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_a));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_g));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S238>/STATE_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->STATE_1_DiagMgr_i));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->STATE_1_SimData_m));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S238>/OUTPUT_1_0'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_DiagMgr_i));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_0_SimData_o));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S148>/OUTPUT_1_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_e));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_f));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S178>/OUTPUT_1_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_f));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_e));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S208>/OUTPUT_1_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_h));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_l));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration_1");
  nesl_destroy_registry();

  // Terminate for SimscapeExecutionBlock: '<S238>/OUTPUT_1_1'
  neu_destroy_diagnostic_manager(static_cast<NeuDiagnosticManager *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_DiagMgr_a));
  nesl_destroy_simulation_data(static_cast<NeslSimulationData *>
    (SatelliteServicing_Mission_DW->OUTPUT_1_1_SimData_o));
  nesl_erase_simulator("SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration_1");
  nesl_destroy_registry();
  rt_FREE(SatelliteServicing_Mission_M->solverInfo);

  // model code
  rt_FREE(SatelliteServicing_Mission_M->blockIO);
  rt_FREE(SatelliteServicing_Mission_M->contStates);
  rt_FREE(SatelliteServicing_Mission_M->dwork);
  delete SatelliteServicing_Mission_M;
}

// Model data allocation function
RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission
  (ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
   ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y)
{
  RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission_M;
  SatelliteServicing_Mission_M = new RT_MODEL_SatelliteServicing_M_T();
  if (SatelliteServicing_Mission_M == (nullptr)) {
    return (nullptr);
  }

  {
    // Setup solver object
    RTWSolverInfo *rt_SolverInfo{ (RTWSolverInfo *) malloc(sizeof(RTWSolverInfo))
    };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,rt_SolverInfo);
    SatelliteServicing_Mission_M->solverInfo = (rt_SolverInfo);
    rtsiSetSimTimeStepPtr(SatelliteServicing_Mission_M->solverInfo,
                          &SatelliteServicing_Mission_M->Timing.simTimeStep);
    rtsiSetTPtr(SatelliteServicing_Mission_M->solverInfo, &rtmGetTPtr
                (SatelliteServicing_Mission_M));
    rtsiSetStepSizePtr(SatelliteServicing_Mission_M->solverInfo,
                       &SatelliteServicing_Mission_M->Timing.stepSize0);
    rtsiSetdXPtr(SatelliteServicing_Mission_M->solverInfo,
                 &SatelliteServicing_Mission_M->derivs);
    rtsiSetContStatesPtr(SatelliteServicing_Mission_M->solverInfo, (real_T **)
                         &SatelliteServicing_Mission_M->contStates);
    rtsiSetNumContStatesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(SatelliteServicing_Mission_M->solverInfo,
      &SatelliteServicing_Mission_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(SatelliteServicing_Mission_M->solverInfo,
                          (&rtmGetErrorStatus(SatelliteServicing_Mission_M)));
    rtsiSetRTModelPtr(SatelliteServicing_Mission_M->solverInfo,
                      SatelliteServicing_Mission_M);
  }

  rtsiSetSolverName(SatelliteServicing_Mission_M->solverInfo,"ode3");

  // block I/O
  {
    B_SatelliteServicing_Mission_T *b{ (B_SatelliteServicing_Mission_T *) malloc
      (sizeof(B_SatelliteServicing_Mission_T)) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,b);
    SatelliteServicing_Mission_M->blockIO = (b);
  }

  // states (continuous)
  {
    X_SatelliteServicing_Mission_T *x{ (X_SatelliteServicing_Mission_T *) malloc
      (sizeof(X_SatelliteServicing_Mission_T)) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,x);
    SatelliteServicing_Mission_M->contStates = (x);
  }

  // states (dwork)
  {
    DW_SatelliteServicing_Mission_T *dwork{ static_cast<
      DW_SatelliteServicing_Mission_T *>(malloc(sizeof
      (DW_SatelliteServicing_Mission_T))) };

    rt_VALIDATE_MEMORY(SatelliteServicing_Mission_M,dwork);
    SatelliteServicing_Mission_M->dwork = (dwork);
  }

  {
    B_SatelliteServicing_Mission_T *SatelliteServicing_Mission_B{
      SatelliteServicing_Mission_M->blockIO };

    DW_SatelliteServicing_Mission_T *SatelliteServicing_Mission_DW{
      SatelliteServicing_Mission_M->dwork };

    X_SatelliteServicing_Mission_T *SatelliteServicing_Mission_X{
      SatelliteServicing_Mission_M->contStates };

    // initialize non-finites
    rt_InitInfAndNaN(sizeof(real_T));
    rtsiSetSimTimeStep(SatelliteServicing_Mission_M->solverInfo, MAJOR_TIME_STEP);
    SatelliteServicing_Mission_M->intgData.y =
      SatelliteServicing_Mission_M->odeY;
    SatelliteServicing_Mission_M->intgData.f[0] =
      SatelliteServicing_Mission_M->odeF[0];
    SatelliteServicing_Mission_M->intgData.f[1] =
      SatelliteServicing_Mission_M->odeF[1];
    SatelliteServicing_Mission_M->intgData.f[2] =
      SatelliteServicing_Mission_M->odeF[2];
    SatelliteServicing_Mission_M->contStates = ((X_SatelliteServicing_Mission_T *)
      SatelliteServicing_Mission_X);
    rtsiSetSolverData(SatelliteServicing_Mission_M->solverInfo, static_cast<void
                      *>(&SatelliteServicing_Mission_M->intgData));
    rtsiSetIsMinorTimeStepWithModeChange
      (SatelliteServicing_Mission_M->solverInfo, false);
    rtmSetTPtr(SatelliteServicing_Mission_M,
               &SatelliteServicing_Mission_M->Timing.tArray[0]);
    SatelliteServicing_Mission_M->Timing.stepSize0 = 0.5;

    // block I/O
    (void) std::memset((static_cast<void *>(SatelliteServicing_Mission_B)), 0,
                       sizeof(B_SatelliteServicing_Mission_T));

    // states (continuous)
    {
      (void) std::memset(static_cast<void *>(SatelliteServicing_Mission_X), 0,
                         sizeof(X_SatelliteServicing_Mission_T));
    }

    // states (dwork)
    (void) std::memset(static_cast<void *>(SatelliteServicing_Mission_DW), 0,
                       sizeof(DW_SatelliteServicing_Mission_T));

    // external inputs
    (void)std::memset(SatelliteServicing_Mission_U, 0, sizeof
                      (ExtU_SatelliteServicing_Missi_T));

    // external outputs
    (void)std::memset(SatelliteServicing_Mission_Y, 0, sizeof
                      (ExtY_SatelliteServicing_Missi_T));
  }

  return SatelliteServicing_Mission_M;
}

//
// File trailer for generated code.
//
// [EOF]
//
