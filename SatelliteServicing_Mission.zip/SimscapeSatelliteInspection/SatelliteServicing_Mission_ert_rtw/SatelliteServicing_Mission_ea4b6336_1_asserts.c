/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

void SatelliteServicing_Mission_ea4b6336_1_validateRuntimeParameters(const
  double *rtp, int32_T *satFlags)
{
  boolean_T bb[12];
  double xx[1];
  xx[0] = rtp[0];
  bb[0] = sm_core_math_anyIsInf(1, xx + 0);
  bb[1] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[1];
  bb[2] = sm_core_math_anyIsInf(1, xx + 0);
  bb[3] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[2];
  bb[4] = sm_core_math_anyIsInf(1, xx + 0);
  bb[5] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[3];
  bb[6] = sm_core_math_anyIsInf(1, xx + 0);
  bb[7] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[4];
  bb[8] = sm_core_math_anyIsInf(1, xx + 0);
  bb[9] = sm_core_math_anyIsNaN(1, xx + 0);
  xx[0] = rtp[5];
  bb[10] = sm_core_math_anyIsInf(1, xx + 0);
  bb[11] = sm_core_math_anyIsNaN(1, xx + 0);
  satFlags[0] = !bb[0] ? 1 : 0;
  satFlags[1] = !bb[1] ? 1 : 0;
  satFlags[2] = !bb[2] ? 1 : 0;
  satFlags[3] = !bb[3] ? 1 : 0;
  satFlags[4] = !bb[4] ? 1 : 0;
  satFlags[5] = !bb[5] ? 1 : 0;
  satFlags[6] = !bb[6] ? 1 : 0;
  satFlags[7] = !bb[7] ? 1 : 0;
  satFlags[8] = !bb[8] ? 1 : 0;
  satFlags[9] = !bb[9] ? 1 : 0;
  satFlags[10] = !bb[10] ? 1 : 0;
  satFlags[11] = !bb[11] ? 1 : 0;
}

const NeAssertData SatelliteServicing_Mission_ea4b6336_1_assertData[12] = {
  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Px/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Py/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Position contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains an Inf value, which is not allowed.",
    "sm:model:evaluate:InvalidValueInf" },

  { "SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/6-DOF Joint",
    0, 0,
    "Mission.Cubesat_Inspection.Cubesats.CubeSat4.CubeSat4_Propagation.x6_DOF_Joint",
    "", false,
    "The parameter Pz/Velocity contains a NaN value, which is not allowed.",
    "sm:model:evaluate:InvalidValueNaN" }
};
