/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "SatelliteServicing_Mission_587682d_1_geometries.h"

PmfMessageId SatelliteServicing_Mission_587682d_1_compOutputsKin(const
  RuntimeDerivedValuesBundle *rtdv, const double *state, const int *modeVector,
  const double *input, const double *inputDot, const double *inputDdot, const
  double *discreteState, double *output, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[10];
  (void) rtdvd;
  (void) rtdvi;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = - state[3];
  xx[1] = - state[4];
  xx[2] = - state[5];
  xx[3] = - state[6];
  xx[4] = state[7];
  xx[5] = state[8];
  xx[6] = state[9];
  pm_math_Quaternion_inverseXform_ra(xx + 0, xx + 4, xx + 7);
  pm_math_Quaternion_xform_ra(xx + 0, xx + 7, xx + 4);
  xx[0] = 9.87654321;
  output[0] = state[0];
  output[1] = state[1];
  output[2] = state[2];
  output[3] = xx[4];
  output[4] = xx[5];
  output[5] = xx[6];
  return NULL;
}
