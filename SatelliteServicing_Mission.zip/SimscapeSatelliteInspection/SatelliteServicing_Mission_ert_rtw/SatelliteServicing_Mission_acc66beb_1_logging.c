/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "SatelliteServicing_Mission_acc66beb_1_geometries.h"

PmfMessageId SatelliteServicing_Mission_acc66beb_1_recordLog(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, double *logVector, double *errorResult,
  NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  int ii[1];
  double xx[89];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) inputDot;
  (void) inputDdot;
  (void) neDiagMgr;
  xx[0] = 57.29577951308232;
  xx[1] = 1.0;
  xx[2] = state[3];
  xx[3] = state[4];
  xx[4] = state[5];
  xx[5] = state[6];
  xx[6] = 0.5;
  xx[7] = - xx[6];
  xx[8] = xx[7];
  xx[9] = xx[6];
  xx[10] = xx[6];
  xx[11] = xx[7];
  pm_math_Quaternion_composeInverse_ra(xx + 2, xx + 8, xx + 12);
  xx[2] = xx[14] * xx[14];
  xx[3] = xx[15] * xx[15];
  xx[4] = 2.0;
  xx[5] = xx[1] - (xx[2] + xx[3]) * xx[4];
  xx[7] = xx[13] * xx[14];
  xx[16] = xx[12] * xx[15];
  xx[17] = xx[4] * (xx[7] - xx[16]);
  xx[18] = xx[12] * xx[14];
  xx[19] = xx[13] * xx[15];
  xx[20] = (xx[18] + xx[19]) * xx[4];
  xx[21] = xx[5];
  xx[22] = xx[17];
  xx[23] = xx[20];
  xx[24] = 452.4999999999999;
  xx[25] = xx[24] * xx[5];
  xx[26] = xx[24] * xx[17];
  xx[27] = xx[24] * xx[20];
  xx[28] = (xx[16] + xx[7]) * xx[4];
  xx[7] = xx[13] * xx[13];
  xx[16] = xx[1] - (xx[3] + xx[7]) * xx[4];
  xx[3] = xx[14] * xx[15];
  xx[29] = xx[12] * xx[13];
  xx[30] = xx[4] * (xx[3] - xx[29]);
  xx[31] = xx[24] * xx[28];
  xx[32] = xx[24] * xx[16];
  xx[33] = xx[24] * xx[30];
  xx[34] = pm_math_Vector3_dot_ra(xx + 21, xx + 31);
  xx[35] = xx[4] * (xx[19] - xx[18]);
  xx[18] = (xx[29] + xx[3]) * xx[4];
  xx[3] = xx[1] - (xx[7] + xx[2]) * xx[4];
  xx[36] = xx[24] * xx[35];
  xx[37] = xx[24] * xx[18];
  xx[38] = xx[24] * xx[3];
  xx[1] = pm_math_Vector3_dot_ra(xx + 21, xx + 36);
  xx[2] = 1.942890293094814e-16;
  xx[7] = xx[2] * xx[20];
  xx[19] = 5.023759186428833e-14;
  xx[29] = xx[2] * xx[17] - xx[19] * xx[5];
  xx[5] = xx[19] * xx[20];
  xx[39] = xx[28];
  xx[40] = xx[16];
  xx[41] = xx[30];
  xx[17] = pm_math_Vector3_dot_ra(xx + 39, xx + 36);
  xx[20] = xx[2] * xx[30];
  xx[42] = xx[2] * xx[16] - xx[19] * xx[28];
  xx[16] = xx[19] * xx[30];
  xx[43] = xx[35];
  xx[44] = xx[18];
  xx[45] = xx[3];
  xx[28] = xx[2] * xx[3];
  xx[30] = xx[2] * xx[18] - xx[19] * xx[35];
  xx[2] = xx[19] * xx[3];
  xx[3] = 141.5794617906537;
  xx[18] = 0.0;
  xx[19] = 2.157041537714581e-32;
  xx[35] = 118.885022412572;
  xx[46] = 146.2582106219183;
  xx[47] = pm_math_Vector3_dot_ra(xx + 21, xx + 25);
  xx[48] = xx[34];
  xx[49] = xx[1];
  xx[50] = xx[7];
  xx[51] = xx[29];
  xx[52] = xx[5];
  xx[53] = xx[34];
  xx[54] = pm_math_Vector3_dot_ra(xx + 39, xx + 31);
  xx[55] = xx[17];
  xx[56] = xx[20];
  xx[57] = xx[42];
  xx[58] = xx[16];
  xx[59] = xx[1];
  xx[60] = xx[17];
  xx[61] = pm_math_Vector3_dot_ra(xx + 43, xx + 36);
  xx[62] = xx[28];
  xx[63] = xx[30];
  xx[64] = xx[2];
  xx[65] = xx[7];
  xx[66] = xx[20];
  xx[67] = xx[28];
  xx[68] = xx[3];
  xx[69] = xx[18];
  xx[70] = xx[19];
  xx[71] = xx[29];
  xx[72] = xx[42];
  xx[73] = xx[30];
  xx[74] = xx[18];
  xx[75] = xx[35];
  xx[76] = xx[18];
  xx[77] = xx[5];
  xx[78] = xx[16];
  xx[79] = xx[2];
  xx[80] = xx[19];
  xx[81] = xx[18];
  xx[82] = xx[46];
  ii[0] = factorSymmetricPosDef(xx + 47, 6, xx + 25);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'SatelliteServicing_Mission/ServicingSatellite/SatConfiguration' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[25] = state[10];
  xx[26] = state[11];
  xx[27] = state[12];
  pm_math_Quaternion_xform_ra(xx + 8, xx + 25, xx + 28);
  xx[25] = state[7];
  xx[26] = state[8];
  xx[27] = state[9];
  pm_math_Quaternion_inverseXform_ra(xx + 12, xx + 25, xx + 31);
  xx[1] = 1.110223024625157e-16;
  xx[2] = 4.293680205734395e-19;
  xx[12] = xx[31] + xx[1] * xx[30];
  xx[13] = xx[32] - xx[2] * xx[30];
  xx[14] = xx[33] + xx[2] * xx[29] - xx[1] * xx[28];
  pm_math_Vector3_cross_ra(xx + 28, xx + 12, xx + 15);
  xx[12] = - xx[31];
  xx[13] = - xx[32];
  xx[14] = - xx[33];
  pm_math_Vector3_cross_ra(xx + 28, xx + 12, xx + 25);
  xx[5] = xx[6] * xx[6] * input[0];
  xx[7] = xx[4] * (xx[5] - xx[5]);
  xx[12] = xx[6] * xx[6] * input[1];
  xx[13] = (xx[12] + xx[12]) * xx[4];
  xx[14] = input[1] - xx[13];
  xx[19] = xx[6] * xx[6] * input[2];
  xx[6] = (xx[15] + xx[25]) * xx[24] - (xx[7] + xx[14] - (xx[19] + xx[19]) * xx
    [4]);
  xx[20] = input[0] - (xx[5] + xx[5]) * xx[4];
  xx[31] = xx[4] * (xx[19] - xx[19]);
  xx[32] = (xx[16] + xx[26]) * xx[24] - (xx[20] + xx[13] + xx[31]);
  xx[13] = xx[4] * (xx[12] - xx[12]);
  xx[12] = input[2] - (xx[19] + xx[19]) * xx[4];
  xx[15] = (xx[17] + xx[27]) * xx[24] - (xx[13] - (xx[5] + xx[5]) * xx[4] + xx
    [12]);
  xx[24] = xx[6];
  xx[25] = xx[32];
  xx[26] = xx[15];
  xx[36] = xx[46] * xx[28];
  xx[37] = xx[3] * xx[29];
  xx[38] = xx[35] * xx[30];
  pm_math_Vector3_cross_ra(xx + 28, xx + 36, xx + 3);
  xx[16] = 0.75;
  xx[17] = 0.6929096493834649;
  xx[27] = input[3];
  xx[28] = input[4];
  xx[29] = input[5];
  pm_math_Quaternion_xform_ra(xx + 8, xx + 27, xx + 33);
  xx[8] = 0.692909649383465;
  xx[83] = - pm_math_Vector3_dot_ra(xx + 21, xx + 24);
  xx[84] = - pm_math_Vector3_dot_ra(xx + 39, xx + 24);
  xx[85] = - pm_math_Vector3_dot_ra(xx + 43, xx + 24);
  xx[86] = - (xx[4] - xx[16] * xx[7] + xx[17] * xx[12] - xx[34] + xx[2] * xx[15]);
  xx[87] = xx[5] - xx[8] * xx[14] - xx[17] * xx[31] - xx[35] - (xx[2] * xx[32] -
    xx[1] * xx[6]);
  xx[88] = xx[3] + xx[16] * xx[20] + xx[8] * xx[13] - xx[33] - xx[1] * xx[15];
  solveSymmetricPosDef(xx + 47, xx + 83, 6, 1, xx + 1, xx + 7);
  logVector[0] = state[0];
  logVector[1] = state[1];
  logVector[2] = state[2];
  logVector[3] = state[3];
  logVector[4] = state[4];
  logVector[5] = state[5];
  logVector[6] = state[6];
  logVector[7] = state[7];
  logVector[8] = state[8];
  logVector[9] = state[9];
  logVector[10] = xx[0] * state[10];
  logVector[11] = xx[0] * state[11];
  logVector[12] = xx[0] * state[12];
  logVector[13] = xx[1];
  logVector[14] = xx[2];
  logVector[15] = xx[3];
  logVector[16] = xx[0] * xx[4];
  logVector[17] = xx[0] * xx[5];
  logVector[18] = xx[0] * xx[6];
  errorResult[0] = xx[18];
  return NULL;
}
