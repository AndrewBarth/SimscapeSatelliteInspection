/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "SatelliteServicing_Mission_acc66beb_1_geometries.h"

PmfMessageId SatelliteServicing_Mission_acc66beb_1_recordLog(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, double *logVector, double *errorResult,
  NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  int ii[1];
  double xx[83];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) neDiagMgr;
  xx[0] = 57.29577951308232;
  xx[1] = 1.0;
  xx[2] = state[3];
  xx[3] = state[4];
  xx[4] = state[5];
  xx[5] = state[6];
  xx[6] = 0.5;
  xx[7] = - xx[6];
  xx[8] = xx[7];
  xx[9] = xx[6];
  xx[10] = xx[6];
  xx[11] = xx[7];
  pm_math_Quaternion_composeInverse_ra(xx + 2, xx + 8, xx + 12);
  xx[2] = xx[14] * xx[14];
  xx[3] = xx[15] * xx[15];
  xx[4] = 2.0;
  xx[5] = xx[1] - (xx[2] + xx[3]) * xx[4];
  xx[6] = xx[13] * xx[14];
  xx[7] = xx[12] * xx[15];
  xx[16] = xx[4] * (xx[6] - xx[7]);
  xx[17] = xx[12] * xx[14];
  xx[18] = xx[13] * xx[15];
  xx[19] = (xx[17] + xx[18]) * xx[4];
  xx[20] = xx[5];
  xx[21] = xx[16];
  xx[22] = xx[19];
  xx[23] = 21.0;
  xx[24] = xx[23] * xx[5];
  xx[25] = xx[23] * xx[16];
  xx[26] = xx[23] * xx[19];
  xx[27] = (xx[7] + xx[6]) * xx[4];
  xx[6] = xx[13] * xx[13];
  xx[7] = xx[1] - (xx[3] + xx[6]) * xx[4];
  xx[3] = xx[14] * xx[15];
  xx[28] = xx[12] * xx[13];
  xx[29] = xx[4] * (xx[3] - xx[28]);
  xx[30] = xx[23] * xx[27];
  xx[31] = xx[23] * xx[7];
  xx[32] = xx[23] * xx[29];
  xx[33] = pm_math_Vector3_dot_ra(xx + 20, xx + 30);
  xx[34] = xx[4] * (xx[18] - xx[17]);
  xx[17] = (xx[28] + xx[3]) * xx[4];
  xx[3] = xx[1] - (xx[6] + xx[2]) * xx[4];
  xx[35] = xx[23] * xx[34];
  xx[36] = xx[23] * xx[17];
  xx[37] = xx[23] * xx[3];
  xx[1] = pm_math_Vector3_dot_ra(xx + 20, xx + 35);
  xx[2] = 4.163336342344364e-17;
  xx[4] = - (xx[2] * xx[19]);
  xx[6] = 5.828670879282072e-16;
  xx[18] = xx[6] * xx[5] - xx[2] * xx[16];
  xx[5] = - (xx[6] * xx[19]);
  xx[38] = xx[27];
  xx[39] = xx[7];
  xx[40] = xx[29];
  xx[16] = pm_math_Vector3_dot_ra(xx + 38, xx + 35);
  xx[19] = - (xx[2] * xx[29]);
  xx[28] = xx[6] * xx[27] - xx[2] * xx[7];
  xx[7] = - (xx[6] * xx[29]);
  xx[41] = xx[34];
  xx[42] = xx[17];
  xx[43] = xx[3];
  xx[27] = - (xx[2] * xx[3]);
  xx[29] = xx[6] * xx[34] - xx[2] * xx[17];
  xx[17] = - (xx[6] * xx[3]);
  xx[3] = 0.7024163313735985;
  xx[34] = 0.0;
  xx[44] = 1.155557966632349e-33;
  xx[45] = 0.7482314200091527;
  xx[46] = 0.8866567553022207;
  xx[47] = pm_math_Vector3_dot_ra(xx + 20, xx + 24);
  xx[48] = xx[33];
  xx[49] = xx[1];
  xx[50] = xx[4];
  xx[51] = xx[18];
  xx[52] = xx[5];
  xx[53] = xx[33];
  xx[54] = pm_math_Vector3_dot_ra(xx + 38, xx + 30);
  xx[55] = xx[16];
  xx[56] = xx[19];
  xx[57] = xx[28];
  xx[58] = xx[7];
  xx[59] = xx[1];
  xx[60] = xx[16];
  xx[61] = pm_math_Vector3_dot_ra(xx + 41, xx + 35);
  xx[62] = xx[27];
  xx[63] = xx[29];
  xx[64] = xx[17];
  xx[65] = xx[4];
  xx[66] = xx[19];
  xx[67] = xx[27];
  xx[68] = xx[3];
  xx[69] = xx[34];
  xx[70] = xx[44];
  xx[71] = xx[18];
  xx[72] = xx[28];
  xx[73] = xx[29];
  xx[74] = xx[34];
  xx[75] = xx[45];
  xx[76] = xx[34];
  xx[77] = xx[5];
  xx[78] = xx[7];
  xx[79] = xx[17];
  xx[80] = xx[44];
  xx[81] = xx[34];
  xx[82] = xx[46];
  ii[0] = factorSymmetricPosDef(xx + 47, 6, xx + 24);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'SatelliteServicing_Mission/ServicingSatellite/SatConfiguration' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[16] = state[10];
  xx[17] = state[11];
  xx[18] = state[12];
  pm_math_Quaternion_xform_ra(xx + 8, xx + 16, xx + 24);
  xx[7] = state[7];
  xx[8] = state[8];
  xx[9] = state[9];
  pm_math_Quaternion_inverseXform_ra(xx + 12, xx + 7, xx + 16);
  xx[1] = 2.775557561562891e-17;
  xx[4] = 1.982541115402078e-18;
  xx[7] = xx[16] - xx[1] * xx[26];
  xx[8] = xx[17] + xx[4] * xx[26];
  xx[9] = xx[18] + xx[1] * xx[24] - xx[4] * xx[25];
  pm_math_Vector3_cross_ra(xx + 24, xx + 7, xx + 10);
  xx[7] = - xx[16];
  xx[8] = - xx[17];
  xx[9] = - xx[18];
  pm_math_Vector3_cross_ra(xx + 24, xx + 7, xx + 13);
  xx[5] = xx[10] + xx[13];
  xx[7] = xx[11] + xx[14];
  xx[8] = (xx[12] + xx[15]) * xx[23];
  xx[9] = xx[5] * xx[23];
  xx[10] = xx[7] * xx[23];
  xx[11] = xx[8];
  xx[12] = xx[46] * xx[24];
  xx[13] = xx[3] * xx[25];
  xx[14] = xx[45] * xx[26];
  pm_math_Vector3_cross_ra(xx + 24, xx + 12, xx + 15);
  xx[23] = - pm_math_Vector3_dot_ra(xx + 20, xx + 9);
  xx[24] = - pm_math_Vector3_dot_ra(xx + 38, xx + 9);
  xx[25] = - pm_math_Vector3_dot_ra(xx + 41, xx + 9);
  xx[26] = - (xx[16] - xx[4] * xx[8]);
  xx[27] = xx[17] - (xx[5] * xx[6] - xx[7] * xx[2]);
  xx[28] = xx[15] + xx[1] * xx[8];
  solveSymmetricPosDef(xx + 47, xx + 23, 6, 1, xx + 1, xx + 7);
  logVector[0] = state[0];
  logVector[1] = state[1];
  logVector[2] = state[2];
  logVector[3] = state[3];
  logVector[4] = state[4];
  logVector[5] = state[5];
  logVector[6] = state[6];
  logVector[7] = state[7];
  logVector[8] = state[8];
  logVector[9] = state[9];
  logVector[10] = xx[0] * state[10];
  logVector[11] = xx[0] * state[11];
  logVector[12] = xx[0] * state[12];
  logVector[13] = xx[1];
  logVector[14] = xx[2];
  logVector[15] = xx[3];
  logVector[16] = xx[0] * xx[4];
  logVector[17] = xx[0] * xx[5];
  logVector[18] = xx[0] * xx[6];
  errorResult[0] = xx[34];
  return NULL;
}
