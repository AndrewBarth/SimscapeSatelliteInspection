// Simscape target specific file.
//  This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration'.


struct RuntimeDerivedValuesBundleTag;
void SatelliteServicing_Mission_e7143f6a_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
