/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "sm_CTarget.h"

static void setTargets_8(const RuntimeDerivedValuesBundle *rtdv, double *values,
  double *auxData)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) rtdvi;
  (void) auxData;
  values[0] = rtdvd[0];
}

static void setTargets_10(const RuntimeDerivedValuesBundle *rtdv, double *values,
  double *auxData)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) rtdvi;
  (void) auxData;
  values[0] = rtdvd[1];
}

static void setTargets_12(const RuntimeDerivedValuesBundle *rtdv, double *values,
  double *auxData)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) rtdvi;
  (void) auxData;
  values[0] = rtdvd[2];
}

void SatelliteServicing_Mission_acc66beb_1_setTargets(const
  RuntimeDerivedValuesBundle *rtdv, CTarget *targets)
{
  setTargets_8(rtdv, targets[8].mValue, targets[8].mAuxiliaryTargetData);
  setTargets_10(rtdv, targets[10].mValue, targets[10].mAuxiliaryTargetData);
  setTargets_12(rtdv, targets[12].mValue, targets[12].mAuxiliaryTargetData);
}

void SatelliteServicing_Mission_acc66beb_1_resetAsmStateVector(const void *mech,
  double *state)
{
  double xx[2];
  (void) mech;
  xx[0] = 0.0;
  xx[1] = 1.0;
  state[0] = xx[0];
  state[1] = xx[0];
  state[2] = xx[0];
  state[3] = xx[1];
  state[4] = xx[0];
  state[5] = xx[0];
  state[6] = xx[0];
  state[7] = xx[0];
  state[8] = xx[0];
  state[9] = xx[0];
  state[10] = xx[0];
  state[11] = xx[0];
  state[12] = xx[0];
  state[13] = xx[0];
  state[14] = xx[0];
  state[15] = xx[0];
  state[16] = xx[0];
  state[17] = xx[0];
  state[18] = xx[0];
  state[19] = xx[0];
  state[20] = xx[0];
  state[21] = xx[0];
  state[22] = xx[1];
  state[23] = xx[0];
  state[24] = xx[0];
  state[25] = xx[0];
  state[26] = xx[0];
  state[27] = xx[0];
  state[28] = xx[0];
  state[29] = xx[0];
  state[30] = xx[0];
  state[31] = xx[0];
}

void SatelliteServicing_Mission_acc66beb_1_initializeTrackedAngleState(const
  void *mech, const RuntimeDerivedValuesBundle *rtdv, const int *modeVector,
  const double *motionData, double *state)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
  (void) modeVector;
  (void) motionData;
}

void SatelliteServicing_Mission_acc66beb_1_computeDiscreteState(const void *mech,
  const RuntimeDerivedValuesBundle *rtdv, double *state)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
}

void SatelliteServicing_Mission_acc66beb_1_adjustPosition(const void *mech,
  const double *dofDeltas, double *state)
{
  double xx[17];
  (void) mech;
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  xx[4] = dofDeltas[3];
  xx[5] = dofDeltas[4];
  xx[6] = dofDeltas[5];
  pm_math_Quaternion_compDeriv_ra(xx + 0, xx + 4, xx + 7);
  xx[0] = state[3] + xx[7];
  xx[1] = state[4] + xx[8];
  xx[2] = state[5] + xx[9];
  xx[3] = state[6] + xx[10];
  xx[4] = 1.0e-64;
  xx[5] = sqrt(xx[0] * xx[0] + xx[1] * xx[1] + xx[2] * xx[2] + xx[3] * xx[3]);
  if (xx[4] > xx[5])
    xx[5] = xx[4];
  xx[6] = state[22];
  xx[7] = state[23];
  xx[8] = state[24];
  xx[9] = state[25];
  xx[10] = dofDeltas[12];
  xx[11] = dofDeltas[13];
  xx[12] = dofDeltas[14];
  pm_math_Quaternion_compDeriv_ra(xx + 6, xx + 10, xx + 13);
  xx[6] = state[22] + xx[13];
  xx[7] = state[23] + xx[14];
  xx[8] = state[24] + xx[15];
  xx[9] = state[25] + xx[16];
  xx[10] = sqrt(xx[6] * xx[6] + xx[7] * xx[7] + xx[8] * xx[8] + xx[9] * xx[9]);
  if (xx[4] > xx[10])
    xx[10] = xx[4];
  state[0] = state[0] + dofDeltas[0];
  state[1] = state[1] + dofDeltas[1];
  state[2] = state[2] + dofDeltas[2];
  state[3] = xx[0] / xx[5];
  state[4] = xx[1] / xx[5];
  state[5] = xx[2] / xx[5];
  state[6] = xx[3] / xx[5];
  state[13] = state[13] + dofDeltas[6];
  state[15] = state[15] + dofDeltas[7];
  state[17] = state[17] + dofDeltas[8];
  state[19] = state[19] + dofDeltas[9];
  state[20] = state[20] + dofDeltas[10];
  state[21] = state[21] + dofDeltas[11];
  state[22] = xx[6] / xx[10];
  state[23] = xx[7] / xx[10];
  state[24] = xx[8] / xx[10];
  state[25] = xx[9] / xx[10];
}

static void perturbAsmJointPrimitiveState_0_0(double mag, double *state)
{
  state[0] = state[0] + mag;
}

static void perturbAsmJointPrimitiveState_0_0v(double mag, double *state)
{
  state[0] = state[0] + mag;
  state[7] = state[7] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_0_1(double mag, double *state)
{
  state[1] = state[1] + mag;
}

static void perturbAsmJointPrimitiveState_0_1v(double mag, double *state)
{
  state[1] = state[1] + mag;
  state[8] = state[8] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_0_2(double mag, double *state)
{
  state[2] = state[2] + mag;
}

static void perturbAsmJointPrimitiveState_0_2v(double mag, double *state)
{
  state[2] = state[2] + mag;
  state[9] = state[9] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_0_3(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 0, xx + 4);
  state[3] = xx[4];
  state[4] = xx[5];
  state[5] = xx[6];
  state[6] = xx[7];
}

static void perturbAsmJointPrimitiveState_0_3v(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[3] = state[3];
  xx[4] = state[4];
  xx[5] = state[5];
  xx[6] = state[6];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 3, xx + 7);
  state[3] = xx[7];
  state[4] = xx[8];
  state[5] = xx[9];
  state[6] = xx[10];
  state[10] = state[10] + 1.2 * mag;
  state[11] = state[11] - xx[2];
  state[12] = state[12] + 0.9 * mag;
}

static void perturbAsmJointPrimitiveState_1_0(double mag, double *state)
{
  state[13] = state[13] + mag;
}

static void perturbAsmJointPrimitiveState_1_0v(double mag, double *state)
{
  state[13] = state[13] + mag;
  state[14] = state[14] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_2_0(double mag, double *state)
{
  state[15] = state[15] + mag;
}

static void perturbAsmJointPrimitiveState_2_0v(double mag, double *state)
{
  state[15] = state[15] + mag;
  state[16] = state[16] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_3_0(double mag, double *state)
{
  state[17] = state[17] + mag;
}

static void perturbAsmJointPrimitiveState_3_0v(double mag, double *state)
{
  state[17] = state[17] + mag;
  state[18] = state[18] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_4_0(double mag, double *state)
{
  state[19] = state[19] + mag;
}

static void perturbAsmJointPrimitiveState_4_0v(double mag, double *state)
{
  state[19] = state[19] + mag;
  state[26] = state[26] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_4_1(double mag, double *state)
{
  state[20] = state[20] + mag;
}

static void perturbAsmJointPrimitiveState_4_1v(double mag, double *state)
{
  state[20] = state[20] + mag;
  state[27] = state[27] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_4_2(double mag, double *state)
{
  state[21] = state[21] + mag;
}

static void perturbAsmJointPrimitiveState_4_2v(double mag, double *state)
{
  state[21] = state[21] + mag;
  state[28] = state[28] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_4_3(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[0] = state[22];
  xx[1] = state[23];
  xx[2] = state[24];
  xx[3] = state[25];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 0, xx + 4);
  state[22] = xx[4];
  state[23] = xx[5];
  state[24] = xx[6];
  state[25] = xx[7];
}

static void perturbAsmJointPrimitiveState_4_3v(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[3] = state[22];
  xx[4] = state[23];
  xx[5] = state[24];
  xx[6] = state[25];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 3, xx + 7);
  state[22] = xx[7];
  state[23] = xx[8];
  state[24] = xx[9];
  state[25] = xx[10];
  state[29] = state[29] + 1.2 * mag;
  state[30] = state[30] - xx[2];
  state[31] = state[31] + 0.9 * mag;
}

void SatelliteServicing_Mission_acc66beb_1_perturbAsmJointPrimitiveState(const
  void *mech, size_t stageIdx, size_t primIdx, double mag, boolean_T
  doPerturbVelocity, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch ((stageIdx * 6 + primIdx) * 2 + (doPerturbVelocity ? 1 : 0))
  {
   case 0:
    perturbAsmJointPrimitiveState_0_0(mag, state);
    break;

   case 1:
    perturbAsmJointPrimitiveState_0_0v(mag, state);
    break;

   case 2:
    perturbAsmJointPrimitiveState_0_1(mag, state);
    break;

   case 3:
    perturbAsmJointPrimitiveState_0_1v(mag, state);
    break;

   case 4:
    perturbAsmJointPrimitiveState_0_2(mag, state);
    break;

   case 5:
    perturbAsmJointPrimitiveState_0_2v(mag, state);
    break;

   case 6:
    perturbAsmJointPrimitiveState_0_3(mag, state);
    break;

   case 7:
    perturbAsmJointPrimitiveState_0_3v(mag, state);
    break;

   case 12:
    perturbAsmJointPrimitiveState_1_0(mag, state);
    break;

   case 13:
    perturbAsmJointPrimitiveState_1_0v(mag, state);
    break;

   case 24:
    perturbAsmJointPrimitiveState_2_0(mag, state);
    break;

   case 25:
    perturbAsmJointPrimitiveState_2_0v(mag, state);
    break;

   case 36:
    perturbAsmJointPrimitiveState_3_0(mag, state);
    break;

   case 37:
    perturbAsmJointPrimitiveState_3_0v(mag, state);
    break;

   case 48:
    perturbAsmJointPrimitiveState_4_0(mag, state);
    break;

   case 49:
    perturbAsmJointPrimitiveState_4_0v(mag, state);
    break;

   case 50:
    perturbAsmJointPrimitiveState_4_1(mag, state);
    break;

   case 51:
    perturbAsmJointPrimitiveState_4_1v(mag, state);
    break;

   case 52:
    perturbAsmJointPrimitiveState_4_2(mag, state);
    break;

   case 53:
    perturbAsmJointPrimitiveState_4_2v(mag, state);
    break;

   case 54:
    perturbAsmJointPrimitiveState_4_3(mag, state);
    break;

   case 55:
    perturbAsmJointPrimitiveState_4_3v(mag, state);
    break;
  }
}

static void computePosDofBlendMatrix_0_3(const double *state, int partialType,
  double *matrix)
{
  double xx[20];
  xx[0] = 9.87654321;
  xx[1] = 2.0;
  xx[2] = xx[1] * (state[4] * state[5] - state[3] * state[6]);
  xx[3] = xx[2] * xx[2];
  xx[4] = 1.0;
  xx[5] = (state[3] * state[3] + state[4] * state[4]) * xx[1] - xx[4];
  xx[6] = xx[5] * xx[5];
  xx[7] = sqrt(xx[3] + xx[6]);
  xx[8] = xx[7] == 0.0 ? 0.0 : - xx[2] / xx[7];
  xx[9] = xx[6] + xx[3];
  xx[3] = sqrt(xx[9]);
  xx[6] = xx[3] == 0.0 ? 0.0 : xx[5] / xx[3];
  xx[10] = 0.0;
  xx[11] = (state[4] * state[6] + state[3] * state[5]) * xx[1];
  xx[1] = sqrt(xx[9] + xx[11] * xx[11]);
  xx[12] = xx[1] == 0.0 ? 0.0 : xx[5] / xx[1];
  xx[14] = xx[8];
  xx[15] = xx[6];
  xx[16] = xx[10];
  xx[17] = xx[8];
  xx[18] = xx[8];
  xx[19] = xx[12];
  xx[6] = xx[13 + (partialType)];
  xx[8] = xx[7] == 0.0 ? 0.0 : xx[5] / xx[7];
  xx[7] = xx[3] == 0.0 ? 0.0 : xx[2] / xx[3];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[2] / xx[1];
  xx[13] = xx[8];
  xx[14] = xx[7];
  xx[15] = xx[10];
  xx[16] = xx[8];
  xx[17] = xx[8];
  xx[18] = xx[3];
  xx[2] = xx[12 + (partialType)];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[11] / xx[1];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[4];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[18] = xx[3];
  xx[1] = xx[12 + (partialType)];
  xx[3] = xx[11] * xx[5];
  xx[5] = sqrt(xx[9] * xx[9] + xx[3] * xx[3]);
  xx[7] = xx[5] == 0.0 ? 0.0 : xx[9] / xx[5];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[7];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[7] = xx[11 + (partialType)];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[10];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[8] = xx[11 + (partialType)];
  xx[9] = xx[5] == 0.0 ? 0.0 : xx[3] / xx[5];
  xx[12] = xx[4];
  xx[13] = xx[4];
  xx[14] = xx[10];
  xx[15] = xx[9];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[0] = xx[11 + (partialType)];
  matrix[0] = xx[6];
  matrix[1] = xx[2];
  matrix[2] = xx[1];
  matrix[3] = xx[7];
  matrix[4] = xx[8];
  matrix[5] = xx[0];
  matrix[6] = xx[8];
  matrix[7] = xx[8];
  matrix[8] = xx[8];
}

static void computePosDofBlendMatrix_4_3(const double *state, int partialType,
  double *matrix)
{
  double xx[20];
  xx[0] = 9.87654321;
  xx[1] = 2.0;
  xx[2] = xx[1] * (state[23] * state[24] - state[22] * state[25]);
  xx[3] = xx[2] * xx[2];
  xx[4] = 1.0;
  xx[5] = (state[22] * state[22] + state[23] * state[23]) * xx[1] - xx[4];
  xx[6] = xx[5] * xx[5];
  xx[7] = sqrt(xx[3] + xx[6]);
  xx[8] = xx[7] == 0.0 ? 0.0 : - xx[2] / xx[7];
  xx[9] = xx[6] + xx[3];
  xx[3] = sqrt(xx[9]);
  xx[6] = xx[3] == 0.0 ? 0.0 : xx[5] / xx[3];
  xx[10] = 0.0;
  xx[11] = (state[23] * state[25] + state[22] * state[24]) * xx[1];
  xx[1] = sqrt(xx[9] + xx[11] * xx[11]);
  xx[12] = xx[1] == 0.0 ? 0.0 : xx[5] / xx[1];
  xx[14] = xx[8];
  xx[15] = xx[6];
  xx[16] = xx[10];
  xx[17] = xx[8];
  xx[18] = xx[8];
  xx[19] = xx[12];
  xx[6] = xx[13 + (partialType)];
  xx[8] = xx[7] == 0.0 ? 0.0 : xx[5] / xx[7];
  xx[7] = xx[3] == 0.0 ? 0.0 : xx[2] / xx[3];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[2] / xx[1];
  xx[13] = xx[8];
  xx[14] = xx[7];
  xx[15] = xx[10];
  xx[16] = xx[8];
  xx[17] = xx[8];
  xx[18] = xx[3];
  xx[2] = xx[12 + (partialType)];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[11] / xx[1];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[4];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[18] = xx[3];
  xx[1] = xx[12 + (partialType)];
  xx[3] = xx[11] * xx[5];
  xx[5] = sqrt(xx[9] * xx[9] + xx[3] * xx[3]);
  xx[7] = xx[5] == 0.0 ? 0.0 : xx[9] / xx[5];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[7];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[7] = xx[11 + (partialType)];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[10];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[8] = xx[11 + (partialType)];
  xx[9] = xx[5] == 0.0 ? 0.0 : xx[3] / xx[5];
  xx[12] = xx[4];
  xx[13] = xx[4];
  xx[14] = xx[10];
  xx[15] = xx[9];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[0] = xx[11 + (partialType)];
  matrix[0] = xx[6];
  matrix[1] = xx[2];
  matrix[2] = xx[1];
  matrix[3] = xx[7];
  matrix[4] = xx[8];
  matrix[5] = xx[0];
  matrix[6] = xx[8];
  matrix[7] = xx[8];
  matrix[8] = xx[8];
}

void SatelliteServicing_Mission_acc66beb_1_computePosDofBlendMatrix(const void
  *mech, size_t stageIdx, size_t primIdx, const double *state, int partialType,
  double *matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
   case 3:
    computePosDofBlendMatrix_0_3(state, partialType, matrix);
    break;

   case 27:
    computePosDofBlendMatrix_4_3(state, partialType, matrix);
    break;
  }
}

static void computeVelDofBlendMatrix_0_3(const double *state, int partialType,
  double *matrix)
{
  double xx[15];
  (void) state;
  xx[0] = 9.87654321;
  xx[1] = 0.0;
  xx[2] = 1.0;
  xx[4] = xx[1];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[2];
  xx[10] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[2];
  xx[9] = xx[1];
  xx[11] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[2];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[12] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[13] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[14] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[0] = xx[3 + (partialType)];
  matrix[0] = xx[10];
  matrix[1] = xx[11];
  matrix[2] = xx[12];
  matrix[3] = xx[13];
  matrix[4] = xx[14];
  matrix[5] = xx[0];
  matrix[6] = xx[13];
  matrix[7] = xx[13];
  matrix[8] = xx[13];
}

static void computeVelDofBlendMatrix_4_3(const double *state, int partialType,
  double *matrix)
{
  double xx[15];
  (void) state;
  xx[0] = 9.87654321;
  xx[1] = 0.0;
  xx[2] = 1.0;
  xx[4] = xx[1];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[2];
  xx[10] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[2];
  xx[9] = xx[1];
  xx[11] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[2];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[12] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[13] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[14] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[0] = xx[3 + (partialType)];
  matrix[0] = xx[10];
  matrix[1] = xx[11];
  matrix[2] = xx[12];
  matrix[3] = xx[13];
  matrix[4] = xx[14];
  matrix[5] = xx[0];
  matrix[6] = xx[13];
  matrix[7] = xx[13];
  matrix[8] = xx[13];
}

void SatelliteServicing_Mission_acc66beb_1_computeVelDofBlendMatrix(const void
  *mech, size_t stageIdx, size_t primIdx, const double *state, int partialType,
  double *matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
   case 3:
    computeVelDofBlendMatrix_0_3(state, partialType, matrix);
    break;

   case 27:
    computeVelDofBlendMatrix_4_3(state, partialType, matrix);
    break;
  }
}

static void projectPartiallyTargetedPos_0_3(const double *origState, int
  partialType, double *state)
{
  boolean_T bb[2];
  double xx[17];
  xx[0] = 2.0;
  xx[1] = (state[4] * state[6] + state[3] * state[5]) * xx[0];
  xx[2] = 0.99999999999999;
  bb[0] = fabs(xx[1]) > xx[2];
  xx[3] = 1.570796326794897;
  if (xx[1] < 0.0)
    xx[4] = -1.0;
  else if (xx[1] > 0.0)
    xx[4] = +1.0;
  else
    xx[4] = 0.0;
  xx[5] = fabs(xx[1]) > 1.0 ? atan2(xx[1], 0.0) : asin(xx[1]);
  xx[1] = bb[0] ? xx[3] * xx[4] : xx[5];
  xx[5] = (origState[4] * origState[6] + origState[3] * origState[5]) * xx[0];
  bb[1] = fabs(xx[5]) > xx[2];
  if (xx[5] < 0.0)
    xx[2] = -1.0;
  else if (xx[5] > 0.0)
    xx[2] = +1.0;
  else
    xx[2] = 0.0;
  xx[6] = fabs(xx[5]) > 1.0 ? atan2(xx[5], 0.0) : asin(xx[5]);
  xx[5] = bb[1] ? xx[3] * xx[2] : xx[6];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[5];
  xx[9] = xx[5];
  xx[10] = xx[1];
  xx[11] = xx[1];
  xx[12] = xx[5];
  xx[1] = xx[6 + (partialType)];
  xx[3] = cos(xx[1]);
  xx[5] = 0.5;
  xx[6] = state[5] * state[6];
  xx[7] = state[3] * state[4];
  xx[8] = state[3] * state[3];
  xx[9] = 1.0;
  xx[10] = (xx[8] + state[5] * state[5]) * xx[0] - xx[9];
  xx[11] = (xx[6] + xx[7]) * xx[0];
  xx[10] = (xx[11] == 0.0 && xx[10] == 0.0) ? 0.0 : atan2(xx[11], xx[10]);
  xx[11] = (xx[8] + state[6] * state[6]) * xx[0] - xx[9];
  xx[12] = - (xx[0] * (xx[6] - xx[7]));
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[6] = bb[0] ? xx[5] * xx[10] : xx[11];
  xx[7] = (xx[8] + state[4] * state[4]) * xx[0] - xx[9];
  xx[10] = - (xx[0] * (state[4] * state[5] - state[3] * state[6]));
  xx[7] = (xx[10] == 0.0 && xx[7] == 0.0) ? 0.0 : atan2(xx[10], xx[7]);
  xx[8] = bb[0] ? xx[4] * xx[6] : xx[7];
  xx[4] = origState[5] * origState[6];
  xx[7] = origState[3] * origState[4];
  xx[10] = origState[3] * origState[3];
  xx[11] = (xx[10] + origState[5] * origState[5]) * xx[0] - xx[9];
  xx[12] = (xx[4] + xx[7]) * xx[0];
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[12] = (xx[10] + origState[6] * origState[6]) * xx[0] - xx[9];
  xx[13] = - (xx[0] * (xx[4] - xx[7]));
  xx[12] = (xx[13] == 0.0 && xx[12] == 0.0) ? 0.0 : atan2(xx[13], xx[12]);
  xx[4] = bb[1] ? xx[5] * xx[11] : xx[12];
  xx[5] = (xx[10] + origState[4] * origState[4]) * xx[0] - xx[9];
  xx[7] = - (xx[0] * (origState[4] * origState[5] - origState[3] * origState[6]));
  xx[5] = (xx[7] == 0.0 && xx[5] == 0.0) ? 0.0 : atan2(xx[7], xx[5]);
  xx[0] = bb[1] ? xx[2] * xx[4] : xx[5];
  xx[9] = xx[8];
  xx[10] = xx[8];
  xx[11] = xx[8];
  xx[12] = xx[8];
  xx[13] = xx[0];
  xx[14] = xx[0];
  xx[15] = xx[0];
  xx[0] = xx[9 + (partialType)];
  xx[2] = cos(xx[0]);
  xx[5] = sin(xx[0]);
  xx[0] = sin(xx[1]);
  xx[7] = xx[6];
  xx[8] = xx[4];
  xx[9] = xx[6];
  xx[10] = xx[4];
  xx[11] = xx[6];
  xx[12] = xx[4];
  xx[13] = xx[6];
  xx[1] = xx[7 + (partialType)];
  xx[4] = cos(xx[1]);
  xx[6] = sin(xx[1]);
  xx[1] = xx[2] * xx[6];
  xx[7] = xx[4] * xx[2];
  xx[8] = xx[3] * xx[2];
  xx[9] = - (xx[3] * xx[5]);
  xx[10] = xx[0];
  xx[11] = xx[4] * xx[5] + xx[1] * xx[0];
  xx[12] = xx[7] - xx[6] * xx[0] * xx[5];
  xx[13] = - (xx[3] * xx[6]);
  xx[14] = xx[6] * xx[5] - xx[7] * xx[0];
  xx[15] = xx[1] + xx[4] * xx[0] * xx[5];
  xx[16] = xx[4] * xx[3];
  pm_math_Quaternion_Matrix3x3Ctor_ra(xx + 8, xx + 0);
  state[3] = xx[0];
  state[4] = xx[1];
  state[5] = xx[2];
  state[6] = xx[3];
}

static void projectPartiallyTargetedPos_4_3(const double *origState, int
  partialType, double *state)
{
  boolean_T bb[2];
  double xx[17];
  xx[0] = 2.0;
  xx[1] = (state[23] * state[25] + state[22] * state[24]) * xx[0];
  xx[2] = 0.99999999999999;
  bb[0] = fabs(xx[1]) > xx[2];
  xx[3] = 1.570796326794897;
  if (xx[1] < 0.0)
    xx[4] = -1.0;
  else if (xx[1] > 0.0)
    xx[4] = +1.0;
  else
    xx[4] = 0.0;
  xx[5] = fabs(xx[1]) > 1.0 ? atan2(xx[1], 0.0) : asin(xx[1]);
  xx[1] = bb[0] ? xx[3] * xx[4] : xx[5];
  xx[5] = (origState[23] * origState[25] + origState[22] * origState[24]) * xx[0];
  bb[1] = fabs(xx[5]) > xx[2];
  if (xx[5] < 0.0)
    xx[2] = -1.0;
  else if (xx[5] > 0.0)
    xx[2] = +1.0;
  else
    xx[2] = 0.0;
  xx[6] = fabs(xx[5]) > 1.0 ? atan2(xx[5], 0.0) : asin(xx[5]);
  xx[5] = bb[1] ? xx[3] * xx[2] : xx[6];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[5];
  xx[9] = xx[5];
  xx[10] = xx[1];
  xx[11] = xx[1];
  xx[12] = xx[5];
  xx[1] = xx[6 + (partialType)];
  xx[3] = cos(xx[1]);
  xx[5] = 0.5;
  xx[6] = state[24] * state[25];
  xx[7] = state[22] * state[23];
  xx[8] = state[22] * state[22];
  xx[9] = 1.0;
  xx[10] = (xx[8] + state[24] * state[24]) * xx[0] - xx[9];
  xx[11] = (xx[6] + xx[7]) * xx[0];
  xx[10] = (xx[11] == 0.0 && xx[10] == 0.0) ? 0.0 : atan2(xx[11], xx[10]);
  xx[11] = (xx[8] + state[25] * state[25]) * xx[0] - xx[9];
  xx[12] = - (xx[0] * (xx[6] - xx[7]));
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[6] = bb[0] ? xx[5] * xx[10] : xx[11];
  xx[7] = (xx[8] + state[23] * state[23]) * xx[0] - xx[9];
  xx[10] = - (xx[0] * (state[23] * state[24] - state[22] * state[25]));
  xx[7] = (xx[10] == 0.0 && xx[7] == 0.0) ? 0.0 : atan2(xx[10], xx[7]);
  xx[8] = bb[0] ? xx[4] * xx[6] : xx[7];
  xx[4] = origState[24] * origState[25];
  xx[7] = origState[22] * origState[23];
  xx[10] = origState[22] * origState[22];
  xx[11] = (xx[10] + origState[24] * origState[24]) * xx[0] - xx[9];
  xx[12] = (xx[4] + xx[7]) * xx[0];
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[12] = (xx[10] + origState[25] * origState[25]) * xx[0] - xx[9];
  xx[13] = - (xx[0] * (xx[4] - xx[7]));
  xx[12] = (xx[13] == 0.0 && xx[12] == 0.0) ? 0.0 : atan2(xx[13], xx[12]);
  xx[4] = bb[1] ? xx[5] * xx[11] : xx[12];
  xx[5] = (xx[10] + origState[23] * origState[23]) * xx[0] - xx[9];
  xx[7] = - (xx[0] * (origState[23] * origState[24] - origState[22] * origState
                      [25]));
  xx[5] = (xx[7] == 0.0 && xx[5] == 0.0) ? 0.0 : atan2(xx[7], xx[5]);
  xx[0] = bb[1] ? xx[2] * xx[4] : xx[5];
  xx[9] = xx[8];
  xx[10] = xx[8];
  xx[11] = xx[8];
  xx[12] = xx[8];
  xx[13] = xx[0];
  xx[14] = xx[0];
  xx[15] = xx[0];
  xx[0] = xx[9 + (partialType)];
  xx[2] = cos(xx[0]);
  xx[5] = sin(xx[0]);
  xx[0] = sin(xx[1]);
  xx[7] = xx[6];
  xx[8] = xx[4];
  xx[9] = xx[6];
  xx[10] = xx[4];
  xx[11] = xx[6];
  xx[12] = xx[4];
  xx[13] = xx[6];
  xx[1] = xx[7 + (partialType)];
  xx[4] = cos(xx[1]);
  xx[6] = sin(xx[1]);
  xx[1] = xx[2] * xx[6];
  xx[7] = xx[4] * xx[2];
  xx[8] = xx[3] * xx[2];
  xx[9] = - (xx[3] * xx[5]);
  xx[10] = xx[0];
  xx[11] = xx[4] * xx[5] + xx[1] * xx[0];
  xx[12] = xx[7] - xx[6] * xx[0] * xx[5];
  xx[13] = - (xx[3] * xx[6]);
  xx[14] = xx[6] * xx[5] - xx[7] * xx[0];
  xx[15] = xx[1] + xx[4] * xx[0] * xx[5];
  xx[16] = xx[4] * xx[3];
  pm_math_Quaternion_Matrix3x3Ctor_ra(xx + 8, xx + 0);
  state[22] = xx[0];
  state[23] = xx[1];
  state[24] = xx[2];
  state[25] = xx[3];
}

void SatelliteServicing_Mission_acc66beb_1_projectPartiallyTargetedPos(const
  void *mech, size_t stageIdx, size_t primIdx, const double *origState, int
  partialType, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) origState;
  (void) partialType;
  (void) state;
  switch ((stageIdx * 6 + primIdx))
  {
   case 3:
    projectPartiallyTargetedPos_0_3(origState, partialType, state);
    break;

   case 27:
    projectPartiallyTargetedPos_4_3(origState, partialType, state);
    break;
  }
}

void SatelliteServicing_Mission_acc66beb_1_propagateMotion(const void *mech,
  const RuntimeDerivedValuesBundle *rtdv, const double *state, double
  *motionData)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[115];
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  xx[4] = - 0.9978591085833576;
  xx[5] = 0.03065708043547177;
  xx[6] = - 0.05583284781297364;
  xx[7] = - 0.01483360851221946;
  pm_math_Quaternion_composeInverse_ra(xx + 0, xx + 4, xx + 8);
  xx[0] = 7.593135577253151e-4;
  xx[1] = 1.951279081653613e-3;
  xx[2] = 1.985920353021044e-3;
  xx[12] = - xx[0];
  xx[13] = - xx[1];
  xx[14] = - xx[2];
  pm_math_Quaternion_xform_ra(xx + 8, xx + 12, xx + 15);
  xx[3] = state[0] - xx[15];
  xx[12] = state[1] - xx[16];
  xx[13] = state[2] - xx[17];
  xx[14] = 0.7160818875165126;
  xx[15] = 0.5;
  xx[16] = xx[15] * state[13];
  xx[17] = sin(xx[16]);
  xx[18] = 0.6951039971795988;
  xx[19] = cos(xx[16]);
  xx[16] = xx[14] * xx[17] - xx[18] * xx[19];
  xx[20] = 0.01780195583420664;
  xx[21] = 0.06115761476881373;
  xx[22] = xx[20] * xx[19] + xx[21] * xx[17];
  xx[23] = - xx[22];
  xx[24] = xx[20] * xx[17] - xx[21] * xx[19];
  xx[20] = xx[18] * xx[17] + xx[14] * xx[19];
  xx[14] = - xx[20];
  xx[17] = 0.1023784696718099;
  xx[18] = xx[17] * xx[24];
  xx[19] = xx[20] * xx[17];
  xx[21] = 2.0;
  xx[25] = 0.01977478948791761 - ((xx[18] * xx[24] + xx[20] * xx[19]) * xx[21] -
    xx[17]);
  xx[26] = 0.2994151397199191 - (xx[19] * xx[16] + xx[22] * xx[18]) * xx[21];
  xx[27] = 0.2498201752704395 - xx[21] * (xx[18] * xx[16] - xx[22] * xx[19]);
  xx[18] = xx[15] * state[15];
  xx[19] = cos(xx[18]);
  xx[28] = 0.0;
  xx[29] = sin(xx[18]);
  xx[18] = 0.1176215303281901;
  xx[30] = xx[17] * xx[29];
  xx[31] = xx[18] - (xx[21] * xx[30] * xx[29] - xx[17]);
  xx[32] = xx[21] * xx[19] * xx[30];
  xx[30] = 0.706996650878707;
  xx[33] = xx[15] * state[17];
  xx[15] = cos(xx[33]);
  xx[34] = xx[30] * xx[15];
  xx[35] = 0.01247940889192258;
  xx[36] = 0.9993770574148331;
  xx[37] = sin(xx[33]);
  xx[33] = xx[36] * xx[37];
  xx[38] = xx[35] * xx[33];
  xx[39] = 0.03529160116614088;
  xx[40] = xx[39] * xx[37];
  xx[37] = xx[30] * xx[40];
  xx[41] = - (xx[34] + xx[38] - xx[37]);
  xx[42] = xx[38] - (xx[37] + xx[34]);
  xx[34] = xx[35] * xx[15];
  xx[15] = xx[30] * xx[33];
  xx[30] = xx[35] * xx[40];
  xx[33] = xx[34] - xx[15] - xx[30];
  xx[35] = - (xx[34] + xx[15] + xx[30]);
  xx[43] = xx[41];
  xx[44] = xx[42];
  xx[45] = xx[33];
  xx[46] = xx[35];
  xx[47] = - 0.04301910471975233;
  xx[48] = 1.291704527118732e-3;
  xx[49] = 7.500000000000014e-3;
  pm_math_Quaternion_xform_ra(xx + 43, xx + 47, xx + 50);
  xx[15] = xx[18] - xx[50];
  xx[18] = - xx[51];
  xx[30] = - xx[52];
  xx[34] = 0.9238795325112867;
  xx[37] = 0.3826834323650898;
  xx[38] = xx[34] * state[22] - xx[37] * state[23];
  xx[40] = xx[37] * state[22] + xx[34] * state[23];
  xx[47] = xx[37] * state[25] + xx[34] * state[24];
  xx[48] = xx[37] * state[24] - xx[34] * state[25];
  xx[49] = - xx[48];
  xx[50] = 2.775557561562891e-17;
  xx[51] = xx[50] * xx[47];
  xx[52] = xx[48] * xx[50];
  xx[53] = xx[19] * xx[16] + xx[20] * xx[29];
  xx[54] = xx[29] * xx[24] - xx[22] * xx[19];
  xx[55] = xx[19] * xx[24] + xx[22] * xx[29];
  xx[56] = xx[29] * xx[16] - xx[20] * xx[19];
  xx[57] = xx[20] * xx[32];
  xx[58] = xx[23];
  xx[59] = xx[24];
  xx[60] = xx[14];
  xx[61] = xx[20] * xx[31];
  xx[20] = xx[22] * xx[32] + xx[31] * xx[24];
  xx[62] = xx[57];
  xx[63] = - xx[61];
  xx[64] = - xx[20];
  pm_math_Vector3_cross_ra(xx + 58, xx + 62, xx + 65);
  xx[22] = xx[31] + (xx[57] * xx[16] + xx[65]) * xx[21] + xx[25];
  xx[57] = (xx[66] - xx[61] * xx[16]) * xx[21] + xx[32] + xx[26];
  xx[58] = xx[21] * (xx[67] - xx[20] * xx[16]) + xx[27];
  pm_math_Quaternion_compose_ra(xx + 53, xx + 43, xx + 59);
  xx[63] = xx[15];
  xx[64] = xx[18];
  xx[65] = xx[30];
  pm_math_Quaternion_xform_ra(xx + 53, xx + 63, xx + 66);
  xx[69] = xx[16];
  xx[70] = xx[23];
  xx[71] = xx[24];
  xx[72] = xx[14];
  pm_math_Quaternion_compose_ra(xx + 8, xx + 69, xx + 73);
  pm_math_Quaternion_xform_ra(xx + 8, xx + 25, xx + 77);
  xx[20] = xx[77] + xx[3];
  xx[80] = xx[78] + xx[12];
  xx[77] = xx[79] + xx[13];
  xx[78] = xx[19] * xx[73] - xx[76] * xx[29];
  xx[79] = xx[19] * xx[74] + xx[75] * xx[29];
  xx[81] = xx[19] * xx[75] - xx[74] * xx[29];
  xx[82] = xx[73] * xx[29] + xx[19] * xx[76];
  xx[83] = xx[76] * xx[32];
  xx[84] = xx[76] * xx[31];
  xx[85] = xx[75] * xx[31] - xx[74] * xx[32];
  xx[86] = - xx[83];
  xx[87] = xx[84];
  xx[88] = - xx[85];
  pm_math_Vector3_cross_ra(xx + 74, xx + 86, xx + 89);
  xx[86] = xx[31] + (xx[89] - xx[73] * xx[83]) * xx[21] + xx[20];
  xx[83] = (xx[73] * xx[84] + xx[90]) * xx[21] + xx[32] + xx[80];
  xx[84] = xx[21] * (xx[91] - xx[85] * xx[73]) + xx[77];
  xx[87] = xx[78];
  xx[88] = xx[79];
  xx[89] = xx[81];
  xx[90] = xx[82];
  pm_math_Quaternion_compose_ra(xx + 87, xx + 43, xx + 91);
  pm_math_Quaternion_xform_ra(xx + 87, xx + 63, xx + 95);
  xx[87] = state[10];
  xx[88] = state[11];
  xx[89] = state[12];
  pm_math_Quaternion_xform_ra(xx + 4, xx + 87, xx + 98);
  xx[4] = state[7];
  xx[5] = state[8];
  xx[6] = state[9];
  pm_math_Quaternion_inverseXform_ra(xx + 8, xx + 4, xx + 87);
  pm_math_Vector3_cross_ra(xx + 98, xx + 0, xx + 4);
  xx[0] = xx[87] + xx[4];
  xx[1] = xx[88] + xx[5];
  xx[2] = xx[89] + xx[6];
  pm_math_Quaternion_inverseXform_ra(xx + 69, xx + 98, xx + 4);
  xx[7] = xx[6] + state[14];
  pm_math_Vector3_cross_ra(xx + 98, xx + 25, xx + 87);
  xx[101] = xx[87] + xx[0];
  xx[102] = xx[88] + xx[1];
  xx[103] = xx[89] + xx[2];
  pm_math_Quaternion_inverseXform_ra(xx + 69, xx + 101, xx + 87);
  xx[6] = xx[88] + xx[17] * state[14];
  xx[69] = xx[5] * xx[29];
  xx[70] = xx[4] * xx[29];
  xx[71] = xx[4] + xx[21] * (xx[19] * xx[69] - xx[70] * xx[29]);
  xx[72] = xx[5] - (xx[19] * xx[70] + xx[69] * xx[29]) * xx[21];
  xx[69] = xx[7] + state[16];
  xx[70] = xx[87] - xx[7] * xx[32];
  xx[85] = xx[7] * xx[31] + xx[6];
  xx[88] = xx[85] * xx[29];
  xx[90] = xx[70] * xx[29];
  xx[101] = xx[70] + xx[21] * (xx[19] * xx[88] - xx[90] * xx[29]);
  xx[70] = xx[85] - (xx[19] * xx[90] + xx[88] * xx[29]) * xx[21] + xx[17] *
    state[16];
  xx[17] = xx[89] - (xx[5] * xx[31] - xx[4] * xx[32]);
  xx[102] = xx[71];
  xx[103] = xx[72];
  xx[104] = xx[69];
  pm_math_Quaternion_inverseXform_ra(xx + 43, xx + 102, xx + 105);
  pm_math_Vector3_cross_ra(xx + 102, xx + 63, xx + 108);
  xx[63] = xx[108] + xx[101];
  xx[64] = xx[109] + xx[70];
  xx[65] = xx[110] + xx[17];
  pm_math_Quaternion_inverseXform_ra(xx + 43, xx + 63, xx + 102);
  xx[43] = xx[37] * state[30];
  xx[44] = xx[37] * state[31];
  xx[45] = state[30] - (xx[37] * xx[43] - xx[34] * xx[44]) * xx[21];
  xx[46] = state[31] - xx[21] * (xx[34] * xx[43] + xx[37] * xx[44]);
  xx[108] = xx[38];
  xx[109] = xx[40];
  xx[110] = xx[47];
  xx[111] = xx[49];
  xx[63] = state[26];
  xx[64] = state[27];
  xx[65] = state[28];
  pm_math_Quaternion_inverseXform_ra(xx + 108, xx + 63, xx + 112);
  motionData[0] = xx[8];
  motionData[1] = xx[9];
  motionData[2] = xx[10];
  motionData[3] = xx[11];
  motionData[4] = xx[3];
  motionData[5] = xx[12];
  motionData[6] = xx[13];
  motionData[7] = xx[16];
  motionData[8] = xx[23];
  motionData[9] = xx[24];
  motionData[10] = xx[14];
  motionData[11] = xx[25];
  motionData[12] = xx[26];
  motionData[13] = xx[27];
  motionData[14] = xx[19];
  motionData[15] = xx[28];
  motionData[16] = xx[28];
  motionData[17] = xx[29];
  motionData[18] = xx[31];
  motionData[19] = xx[32];
  motionData[20] = xx[28];
  motionData[21] = xx[41];
  motionData[22] = xx[42];
  motionData[23] = xx[33];
  motionData[24] = xx[35];
  motionData[25] = xx[15];
  motionData[26] = xx[18];
  motionData[27] = xx[30];
  motionData[28] = xx[38];
  motionData[29] = xx[40];
  motionData[30] = xx[47];
  motionData[31] = xx[49];
  motionData[32] = state[19] - (xx[51] * xx[47] + xx[48] * xx[52]) * xx[21] -
    0.04999999999999996;
  motionData[33] = state[20] - xx[21] * (xx[52] * xx[38] - xx[51] * xx[40]) +
    1.5;
  motionData[34] = state[21] - (xx[51] * xx[38] + xx[52] * xx[40]) * xx[21] +
    0.25;
  motionData[35] = xx[53];
  motionData[36] = xx[54];
  motionData[37] = xx[55];
  motionData[38] = xx[56];
  motionData[39] = xx[22];
  motionData[40] = xx[57];
  motionData[41] = xx[58];
  motionData[42] = xx[59];
  motionData[43] = xx[60];
  motionData[44] = xx[61];
  motionData[45] = xx[62];
  motionData[46] = xx[66] + xx[22];
  motionData[47] = xx[67] + xx[57];
  motionData[48] = xx[68] + xx[58];
  motionData[49] = xx[73];
  motionData[50] = xx[74];
  motionData[51] = xx[75];
  motionData[52] = xx[76];
  motionData[53] = xx[20];
  motionData[54] = xx[80];
  motionData[55] = xx[77];
  motionData[56] = xx[78];
  motionData[57] = xx[79];
  motionData[58] = xx[81];
  motionData[59] = xx[82];
  motionData[60] = xx[86];
  motionData[61] = xx[83];
  motionData[62] = xx[84];
  motionData[63] = xx[91];
  motionData[64] = xx[92];
  motionData[65] = xx[93];
  motionData[66] = xx[94];
  motionData[67] = xx[95] + xx[86];
  motionData[68] = xx[96] + xx[83];
  motionData[69] = xx[97] + xx[84];
  motionData[70] = xx[98];
  motionData[71] = xx[99];
  motionData[72] = xx[100];
  motionData[73] = xx[0];
  motionData[74] = xx[1];
  motionData[75] = xx[2];
  motionData[76] = xx[4];
  motionData[77] = xx[5];
  motionData[78] = xx[7];
  motionData[79] = xx[87];
  motionData[80] = xx[6];
  motionData[81] = xx[89];
  motionData[82] = xx[71];
  motionData[83] = xx[72];
  motionData[84] = xx[69];
  motionData[85] = xx[101];
  motionData[86] = xx[70];
  motionData[87] = xx[17];
  motionData[88] = xx[105] + xx[39] * state[18];
  motionData[89] = xx[106] + xx[36] * state[18];
  motionData[90] = xx[107];
  motionData[91] = xx[102] - 7.495327930611261e-3 * state[18];
  motionData[92] = xx[103] + 2.646870087460475e-4 * state[18];
  motionData[93] = xx[104] - 0.04303789260844221 * state[18];
  motionData[94] = state[29];
  motionData[95] = xx[45];
  motionData[96] = xx[46];
  motionData[97] = xx[112];
  motionData[98] = xx[113] + xx[46] * xx[50];
  motionData[99] = xx[114] - xx[50] * xx[45];
}

size_t SatelliteServicing_Mission_acc66beb_1_computeAssemblyError(const void
  *mech, const RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx, const int
  *modeVector, const double *motionData, double *error)
{
  (void) mech;
  (void)rtdv;
  (void) modeVector;
  (void) motionData;
  (void) error;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t SatelliteServicing_Mission_acc66beb_1_computeAssemblyJacobian(const void *
  mech, const RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx, boolean_T
  forVelocitySatisfaction, const double *state, const int *modeVector, const
  double *motionData, double *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) modeVector;
  (void) forVelocitySatisfaction;
  (void) motionData;
  (void) J;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t SatelliteServicing_Mission_acc66beb_1_computeFullAssemblyJacobian(const
  void *mech, const RuntimeDerivedValuesBundle *rtdv, const double *state, const
  int *modeVector, const double *motionData, double *J)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
  (void) modeVector;
  (void) motionData;
  (void) J;
  return 0;
}

boolean_T SatelliteServicing_Mission_acc66beb_1_isInKinematicSingularity(const
  void *mech, const RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx,
  const int *modeVector, const double *motionData)
{
  (void) mech;
  (void) rtdv;
  (void) modeVector;
  (void) motionData;
  switch (constraintIdx)
  {
  }

  return 0;
}

void SatelliteServicing_Mission_acc66beb_1_convertStateVector(const void
  *asmMech, const RuntimeDerivedValuesBundle *rtdv, const void *simMech, const
  double *asmState, const int *asmModeVector, const int *simModeVector, double
  *simState)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) asmMech;
  (void) rtdvd;
  (void) rtdvi;
  (void) simMech;
  (void) asmModeVector;
  (void) simModeVector;
  simState[0] = asmState[0];
  simState[1] = asmState[1];
  simState[2] = asmState[2];
  simState[3] = asmState[3];
  simState[4] = asmState[4];
  simState[5] = asmState[5];
  simState[6] = asmState[6];
  simState[7] = asmState[7];
  simState[8] = asmState[8];
  simState[9] = asmState[9];
  simState[10] = asmState[10];
  simState[11] = asmState[11];
  simState[12] = asmState[12];
  simState[13] = asmState[13];
  simState[14] = asmState[14];
  simState[15] = asmState[15];
  simState[16] = asmState[16];
  simState[17] = asmState[17];
  simState[18] = asmState[18];
  simState[19] = asmState[19];
  simState[20] = asmState[20];
  simState[21] = asmState[21];
  simState[22] = asmState[22];
  simState[23] = asmState[23];
  simState[24] = asmState[24];
  simState[25] = asmState[25];
  simState[26] = asmState[26];
  simState[27] = asmState[27];
  simState[28] = asmState[28];
  simState[29] = asmState[29];
  simState[30] = asmState[30];
  simState[31] = asmState[31];
}
