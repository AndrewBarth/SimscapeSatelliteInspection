// Simscape target specific file.
//  This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration'.
struct RuntimeDerivedValuesBundleTag;
void SatelliteServicing_Mission_d72b4a86_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
