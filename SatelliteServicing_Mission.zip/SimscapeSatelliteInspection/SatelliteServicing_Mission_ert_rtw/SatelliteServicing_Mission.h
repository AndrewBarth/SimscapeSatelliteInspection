//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.62
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Thu May  9 15:18:16 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_SatelliteServicing_Mission_h_
#define RTW_HEADER_SatelliteServicing_Mission_h_
#include <stdlib.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "nesl_rtw_rtp.h"
#include "SatelliteServicing_Mission_acc66beb_1_gateway.h"
#include "nesl_rtw.h"
#include "SatelliteServicing_Mission_types.h"

extern "C"
{

#include "rt_nonfinite.h"

}

#include "rtGetNaN.h"
#include <cstring>

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

// Block signals (default storage)
struct B_SatelliteServicing_Mission_T {
  real_T RTP_1;                        // '<S4>/RTP_1'
  real_T STATE_1[78];                  // '<S264>/STATE_1'
  real_T Delay[122];                   // '<S89>/Delay'
  real_T Delay1[122];                  // '<S89>/Delay1'
  real_T INPUT_1_1_1[4];               // '<S264>/INPUT_1_1_1'
  real_T INPUT_2_1_1[4];               // '<S264>/INPUT_2_1_1'
  real_T INPUT_3_1_1[4];               // '<S264>/INPUT_3_1_1'
  real_T INPUT_4_1_1[4];               // '<S264>/INPUT_4_1_1'
  real_T INPUT_5_1_1[4];               // '<S264>/INPUT_5_1_1'
  real_T INPUT_6_1_1[4];               // '<S264>/INPUT_6_1_1'
  real_T INPUT_7_1_1[4];               // '<S264>/INPUT_7_1_1'
  real_T INPUT_8_1_1[4];               // '<S264>/INPUT_8_1_1'
  real_T INPUT_9_1_1[4];               // '<S264>/INPUT_9_1_1'
  real_T INPUT_10_1_1[4];              // '<S264>/INPUT_10_1_1'
  real_T INPUT_11_1_1[4];              // '<S264>/INPUT_11_1_1'
  real_T INPUT_12_1_1[4];              // '<S264>/INPUT_12_1_1'
  real_T Product5[3];                  // '<S219>/Product5'
  real_T controlErrorECEF[6];          // '<S219>/Sum1'
  real_T INPUT_13_1_1[4];              // '<S264>/INPUT_13_1_1'
  real_T INPUT_14_1_1[4];              // '<S264>/INPUT_14_1_1'
  real_T INPUT_15_1_1[4];              // '<S264>/INPUT_15_1_1'
  real_T Product5_b[3];                // '<S218>/Product5'
  real_T controlErrorECEF_l[6];        // '<S218>/Sum1'
  real_T INPUT_16_1_1[4];              // '<S264>/INPUT_16_1_1'
  real_T INPUT_16_1_2[4];              // '<S264>/INPUT_16_1_2'
  real_T INPUT_16_1_3[4];              // '<S264>/INPUT_16_1_3'
  real_T coverage_out[122];            // '<S89>/computeCoverage'
  real_T credit_out[122];              // '<S89>/computeCoverage'
};

// Block states (default storage) for system '<Root>'
struct DW_SatelliteServicing_Mission_T {
  real_T Delay_DSTATE[122];            // '<S89>/Delay'
  real_T Delay1_DSTATE[122];           // '<S89>/Delay1'
  real_T INPUT_1_1_1_Discrete[2];      // '<S264>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete[2];      // '<S264>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete[2];      // '<S264>/INPUT_3_1_1'
  real_T INPUT_4_1_1_Discrete[2];      // '<S264>/INPUT_4_1_1'
  real_T INPUT_5_1_1_Discrete[2];      // '<S264>/INPUT_5_1_1'
  real_T INPUT_6_1_1_Discrete[2];      // '<S264>/INPUT_6_1_1'
  real_T INPUT_7_1_1_Discrete[2];      // '<S264>/INPUT_7_1_1'
  real_T INPUT_8_1_1_Discrete[2];      // '<S264>/INPUT_8_1_1'
  real_T INPUT_9_1_1_Discrete[2];      // '<S264>/INPUT_9_1_1'
  real_T INPUT_10_1_1_Discrete[2];     // '<S264>/INPUT_10_1_1'
  real_T INPUT_11_1_1_Discrete[2];     // '<S264>/INPUT_11_1_1'
  real_T INPUT_12_1_1_Discrete[2];     // '<S264>/INPUT_12_1_1'
  real_T DiscreteTimeIntegrator1_DSTATE[3];// '<S219>/Discrete-Time Integrator1' 
  real_T INPUT_13_1_1_Discrete[2];     // '<S264>/INPUT_13_1_1'
  real_T INPUT_14_1_1_Discrete[2];     // '<S264>/INPUT_14_1_1'
  real_T INPUT_15_1_1_Discrete[2];     // '<S264>/INPUT_15_1_1'
  real_T DiscreteTimeIntegrator1_DSTAT_m[3];// '<S218>/Discrete-Time Integrator1' 
  real_T INPUT_16_1_1_Discrete[2];     // '<S264>/INPUT_16_1_1'
  real_T INPUT_16_1_2_Discrete[2];     // '<S264>/INPUT_16_1_2'
  real_T INPUT_16_1_3_Discrete[2];     // '<S264>/INPUT_16_1_3'
  real_T STATE_1_Discrete;             // '<S264>/STATE_1'
  real_T OUTPUT_1_0_Discrete;          // '<S264>/OUTPUT_1_0'
  real_T OUTPUT_1_1_Discrete;          // '<S264>/OUTPUT_1_1'
  void* RTP_1_RtpManager;              // '<S4>/RTP_1'
  void* STATE_1_Simulator;             // '<S264>/STATE_1'
  void* STATE_1_SimData;               // '<S264>/STATE_1'
  void* STATE_1_DiagMgr;               // '<S264>/STATE_1'
  void* STATE_1_ZcLogger;              // '<S264>/STATE_1'
  void* STATE_1_TsInfo;                // '<S264>/STATE_1'
  void* OUTPUT_1_0_Simulator;          // '<S264>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData;            // '<S264>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr;            // '<S264>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger;           // '<S264>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo;             // '<S264>/OUTPUT_1_0'
  void* SINK_1_RtwLogger;              // '<S264>/SINK_1'
  void* SINK_1_RtwLogBuffer;           // '<S264>/SINK_1'
  void* SINK_1_RtwLogFcnManager;       // '<S264>/SINK_1'
  void* OUTPUT_1_1_Simulator;          // '<S264>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData;            // '<S264>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr;            // '<S264>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger;           // '<S264>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo;             // '<S264>/OUTPUT_1_1'
  int_T STATE_1_Modes;                 // '<S264>/STATE_1'
  int_T OUTPUT_1_0_Modes;              // '<S264>/OUTPUT_1_0'
  int_T OUTPUT_1_1_Modes;              // '<S264>/OUTPUT_1_1'
  boolean_T RTP_1_SetParametersNeeded; // '<S4>/RTP_1'
  boolean_T STATE_1_FirstOutput;       // '<S264>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput;    // '<S264>/OUTPUT_1_0'
  boolean_T icLoad;                    // '<S89>/Delay'
  boolean_T icLoad_d;                  // '<S89>/Delay1'
  boolean_T OUTPUT_1_1_FirstOutput;    // '<S264>/OUTPUT_1_1'
};

// Continuous states (default storage)
struct X_SatelliteServicing_Mission_T {
  real_T SatelliteServicing_MissionClien[78];// '<S264>/STATE_1'
};

// State derivatives (default storage)
struct XDot_SatelliteServicing_Missi_T {
  real_T SatelliteServicing_MissionClien[78];// '<S264>/STATE_1'
};

// State disabled
struct XDis_SatelliteServicing_Missi_T {
  boolean_T SatelliteServicing_MissionClien[78];// '<S264>/STATE_1'
};

#ifndef ODE3_INTG
#define ODE3_INTG

// ODE3 Integration Data
struct ODE3_IntgData {
  real_T *y;                           // output
  real_T *f[3];                        // derivatives
};

#endif

// External inputs (root inport signals with default storage)
struct ExtU_SatelliteServicing_Missi_T {
  real_T ManipulatorActions[3];        // '<Root>/ManipulatorActions'
};

// External outputs (root outports fed by signals with default storage)
struct ExtY_SatelliteServicing_Missi_T {
  real_T Observations[24];             // '<Root>/Observations'
  real_T ControlError[122];            // '<Root>/ControlError'
};

// Parameters (default storage)
struct P_SatelliteServicing_Mission_T_ {
  satControlDataBus_Rot satControlData_Rot;// Variable: satControlData_Rot
                                              //  Referenced by:
                                              //    '<S213>/Constant2'
                                              //    '<S214>/Constant2'
                                              //    '<S216>/Saturation1'

  satControlDataBus_Trans satControlData_Trans;// Variable: satControlData_Trans
                                                  //  Referenced by:
                                                  //    '<S213>/Constant1'
                                                  //    '<S214>/Constant1'
                                                  //    '<S217>/Saturation1'

  struct_Yf8rt61VEQC0Uc7ZmBWdrE cubesat[4];// Variable: cubesat
                                              //  Referenced by:
                                              //    '<S94>/Constant1'
                                              //    '<S121>/Constant1'
                                              //    '<S148>/Constant1'
                                              //    '<S175>/Constant1'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PxPositionTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PxVelocityTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PyPositionTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PyVelocityTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PzPositionTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PzVelocityTargetValue'
                                              //    '<S121>/Subsystem_around_RTP_517418D9_PxPositionTargetValue'
                                              //    '<S121>/Subsystem_around_RTP_517418D9_PxVelocityTargetValue'
                                              //    '<S121>/Subsystem_around_RTP_517418D9_PyPositionTargetValue'
                                              //    '<S121>/Subsystem_around_RTP_517418D9_PyVelocityTargetValue'
                                              //    '<S121>/Subsystem_around_RTP_517418D9_PzPositionTargetValue'
                                              //    '<S121>/Subsystem_around_RTP_517418D9_PzVelocityTargetValue'
                                              //    '<S148>/Subsystem_around_RTP_6835F894_PxPositionTargetValue'
                                              //    '<S148>/Subsystem_around_RTP_6835F894_PxVelocityTargetValue'
                                              //    '<S148>/Subsystem_around_RTP_6835F894_PyPositionTargetValue'
                                              //    '<S148>/Subsystem_around_RTP_6835F894_PyVelocityTargetValue'
                                              //    '<S148>/Subsystem_around_RTP_6835F894_PzPositionTargetValue'
                                              //    '<S148>/Subsystem_around_RTP_6835F894_PzVelocityTargetValue'
                                              //    '<S175>/Subsystem_around_RTP_84B5FE6B_PxPositionTargetValue'
                                              //    '<S175>/Subsystem_around_RTP_84B5FE6B_PxVelocityTargetValue'
                                              //    '<S175>/Subsystem_around_RTP_84B5FE6B_PyPositionTargetValue'
                                              //    '<S175>/Subsystem_around_RTP_84B5FE6B_PyVelocityTargetValue'
                                              //    '<S175>/Subsystem_around_RTP_84B5FE6B_PzPositionTargetValue'
                                              //    '<S175>/Subsystem_around_RTP_84B5FE6B_PzVelocityTargetValue'

  struct_b9EoG14LaCnLOpiLP034lD orbit; // Variable: orbit
                                          //  Referenced by: '<S88>/Constant1'

  real_T nsat;                         // Variable: nsat
                                          //  Referenced by: '<S89>/Constant1'

  real_T Constant3_Value[366];         // Expression: client.faceCenter
                                          //  Referenced by: '<S89>/Constant3'

  real_T Constant2_Value;              // Expression: client.inspectionFOV
                                          //  Referenced by: '<S89>/Constant2'

  real_T Constant6_Value;           // Expression: client.inspectionSphereRadius
                                       //  Referenced by: '<S89>/Constant6'

  real_T Constant5_Value[122];         // Expression: client.faceRadius
                                          //  Referenced by: '<S89>/Constant5'

  real_T Constant4_Value[122];         // Expression: zeros(client.nFaces,1)
                                          //  Referenced by: '<S89>/Constant4'

  real_T Constant_Value[3];            // Expression: [0,0,0]
                                          //  Referenced by: '<S88>/Constant'

  real_T DiscreteTimeIntegrator1_gainval;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainval
                             //  Referenced by: '<S219>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC;   // Expression: 0
                                          //  Referenced by: '<S219>/Discrete-Time Integrator1'

  real_T Gain1_Gain;                   // Expression: -1
                                          //  Referenced by: '<S219>/Gain1'

  real_T DiscreteTimeIntegrator1_gainv_b;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainv_b
                             //  Referenced by: '<S218>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC_f; // Expression: 0
                                          //  Referenced by: '<S218>/Discrete-Time Integrator1'

  real_T Gain1_Gain_m;                 // Expression: -1
                                          //  Referenced by: '<S218>/Gain1'

};

// Real-time Model Data Structure
struct tag_RTM_SatelliteServicing_Mi_T {
  const char_T *errorStatus;
  RTWSolverInfo *solverInfo;
  B_SatelliteServicing_Mission_T *blockIO;
  X_SatelliteServicing_Mission_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_SatelliteServicing_Missi_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[78];
  real_T odeF[3][78];
  ODE3_IntgData intgData;
  DW_SatelliteServicing_Mission_T *dwork;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

// Block parameters (default storage)
#ifdef __cplusplus

extern "C"
{

#endif

  extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;

#ifdef __cplusplus

}

#endif

// External data declarations for dependent source files
#ifdef __cplusplus

extern "C"
{

#endif

  extern const char_T *RT_MEMORY_ALLOCATION_ERROR;

#ifdef __cplusplus

}

#endif

extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;// parameters 

#ifdef __cplusplus

extern "C"
{

#endif

  // Model entry point functions
  extern RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission
    (ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
     ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_initialize
    (RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M);
  extern void SatelliteServicing_Mission_step(RT_MODEL_SatelliteServicing_M_T *
    const SatelliteServicing_Mission_M, ExtY_SatelliteServicing_Missi_T
    *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_terminate
    (RT_MODEL_SatelliteServicing_M_T * SatelliteServicing_Mission_M);

#ifdef __cplusplus

}

#endif

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S37>/RESHAPE' : Reshape block reduction
//  Block '<S77>/RESHAPE' : Reshape block reduction
//  Block '<S254>/RESHAPE' : Reshape block reduction


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'SatelliteServicing_Mission'
//  '<S1>'   : 'SatelliteServicing_Mission/ClientSatellite'
//  '<S2>'   : 'SatelliteServicing_Mission/Mission'
//  '<S3>'   : 'SatelliteServicing_Mission/ServicingSatellite'
//  '<S4>'   : 'SatelliteServicing_Mission/Solver Configuration'
//  '<S5>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1'
//  '<S6>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output2'
//  '<S7>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter1'
//  '<S8>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter10'
//  '<S9>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter11'
//  '<S10>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter12'
//  '<S11>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter13'
//  '<S12>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter14'
//  '<S13>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter15'
//  '<S14>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter16'
//  '<S15>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter17'
//  '<S16>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter18'
//  '<S17>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter2'
//  '<S18>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter3'
//  '<S19>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter4'
//  '<S20>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter5'
//  '<S21>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter6'
//  '<S22>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter7'
//  '<S23>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter8'
//  '<S24>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter9'
//  '<S25>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/Reorder_to_XYZ'
//  '<S26>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/formPoseMat'
//  '<S27>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/positiveQuat'
//  '<S28>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/quat2MRP'
//  '<S29>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S30>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S31>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S32>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S33>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S34>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S35>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S36>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S37>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S38>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S39>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S40>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S41>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S42>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S43>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S44>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S45>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S46>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S47>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1'
//  '<S48>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10'
//  '<S49>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11'
//  '<S50>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12'
//  '<S51>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13'
//  '<S52>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14'
//  '<S53>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15'
//  '<S54>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16'
//  '<S55>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter17'
//  '<S56>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter18'
//  '<S57>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2'
//  '<S58>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3'
//  '<S59>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4'
//  '<S60>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5'
//  '<S61>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6'
//  '<S62>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7'
//  '<S63>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8'
//  '<S64>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9'
//  '<S65>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/Reorder_to_XYZ'
//  '<S66>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/formPoseMat'
//  '<S67>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/positiveQuat'
//  '<S68>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/quat2MRP'
//  '<S69>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S70>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10/EVAL_KEY'
//  '<S71>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11/EVAL_KEY'
//  '<S72>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12/EVAL_KEY'
//  '<S73>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S74>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S75>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15/EVAL_KEY'
//  '<S76>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16/EVAL_KEY'
//  '<S77>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter17/EVAL_KEY'
//  '<S78>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter18/EVAL_KEY'
//  '<S79>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2/EVAL_KEY'
//  '<S80>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3/EVAL_KEY'
//  '<S81>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4/EVAL_KEY'
//  '<S82>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5/EVAL_KEY'
//  '<S83>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6/EVAL_KEY'
//  '<S84>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7/EVAL_KEY'
//  '<S85>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8/EVAL_KEY'
//  '<S86>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S87>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection'
//  '<S88>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats'
//  '<S89>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/InspectionCoverage'
//  '<S90>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1'
//  '<S91>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2'
//  '<S92>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3'
//  '<S93>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4'
//  '<S94>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation'
//  '<S95>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/MATLAB Function'
//  '<S96>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor'
//  '<S97>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter1'
//  '<S98>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter2'
//  '<S99>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter3'
//  '<S100>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter1'
//  '<S101>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter11'
//  '<S102>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter12'
//  '<S103>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter15'
//  '<S104>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter2'
//  '<S105>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter3'
//  '<S106>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter4'
//  '<S107>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter5'
//  '<S108>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter6'
//  '<S109>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S110>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S111>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S112>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S113>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S114>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S115>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S116>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S117>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S118>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S119>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S120>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S121>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation'
//  '<S122>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/MATLAB Function'
//  '<S123>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor'
//  '<S124>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter1'
//  '<S125>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter2'
//  '<S126>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter3'
//  '<S127>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter1'
//  '<S128>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter11'
//  '<S129>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter12'
//  '<S130>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter15'
//  '<S131>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter2'
//  '<S132>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter3'
//  '<S133>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter4'
//  '<S134>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter5'
//  '<S135>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter6'
//  '<S136>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S137>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S138>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S139>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S140>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S141>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S142>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S143>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S144>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S145>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S146>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S147>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S148>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation'
//  '<S149>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/MATLAB Function'
//  '<S150>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor'
//  '<S151>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter1'
//  '<S152>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter2'
//  '<S153>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter3'
//  '<S154>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter1'
//  '<S155>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter11'
//  '<S156>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter12'
//  '<S157>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter15'
//  '<S158>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter2'
//  '<S159>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter3'
//  '<S160>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter4'
//  '<S161>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter5'
//  '<S162>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter6'
//  '<S163>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S164>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S165>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S166>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S167>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S168>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S169>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S170>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S171>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S172>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S173>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S174>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S175>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation'
//  '<S176>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/MATLAB Function'
//  '<S177>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor'
//  '<S178>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter1'
//  '<S179>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter2'
//  '<S180>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter3'
//  '<S181>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter1'
//  '<S182>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter11'
//  '<S183>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter12'
//  '<S184>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter15'
//  '<S185>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter2'
//  '<S186>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter3'
//  '<S187>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter4'
//  '<S188>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter5'
//  '<S189>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter6'
//  '<S190>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S191>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S192>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S193>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S194>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S195>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S196>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S197>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S198>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S199>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S200>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S201>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S202>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/InspectionCoverage/computeCoverage'
//  '<S203>' : 'SatelliteServicing_Mission/ServicingSatellite/Camera'
//  '<S204>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC'
//  '<S205>' : 'SatelliteServicing_Mission/ServicingSatellite/Sat1Solid'
//  '<S206>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel1'
//  '<S207>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel2'
//  '<S208>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter'
//  '<S209>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1'
//  '<S210>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2'
//  '<S211>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3'
//  '<S212>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1'
//  '<S213>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl'
//  '<S214>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefGuidance'
//  '<S215>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefNavigation'
//  '<S216>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/RotationalControl'
//  '<S217>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/TranslationalControl'
//  '<S218>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/RotationalControl/PIDControl'
//  '<S219>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/TranslationalControl/PIDControl'
//  '<S220>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter/EVAL_KEY'
//  '<S221>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1/EVAL_KEY'
//  '<S222>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2/EVAL_KEY'
//  '<S223>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3/EVAL_KEY'
//  '<S224>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter1'
//  '<S225>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter10'
//  '<S226>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter11'
//  '<S227>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter12'
//  '<S228>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter13'
//  '<S229>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter14'
//  '<S230>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter15'
//  '<S231>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter16'
//  '<S232>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter17'
//  '<S233>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter18'
//  '<S234>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter2'
//  '<S235>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter3'
//  '<S236>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter4'
//  '<S237>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter5'
//  '<S238>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter6'
//  '<S239>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter7'
//  '<S240>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter8'
//  '<S241>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter9'
//  '<S242>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/Reorder_to_XYZ'
//  '<S243>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/formPoseMat'
//  '<S244>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/positiveQuat'
//  '<S245>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/quat2MRP'
//  '<S246>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S247>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S248>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S249>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S250>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S251>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S252>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S253>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S254>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S255>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S256>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S257>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S258>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S259>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S260>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S261>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S262>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S263>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S264>' : 'SatelliteServicing_Mission/Solver Configuration/EVAL_KEY'

#endif                              // RTW_HEADER_SatelliteServicing_Mission_h_

//
// File trailer for generated code.
//
// [EOF]
//
