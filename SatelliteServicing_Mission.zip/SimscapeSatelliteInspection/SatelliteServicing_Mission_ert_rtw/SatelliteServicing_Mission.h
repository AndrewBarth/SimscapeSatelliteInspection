//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// File: SatelliteServicing_Mission.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 4.14
// Simulink Coder version         : 9.8 (R2022b) 13-May-2022
// C/C++ source code generated on : Tue Jun 13 12:29:47 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_SatelliteServicing_Mission_h_
#define RTW_HEADER_SatelliteServicing_Mission_h_
#include <stdlib.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "nesl_rtw_rtp.h"
#include "SatelliteServicing_Mission_acc66beb_1_gateway.h"
#include "nesl_rtw.h"
#include "SatelliteServicing_Mission_types.h"
#include "rtGetInf.h"
#include <cstring>

extern "C"
{

#include "rt_nonfinite.h"

}

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

// Block signals (default storage)
struct B_SatelliteServicing_Mission_T {
  real_T RTP_1;                        // '<S6>/RTP_1'
  real_T STATE_1[32];                  // '<S320>/STATE_1'
  real_T INPUT_1_1_1[4];               // '<S320>/INPUT_1_1_1'
  real_T INPUT_2_1_1[4];               // '<S320>/INPUT_2_1_1'
  real_T INPUT_3_1_1[4];               // '<S320>/INPUT_3_1_1'
  real_T Product5[3];                  // '<S258>/Product5'
  real_T controlErrorECEF[6];          // '<S258>/Sum1'
  real_T INPUT_4_1_1[4];               // '<S320>/INPUT_4_1_1'
  real_T INPUT_5_1_1[4];               // '<S320>/INPUT_5_1_1'
  real_T INPUT_6_1_1[4];               // '<S320>/INPUT_6_1_1'
  real_T Product5_j[3];                // '<S257>/Product5'
  real_T controlErrorECEF_n[6];        // '<S257>/Sum1'
  real_T INPUT_7_1_1[4];               // '<S320>/INPUT_7_1_1'
  real_T INPUT_7_1_2[4];               // '<S320>/INPUT_7_1_2'
  real_T INPUT_7_1_3[4];               // '<S320>/INPUT_7_1_3'
  real_T mat[16];                      // '<S267>/formPoseMat'
  real_T joint_torque_out[3];          // '<S233>/Check_Angle_Limits'
};

// Block states (default storage) for system '<Root>'
struct DW_SatelliteServicing_Mission_T {
  real_T INPUT_1_1_1_Discrete;         // '<S320>/INPUT_1_1_1'
  real_T INPUT_1_1_1_FirstOutput;      // '<S320>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete;         // '<S320>/INPUT_2_1_1'
  real_T INPUT_2_1_1_FirstOutput;      // '<S320>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete;         // '<S320>/INPUT_3_1_1'
  real_T INPUT_3_1_1_FirstOutput;      // '<S320>/INPUT_3_1_1'
  real_T DiscreteTimeIntegrator1_DSTATE[3];// '<S258>/Discrete-Time Integrator1' 
  real_T INPUT_4_1_1_Discrete[2];      // '<S320>/INPUT_4_1_1'
  real_T INPUT_5_1_1_Discrete[2];      // '<S320>/INPUT_5_1_1'
  real_T INPUT_6_1_1_Discrete[2];      // '<S320>/INPUT_6_1_1'
  real_T DiscreteTimeIntegrator1_DSTAT_n[3];// '<S257>/Discrete-Time Integrator1' 
  real_T INPUT_7_1_1_Discrete[2];      // '<S320>/INPUT_7_1_1'
  real_T INPUT_7_1_2_Discrete[2];      // '<S320>/INPUT_7_1_2'
  real_T INPUT_7_1_3_Discrete[2];      // '<S320>/INPUT_7_1_3'
  real_T STATE_1_Discrete;             // '<S320>/STATE_1'
  real_T OUTPUT_1_0_Discrete;          // '<S320>/OUTPUT_1_0'
  real_T OUTPUT_1_1_Discrete;          // '<S320>/OUTPUT_1_1'
  void* RTP_1_RtpManager;              // '<S6>/RTP_1'
  void* STATE_1_Simulator;             // '<S320>/STATE_1'
  void* STATE_1_SimData;               // '<S320>/STATE_1'
  void* STATE_1_DiagMgr;               // '<S320>/STATE_1'
  void* STATE_1_ZcLogger;              // '<S320>/STATE_1'
  void* STATE_1_TsInfo;                // '<S320>/STATE_1'
  void* OUTPUT_1_0_Simulator;          // '<S320>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData;            // '<S320>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr;            // '<S320>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger;           // '<S320>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo;             // '<S320>/OUTPUT_1_0'
  void* OUTPUT_1_1_Simulator;          // '<S320>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData;            // '<S320>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr;            // '<S320>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger;           // '<S320>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo;             // '<S320>/OUTPUT_1_1'
  void* SINK_1_RtwLogger;              // '<S320>/SINK_1'
  void* SINK_1_RtwLogBuffer;           // '<S320>/SINK_1'
  void* SINK_1_RtwLogFcnManager;       // '<S320>/SINK_1'
  int_T STATE_1_Modes;                 // '<S320>/STATE_1'
  int_T OUTPUT_1_0_Modes;              // '<S320>/OUTPUT_1_0'
  int_T OUTPUT_1_1_Modes;              // '<S320>/OUTPUT_1_1'
  boolean_T RTP_1_SetParametersNeeded; // '<S6>/RTP_1'
  boolean_T STATE_1_FirstOutput;       // '<S320>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput;    // '<S320>/OUTPUT_1_0'
  boolean_T OUTPUT_1_1_FirstOutput;    // '<S320>/OUTPUT_1_1'
};

// Continuous states (default storage)
struct X_SatelliteServicing_Mission_T {
  real_T SatelliteServicing_MissionServi[32];// '<S320>/STATE_1'
  real_T SatelliteServicing_MissionRobot[2];// '<S320>/INPUT_1_1_1'
  real_T SatelliteServicing_MissionRob_j[2];// '<S320>/INPUT_2_1_1'
  real_T SatelliteServicing_MissionRob_k[2];// '<S320>/INPUT_3_1_1'
};

// State derivatives (default storage)
struct XDot_SatelliteServicing_Missi_T {
  real_T SatelliteServicing_MissionServi[32];// '<S320>/STATE_1'
  real_T SatelliteServicing_MissionRobot[2];// '<S320>/INPUT_1_1_1'
  real_T SatelliteServicing_MissionRob_j[2];// '<S320>/INPUT_2_1_1'
  real_T SatelliteServicing_MissionRob_k[2];// '<S320>/INPUT_3_1_1'
};

// State disabled
struct XDis_SatelliteServicing_Missi_T {
  boolean_T SatelliteServicing_MissionServi[32];// '<S320>/STATE_1'
  boolean_T SatelliteServicing_MissionRobot[2];// '<S320>/INPUT_1_1_1'
  boolean_T SatelliteServicing_MissionRob_j[2];// '<S320>/INPUT_2_1_1'
  boolean_T SatelliteServicing_MissionRob_k[2];// '<S320>/INPUT_3_1_1'
};

#ifndef ODE3_INTG
#define ODE3_INTG

// ODE3 Integration Data
struct ODE3_IntgData {
  real_T *y;                           // output
  real_T *f[3];                        // derivatives
};

#endif

// External inputs (root inport signals with default storage)
struct ExtU_SatelliteServicing_Missi_T {
  real_T ManipulatorActions[3];        // '<Root>/ManipulatorActions'
};

// External outputs (root outports fed by signals with default storage)
struct ExtY_SatelliteServicing_Missi_T {
  real_T Observations[33];             // '<Root>/Observations'
};

// Parameters (default storage)
struct P_SatelliteServicing_Mission_T_ {
  jointControlDataBus jointControlData;// Variable: jointControlData
                                          //  Referenced by: '<S4>/Constant1'

  satControlDataBus_Rot satControlData_Rot;// Variable: satControlData_Rot
                                              //  Referenced by:
                                              //    '<S233>/Constant2'
                                              //    '<S238>/Saturation1'

  satControlDataBus_Trans satControlData_Trans;// Variable: satControlData_Trans
                                                  //  Referenced by:
                                                  //    '<S233>/Constant1'
                                                  //    '<S239>/Saturation1'

  struct_kjtWkwU9EJughpNsMWHSGE nav;   // Variable: nav
                                          //  Referenced by: '<S267>/Constant1'

  real_T RTP_3768B6F2_PositionTargetValu;
                                  // Expression: smiData.RevoluteJoint(2).Rz.Pos
                                     //  Referenced by: '<S119>/Subsystem_around_RTP_3768B6F2_PositionTargetValue'

  real_T RTP_406F8664_PositionTargetValu;
                                  // Expression: smiData.RevoluteJoint(3).Rz.Pos
                                     //  Referenced by: '<S119>/Subsystem_around_RTP_406F8664_PositionTargetValue'

  real_T RTP_AE61E748_PositionTargetValu;
                                  // Expression: smiData.RevoluteJoint(1).Rz.Pos
                                     //  Referenced by: '<S119>/Subsystem_around_RTP_AE61E748_PositionTargetValue'

  real_T DiscreteTimeIntegrator1_gainval;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainval
                             //  Referenced by: '<S258>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC;   // Expression: 0
                                          //  Referenced by: '<S258>/Discrete-Time Integrator1'

  real_T Gain1_Gain;                   // Expression: -1
                                          //  Referenced by: '<S258>/Gain1'

  real_T DiscreteTimeIntegrator1_gainv_f;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainv_f
                             //  Referenced by: '<S257>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC_l; // Expression: 0
                                          //  Referenced by: '<S257>/Discrete-Time Integrator1'

  real_T Gain1_Gain_l;                 // Expression: -1
                                          //  Referenced by: '<S257>/Gain1'

  real_T Constant2_Value[3];           // Expression: [0 0 0]
                                          //  Referenced by: '<S267>/Constant2'

  uint32_T Bias_Bias;                  // Computed Parameter: Bias_Bias
                                          //  Referenced by: '<S234>/Bias'

};

// Real-time Model Data Structure
struct tag_RTM_SatelliteServicing_Mi_T {
  const char_T *errorStatus;
  RTWSolverInfo *solverInfo;
  B_SatelliteServicing_Mission_T *blockIO;
  X_SatelliteServicing_Mission_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_SatelliteServicing_Missi_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[38];
  real_T odeF[3][38];
  ODE3_IntgData intgData;
  DW_SatelliteServicing_Mission_T *dwork;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

// Block parameters (default storage)
#ifdef __cplusplus

extern "C"
{

#endif

  extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;

#ifdef __cplusplus

}

#endif

// External data declarations for dependent source files
#ifdef __cplusplus

extern "C"
{

#endif

  extern const char *RT_MEMORY_ALLOCATION_ERROR;

#ifdef __cplusplus

}

#endif

extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;// parameters 

#ifdef __cplusplus

extern "C"
{

#endif

  // Model entry point functions
  extern RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission
    (ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
     ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_initialize
    (RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M,
     ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
     ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_step(RT_MODEL_SatelliteServicing_M_T *
    const SatelliteServicing_Mission_M, ExtU_SatelliteServicing_Missi_T
    *SatelliteServicing_Mission_U, ExtY_SatelliteServicing_Missi_T
    *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_terminate
    (RT_MODEL_SatelliteServicing_M_T * SatelliteServicing_Mission_M);

#ifdef __cplusplus

}

#endif

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S110>/RESHAPE' : Unused code path elimination
//  Block '<S243>/Sum1' : Unused code path elimination
//  Block '<S244>/Product5' : Unused code path elimination
//  Block '<S244>/Reshape4' : Unused code path elimination
//  Block '<S244>/Sum1' : Unused code path elimination
//  Block '<S244>/Sum2' : Unused code path elimination
//  Block '<S245>/Add2' : Unused code path elimination
//  Block '<S245>/Sum1' : Unused code path elimination
//  Block '<S242>/Reshape1' : Reshape block reduction
//  Block '<S242>/Reshape2' : Reshape block reduction
//  Block '<S242>/Reshape4' : Reshape block reduction
//  Block '<S259>/Reshape' : Reshape block reduction
//  Block '<S259>/Reshape1' : Reshape block reduction
//  Block '<S259>/Reshape3' : Reshape block reduction
//  Block '<S259>/Reshape4' : Reshape block reduction
//  Block '<S259>/Reshape5' : Reshape block reduction
//  Block '<S259>/Reshape7' : Reshape block reduction
//  Block '<S267>/Reshape' : Reshape block reduction


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'SatelliteServicing_Mission'
//  '<S1>'   : 'SatelliteServicing_Mission/ClientSatellite'
//  '<S2>'   : 'SatelliteServicing_Mission/RelativeState'
//  '<S3>'   : 'SatelliteServicing_Mission/RoboticArm'
//  '<S4>'   : 'SatelliteServicing_Mission/ServicingSatGNC'
//  '<S5>'   : 'SatelliteServicing_Mission/ServicingSatellite'
//  '<S6>'   : 'SatelliteServicing_Mission/Solver Configuration'
//  '<S7>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output'
//  '<S8>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output2'
//  '<S9>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output/MATLAB Function'
//  '<S10>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter1'
//  '<S11>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter10'
//  '<S12>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter11'
//  '<S13>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter12'
//  '<S14>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter13'
//  '<S15>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter14'
//  '<S16>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter15'
//  '<S17>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter16'
//  '<S18>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter2'
//  '<S19>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter3'
//  '<S20>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter4'
//  '<S21>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter5'
//  '<S22>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter6'
//  '<S23>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter7'
//  '<S24>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter8'
//  '<S25>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter9'
//  '<S26>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/QuatToDCM'
//  '<S27>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/QuatToEuler321'
//  '<S28>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/formPoseMat'
//  '<S29>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter1/EVAL_KEY'
//  '<S30>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter10/EVAL_KEY'
//  '<S31>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter11/EVAL_KEY'
//  '<S32>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter12/EVAL_KEY'
//  '<S33>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter13/EVAL_KEY'
//  '<S34>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter14/EVAL_KEY'
//  '<S35>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter15/EVAL_KEY'
//  '<S36>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter16/EVAL_KEY'
//  '<S37>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter2/EVAL_KEY'
//  '<S38>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter3/EVAL_KEY'
//  '<S39>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter4/EVAL_KEY'
//  '<S40>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter5/EVAL_KEY'
//  '<S41>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter6/EVAL_KEY'
//  '<S42>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter7/EVAL_KEY'
//  '<S43>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter8/EVAL_KEY'
//  '<S44>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output/PS-Simulink Converter9/EVAL_KEY'
//  '<S45>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/MATLAB Function'
//  '<S46>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1'
//  '<S47>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10'
//  '<S48>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11'
//  '<S49>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12'
//  '<S50>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13'
//  '<S51>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14'
//  '<S52>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15'
//  '<S53>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16'
//  '<S54>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2'
//  '<S55>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3'
//  '<S56>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4'
//  '<S57>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5'
//  '<S58>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6'
//  '<S59>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7'
//  '<S60>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8'
//  '<S61>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9'
//  '<S62>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/QuatToDCM'
//  '<S63>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/QuatToEuler321'
//  '<S64>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/formPoseMat'
//  '<S65>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S66>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10/EVAL_KEY'
//  '<S67>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11/EVAL_KEY'
//  '<S68>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12/EVAL_KEY'
//  '<S69>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S70>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S71>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15/EVAL_KEY'
//  '<S72>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16/EVAL_KEY'
//  '<S73>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2/EVAL_KEY'
//  '<S74>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3/EVAL_KEY'
//  '<S75>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4/EVAL_KEY'
//  '<S76>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5/EVAL_KEY'
//  '<S77>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6/EVAL_KEY'
//  '<S78>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7/EVAL_KEY'
//  '<S79>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8/EVAL_KEY'
//  '<S80>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S81>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2'
//  '<S82>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter1'
//  '<S83>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter10'
//  '<S84>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter11'
//  '<S85>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter12'
//  '<S86>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter13'
//  '<S87>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter14'
//  '<S88>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter15'
//  '<S89>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter16'
//  '<S90>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter17'
//  '<S91>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter2'
//  '<S92>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter3'
//  '<S93>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter4'
//  '<S94>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter5'
//  '<S95>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter6'
//  '<S96>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter7'
//  '<S97>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter8'
//  '<S98>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter9'
//  '<S99>'  : 'SatelliteServicing_Mission/RelativeState/State_Output2/QuatToDCM'
//  '<S100>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/QuatToEuler321'
//  '<S101>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/formPoseMat'
//  '<S102>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S103>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter10/EVAL_KEY'
//  '<S104>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter11/EVAL_KEY'
//  '<S105>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter12/EVAL_KEY'
//  '<S106>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S107>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S108>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter15/EVAL_KEY'
//  '<S109>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter16/EVAL_KEY'
//  '<S110>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter17/EVAL_KEY'
//  '<S111>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter2/EVAL_KEY'
//  '<S112>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter3/EVAL_KEY'
//  '<S113>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter4/EVAL_KEY'
//  '<S114>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter5/EVAL_KEY'
//  '<S115>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter6/EVAL_KEY'
//  '<S116>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter7/EVAL_KEY'
//  '<S117>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter8/EVAL_KEY'
//  '<S118>' : 'SatelliteServicing_Mission/RelativeState/State_Output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S119>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link'
//  '<S120>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmBase_1_RIGID1'
//  '<S121>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmSegmentAssembly_2'
//  '<S122>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmSegmentAssembly_3'
//  '<S123>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Gripper_2_RIGID'
//  '<S124>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1'
//  '<S125>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2'
//  '<S126>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3'
//  '<S127>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter1'
//  '<S128>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter2'
//  '<S129>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter3'
//  '<S130>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1'
//  '<S131>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2'
//  '<S132>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmSegmentAssembly_2/ArmSegment_1_RIGID'
//  '<S133>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmSegmentAssembly_3/ArmSegment_1_RIGID'
//  '<S134>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter1'
//  '<S135>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter13'
//  '<S136>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter14'
//  '<S137>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter9'
//  '<S138>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S139>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S140>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S141>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S142>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter1'
//  '<S143>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter13'
//  '<S144>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter14'
//  '<S145>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter9'
//  '<S146>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S147>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S148>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S149>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S150>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter1'
//  '<S151>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter13'
//  '<S152>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter14'
//  '<S153>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter9'
//  '<S154>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter1/EVAL_KEY'
//  '<S155>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter13/EVAL_KEY'
//  '<S156>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter14/EVAL_KEY'
//  '<S157>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter9/EVAL_KEY'
//  '<S158>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter1/EVAL_KEY'
//  '<S159>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter2/EVAL_KEY'
//  '<S160>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter3/EVAL_KEY'
//  '<S161>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/MATLAB Function'
//  '<S162>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter1'
//  '<S163>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter10'
//  '<S164>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter11'
//  '<S165>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter12'
//  '<S166>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter13'
//  '<S167>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter14'
//  '<S168>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter15'
//  '<S169>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter16'
//  '<S170>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter2'
//  '<S171>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter3'
//  '<S172>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter4'
//  '<S173>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter5'
//  '<S174>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter6'
//  '<S175>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter7'
//  '<S176>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter8'
//  '<S177>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter9'
//  '<S178>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/QuatToDCM'
//  '<S179>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/QuatToEuler321'
//  '<S180>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/formPoseMat'
//  '<S181>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S182>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S183>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S184>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S185>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S186>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S187>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S188>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S189>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S190>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S191>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S192>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S193>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S194>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S195>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S196>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S197>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/MATLAB Function'
//  '<S198>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter1'
//  '<S199>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter10'
//  '<S200>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter11'
//  '<S201>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter12'
//  '<S202>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter13'
//  '<S203>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter14'
//  '<S204>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter15'
//  '<S205>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter16'
//  '<S206>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter2'
//  '<S207>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter3'
//  '<S208>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter4'
//  '<S209>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter5'
//  '<S210>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter6'
//  '<S211>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter7'
//  '<S212>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter8'
//  '<S213>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter9'
//  '<S214>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/QuatToDCM'
//  '<S215>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/QuatToEuler321'
//  '<S216>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/formPoseMat'
//  '<S217>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S218>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter10/EVAL_KEY'
//  '<S219>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter11/EVAL_KEY'
//  '<S220>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter12/EVAL_KEY'
//  '<S221>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S222>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S223>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter15/EVAL_KEY'
//  '<S224>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter16/EVAL_KEY'
//  '<S225>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter2/EVAL_KEY'
//  '<S226>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter3/EVAL_KEY'
//  '<S227>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter4/EVAL_KEY'
//  '<S228>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter5/EVAL_KEY'
//  '<S229>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter6/EVAL_KEY'
//  '<S230>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter7/EVAL_KEY'
//  '<S231>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter8/EVAL_KEY'
//  '<S232>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S233>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control'
//  '<S234>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance'
//  '<S235>' : 'SatelliteServicing_Mission/ServicingSatGNC/Navigation'
//  '<S236>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl'
//  '<S237>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/Check_Angle_Limits'
//  '<S238>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/RotationalControl'
//  '<S239>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/TranslationalControl'
//  '<S240>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl'
//  '<S241>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem'
//  '<S242>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError'
//  '<S243>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/PositionError'
//  '<S244>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/RateError1'
//  '<S245>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/VelocityError'
//  '<S246>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError/ModifiedRodrigues'
//  '<S247>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError/errorQuat'
//  '<S248>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError/positiveQuat'
//  '<S249>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError/quat2Euler'
//  '<S250>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError/unwrap'
//  '<S251>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError/ModifiedRodrigues/errorMRP'
//  '<S252>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError/ModifiedRodrigues/quat2MPR1'
//  '<S253>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/AttitudeError/ModifiedRodrigues/quat2MRP'
//  '<S254>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/RateError1/formRotation'
//  '<S255>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/RateError1/positiveQuat'
//  '<S256>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl/Subsystem/VelocityError/cross'
//  '<S257>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/RotationalControl/PIDControl'
//  '<S258>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/TranslationalControl/PIDControl'
//  '<S259>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative'
//  '<S260>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/MATLAB Function'
//  '<S261>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/formPoseMat'
//  '<S262>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/formRotMat'
//  '<S263>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/formRotMat1'
//  '<S264>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/formRotMat2'
//  '<S265>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/formRotMat4'
//  '<S266>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/quatconj'
//  '<S267>' : 'SatelliteServicing_Mission/ServicingSatGNC/Navigation/ComputeRelativePose'
//  '<S268>' : 'SatelliteServicing_Mission/ServicingSatGNC/Navigation/ComputeRelativePose/formPoseMat'
//  '<S269>' : 'SatelliteServicing_Mission/ServicingSatGNC/Navigation/ComputeRelativePose/formRotMat'
//  '<S270>' : 'SatelliteServicing_Mission/ServicingSatGNC/Navigation/ComputeRelativePose/formRotMat1'
//  '<S271>' : 'SatelliteServicing_Mission/ServicingSatellite/Camera'
//  '<S272>' : 'SatelliteServicing_Mission/ServicingSatellite/Sat1Solid'
//  '<S273>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel1'
//  '<S274>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel2'
//  '<S275>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter'
//  '<S276>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1'
//  '<S277>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2'
//  '<S278>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3'
//  '<S279>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output'
//  '<S280>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter/EVAL_KEY'
//  '<S281>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1/EVAL_KEY'
//  '<S282>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2/EVAL_KEY'
//  '<S283>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3/EVAL_KEY'
//  '<S284>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/MATLAB Function'
//  '<S285>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter1'
//  '<S286>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter10'
//  '<S287>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter11'
//  '<S288>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter12'
//  '<S289>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter13'
//  '<S290>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter14'
//  '<S291>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter15'
//  '<S292>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter16'
//  '<S293>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter2'
//  '<S294>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter3'
//  '<S295>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter4'
//  '<S296>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter5'
//  '<S297>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter6'
//  '<S298>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter7'
//  '<S299>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter8'
//  '<S300>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter9'
//  '<S301>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/QuatToDCM'
//  '<S302>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/QuatToEuler321'
//  '<S303>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/formPoseMat'
//  '<S304>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter1/EVAL_KEY'
//  '<S305>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter10/EVAL_KEY'
//  '<S306>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter11/EVAL_KEY'
//  '<S307>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter12/EVAL_KEY'
//  '<S308>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter13/EVAL_KEY'
//  '<S309>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter14/EVAL_KEY'
//  '<S310>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter15/EVAL_KEY'
//  '<S311>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter16/EVAL_KEY'
//  '<S312>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter2/EVAL_KEY'
//  '<S313>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter3/EVAL_KEY'
//  '<S314>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter4/EVAL_KEY'
//  '<S315>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter5/EVAL_KEY'
//  '<S316>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter6/EVAL_KEY'
//  '<S317>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter7/EVAL_KEY'
//  '<S318>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter8/EVAL_KEY'
//  '<S319>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output/PS-Simulink Converter9/EVAL_KEY'
//  '<S320>' : 'SatelliteServicing_Mission/Solver Configuration/EVAL_KEY'

#endif                              // RTW_HEADER_SatelliteServicing_Mission_h_

//
// File trailer for generated code.
//
// [EOF]
//
