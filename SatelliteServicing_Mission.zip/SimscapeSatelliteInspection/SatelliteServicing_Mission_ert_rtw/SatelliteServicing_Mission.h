//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.27
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Wed Mar  6 22:36:49 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_SatelliteServicing_Mission_h_
#define RTW_HEADER_SatelliteServicing_Mission_h_
#include <stdlib.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "nesl_rtw_rtp.h"
#include "SatelliteServicing_Mission_acc66beb_1_gateway.h"
#include "nesl_rtw.h"
#include "SatelliteServicing_Mission_types.h"
#include <cstring>

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

// Block signals (default storage)
struct B_SatelliteServicing_Mission_T {
  real_T RTP_1;                        // '<S6>/RTP_1'
  real_T STATE_1[32];                  // '<S305>/STATE_1'
  real_T INPUT_1_1_1[4];               // '<S305>/INPUT_1_1_1'
  real_T INPUT_2_1_1[4];               // '<S305>/INPUT_2_1_1'
  real_T INPUT_3_1_1[4];               // '<S305>/INPUT_3_1_1'
  real_T Product5[3];                  // '<S241>/Product5'
  real_T controlErrorECEF[6];          // '<S241>/Sum1'
  real_T INPUT_4_1_1[4];               // '<S305>/INPUT_4_1_1'
  real_T INPUT_5_1_1[4];               // '<S305>/INPUT_5_1_1'
  real_T INPUT_6_1_1[4];               // '<S305>/INPUT_6_1_1'
  real_T Product5_j[3];                // '<S238>/Product5'
  real_T controlErrorECEF_n[6];        // '<S238>/Sum1'
  real_T INPUT_7_1_1[4];               // '<S305>/INPUT_7_1_1'
  real_T INPUT_7_1_2[4];               // '<S305>/INPUT_7_1_2'
  real_T INPUT_7_1_3[4];               // '<S305>/INPUT_7_1_3'
  real_T joint_torque_out[3];          // '<S219>/Check_Rate_Limits'
};

// Block states (default storage) for system '<Root>'
struct DW_SatelliteServicing_Mission_T {
  real_T INPUT_1_1_1_Discrete;         // '<S305>/INPUT_1_1_1'
  real_T INPUT_1_1_1_FirstOutput;      // '<S305>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete;         // '<S305>/INPUT_2_1_1'
  real_T INPUT_2_1_1_FirstOutput;      // '<S305>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete;         // '<S305>/INPUT_3_1_1'
  real_T INPUT_3_1_1_FirstOutput;      // '<S305>/INPUT_3_1_1'
  real_T DiscreteTimeIntegrator1_DSTATE[3];// '<S241>/Discrete-Time Integrator1' 
  real_T INPUT_4_1_1_Discrete[2];      // '<S305>/INPUT_4_1_1'
  real_T INPUT_5_1_1_Discrete[2];      // '<S305>/INPUT_5_1_1'
  real_T INPUT_6_1_1_Discrete[2];      // '<S305>/INPUT_6_1_1'
  real_T DiscreteTimeIntegrator1_DSTAT_n[3];// '<S238>/Discrete-Time Integrator1' 
  real_T INPUT_7_1_1_Discrete[2];      // '<S305>/INPUT_7_1_1'
  real_T INPUT_7_1_2_Discrete[2];      // '<S305>/INPUT_7_1_2'
  real_T INPUT_7_1_3_Discrete[2];      // '<S305>/INPUT_7_1_3'
  real_T STATE_1_Discrete;             // '<S305>/STATE_1'
  real_T OUTPUT_1_0_Discrete;          // '<S305>/OUTPUT_1_0'
  real_T OUTPUT_1_1_Discrete;          // '<S305>/OUTPUT_1_1'
  void* RTP_1_RtpManager;              // '<S6>/RTP_1'
  void* STATE_1_Simulator;             // '<S305>/STATE_1'
  void* STATE_1_SimData;               // '<S305>/STATE_1'
  void* STATE_1_DiagMgr;               // '<S305>/STATE_1'
  void* STATE_1_ZcLogger;              // '<S305>/STATE_1'
  void* STATE_1_TsInfo;                // '<S305>/STATE_1'
  void* OUTPUT_1_0_Simulator;          // '<S305>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData;            // '<S305>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr;            // '<S305>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger;           // '<S305>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo;             // '<S305>/OUTPUT_1_0'
  void* OUTPUT_1_1_Simulator;          // '<S305>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData;            // '<S305>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr;            // '<S305>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger;           // '<S305>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo;             // '<S305>/OUTPUT_1_1'
  void* SINK_1_RtwLogger;              // '<S305>/SINK_1'
  void* SINK_1_RtwLogBuffer;           // '<S305>/SINK_1'
  void* SINK_1_RtwLogFcnManager;       // '<S305>/SINK_1'
  int_T STATE_1_Modes;                 // '<S305>/STATE_1'
  int_T OUTPUT_1_0_Modes;              // '<S305>/OUTPUT_1_0'
  int_T OUTPUT_1_1_Modes;              // '<S305>/OUTPUT_1_1'
  boolean_T RTP_1_SetParametersNeeded; // '<S6>/RTP_1'
  boolean_T STATE_1_FirstOutput;       // '<S305>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput;    // '<S305>/OUTPUT_1_0'
  boolean_T OUTPUT_1_1_FirstOutput;    // '<S305>/OUTPUT_1_1'
};

// Continuous states (default storage)
struct X_SatelliteServicing_Mission_T {
  real_T SatelliteServicing_MissionServi[32];// '<S305>/STATE_1'
  real_T SatelliteServicing_MissionRobot[2];// '<S305>/INPUT_1_1_1'
  real_T SatelliteServicing_MissionRob_j[2];// '<S305>/INPUT_2_1_1'
  real_T SatelliteServicing_MissionRob_k[2];// '<S305>/INPUT_3_1_1'
};

// State derivatives (default storage)
struct XDot_SatelliteServicing_Missi_T {
  real_T SatelliteServicing_MissionServi[32];// '<S305>/STATE_1'
  real_T SatelliteServicing_MissionRobot[2];// '<S305>/INPUT_1_1_1'
  real_T SatelliteServicing_MissionRob_j[2];// '<S305>/INPUT_2_1_1'
  real_T SatelliteServicing_MissionRob_k[2];// '<S305>/INPUT_3_1_1'
};

// State disabled
struct XDis_SatelliteServicing_Missi_T {
  boolean_T SatelliteServicing_MissionServi[32];// '<S305>/STATE_1'
  boolean_T SatelliteServicing_MissionRobot[2];// '<S305>/INPUT_1_1_1'
  boolean_T SatelliteServicing_MissionRob_j[2];// '<S305>/INPUT_2_1_1'
  boolean_T SatelliteServicing_MissionRob_k[2];// '<S305>/INPUT_3_1_1'
};

#ifndef ODE3_INTG
#define ODE3_INTG

// ODE3 Integration Data
struct ODE3_IntgData {
  real_T *y;                           // output
  real_T *f[3];                        // derivatives
};

#endif

// External inputs (root inport signals with default storage)
struct ExtU_SatelliteServicing_Missi_T {
  real_T ManipulatorActions[3];        // '<Root>/ManipulatorActions'
};

// External outputs (root outports fed by signals with default storage)
struct ExtY_SatelliteServicing_Missi_T {
  real_T Observations[34];             // '<Root>/Observations'
  real_T ControlError[13];             // '<Root>/ControlError'
};

// Parameters (default storage)
struct P_SatelliteServicing_Mission_T_ {
  jointControlDataBus jointControlData;// Variable: jointControlData
                                          //  Referenced by: '<S4>/Constant1'

  satControlDataBus_Rot satControlData_Rot;// Variable: satControlData_Rot
                                              //  Referenced by:
                                              //    '<S213>/Constant2'
                                              //    '<S218>/Saturation1'

  satControlDataBus_Trans satControlData_Trans;// Variable: satControlData_Trans
                                                  //  Referenced by:
                                                  //    '<S213>/Constant1'
                                                  //    '<S220>/Saturation1'

  real_T RTP_3768B6F2_PositionTargetValu;
                                  // Expression: smiData.RevoluteJoint(2).Rz.Pos
                                     //  Referenced by: '<S91>/Subsystem_around_RTP_3768B6F2_PositionTargetValue'

  real_T RTP_406F8664_PositionTargetValu;
                                  // Expression: smiData.RevoluteJoint(3).Rz.Pos
                                     //  Referenced by: '<S91>/Subsystem_around_RTP_406F8664_PositionTargetValue'

  real_T RTP_AE61E748_PositionTargetValu;
                                  // Expression: smiData.RevoluteJoint(1).Rz.Pos
                                     //  Referenced by: '<S91>/Subsystem_around_RTP_AE61E748_PositionTargetValue'

  real_T DiscreteTimeIntegrator1_gainval;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainval
                             //  Referenced by: '<S241>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC;   // Expression: 0
                                          //  Referenced by: '<S241>/Discrete-Time Integrator1'

  real_T Gain1_Gain;                   // Expression: -1
                                          //  Referenced by: '<S241>/Gain1'

  real_T DiscreteTimeIntegrator1_gainv_f;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainv_f
                             //  Referenced by: '<S238>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC_l; // Expression: 0
                                          //  Referenced by: '<S238>/Discrete-Time Integrator1'

  real_T Gain1_Gain_l;                 // Expression: -1
                                          //  Referenced by: '<S238>/Gain1'

  uint32_T Bias_Bias;                  // Computed Parameter: Bias_Bias
                                          //  Referenced by: '<S214>/Bias'

};

// Real-time Model Data Structure
struct tag_RTM_SatelliteServicing_Mi_T {
  const char_T *errorStatus;
  RTWSolverInfo *solverInfo;
  B_SatelliteServicing_Mission_T *blockIO;
  X_SatelliteServicing_Mission_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_SatelliteServicing_Missi_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[38];
  real_T odeF[3][38];
  ODE3_IntgData intgData;
  DW_SatelliteServicing_Mission_T *dwork;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

// Block parameters (default storage)
#ifdef __cplusplus

extern "C"
{

#endif

  extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;

#ifdef __cplusplus

}

#endif

// External data declarations for dependent source files
#ifdef __cplusplus

extern "C"
{

#endif

  extern const char_T *RT_MEMORY_ALLOCATION_ERROR;

#ifdef __cplusplus

}

#endif

extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;// parameters 

#ifdef __cplusplus

extern "C"
{

#endif

  // Model entry point functions
  extern RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission
    (ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
     ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_initialize
    (RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M);
  extern void SatelliteServicing_Mission_step(RT_MODEL_SatelliteServicing_M_T *
    const SatelliteServicing_Mission_M, ExtU_SatelliteServicing_Missi_T
    *SatelliteServicing_Mission_U, ExtY_SatelliteServicing_Missi_T
    *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_terminate
    (RT_MODEL_SatelliteServicing_M_T * SatelliteServicing_Mission_M);

#ifdef __cplusplus

}

#endif

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S224>/Product5' : Unused code path elimination
//  Block '<S224>/Reshape4' : Unused code path elimination
//  Block '<S224>/Sum2' : Unused code path elimination
//  Block '<S225>/Add2' : Unused code path elimination
//  Block '<S40>/RESHAPE' : Reshape block reduction
//  Block '<S80>/RESHAPE' : Reshape block reduction
//  Block '<S163>/RESHAPE' : Reshape block reduction
//  Block '<S203>/RESHAPE' : Reshape block reduction
//  Block '<S222>/Reshape1' : Reshape block reduction
//  Block '<S222>/Reshape2' : Reshape block reduction
//  Block '<S222>/Reshape3' : Reshape block reduction
//  Block '<S222>/Reshape4' : Reshape block reduction
//  Block '<S217>/Reshape1' : Reshape block reduction
//  Block '<S217>/Reshape2' : Reshape block reduction
//  Block '<S217>/Reshape3' : Reshape block reduction
//  Block '<S217>/Reshape4' : Reshape block reduction
//  Block '<S217>/Reshape5' : Reshape block reduction
//  Block '<S242>/Reshape4' : Reshape block reduction
//  Block '<S242>/Reshape5' : Reshape block reduction
//  Block '<S242>/Reshape6' : Reshape block reduction
//  Block '<S242>/Reshape8' : Reshape block reduction
//  Block '<S243>/Reshape7' : Reshape block reduction
//  Block '<S295>/RESHAPE' : Reshape block reduction
//  Block '<S336>/RESHAPE' : Reshape block reduction


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'SatelliteServicing_Mission'
//  '<S1>'   : 'SatelliteServicing_Mission/ClientSatellite'
//  '<S2>'   : 'SatelliteServicing_Mission/PlaybackMode'
//  '<S3>'   : 'SatelliteServicing_Mission/RoboticArm'
//  '<S4>'   : 'SatelliteServicing_Mission/ServicingSatGNC'
//  '<S5>'   : 'SatelliteServicing_Mission/ServicingSatellite'
//  '<S6>'   : 'SatelliteServicing_Mission/Solver Configuration'
//  '<S7>'   : 'SatelliteServicing_Mission/State_Output_RelBase'
//  '<S8>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1'
//  '<S9>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output2'
//  '<S10>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter1'
//  '<S11>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter10'
//  '<S12>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter11'
//  '<S13>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter12'
//  '<S14>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter13'
//  '<S15>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter14'
//  '<S16>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter15'
//  '<S17>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter16'
//  '<S18>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter17'
//  '<S19>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter18'
//  '<S20>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter2'
//  '<S21>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter3'
//  '<S22>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter4'
//  '<S23>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter5'
//  '<S24>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter6'
//  '<S25>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter7'
//  '<S26>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter8'
//  '<S27>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter9'
//  '<S28>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/Reorder_to_XYZ'
//  '<S29>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/formPoseMat'
//  '<S30>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/positiveQuat'
//  '<S31>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/quat2MRP'
//  '<S32>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S33>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S34>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S35>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S36>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S37>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S38>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S39>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S40>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S41>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S42>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S43>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S44>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S45>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S46>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S47>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S48>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S49>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S50>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1'
//  '<S51>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10'
//  '<S52>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11'
//  '<S53>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12'
//  '<S54>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13'
//  '<S55>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14'
//  '<S56>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15'
//  '<S57>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16'
//  '<S58>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter17'
//  '<S59>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter18'
//  '<S60>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2'
//  '<S61>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3'
//  '<S62>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4'
//  '<S63>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5'
//  '<S64>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6'
//  '<S65>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7'
//  '<S66>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8'
//  '<S67>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9'
//  '<S68>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/Reorder_to_XYZ'
//  '<S69>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/formPoseMat'
//  '<S70>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/positiveQuat'
//  '<S71>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/quat2MRP'
//  '<S72>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S73>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10/EVAL_KEY'
//  '<S74>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11/EVAL_KEY'
//  '<S75>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12/EVAL_KEY'
//  '<S76>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S77>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S78>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15/EVAL_KEY'
//  '<S79>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16/EVAL_KEY'
//  '<S80>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter17/EVAL_KEY'
//  '<S81>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter18/EVAL_KEY'
//  '<S82>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2/EVAL_KEY'
//  '<S83>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3/EVAL_KEY'
//  '<S84>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4/EVAL_KEY'
//  '<S85>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5/EVAL_KEY'
//  '<S86>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6/EVAL_KEY'
//  '<S87>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7/EVAL_KEY'
//  '<S88>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8/EVAL_KEY'
//  '<S89>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S90>'  : 'SatelliteServicing_Mission/PlaybackMode/Computed_JointTorques'
//  '<S91>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link'
//  '<S92>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmBase_1_RIGID1'
//  '<S93>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmSegmentAssembly_2'
//  '<S94>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmSegmentAssembly_3'
//  '<S95>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Gripper_2_RIGID'
//  '<S96>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1'
//  '<S97>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2'
//  '<S98>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3'
//  '<S99>'  : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter1'
//  '<S100>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter2'
//  '<S101>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter3'
//  '<S102>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1'
//  '<S103>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2'
//  '<S104>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmSegmentAssembly_2/ArmSegment_1_RIGID'
//  '<S105>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/ArmSegmentAssembly_3/ArmSegment_1_RIGID'
//  '<S106>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter1'
//  '<S107>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter13'
//  '<S108>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter14'
//  '<S109>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter9'
//  '<S110>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S111>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S112>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S113>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S114>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter1'
//  '<S115>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter13'
//  '<S116>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter14'
//  '<S117>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter9'
//  '<S118>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S119>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S120>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S121>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S122>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter1'
//  '<S123>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter13'
//  '<S124>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter14'
//  '<S125>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter9'
//  '<S126>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter1/EVAL_KEY'
//  '<S127>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter13/EVAL_KEY'
//  '<S128>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter14/EVAL_KEY'
//  '<S129>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Joint_output3/PS-Simulink Converter9/EVAL_KEY'
//  '<S130>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter1/EVAL_KEY'
//  '<S131>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter2/EVAL_KEY'
//  '<S132>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/Simulink-PS Converter3/EVAL_KEY'
//  '<S133>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter1'
//  '<S134>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter10'
//  '<S135>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter11'
//  '<S136>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter12'
//  '<S137>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter13'
//  '<S138>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter14'
//  '<S139>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter15'
//  '<S140>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter16'
//  '<S141>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter17'
//  '<S142>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter18'
//  '<S143>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter2'
//  '<S144>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter3'
//  '<S145>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter4'
//  '<S146>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter5'
//  '<S147>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter6'
//  '<S148>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter7'
//  '<S149>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter8'
//  '<S150>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter9'
//  '<S151>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/Reorder_to_XYZ'
//  '<S152>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/formPoseMat'
//  '<S153>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/positiveQuat'
//  '<S154>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/quat2MRP'
//  '<S155>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S156>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S157>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S158>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S159>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S160>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S161>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S162>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S163>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S164>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S165>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S166>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S167>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S168>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S169>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S170>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S171>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S172>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S173>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter1'
//  '<S174>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter10'
//  '<S175>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter11'
//  '<S176>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter12'
//  '<S177>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter13'
//  '<S178>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter14'
//  '<S179>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter15'
//  '<S180>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter16'
//  '<S181>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter17'
//  '<S182>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter18'
//  '<S183>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter2'
//  '<S184>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter3'
//  '<S185>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter4'
//  '<S186>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter5'
//  '<S187>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter6'
//  '<S188>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter7'
//  '<S189>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter8'
//  '<S190>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter9'
//  '<S191>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/Reorder_to_XYZ'
//  '<S192>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/formPoseMat'
//  '<S193>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/positiveQuat'
//  '<S194>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/quat2MRP'
//  '<S195>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S196>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter10/EVAL_KEY'
//  '<S197>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter11/EVAL_KEY'
//  '<S198>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter12/EVAL_KEY'
//  '<S199>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S200>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S201>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter15/EVAL_KEY'
//  '<S202>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter16/EVAL_KEY'
//  '<S203>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter17/EVAL_KEY'
//  '<S204>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter18/EVAL_KEY'
//  '<S205>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter2/EVAL_KEY'
//  '<S206>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter3/EVAL_KEY'
//  '<S207>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter4/EVAL_KEY'
//  '<S208>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter5/EVAL_KEY'
//  '<S209>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter6/EVAL_KEY'
//  '<S210>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter7/EVAL_KEY'
//  '<S211>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter8/EVAL_KEY'
//  '<S212>' : 'SatelliteServicing_Mission/RoboticArm/RoboticArmPlanar3Link/State_Output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S213>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control'
//  '<S214>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance'
//  '<S215>' : 'SatelliteServicing_Mission/ServicingSatGNC/Navigation'
//  '<S216>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl'
//  '<S217>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors'
//  '<S218>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/RotationalControl'
//  '<S219>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/Subsystem'
//  '<S220>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/TranslationalControl'
//  '<S221>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ArmControl/RLBasedArmControl'
//  '<S222>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError'
//  '<S223>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputePositionError'
//  '<S224>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeRateError'
//  '<S225>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeVelocityError'
//  '<S226>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/quatConj1'
//  '<S227>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError/ModifiedRodrigues'
//  '<S228>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError/errorQuat'
//  '<S229>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError/positiveQuat'
//  '<S230>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError/quat2Euler'
//  '<S231>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError/unwrap'
//  '<S232>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError/ModifiedRodrigues/errorMRP'
//  '<S233>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError/ModifiedRodrigues/quat2MRP'
//  '<S234>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeAttitudeError/ModifiedRodrigues/quat2MRP1'
//  '<S235>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeRateError/formRotation'
//  '<S236>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeRateError/positiveQuat'
//  '<S237>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/ComputeErrors/ComputeVelocityError/cross'
//  '<S238>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/RotationalControl/PIDControl'
//  '<S239>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/Subsystem/Check_Angle_Limits'
//  '<S240>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/Subsystem/Check_Rate_Limits'
//  '<S241>' : 'SatelliteServicing_Mission/ServicingSatGNC/Control/TranslationalControl/PIDControl'
//  '<S242>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative'
//  '<S243>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/FormQuatCmd'
//  '<S244>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/ConvertToWorldFrame'
//  '<S245>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/Cross Product'
//  '<S246>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/quatConj'
//  '<S247>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/quatConj1'
//  '<S248>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/quatMult'
//  '<S249>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/quatToEuler_321'
//  '<S250>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/Convert_to_WorldRelative/ConvertToWorldFrame/quatRotate'
//  '<S251>' : 'SatelliteServicing_Mission/ServicingSatGNC/Guidance/FormQuatCmd/MATLAB Function'
//  '<S252>' : 'SatelliteServicing_Mission/ServicingSatellite/Camera'
//  '<S253>' : 'SatelliteServicing_Mission/ServicingSatellite/Sat1Solid'
//  '<S254>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel1'
//  '<S255>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel2'
//  '<S256>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter'
//  '<S257>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1'
//  '<S258>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2'
//  '<S259>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3'
//  '<S260>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1'
//  '<S261>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter/EVAL_KEY'
//  '<S262>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1/EVAL_KEY'
//  '<S263>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2/EVAL_KEY'
//  '<S264>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3/EVAL_KEY'
//  '<S265>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter1'
//  '<S266>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter10'
//  '<S267>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter11'
//  '<S268>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter12'
//  '<S269>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter13'
//  '<S270>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter14'
//  '<S271>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter15'
//  '<S272>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter16'
//  '<S273>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter17'
//  '<S274>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter18'
//  '<S275>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter2'
//  '<S276>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter3'
//  '<S277>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter4'
//  '<S278>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter5'
//  '<S279>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter6'
//  '<S280>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter7'
//  '<S281>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter8'
//  '<S282>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter9'
//  '<S283>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/Reorder_to_XYZ'
//  '<S284>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/formPoseMat'
//  '<S285>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/positiveQuat'
//  '<S286>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/quat2MRP'
//  '<S287>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S288>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S289>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S290>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S291>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S292>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S293>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S294>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S295>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S296>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S297>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S298>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S299>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S300>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S301>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S302>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S303>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S304>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S305>' : 'SatelliteServicing_Mission/Solver Configuration/EVAL_KEY'
//  '<S306>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter1'
//  '<S307>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter10'
//  '<S308>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter11'
//  '<S309>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter12'
//  '<S310>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter13'
//  '<S311>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter14'
//  '<S312>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter15'
//  '<S313>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter16'
//  '<S314>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter17'
//  '<S315>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter18'
//  '<S316>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter2'
//  '<S317>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter3'
//  '<S318>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter4'
//  '<S319>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter5'
//  '<S320>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter6'
//  '<S321>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter7'
//  '<S322>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter8'
//  '<S323>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter9'
//  '<S324>' : 'SatelliteServicing_Mission/State_Output_RelBase/Reorder_to_XYZ'
//  '<S325>' : 'SatelliteServicing_Mission/State_Output_RelBase/formPoseMat'
//  '<S326>' : 'SatelliteServicing_Mission/State_Output_RelBase/positiveQuat'
//  '<S327>' : 'SatelliteServicing_Mission/State_Output_RelBase/quat2MRP'
//  '<S328>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter1/EVAL_KEY'
//  '<S329>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter10/EVAL_KEY'
//  '<S330>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter11/EVAL_KEY'
//  '<S331>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter12/EVAL_KEY'
//  '<S332>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter13/EVAL_KEY'
//  '<S333>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter14/EVAL_KEY'
//  '<S334>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter15/EVAL_KEY'
//  '<S335>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter16/EVAL_KEY'
//  '<S336>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter17/EVAL_KEY'
//  '<S337>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter18/EVAL_KEY'
//  '<S338>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter2/EVAL_KEY'
//  '<S339>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter3/EVAL_KEY'
//  '<S340>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter4/EVAL_KEY'
//  '<S341>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter5/EVAL_KEY'
//  '<S342>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter6/EVAL_KEY'
//  '<S343>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter7/EVAL_KEY'
//  '<S344>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter8/EVAL_KEY'
//  '<S345>' : 'SatelliteServicing_Mission/State_Output_RelBase/PS-Simulink Converter9/EVAL_KEY'

#endif                              // RTW_HEADER_SatelliteServicing_Mission_h_

//
// File trailer for generated code.
//
// [EOF]
//
