//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.126
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Thu Aug 29 11:41:51 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_SatelliteServicing_Mission_h_
#define RTW_HEADER_SatelliteServicing_Mission_h_
#include <stdlib.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "nesl_rtw.h"
#include "SatelliteServicing_Mission_acc66beb_1_gateway.h"
#include "nesl_rtw_rtp.h"
#include "SatelliteServicing_Mission_e7143f6a_1_gateway.h"
#include "SatelliteServicing_Mission_587682d_1_gateway.h"
#include "SatelliteServicing_Mission_2eaac34_1_gateway.h"
#include "SatelliteServicing_Mission_ea4b6336_1_gateway.h"
#include "SatelliteServicing_Mission_types.h"

extern "C"
{

#include "rt_nonfinite.h"

}

#include "rtGetNaN.h"
#include <cstring>

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

// Block signals (default storage)
struct B_SatelliteServicing_Mission_T {
  real_T STATE_1[13];                  // '<S300>/STATE_1'
  real_T Product5[3];                  // '<S255>/Product5'
  real_T controlErrorECEF[6];          // '<S255>/Sum1'
  real_T INPUT_1_1_1[4];               // '<S300>/INPUT_1_1_1'
  real_T INPUT_2_1_1[4];               // '<S300>/INPUT_2_1_1'
  real_T INPUT_3_1_1[4];               // '<S300>/INPUT_3_1_1'
  real_T Product5_b[3];                // '<S254>/Product5'
  real_T controlErrorECEF_l[6];        // '<S254>/Sum1'
  real_T INPUT_4_1_1[4];               // '<S300>/INPUT_4_1_1'
  real_T INPUT_4_1_2[4];               // '<S300>/INPUT_4_1_2'
  real_T INPUT_4_1_3[4];               // '<S300>/INPUT_4_1_3'
  real_T RTP_1;                        // '<S125>/RTP_1'
  real_T STATE_1_o[13];                // '<S148>/STATE_1'
  real_T RTP_1_l;                      // '<S155>/RTP_1'
  real_T STATE_1_n[13];                // '<S178>/STATE_1'
  real_T RTP_1_b;                      // '<S185>/RTP_1'
  real_T STATE_1_b[13];                // '<S208>/STATE_1'
  real_T RTP_1_i;                      // '<S215>/RTP_1'
  real_T STATE_1_l[13];                // '<S238>/STATE_1'
  real_T Delay[32];                    // '<S114>/Delay'
  real_T Delay1[32];                   // '<S114>/Delay1'
  real_T INPUT_1_1_1_d[4];             // '<S238>/INPUT_1_1_1'
  real_T INPUT_2_1_1_k[4];             // '<S238>/INPUT_2_1_1'
  real_T INPUT_3_1_1_c[4];             // '<S238>/INPUT_3_1_1'
  real_T INPUT_1_1_1_p[4];             // '<S208>/INPUT_1_1_1'
  real_T INPUT_2_1_1_h[4];             // '<S208>/INPUT_2_1_1'
  real_T INPUT_3_1_1_n[4];             // '<S208>/INPUT_3_1_1'
  real_T INPUT_1_1_1_n[4];             // '<S178>/INPUT_1_1_1'
  real_T INPUT_2_1_1_c[4];             // '<S178>/INPUT_2_1_1'
  real_T INPUT_3_1_1_b[4];             // '<S178>/INPUT_3_1_1'
  real_T INPUT_1_1_1_h[4];             // '<S148>/INPUT_1_1_1'
  real_T INPUT_2_1_1_km[4];            // '<S148>/INPUT_2_1_1'
  real_T INPUT_3_1_1_m[4];             // '<S148>/INPUT_3_1_1'
  real_T coverage_out[32];             // '<S114>/computeCoverage'
  real_T credit_out[32];               // '<S114>/computeCoverage'
};

// Block states (default storage) for system '<Root>'
struct DW_SatelliteServicing_Mission_T {
  real_T DiscreteTimeIntegrator1_DSTATE[3];// '<S255>/Discrete-Time Integrator1' 
  real_T INPUT_1_1_1_Discrete[2];      // '<S300>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete[2];      // '<S300>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete[2];      // '<S300>/INPUT_3_1_1'
  real_T DiscreteTimeIntegrator1_DSTAT_m[3];// '<S254>/Discrete-Time Integrator1' 
  real_T INPUT_4_1_1_Discrete[2];      // '<S300>/INPUT_4_1_1'
  real_T INPUT_4_1_2_Discrete[2];      // '<S300>/INPUT_4_1_2'
  real_T INPUT_4_1_3_Discrete[2];      // '<S300>/INPUT_4_1_3'
  real_T Delay_DSTATE[32];             // '<S114>/Delay'
  real_T Delay1_DSTATE[32];            // '<S114>/Delay1'
  real_T INPUT_1_1_1_Discrete_m[2];    // '<S238>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete_h[2];    // '<S238>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete_d[2];    // '<S238>/INPUT_3_1_1'
  real_T INPUT_1_1_1_Discrete_d[2];    // '<S208>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete_g[2];    // '<S208>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete_p[2];    // '<S208>/INPUT_3_1_1'
  real_T INPUT_1_1_1_Discrete_c[2];    // '<S178>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete_gr[2];   // '<S178>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete_h[2];    // '<S178>/INPUT_3_1_1'
  real_T INPUT_1_1_1_Discrete_cx[2];   // '<S148>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete_e[2];    // '<S148>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete_k[2];    // '<S148>/INPUT_3_1_1'
  real_T STATE_1_Discrete;             // '<S300>/STATE_1'
  real_T OUTPUT_1_0_Discrete;          // '<S300>/OUTPUT_1_0'
  real_T OUTPUT_1_1_Discrete;          // '<S300>/OUTPUT_1_1'
  real_T STATE_1_Discrete_k;           // '<S148>/STATE_1'
  real_T OUTPUT_1_0_Discrete_c;        // '<S148>/OUTPUT_1_0'
  real_T STATE_1_Discrete_l;           // '<S178>/STATE_1'
  real_T OUTPUT_1_0_Discrete_cj;       // '<S178>/OUTPUT_1_0'
  real_T STATE_1_Discrete_k5;          // '<S208>/STATE_1'
  real_T OUTPUT_1_0_Discrete_h;        // '<S208>/OUTPUT_1_0'
  real_T STATE_1_Discrete_h;           // '<S238>/STATE_1'
  real_T OUTPUT_1_0_Discrete_f;        // '<S238>/OUTPUT_1_0'
  real_T OUTPUT_1_1_Discrete_p;        // '<S148>/OUTPUT_1_1'
  real_T OUTPUT_1_1_Discrete_o;        // '<S178>/OUTPUT_1_1'
  real_T OUTPUT_1_1_Discrete_g;        // '<S208>/OUTPUT_1_1'
  real_T OUTPUT_1_1_Discrete_h;        // '<S238>/OUTPUT_1_1'
  void* STATE_1_Simulator;             // '<S300>/STATE_1'
  void* STATE_1_SimData;               // '<S300>/STATE_1'
  void* STATE_1_DiagMgr;               // '<S300>/STATE_1'
  void* STATE_1_ZcLogger;              // '<S300>/STATE_1'
  void* STATE_1_TsInfo;                // '<S300>/STATE_1'
  void* OUTPUT_1_0_Simulator;          // '<S300>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData;            // '<S300>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr;            // '<S300>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger;           // '<S300>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo;             // '<S300>/OUTPUT_1_0'
  void* OUTPUT_1_1_Simulator;          // '<S300>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData;            // '<S300>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr;            // '<S300>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger;           // '<S300>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo;             // '<S300>/OUTPUT_1_1'
  void* SINK_1_RtwLogger;              // '<S300>/SINK_1'
  void* SINK_1_RtwLogBuffer;           // '<S300>/SINK_1'
  void* SINK_1_RtwLogFcnManager;       // '<S300>/SINK_1'
  void* RTP_1_RtpManager;              // '<S125>/RTP_1'
  void* STATE_1_Simulator_i;           // '<S148>/STATE_1'
  void* STATE_1_SimData_g;             // '<S148>/STATE_1'
  void* STATE_1_DiagMgr_a;             // '<S148>/STATE_1'
  void* STATE_1_ZcLogger_o;            // '<S148>/STATE_1'
  void* STATE_1_TsInfo_d;              // '<S148>/STATE_1'
  void* OUTPUT_1_0_Simulator_j;        // '<S148>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData_b;          // '<S148>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr_g;          // '<S148>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger_g;         // '<S148>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo_p;           // '<S148>/OUTPUT_1_0'
  void* RTP_1_RtpManager_k;            // '<S155>/RTP_1'
  void* STATE_1_Simulator_n;           // '<S178>/STATE_1'
  void* STATE_1_SimData_f;             // '<S178>/STATE_1'
  void* STATE_1_DiagMgr_p;             // '<S178>/STATE_1'
  void* STATE_1_ZcLogger_ob;           // '<S178>/STATE_1'
  void* STATE_1_TsInfo_f;              // '<S178>/STATE_1'
  void* OUTPUT_1_0_Simulator_g;        // '<S178>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData_n;          // '<S178>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr_m;          // '<S178>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger_f;         // '<S178>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo_i;           // '<S178>/OUTPUT_1_0'
  void* RTP_1_RtpManager_a;            // '<S185>/RTP_1'
  void* STATE_1_Simulator_l;           // '<S208>/STATE_1'
  void* STATE_1_SimData_k;             // '<S208>/STATE_1'
  void* STATE_1_DiagMgr_pq;            // '<S208>/STATE_1'
  void* STATE_1_ZcLogger_p;            // '<S208>/STATE_1'
  void* STATE_1_TsInfo_da;             // '<S208>/STATE_1'
  void* OUTPUT_1_0_Simulator_jb;       // '<S208>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData_g;          // '<S208>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr_a;          // '<S208>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger_k;         // '<S208>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo_b;           // '<S208>/OUTPUT_1_0'
  void* RTP_1_RtpManager_n;            // '<S215>/RTP_1'
  void* STATE_1_Simulator_j;           // '<S238>/STATE_1'
  void* STATE_1_SimData_m;             // '<S238>/STATE_1'
  void* STATE_1_DiagMgr_i;             // '<S238>/STATE_1'
  void* STATE_1_ZcLogger_n;            // '<S238>/STATE_1'
  void* STATE_1_TsInfo_h;              // '<S238>/STATE_1'
  void* OUTPUT_1_0_Simulator_a;        // '<S238>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData_o;          // '<S238>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr_i;          // '<S238>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger_d;         // '<S238>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo_m;           // '<S238>/OUTPUT_1_0'
  void* SINK_1_RtwLogger_g;            // '<S238>/SINK_1'
  void* SINK_1_RtwLogBuffer_c;         // '<S238>/SINK_1'
  void* SINK_1_RtwLogFcnManager_f;     // '<S238>/SINK_1'
  void* SINK_1_RtwLogger_d;            // '<S208>/SINK_1'
  void* SINK_1_RtwLogBuffer_e;         // '<S208>/SINK_1'
  void* SINK_1_RtwLogFcnManager_o;     // '<S208>/SINK_1'
  void* SINK_1_RtwLogger_j;            // '<S178>/SINK_1'
  void* SINK_1_RtwLogBuffer_k;         // '<S178>/SINK_1'
  void* SINK_1_RtwLogFcnManager_d;     // '<S178>/SINK_1'
  void* SINK_1_RtwLogger_m;            // '<S148>/SINK_1'
  void* SINK_1_RtwLogBuffer_k3;        // '<S148>/SINK_1'
  void* SINK_1_RtwLogFcnManager_b;     // '<S148>/SINK_1'
  void* OUTPUT_1_1_Simulator_j;        // '<S148>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData_f;          // '<S148>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr_e;          // '<S148>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger_i;         // '<S148>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo_g;           // '<S148>/OUTPUT_1_1'
  void* OUTPUT_1_1_Simulator_n;        // '<S178>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData_e;          // '<S178>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr_f;          // '<S178>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger_d;         // '<S178>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo_d;           // '<S178>/OUTPUT_1_1'
  void* OUTPUT_1_1_Simulator_jb;       // '<S208>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData_l;          // '<S208>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr_h;          // '<S208>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger_e;         // '<S208>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo_o;           // '<S208>/OUTPUT_1_1'
  void* OUTPUT_1_1_Simulator_d;        // '<S238>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData_o;          // '<S238>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr_a;          // '<S238>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger_g;         // '<S238>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo_l;           // '<S238>/OUTPUT_1_1'
  int_T STATE_1_Modes;                 // '<S300>/STATE_1'
  int_T OUTPUT_1_0_Modes;              // '<S300>/OUTPUT_1_0'
  int_T OUTPUT_1_1_Modes;              // '<S300>/OUTPUT_1_1'
  int_T STATE_1_Modes_l;               // '<S148>/STATE_1'
  int_T OUTPUT_1_0_Modes_j;            // '<S148>/OUTPUT_1_0'
  int_T STATE_1_Modes_l0;              // '<S178>/STATE_1'
  int_T OUTPUT_1_0_Modes_m;            // '<S178>/OUTPUT_1_0'
  int_T STATE_1_Modes_j;               // '<S208>/STATE_1'
  int_T OUTPUT_1_0_Modes_n;            // '<S208>/OUTPUT_1_0'
  int_T STATE_1_Modes_h;               // '<S238>/STATE_1'
  int_T OUTPUT_1_0_Modes_p;            // '<S238>/OUTPUT_1_0'
  int_T OUTPUT_1_1_Modes_p;            // '<S148>/OUTPUT_1_1'
  int_T OUTPUT_1_1_Modes_i;            // '<S178>/OUTPUT_1_1'
  int_T OUTPUT_1_1_Modes_pb;           // '<S208>/OUTPUT_1_1'
  int_T OUTPUT_1_1_Modes_o;            // '<S238>/OUTPUT_1_1'
  boolean_T STATE_1_FirstOutput;       // '<S300>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput;    // '<S300>/OUTPUT_1_0'
  boolean_T OUTPUT_1_1_FirstOutput;    // '<S300>/OUTPUT_1_1'
  boolean_T RTP_1_SetParametersNeeded; // '<S125>/RTP_1'
  boolean_T STATE_1_FirstOutput_n;     // '<S148>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput_d;  // '<S148>/OUTPUT_1_0'
  boolean_T RTP_1_SetParametersNeeded_k;// '<S155>/RTP_1'
  boolean_T STATE_1_FirstOutput_g;     // '<S178>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput_g;  // '<S178>/OUTPUT_1_0'
  boolean_T RTP_1_SetParametersNeeded_a;// '<S185>/RTP_1'
  boolean_T STATE_1_FirstOutput_f;     // '<S208>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput_p;  // '<S208>/OUTPUT_1_0'
  boolean_T RTP_1_SetParametersNeeded_l;// '<S215>/RTP_1'
  boolean_T STATE_1_FirstOutput_fd;    // '<S238>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput_e;  // '<S238>/OUTPUT_1_0'
  boolean_T icLoad;                    // '<S114>/Delay'
  boolean_T icLoad_d;                  // '<S114>/Delay1'
  boolean_T OUTPUT_1_1_FirstOutput_o;  // '<S148>/OUTPUT_1_1'
  boolean_T OUTPUT_1_1_FirstOutput_n;  // '<S178>/OUTPUT_1_1'
  boolean_T OUTPUT_1_1_FirstOutput_k;  // '<S208>/OUTPUT_1_1'
  boolean_T OUTPUT_1_1_FirstOutput_h;  // '<S238>/OUTPUT_1_1'
};

// Continuous states (default storage)
struct X_SatelliteServicing_Mission_T {
  real_T SatelliteServicing_MissionServi[13];// '<S300>/STATE_1'
  real_T SatelliteServicing_MissionMissi[13];// '<S148>/STATE_1'
  real_T SatelliteServicing_MissionMis_m[13];// '<S178>/STATE_1'
  real_T SatelliteServicing_MissionMis_k[13];// '<S208>/STATE_1'
  real_T SatelliteServicing_MissionMis_n[13];// '<S238>/STATE_1'
};

// State derivatives (default storage)
struct XDot_SatelliteServicing_Missi_T {
  real_T SatelliteServicing_MissionServi[13];// '<S300>/STATE_1'
  real_T SatelliteServicing_MissionMissi[13];// '<S148>/STATE_1'
  real_T SatelliteServicing_MissionMis_m[13];// '<S178>/STATE_1'
  real_T SatelliteServicing_MissionMis_k[13];// '<S208>/STATE_1'
  real_T SatelliteServicing_MissionMis_n[13];// '<S238>/STATE_1'
};

// State disabled
struct XDis_SatelliteServicing_Missi_T {
  boolean_T SatelliteServicing_MissionServi[13];// '<S300>/STATE_1'
  boolean_T SatelliteServicing_MissionMissi[13];// '<S148>/STATE_1'
  boolean_T SatelliteServicing_MissionMis_m[13];// '<S178>/STATE_1'
  boolean_T SatelliteServicing_MissionMis_k[13];// '<S208>/STATE_1'
  boolean_T SatelliteServicing_MissionMis_n[13];// '<S238>/STATE_1'
};

#ifndef ODE3_INTG
#define ODE3_INTG

// ODE3 Integration Data
struct ODE3_IntgData {
  real_T *y;                           // output
  real_T *f[3];                        // derivatives
};

#endif

// External inputs (root inport signals with default storage)
struct ExtU_SatelliteServicing_Missi_T {
  real_T ManipulatorActions[3];        // '<Root>/ManipulatorActions'
};

// External outputs (root outports fed by signals with default storage)
struct ExtY_SatelliteServicing_Missi_T {
  real_T Observations[36];             // '<Root>/Observations'
  real_T ControlError[32];             // '<Root>/ControlError'
};

// Parameters (default storage)
struct P_SatelliteServicing_Mission_T_ {
  satControlDataBus_Rot satControlData_Rot;// Variable: satControlData_Rot
                                              //  Referenced by:
                                              //    '<S249>/Constant2'
                                              //    '<S250>/Constant2'
                                              //    '<S252>/Saturation1'

  satControlDataBus_Trans satControlData_Trans;// Variable: satControlData_Trans
                                                  //  Referenced by:
                                                  //    '<S249>/Constant1'
                                                  //    '<S250>/Constant1'
                                                  //    '<S253>/Saturation1'

  struct_Yf8rt61VEQC0Uc7ZmBWdrE cubesat[4];// Variable: cubesat
                                              //  Referenced by:
                                              //    '<S119>/Constant1'
                                              //    '<S149>/Constant1'
                                              //    '<S179>/Constant1'
                                              //    '<S209>/Constant1'
                                              //    '<S119>/Subsystem_around_RTP_5F0325A4_PxPositionTargetValue'
                                              //    '<S119>/Subsystem_around_RTP_5F0325A4_PxVelocityTargetValue'
                                              //    '<S119>/Subsystem_around_RTP_5F0325A4_PyPositionTargetValue'
                                              //    '<S119>/Subsystem_around_RTP_5F0325A4_PyVelocityTargetValue'
                                              //    '<S119>/Subsystem_around_RTP_5F0325A4_PzPositionTargetValue'
                                              //    '<S119>/Subsystem_around_RTP_5F0325A4_PzVelocityTargetValue'
                                              //    '<S149>/Subsystem_around_RTP_517418D9_PxPositionTargetValue'
                                              //    '<S149>/Subsystem_around_RTP_517418D9_PxVelocityTargetValue'
                                              //    '<S149>/Subsystem_around_RTP_517418D9_PyPositionTargetValue'
                                              //    '<S149>/Subsystem_around_RTP_517418D9_PyVelocityTargetValue'
                                              //    '<S149>/Subsystem_around_RTP_517418D9_PzPositionTargetValue'
                                              //    '<S149>/Subsystem_around_RTP_517418D9_PzVelocityTargetValue'
                                              //    '<S179>/Subsystem_around_RTP_6835F894_PxPositionTargetValue'
                                              //    '<S179>/Subsystem_around_RTP_6835F894_PxVelocityTargetValue'
                                              //    '<S179>/Subsystem_around_RTP_6835F894_PyPositionTargetValue'
                                              //    '<S179>/Subsystem_around_RTP_6835F894_PyVelocityTargetValue'
                                              //    '<S179>/Subsystem_around_RTP_6835F894_PzPositionTargetValue'
                                              //    '<S179>/Subsystem_around_RTP_6835F894_PzVelocityTargetValue'
                                              //    '<S209>/Subsystem_around_RTP_84B5FE6B_PxPositionTargetValue'
                                              //    '<S209>/Subsystem_around_RTP_84B5FE6B_PxVelocityTargetValue'
                                              //    '<S209>/Subsystem_around_RTP_84B5FE6B_PyPositionTargetValue'
                                              //    '<S209>/Subsystem_around_RTP_84B5FE6B_PyVelocityTargetValue'
                                              //    '<S209>/Subsystem_around_RTP_84B5FE6B_PzPositionTargetValue'
                                              //    '<S209>/Subsystem_around_RTP_84B5FE6B_PzVelocityTargetValue'

  struct_b9EoG14LaCnLOpiLP034lD orbit; // Variable: orbit
                                          //  Referenced by: '<S113>/Constant1'

  real_T nsat;                         // Variable: nsat
                                          //  Referenced by: '<S114>/Constant1'

  real_T DiscreteTimeIntegrator1_gainval;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainval
                             //  Referenced by: '<S255>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC;   // Expression: 0
                                          //  Referenced by: '<S255>/Discrete-Time Integrator1'

  real_T Gain1_Gain;                   // Expression: -1
                                          //  Referenced by: '<S255>/Gain1'

  real_T DiscreteTimeIntegrator1_gainv_b;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainv_b
                             //  Referenced by: '<S254>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC_f; // Expression: 0
                                          //  Referenced by: '<S254>/Discrete-Time Integrator1'

  real_T Gain1_Gain_m;                 // Expression: -1
                                          //  Referenced by: '<S254>/Gain1'

  real_T Constant3_Value[96];          // Expression: client.faceCenter
                                          //  Referenced by: '<S114>/Constant3'

  real_T Constant2_Value[4];           // Expression: client.inspectionFOV
                                          //  Referenced by: '<S114>/Constant2'

  real_T Constant6_Value;           // Expression: client.inspectionSphereRadius
                                       //  Referenced by: '<S114>/Constant6'

  real_T Constant5_Value[32];          // Expression: client.faceRadius
                                          //  Referenced by: '<S114>/Constant5'

  real_T Constant4_Value[32];          // Expression: zeros(client.nFaces,1)
                                          //  Referenced by: '<S114>/Constant4'

  real_T Constant_Value[3];            // Expression: [0,0,0]
                                          //  Referenced by: '<S113>/Constant'

};

// Real-time Model Data Structure
struct tag_RTM_SatelliteServicing_Mi_T {
  const char_T *errorStatus;
  RTWSolverInfo *solverInfo;
  B_SatelliteServicing_Mission_T *blockIO;
  X_SatelliteServicing_Mission_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_SatelliteServicing_Missi_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[65];
  real_T odeF[3][65];
  ODE3_IntgData intgData;
  DW_SatelliteServicing_Mission_T *dwork;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

// Block parameters (default storage)
#ifdef __cplusplus

extern "C"
{

#endif

  extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;

#ifdef __cplusplus

}

#endif

// External data declarations for dependent source files
#ifdef __cplusplus

extern "C"
{

#endif

  extern const char_T *RT_MEMORY_ALLOCATION_ERROR;

#ifdef __cplusplus

}

#endif

extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;// parameters 

#ifdef __cplusplus

extern "C"
{

#endif

  // Model entry point functions
  extern RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission
    (ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
     ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_initialize
    (RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M);
  extern void SatelliteServicing_Mission_step(RT_MODEL_SatelliteServicing_M_T *
    const SatelliteServicing_Mission_M, ExtY_SatelliteServicing_Missi_T
    *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_terminate
    (RT_MODEL_SatelliteServicing_M_T * SatelliteServicing_Mission_M);

#ifdef __cplusplus

}

#endif

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S100>/RESHAPE' : Unused code path elimination
//  Block '<S102>/RESHAPE' : Unused code path elimination
//  Block '<S104>/RESHAPE' : Unused code path elimination
//  Block '<S105>/RESHAPE' : Unused code path elimination
//  Block '<S106>/RESHAPE' : Unused code path elimination
//  Block '<S107>/RESHAPE' : Unused code path elimination
//  Block '<S109>/RESHAPE' : Unused code path elimination
//  Block '<S110>/RESHAPE' : Unused code path elimination
//  Block '<S2>/Reshape' : Unused code path elimination
//  Block '<S2>/Reshape1' : Unused code path elimination
//  Block '<S38>/RESHAPE' : Reshape block reduction
//  Block '<S78>/RESHAPE' : Reshape block reduction
//  Block '<S290>/RESHAPE' : Reshape block reduction


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'SatelliteServicing_Mission'
//  '<S1>'   : 'SatelliteServicing_Mission/ClientSatellite'
//  '<S2>'   : 'SatelliteServicing_Mission/MassPropSensor2'
//  '<S3>'   : 'SatelliteServicing_Mission/Mission'
//  '<S4>'   : 'SatelliteServicing_Mission/ServicingSatellite'
//  '<S5>'   : 'SatelliteServicing_Mission/Solver Configuration'
//  '<S6>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1'
//  '<S7>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output2'
//  '<S8>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter1'
//  '<S9>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter10'
//  '<S10>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter11'
//  '<S11>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter12'
//  '<S12>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter13'
//  '<S13>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter14'
//  '<S14>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter15'
//  '<S15>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter16'
//  '<S16>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter17'
//  '<S17>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter18'
//  '<S18>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter2'
//  '<S19>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter3'
//  '<S20>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter4'
//  '<S21>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter5'
//  '<S22>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter6'
//  '<S23>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter7'
//  '<S24>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter8'
//  '<S25>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter9'
//  '<S26>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/Reorder_to_XYZ'
//  '<S27>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/formPoseMat'
//  '<S28>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/positiveQuat'
//  '<S29>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/quat2MRP'
//  '<S30>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S31>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S32>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S33>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S34>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S35>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S36>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S37>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S38>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S39>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S40>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S41>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S42>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S43>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S44>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S45>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S46>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S47>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S48>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1'
//  '<S49>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10'
//  '<S50>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11'
//  '<S51>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12'
//  '<S52>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13'
//  '<S53>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14'
//  '<S54>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15'
//  '<S55>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16'
//  '<S56>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter17'
//  '<S57>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter18'
//  '<S58>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2'
//  '<S59>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3'
//  '<S60>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4'
//  '<S61>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5'
//  '<S62>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6'
//  '<S63>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7'
//  '<S64>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8'
//  '<S65>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9'
//  '<S66>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/Reorder_to_XYZ'
//  '<S67>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/formPoseMat'
//  '<S68>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/positiveQuat'
//  '<S69>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/quat2MRP'
//  '<S70>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S71>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10/EVAL_KEY'
//  '<S72>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11/EVAL_KEY'
//  '<S73>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12/EVAL_KEY'
//  '<S74>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S75>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S76>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15/EVAL_KEY'
//  '<S77>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16/EVAL_KEY'
//  '<S78>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter17/EVAL_KEY'
//  '<S79>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter18/EVAL_KEY'
//  '<S80>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2/EVAL_KEY'
//  '<S81>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3/EVAL_KEY'
//  '<S82>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4/EVAL_KEY'
//  '<S83>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5/EVAL_KEY'
//  '<S84>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6/EVAL_KEY'
//  '<S85>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7/EVAL_KEY'
//  '<S86>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8/EVAL_KEY'
//  '<S87>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S88>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter1'
//  '<S89>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter10'
//  '<S90>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter13'
//  '<S91>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter14'
//  '<S92>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter2'
//  '<S93>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter3'
//  '<S94>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter4'
//  '<S95>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter5'
//  '<S96>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter6'
//  '<S97>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter7'
//  '<S98>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter8'
//  '<S99>'  : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter9'
//  '<S100>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter1/EVAL_KEY'
//  '<S101>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter10/EVAL_KEY'
//  '<S102>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter13/EVAL_KEY'
//  '<S103>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter14/EVAL_KEY'
//  '<S104>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter2/EVAL_KEY'
//  '<S105>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter3/EVAL_KEY'
//  '<S106>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter4/EVAL_KEY'
//  '<S107>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter5/EVAL_KEY'
//  '<S108>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter6/EVAL_KEY'
//  '<S109>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter7/EVAL_KEY'
//  '<S110>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter8/EVAL_KEY'
//  '<S111>' : 'SatelliteServicing_Mission/MassPropSensor2/PS-Simulink Converter9/EVAL_KEY'
//  '<S112>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection'
//  '<S113>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats'
//  '<S114>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/InspectionCoverage'
//  '<S115>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1'
//  '<S116>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2'
//  '<S117>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3'
//  '<S118>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4'
//  '<S119>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation'
//  '<S120>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Cubesat_Acceleration'
//  '<S121>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor'
//  '<S122>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter1'
//  '<S123>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter2'
//  '<S124>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter3'
//  '<S125>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration'
//  '<S126>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Cubesat_Acceleration/CW_Equations'
//  '<S127>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter1'
//  '<S128>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter11'
//  '<S129>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter12'
//  '<S130>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter15'
//  '<S131>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter2'
//  '<S132>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter3'
//  '<S133>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter4'
//  '<S134>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter5'
//  '<S135>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter6'
//  '<S136>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S137>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S138>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S139>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S140>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S141>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S142>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S143>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S144>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S145>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S146>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S147>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S148>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration/EVAL_KEY'
//  '<S149>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation'
//  '<S150>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Cubesat_Acceleration'
//  '<S151>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor'
//  '<S152>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter1'
//  '<S153>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter2'
//  '<S154>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter3'
//  '<S155>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration'
//  '<S156>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Cubesat_Acceleration/CW_Equations'
//  '<S157>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter1'
//  '<S158>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter11'
//  '<S159>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter12'
//  '<S160>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter15'
//  '<S161>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter2'
//  '<S162>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter3'
//  '<S163>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter4'
//  '<S164>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter5'
//  '<S165>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter6'
//  '<S166>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S167>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S168>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S169>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S170>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S171>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S172>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S173>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S174>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S175>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S176>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S177>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S178>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration/EVAL_KEY'
//  '<S179>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation'
//  '<S180>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Cubesat_Acceleration'
//  '<S181>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor'
//  '<S182>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter1'
//  '<S183>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter2'
//  '<S184>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter3'
//  '<S185>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration'
//  '<S186>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Cubesat_Acceleration/CW_Equations'
//  '<S187>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter1'
//  '<S188>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter11'
//  '<S189>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter12'
//  '<S190>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter15'
//  '<S191>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter2'
//  '<S192>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter3'
//  '<S193>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter4'
//  '<S194>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter5'
//  '<S195>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter6'
//  '<S196>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S197>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S198>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S199>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S200>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S201>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S202>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S203>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S204>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S205>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S206>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S207>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S208>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration/EVAL_KEY'
//  '<S209>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation'
//  '<S210>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Cubesat_Acceleration'
//  '<S211>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor'
//  '<S212>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter1'
//  '<S213>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter2'
//  '<S214>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter3'
//  '<S215>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration'
//  '<S216>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Cubesat_Acceleration/CW_Equations'
//  '<S217>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter1'
//  '<S218>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter11'
//  '<S219>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter12'
//  '<S220>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter15'
//  '<S221>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter2'
//  '<S222>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter3'
//  '<S223>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter4'
//  '<S224>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter5'
//  '<S225>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter6'
//  '<S226>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S227>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S228>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S229>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S230>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S231>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S232>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S233>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S234>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S235>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S236>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S237>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S238>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration/EVAL_KEY'
//  '<S239>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/InspectionCoverage/computeCoverage'
//  '<S240>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC'
//  '<S241>' : 'SatelliteServicing_Mission/ServicingSatellite/Sat1Solid'
//  '<S242>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel1'
//  '<S243>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel2'
//  '<S244>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter'
//  '<S245>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1'
//  '<S246>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2'
//  '<S247>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3'
//  '<S248>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1'
//  '<S249>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl'
//  '<S250>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefGuidance'
//  '<S251>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefNavigation'
//  '<S252>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/RotationalControl'
//  '<S253>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/TranslationalControl'
//  '<S254>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/RotationalControl/PIDControl'
//  '<S255>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/TranslationalControl/PIDControl'
//  '<S256>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter/EVAL_KEY'
//  '<S257>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1/EVAL_KEY'
//  '<S258>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2/EVAL_KEY'
//  '<S259>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3/EVAL_KEY'
//  '<S260>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter1'
//  '<S261>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter10'
//  '<S262>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter11'
//  '<S263>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter12'
//  '<S264>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter13'
//  '<S265>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter14'
//  '<S266>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter15'
//  '<S267>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter16'
//  '<S268>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter17'
//  '<S269>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter18'
//  '<S270>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter2'
//  '<S271>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter3'
//  '<S272>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter4'
//  '<S273>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter5'
//  '<S274>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter6'
//  '<S275>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter7'
//  '<S276>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter8'
//  '<S277>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter9'
//  '<S278>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/Reorder_to_XYZ'
//  '<S279>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/formPoseMat'
//  '<S280>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/positiveQuat'
//  '<S281>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/quat2MRP'
//  '<S282>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S283>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S284>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S285>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S286>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S287>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S288>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S289>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S290>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S291>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S292>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S293>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S294>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S295>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S296>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S297>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S298>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S299>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S300>' : 'SatelliteServicing_Mission/Solver Configuration/EVAL_KEY'

#endif                              // RTW_HEADER_SatelliteServicing_Mission_h_

//
// File trailer for generated code.
//
// [EOF]
//
