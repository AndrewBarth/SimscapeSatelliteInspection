//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: SatelliteServicing_Mission.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.65
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri May 17 09:12:37 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_SatelliteServicing_Mission_h_
#define RTW_HEADER_SatelliteServicing_Mission_h_
#include <stdlib.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "nesl_rtw_rtp.h"
#include "SatelliteServicing_Mission_e7143f6a_1_gateway.h"
#include "nesl_rtw.h"
#include "SatelliteServicing_Mission_587682d_1_gateway.h"
#include "SatelliteServicing_Mission_2eaac34_1_gateway.h"
#include "SatelliteServicing_Mission_ea4b6336_1_gateway.h"
#include "SatelliteServicing_Mission_acc66beb_1_gateway.h"
#include "SatelliteServicing_Mission_types.h"

extern "C"
{

#include "rt_nonfinite.h"

}

#include "rtGetNaN.h"
#include <cstring>

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

// Block signals (default storage)
struct B_SatelliteServicing_Mission_T {
  real_T RTP_1;                        // '<S100>/RTP_1'
  real_T STATE_1[13];                  // '<S123>/STATE_1'
  real_T RTP_1_l;                      // '<S130>/RTP_1'
  real_T STATE_1_n[13];                // '<S153>/STATE_1'
  real_T RTP_1_b;                      // '<S160>/RTP_1'
  real_T STATE_1_b[13];                // '<S183>/STATE_1'
  real_T RTP_1_i;                      // '<S190>/RTP_1'
  real_T STATE_1_l[13];                // '<S213>/STATE_1'
  real_T Delay[122];                   // '<S89>/Delay'
  real_T Delay1[122];                  // '<S89>/Delay1'
  real_T INPUT_1_1_1[4];               // '<S213>/INPUT_1_1_1'
  real_T INPUT_2_1_1[4];               // '<S213>/INPUT_2_1_1'
  real_T INPUT_3_1_1[4];               // '<S213>/INPUT_3_1_1'
  real_T INPUT_1_1_1_p[4];             // '<S183>/INPUT_1_1_1'
  real_T INPUT_2_1_1_h[4];             // '<S183>/INPUT_2_1_1'
  real_T INPUT_3_1_1_n[4];             // '<S183>/INPUT_3_1_1'
  real_T INPUT_1_1_1_n[4];             // '<S153>/INPUT_1_1_1'
  real_T INPUT_2_1_1_c[4];             // '<S153>/INPUT_2_1_1'
  real_T INPUT_3_1_1_b[4];             // '<S153>/INPUT_3_1_1'
  real_T INPUT_1_1_1_h[4];             // '<S123>/INPUT_1_1_1'
  real_T INPUT_2_1_1_k[4];             // '<S123>/INPUT_2_1_1'
  real_T INPUT_3_1_1_m[4];             // '<S123>/INPUT_3_1_1'
  real_T STATE_1_k[26];                // '<S276>/STATE_1'
  real_T Product5[3];                  // '<S231>/Product5'
  real_T controlErrorECEF[6];          // '<S231>/Sum1'
  real_T INPUT_1_1_1_k[4];             // '<S276>/INPUT_1_1_1'
  real_T INPUT_2_1_1_ha[4];            // '<S276>/INPUT_2_1_1'
  real_T INPUT_3_1_1_nu[4];            // '<S276>/INPUT_3_1_1'
  real_T Product5_b[3];                // '<S230>/Product5'
  real_T controlErrorECEF_l[6];        // '<S230>/Sum1'
  real_T INPUT_4_1_1[4];               // '<S276>/INPUT_4_1_1'
  real_T INPUT_4_1_2[4];               // '<S276>/INPUT_4_1_2'
  real_T INPUT_4_1_3[4];               // '<S276>/INPUT_4_1_3'
  real_T coverage_out[122];            // '<S89>/computeCoverage'
  real_T credit_out[122];              // '<S89>/computeCoverage'
};

// Block states (default storage) for system '<Root>'
struct DW_SatelliteServicing_Mission_T {
  real_T Delay_DSTATE[122];            // '<S89>/Delay'
  real_T Delay1_DSTATE[122];           // '<S89>/Delay1'
  real_T INPUT_1_1_1_Discrete[2];      // '<S213>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete[2];      // '<S213>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete[2];      // '<S213>/INPUT_3_1_1'
  real_T INPUT_1_1_1_Discrete_d[2];    // '<S183>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete_g[2];    // '<S183>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete_p[2];    // '<S183>/INPUT_3_1_1'
  real_T INPUT_1_1_1_Discrete_c[2];    // '<S153>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete_gr[2];   // '<S153>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete_h[2];    // '<S153>/INPUT_3_1_1'
  real_T INPUT_1_1_1_Discrete_cx[2];   // '<S123>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete_e[2];    // '<S123>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete_k[2];    // '<S123>/INPUT_3_1_1'
  real_T DiscreteTimeIntegrator1_DSTATE[3];// '<S231>/Discrete-Time Integrator1' 
  real_T INPUT_1_1_1_Discrete_m[2];    // '<S276>/INPUT_1_1_1'
  real_T INPUT_2_1_1_Discrete_gz[2];   // '<S276>/INPUT_2_1_1'
  real_T INPUT_3_1_1_Discrete_n[2];    // '<S276>/INPUT_3_1_1'
  real_T DiscreteTimeIntegrator1_DSTAT_m[3];// '<S230>/Discrete-Time Integrator1' 
  real_T INPUT_4_1_1_Discrete[2];      // '<S276>/INPUT_4_1_1'
  real_T INPUT_4_1_2_Discrete[2];      // '<S276>/INPUT_4_1_2'
  real_T INPUT_4_1_3_Discrete[2];      // '<S276>/INPUT_4_1_3'
  real_T STATE_1_Discrete;             // '<S123>/STATE_1'
  real_T OUTPUT_1_0_Discrete;          // '<S123>/OUTPUT_1_0'
  real_T STATE_1_Discrete_l;           // '<S153>/STATE_1'
  real_T OUTPUT_1_0_Discrete_c;        // '<S153>/OUTPUT_1_0'
  real_T STATE_1_Discrete_k;           // '<S183>/STATE_1'
  real_T OUTPUT_1_0_Discrete_h;        // '<S183>/OUTPUT_1_0'
  real_T STATE_1_Discrete_h;           // '<S213>/STATE_1'
  real_T OUTPUT_1_0_Discrete_f;        // '<S213>/OUTPUT_1_0'
  real_T OUTPUT_1_1_Discrete;          // '<S123>/OUTPUT_1_1'
  real_T OUTPUT_1_1_Discrete_o;        // '<S153>/OUTPUT_1_1'
  real_T OUTPUT_1_1_Discrete_g;        // '<S183>/OUTPUT_1_1'
  real_T OUTPUT_1_1_Discrete_h;        // '<S213>/OUTPUT_1_1'
  real_T STATE_1_Discrete_j;           // '<S276>/STATE_1'
  real_T OUTPUT_1_0_Discrete_l;        // '<S276>/OUTPUT_1_0'
  real_T OUTPUT_1_1_Discrete_e;        // '<S276>/OUTPUT_1_1'
  void* RTP_1_RtpManager;              // '<S100>/RTP_1'
  void* STATE_1_Simulator;             // '<S123>/STATE_1'
  void* STATE_1_SimData;               // '<S123>/STATE_1'
  void* STATE_1_DiagMgr;               // '<S123>/STATE_1'
  void* STATE_1_ZcLogger;              // '<S123>/STATE_1'
  void* STATE_1_TsInfo;                // '<S123>/STATE_1'
  void* OUTPUT_1_0_Simulator;          // '<S123>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData;            // '<S123>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr;            // '<S123>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger;           // '<S123>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo;             // '<S123>/OUTPUT_1_0'
  void* RTP_1_RtpManager_k;            // '<S130>/RTP_1'
  void* STATE_1_Simulator_n;           // '<S153>/STATE_1'
  void* STATE_1_SimData_f;             // '<S153>/STATE_1'
  void* STATE_1_DiagMgr_p;             // '<S153>/STATE_1'
  void* STATE_1_ZcLogger_o;            // '<S153>/STATE_1'
  void* STATE_1_TsInfo_f;              // '<S153>/STATE_1'
  void* OUTPUT_1_0_Simulator_g;        // '<S153>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData_n;          // '<S153>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr_m;          // '<S153>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger_f;         // '<S153>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo_i;           // '<S153>/OUTPUT_1_0'
  void* RTP_1_RtpManager_a;            // '<S160>/RTP_1'
  void* STATE_1_Simulator_l;           // '<S183>/STATE_1'
  void* STATE_1_SimData_k;             // '<S183>/STATE_1'
  void* STATE_1_DiagMgr_pq;            // '<S183>/STATE_1'
  void* STATE_1_ZcLogger_p;            // '<S183>/STATE_1'
  void* STATE_1_TsInfo_d;              // '<S183>/STATE_1'
  void* OUTPUT_1_0_Simulator_j;        // '<S183>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData_g;          // '<S183>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr_a;          // '<S183>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger_k;         // '<S183>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo_b;           // '<S183>/OUTPUT_1_0'
  void* RTP_1_RtpManager_n;            // '<S190>/RTP_1'
  void* STATE_1_Simulator_j;           // '<S213>/STATE_1'
  void* STATE_1_SimData_m;             // '<S213>/STATE_1'
  void* STATE_1_DiagMgr_i;             // '<S213>/STATE_1'
  void* STATE_1_ZcLogger_n;            // '<S213>/STATE_1'
  void* STATE_1_TsInfo_h;              // '<S213>/STATE_1'
  void* OUTPUT_1_0_Simulator_a;        // '<S213>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData_o;          // '<S213>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr_i;          // '<S213>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger_d;         // '<S213>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo_m;           // '<S213>/OUTPUT_1_0'
  void* SINK_1_RtwLogger;              // '<S213>/SINK_1'
  void* SINK_1_RtwLogBuffer;           // '<S213>/SINK_1'
  void* SINK_1_RtwLogFcnManager;       // '<S213>/SINK_1'
  void* SINK_1_RtwLogger_d;            // '<S183>/SINK_1'
  void* SINK_1_RtwLogBuffer_e;         // '<S183>/SINK_1'
  void* SINK_1_RtwLogFcnManager_o;     // '<S183>/SINK_1'
  void* SINK_1_RtwLogger_j;            // '<S153>/SINK_1'
  void* SINK_1_RtwLogBuffer_k;         // '<S153>/SINK_1'
  void* SINK_1_RtwLogFcnManager_d;     // '<S153>/SINK_1'
  void* SINK_1_RtwLogger_m;            // '<S123>/SINK_1'
  void* SINK_1_RtwLogBuffer_k3;        // '<S123>/SINK_1'
  void* SINK_1_RtwLogFcnManager_b;     // '<S123>/SINK_1'
  void* OUTPUT_1_1_Simulator;          // '<S123>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData;            // '<S123>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr;            // '<S123>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger;           // '<S123>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo;             // '<S123>/OUTPUT_1_1'
  void* OUTPUT_1_1_Simulator_n;        // '<S153>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData_e;          // '<S153>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr_f;          // '<S153>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger_d;         // '<S153>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo_d;           // '<S153>/OUTPUT_1_1'
  void* OUTPUT_1_1_Simulator_j;        // '<S183>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData_l;          // '<S183>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr_h;          // '<S183>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger_e;         // '<S183>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo_o;           // '<S183>/OUTPUT_1_1'
  void* OUTPUT_1_1_Simulator_d;        // '<S213>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData_o;          // '<S213>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr_a;          // '<S213>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger_g;         // '<S213>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo_l;           // '<S213>/OUTPUT_1_1'
  void* STATE_1_Simulator_e;           // '<S276>/STATE_1'
  void* STATE_1_SimData_mw;            // '<S276>/STATE_1'
  void* STATE_1_DiagMgr_o;             // '<S276>/STATE_1'
  void* STATE_1_ZcLogger_c;            // '<S276>/STATE_1'
  void* STATE_1_TsInfo_b;              // '<S276>/STATE_1'
  void* OUTPUT_1_0_Simulator_h;        // '<S276>/OUTPUT_1_0'
  void* OUTPUT_1_0_SimData_n5;         // '<S276>/OUTPUT_1_0'
  void* OUTPUT_1_0_DiagMgr_b;          // '<S276>/OUTPUT_1_0'
  void* OUTPUT_1_0_ZcLogger_a;         // '<S276>/OUTPUT_1_0'
  void* OUTPUT_1_0_TsInfo_k;           // '<S276>/OUTPUT_1_0'
  void* SINK_1_RtwLogger_k;            // '<S276>/SINK_1'
  void* SINK_1_RtwLogBuffer_o;         // '<S276>/SINK_1'
  void* SINK_1_RtwLogFcnManager_k;     // '<S276>/SINK_1'
  void* OUTPUT_1_1_Simulator_l;        // '<S276>/OUTPUT_1_1'
  void* OUTPUT_1_1_SimData_c;          // '<S276>/OUTPUT_1_1'
  void* OUTPUT_1_1_DiagMgr_fo;         // '<S276>/OUTPUT_1_1'
  void* OUTPUT_1_1_ZcLogger_ex;        // '<S276>/OUTPUT_1_1'
  void* OUTPUT_1_1_TsInfo_ox;          // '<S276>/OUTPUT_1_1'
  int_T STATE_1_Modes;                 // '<S123>/STATE_1'
  int_T OUTPUT_1_0_Modes;              // '<S123>/OUTPUT_1_0'
  int_T STATE_1_Modes_l;               // '<S153>/STATE_1'
  int_T OUTPUT_1_0_Modes_m;            // '<S153>/OUTPUT_1_0'
  int_T STATE_1_Modes_j;               // '<S183>/STATE_1'
  int_T OUTPUT_1_0_Modes_n;            // '<S183>/OUTPUT_1_0'
  int_T STATE_1_Modes_h;               // '<S213>/STATE_1'
  int_T OUTPUT_1_0_Modes_p;            // '<S213>/OUTPUT_1_0'
  int_T OUTPUT_1_1_Modes;              // '<S123>/OUTPUT_1_1'
  int_T OUTPUT_1_1_Modes_i;            // '<S153>/OUTPUT_1_1'
  int_T OUTPUT_1_1_Modes_p;            // '<S183>/OUTPUT_1_1'
  int_T OUTPUT_1_1_Modes_o;            // '<S213>/OUTPUT_1_1'
  int_T STATE_1_Modes_p;               // '<S276>/STATE_1'
  int_T OUTPUT_1_0_Modes_c;            // '<S276>/OUTPUT_1_0'
  int_T OUTPUT_1_1_Modes_f;            // '<S276>/OUTPUT_1_1'
  boolean_T RTP_1_SetParametersNeeded; // '<S100>/RTP_1'
  boolean_T STATE_1_FirstOutput;       // '<S123>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput;    // '<S123>/OUTPUT_1_0'
  boolean_T RTP_1_SetParametersNeeded_k;// '<S130>/RTP_1'
  boolean_T STATE_1_FirstOutput_g;     // '<S153>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput_g;  // '<S153>/OUTPUT_1_0'
  boolean_T RTP_1_SetParametersNeeded_a;// '<S160>/RTP_1'
  boolean_T STATE_1_FirstOutput_f;     // '<S183>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput_p;  // '<S183>/OUTPUT_1_0'
  boolean_T RTP_1_SetParametersNeeded_l;// '<S190>/RTP_1'
  boolean_T STATE_1_FirstOutput_fd;    // '<S213>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput_e;  // '<S213>/OUTPUT_1_0'
  boolean_T icLoad;                    // '<S89>/Delay'
  boolean_T icLoad_d;                  // '<S89>/Delay1'
  boolean_T OUTPUT_1_1_FirstOutput;    // '<S123>/OUTPUT_1_1'
  boolean_T OUTPUT_1_1_FirstOutput_n;  // '<S153>/OUTPUT_1_1'
  boolean_T OUTPUT_1_1_FirstOutput_k;  // '<S183>/OUTPUT_1_1'
  boolean_T OUTPUT_1_1_FirstOutput_h;  // '<S213>/OUTPUT_1_1'
  boolean_T STATE_1_FirstOutput_c;     // '<S276>/STATE_1'
  boolean_T OUTPUT_1_0_FirstOutput_j;  // '<S276>/OUTPUT_1_0'
  boolean_T OUTPUT_1_1_FirstOutput_nm; // '<S276>/OUTPUT_1_1'
};

// Continuous states (default storage)
struct X_SatelliteServicing_Mission_T {
  real_T SatelliteServicing_MissionMissi[13];// '<S123>/STATE_1'
  real_T SatelliteServicing_MissionMis_m[13];// '<S153>/STATE_1'
  real_T SatelliteServicing_MissionMis_k[13];// '<S183>/STATE_1'
  real_T SatelliteServicing_MissionMis_n[13];// '<S213>/STATE_1'
  real_T SatelliteServicing_MissionClien[26];// '<S276>/STATE_1'
};

// State derivatives (default storage)
struct XDot_SatelliteServicing_Missi_T {
  real_T SatelliteServicing_MissionMissi[13];// '<S123>/STATE_1'
  real_T SatelliteServicing_MissionMis_m[13];// '<S153>/STATE_1'
  real_T SatelliteServicing_MissionMis_k[13];// '<S183>/STATE_1'
  real_T SatelliteServicing_MissionMis_n[13];// '<S213>/STATE_1'
  real_T SatelliteServicing_MissionClien[26];// '<S276>/STATE_1'
};

// State disabled
struct XDis_SatelliteServicing_Missi_T {
  boolean_T SatelliteServicing_MissionMissi[13];// '<S123>/STATE_1'
  boolean_T SatelliteServicing_MissionMis_m[13];// '<S153>/STATE_1'
  boolean_T SatelliteServicing_MissionMis_k[13];// '<S183>/STATE_1'
  boolean_T SatelliteServicing_MissionMis_n[13];// '<S213>/STATE_1'
  boolean_T SatelliteServicing_MissionClien[26];// '<S276>/STATE_1'
};

#ifndef ODE3_INTG
#define ODE3_INTG

// ODE3 Integration Data
struct ODE3_IntgData {
  real_T *y;                           // output
  real_T *f[3];                        // derivatives
};

#endif

// External inputs (root inport signals with default storage)
struct ExtU_SatelliteServicing_Missi_T {
  real_T ManipulatorActions[3];        // '<Root>/ManipulatorActions'
};

// External outputs (root outports fed by signals with default storage)
struct ExtY_SatelliteServicing_Missi_T {
  real_T Observations[36];             // '<Root>/Observations'
  real_T ControlError[122];            // '<Root>/ControlError'
};

// Parameters (default storage)
struct P_SatelliteServicing_Mission_T_ {
  satControlDataBus_Rot satControlData_Rot;// Variable: satControlData_Rot
                                              //  Referenced by:
                                              //    '<S225>/Constant2'
                                              //    '<S226>/Constant2'
                                              //    '<S228>/Saturation1'

  satControlDataBus_Trans satControlData_Trans;// Variable: satControlData_Trans
                                                  //  Referenced by:
                                                  //    '<S225>/Constant1'
                                                  //    '<S226>/Constant1'
                                                  //    '<S229>/Saturation1'

  struct_Yf8rt61VEQC0Uc7ZmBWdrE cubesat[4];// Variable: cubesat
                                              //  Referenced by:
                                              //    '<S94>/Constant1'
                                              //    '<S124>/Constant1'
                                              //    '<S154>/Constant1'
                                              //    '<S184>/Constant1'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PxPositionTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PxVelocityTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PyPositionTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PyVelocityTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PzPositionTargetValue'
                                              //    '<S94>/Subsystem_around_RTP_5F0325A4_PzVelocityTargetValue'
                                              //    '<S124>/Subsystem_around_RTP_517418D9_PxPositionTargetValue'
                                              //    '<S124>/Subsystem_around_RTP_517418D9_PxVelocityTargetValue'
                                              //    '<S124>/Subsystem_around_RTP_517418D9_PyPositionTargetValue'
                                              //    '<S124>/Subsystem_around_RTP_517418D9_PyVelocityTargetValue'
                                              //    '<S124>/Subsystem_around_RTP_517418D9_PzPositionTargetValue'
                                              //    '<S124>/Subsystem_around_RTP_517418D9_PzVelocityTargetValue'
                                              //    '<S154>/Subsystem_around_RTP_6835F894_PxPositionTargetValue'
                                              //    '<S154>/Subsystem_around_RTP_6835F894_PxVelocityTargetValue'
                                              //    '<S154>/Subsystem_around_RTP_6835F894_PyPositionTargetValue'
                                              //    '<S154>/Subsystem_around_RTP_6835F894_PyVelocityTargetValue'
                                              //    '<S154>/Subsystem_around_RTP_6835F894_PzPositionTargetValue'
                                              //    '<S154>/Subsystem_around_RTP_6835F894_PzVelocityTargetValue'
                                              //    '<S184>/Subsystem_around_RTP_84B5FE6B_PxPositionTargetValue'
                                              //    '<S184>/Subsystem_around_RTP_84B5FE6B_PxVelocityTargetValue'
                                              //    '<S184>/Subsystem_around_RTP_84B5FE6B_PyPositionTargetValue'
                                              //    '<S184>/Subsystem_around_RTP_84B5FE6B_PyVelocityTargetValue'
                                              //    '<S184>/Subsystem_around_RTP_84B5FE6B_PzPositionTargetValue'
                                              //    '<S184>/Subsystem_around_RTP_84B5FE6B_PzVelocityTargetValue'

  struct_b9EoG14LaCnLOpiLP034lD orbit; // Variable: orbit
                                          //  Referenced by: '<S88>/Constant1'

  real_T nsat;                         // Variable: nsat
                                          //  Referenced by: '<S89>/Constant1'

  real_T Constant3_Value[366];         // Expression: client.faceCenter
                                          //  Referenced by: '<S89>/Constant3'

  real_T Constant2_Value;              // Expression: client.inspectionFOV
                                          //  Referenced by: '<S89>/Constant2'

  real_T Constant6_Value;           // Expression: client.inspectionSphereRadius
                                       //  Referenced by: '<S89>/Constant6'

  real_T Constant5_Value[122];         // Expression: client.faceRadius
                                          //  Referenced by: '<S89>/Constant5'

  real_T Constant4_Value[122];         // Expression: zeros(client.nFaces,1)
                                          //  Referenced by: '<S89>/Constant4'

  real_T Constant_Value[3];            // Expression: [0,0,0]
                                          //  Referenced by: '<S88>/Constant'

  real_T DiscreteTimeIntegrator1_gainval;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainval
                             //  Referenced by: '<S231>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC;   // Expression: 0
                                          //  Referenced by: '<S231>/Discrete-Time Integrator1'

  real_T Gain1_Gain;                   // Expression: -1
                                          //  Referenced by: '<S231>/Gain1'

  real_T DiscreteTimeIntegrator1_gainv_b;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainv_b
                             //  Referenced by: '<S230>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC_f; // Expression: 0
                                          //  Referenced by: '<S230>/Discrete-Time Integrator1'

  real_T Gain1_Gain_m;                 // Expression: -1
                                          //  Referenced by: '<S230>/Gain1'

};

// Real-time Model Data Structure
struct tag_RTM_SatelliteServicing_Mi_T {
  const char_T *errorStatus;
  RTWSolverInfo *solverInfo;
  B_SatelliteServicing_Mission_T *blockIO;
  X_SatelliteServicing_Mission_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_SatelliteServicing_Missi_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[78];
  real_T odeF[3][78];
  ODE3_IntgData intgData;
  DW_SatelliteServicing_Mission_T *dwork;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

// Block parameters (default storage)
#ifdef __cplusplus

extern "C"
{

#endif

  extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;

#ifdef __cplusplus

}

#endif

// External data declarations for dependent source files
#ifdef __cplusplus

extern "C"
{

#endif

  extern const char_T *RT_MEMORY_ALLOCATION_ERROR;

#ifdef __cplusplus

}

#endif

extern P_SatelliteServicing_Mission_T SatelliteServicing_Mission_P;// parameters 

#ifdef __cplusplus

extern "C"
{

#endif

  // Model entry point functions
  extern RT_MODEL_SatelliteServicing_M_T *SatelliteServicing_Mission
    (ExtU_SatelliteServicing_Missi_T *SatelliteServicing_Mission_U,
     ExtY_SatelliteServicing_Missi_T *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_initialize
    (RT_MODEL_SatelliteServicing_M_T *const SatelliteServicing_Mission_M);
  extern void SatelliteServicing_Mission_step(RT_MODEL_SatelliteServicing_M_T *
    const SatelliteServicing_Mission_M, ExtY_SatelliteServicing_Missi_T
    *SatelliteServicing_Mission_Y);
  extern void SatelliteServicing_Mission_terminate
    (RT_MODEL_SatelliteServicing_M_T * SatelliteServicing_Mission_M);

#ifdef __cplusplus

}

#endif

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S37>/RESHAPE' : Reshape block reduction
//  Block '<S77>/RESHAPE' : Reshape block reduction
//  Block '<S266>/RESHAPE' : Reshape block reduction


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'SatelliteServicing_Mission'
//  '<S1>'   : 'SatelliteServicing_Mission/ClientSatellite'
//  '<S2>'   : 'SatelliteServicing_Mission/Mission'
//  '<S3>'   : 'SatelliteServicing_Mission/ServicingSatellite'
//  '<S4>'   : 'SatelliteServicing_Mission/Solver Configuration'
//  '<S5>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1'
//  '<S6>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output2'
//  '<S7>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter1'
//  '<S8>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter10'
//  '<S9>'   : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter11'
//  '<S10>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter12'
//  '<S11>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter13'
//  '<S12>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter14'
//  '<S13>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter15'
//  '<S14>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter16'
//  '<S15>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter17'
//  '<S16>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter18'
//  '<S17>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter2'
//  '<S18>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter3'
//  '<S19>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter4'
//  '<S20>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter5'
//  '<S21>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter6'
//  '<S22>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter7'
//  '<S23>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter8'
//  '<S24>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter9'
//  '<S25>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/Reorder_to_XYZ'
//  '<S26>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/formPoseMat'
//  '<S27>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/positiveQuat'
//  '<S28>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/quat2MRP'
//  '<S29>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S30>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S31>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S32>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S33>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S34>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S35>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S36>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S37>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S38>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S39>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S40>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S41>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S42>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S43>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S44>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S45>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S46>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S47>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1'
//  '<S48>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10'
//  '<S49>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11'
//  '<S50>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12'
//  '<S51>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13'
//  '<S52>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14'
//  '<S53>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15'
//  '<S54>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16'
//  '<S55>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter17'
//  '<S56>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter18'
//  '<S57>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2'
//  '<S58>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3'
//  '<S59>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4'
//  '<S60>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5'
//  '<S61>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6'
//  '<S62>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7'
//  '<S63>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8'
//  '<S64>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9'
//  '<S65>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/Reorder_to_XYZ'
//  '<S66>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/formPoseMat'
//  '<S67>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/positiveQuat'
//  '<S68>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/quat2MRP'
//  '<S69>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter1/EVAL_KEY'
//  '<S70>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter10/EVAL_KEY'
//  '<S71>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter11/EVAL_KEY'
//  '<S72>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter12/EVAL_KEY'
//  '<S73>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter13/EVAL_KEY'
//  '<S74>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter14/EVAL_KEY'
//  '<S75>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter15/EVAL_KEY'
//  '<S76>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter16/EVAL_KEY'
//  '<S77>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter17/EVAL_KEY'
//  '<S78>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter18/EVAL_KEY'
//  '<S79>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter2/EVAL_KEY'
//  '<S80>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter3/EVAL_KEY'
//  '<S81>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter4/EVAL_KEY'
//  '<S82>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter5/EVAL_KEY'
//  '<S83>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter6/EVAL_KEY'
//  '<S84>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter7/EVAL_KEY'
//  '<S85>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter8/EVAL_KEY'
//  '<S86>'  : 'SatelliteServicing_Mission/ClientSatellite/State_Output2/PS-Simulink Converter9/EVAL_KEY'
//  '<S87>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection'
//  '<S88>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats'
//  '<S89>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/InspectionCoverage'
//  '<S90>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1'
//  '<S91>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2'
//  '<S92>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3'
//  '<S93>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4'
//  '<S94>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation'
//  '<S95>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Cubesat_Acceleration'
//  '<S96>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor'
//  '<S97>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter1'
//  '<S98>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter2'
//  '<S99>'  : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter3'
//  '<S100>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration'
//  '<S101>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Cubesat_Acceleration/CW_Equations'
//  '<S102>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter1'
//  '<S103>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter11'
//  '<S104>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter12'
//  '<S105>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter15'
//  '<S106>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter2'
//  '<S107>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter3'
//  '<S108>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter4'
//  '<S109>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter5'
//  '<S110>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter6'
//  '<S111>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S112>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S113>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S114>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S115>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S116>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S117>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S118>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S119>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S120>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S121>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S122>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S123>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat1/CubeSat1_Propagation/Solver Configuration/EVAL_KEY'
//  '<S124>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation'
//  '<S125>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Cubesat_Acceleration'
//  '<S126>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor'
//  '<S127>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter1'
//  '<S128>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter2'
//  '<S129>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter3'
//  '<S130>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration'
//  '<S131>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Cubesat_Acceleration/CW_Equations'
//  '<S132>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter1'
//  '<S133>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter11'
//  '<S134>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter12'
//  '<S135>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter15'
//  '<S136>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter2'
//  '<S137>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter3'
//  '<S138>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter4'
//  '<S139>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter5'
//  '<S140>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter6'
//  '<S141>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S142>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S143>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S144>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S145>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S146>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S147>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S148>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S149>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S150>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S151>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S152>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S153>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat2/CubeSat2_Propagation/Solver Configuration/EVAL_KEY'
//  '<S154>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation'
//  '<S155>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Cubesat_Acceleration'
//  '<S156>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor'
//  '<S157>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter1'
//  '<S158>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter2'
//  '<S159>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter3'
//  '<S160>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration'
//  '<S161>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Cubesat_Acceleration/CW_Equations'
//  '<S162>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter1'
//  '<S163>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter11'
//  '<S164>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter12'
//  '<S165>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter15'
//  '<S166>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter2'
//  '<S167>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter3'
//  '<S168>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter4'
//  '<S169>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter5'
//  '<S170>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter6'
//  '<S171>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S172>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S173>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S174>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S175>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S176>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S177>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S178>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S179>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S180>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S181>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S182>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S183>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration/EVAL_KEY'
//  '<S184>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation'
//  '<S185>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Cubesat_Acceleration'
//  '<S186>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor'
//  '<S187>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter1'
//  '<S188>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter2'
//  '<S189>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter3'
//  '<S190>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration'
//  '<S191>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Cubesat_Acceleration/CW_Equations'
//  '<S192>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter1'
//  '<S193>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter11'
//  '<S194>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter12'
//  '<S195>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter15'
//  '<S196>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter2'
//  '<S197>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter3'
//  '<S198>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter4'
//  '<S199>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter5'
//  '<S200>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter6'
//  '<S201>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter1/EVAL_KEY'
//  '<S202>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter11/EVAL_KEY'
//  '<S203>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter12/EVAL_KEY'
//  '<S204>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter15/EVAL_KEY'
//  '<S205>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter2/EVAL_KEY'
//  '<S206>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter3/EVAL_KEY'
//  '<S207>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter4/EVAL_KEY'
//  '<S208>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter5/EVAL_KEY'
//  '<S209>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Sensor/PS-Simulink Converter6/EVAL_KEY'
//  '<S210>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter1/EVAL_KEY'
//  '<S211>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter2/EVAL_KEY'
//  '<S212>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Simulink-PS Converter3/EVAL_KEY'
//  '<S213>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat4/CubeSat4_Propagation/Solver Configuration/EVAL_KEY'
//  '<S214>' : 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/InspectionCoverage/computeCoverage'
//  '<S215>' : 'SatelliteServicing_Mission/ServicingSatellite/Camera'
//  '<S216>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC'
//  '<S217>' : 'SatelliteServicing_Mission/ServicingSatellite/Sat1Solid'
//  '<S218>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel1'
//  '<S219>' : 'SatelliteServicing_Mission/ServicingSatellite/SatSolarPanel2'
//  '<S220>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter'
//  '<S221>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1'
//  '<S222>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2'
//  '<S223>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3'
//  '<S224>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1'
//  '<S225>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl'
//  '<S226>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefGuidance'
//  '<S227>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefNavigation'
//  '<S228>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/RotationalControl'
//  '<S229>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/TranslationalControl'
//  '<S230>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/RotationalControl/PIDControl'
//  '<S231>' : 'SatelliteServicing_Mission/ServicingSatellite/ChiefGNC/ChiefControl/TranslationalControl/PIDControl'
//  '<S232>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter/EVAL_KEY'
//  '<S233>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter1/EVAL_KEY'
//  '<S234>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter2/EVAL_KEY'
//  '<S235>' : 'SatelliteServicing_Mission/ServicingSatellite/Simulink-PS Converter3/EVAL_KEY'
//  '<S236>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter1'
//  '<S237>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter10'
//  '<S238>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter11'
//  '<S239>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter12'
//  '<S240>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter13'
//  '<S241>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter14'
//  '<S242>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter15'
//  '<S243>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter16'
//  '<S244>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter17'
//  '<S245>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter18'
//  '<S246>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter2'
//  '<S247>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter3'
//  '<S248>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter4'
//  '<S249>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter5'
//  '<S250>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter6'
//  '<S251>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter7'
//  '<S252>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter8'
//  '<S253>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter9'
//  '<S254>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/Reorder_to_XYZ'
//  '<S255>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/formPoseMat'
//  '<S256>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/positiveQuat'
//  '<S257>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/quat2MRP'
//  '<S258>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter1/EVAL_KEY'
//  '<S259>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter10/EVAL_KEY'
//  '<S260>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter11/EVAL_KEY'
//  '<S261>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter12/EVAL_KEY'
//  '<S262>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter13/EVAL_KEY'
//  '<S263>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter14/EVAL_KEY'
//  '<S264>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter15/EVAL_KEY'
//  '<S265>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter16/EVAL_KEY'
//  '<S266>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter17/EVAL_KEY'
//  '<S267>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter18/EVAL_KEY'
//  '<S268>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter2/EVAL_KEY'
//  '<S269>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter3/EVAL_KEY'
//  '<S270>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter4/EVAL_KEY'
//  '<S271>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter5/EVAL_KEY'
//  '<S272>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter6/EVAL_KEY'
//  '<S273>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter7/EVAL_KEY'
//  '<S274>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter8/EVAL_KEY'
//  '<S275>' : 'SatelliteServicing_Mission/ServicingSatellite/State_Output1/PS-Simulink Converter9/EVAL_KEY'
//  '<S276>' : 'SatelliteServicing_Mission/Solver Configuration/EVAL_KEY'

#endif                              // RTW_HEADER_SatelliteServicing_Mission_h_

//
// File trailer for generated code.
//
// [EOF]
//
