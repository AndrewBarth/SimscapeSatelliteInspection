// Simscape target specific file.
//  This file is generated for the Simscape network associated with the solver block 'SatelliteServicing_Mission/Mission/Cubesat_Inspection/Cubesats/CubeSat3/CubeSat3_Propagation/Solver Configuration'.


struct RuntimeDerivedValuesBundleTag;
void SatelliteServicing_Mission_2eaac34_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
