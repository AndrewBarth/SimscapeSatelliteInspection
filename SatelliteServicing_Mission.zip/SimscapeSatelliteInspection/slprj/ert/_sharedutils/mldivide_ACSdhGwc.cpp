//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: mldivide_ACSdhGwc.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.3
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep  1 10:31:47 2023
//
#include "rtwtypes.h"
#include "mldivide_ACSdhGwc.h"
#include <cstring>
#include <cmath>

// Function for MATLAB Function: '<S208>/ArmKinematics'
void mldivide_ACSdhGwc(const real_T A[9], const real_T B[9], real_T Y[9])
{
  real_T b_A[9];
  real_T Y_0;
  real_T Y_tmp;
  real_T Y_tmp_0;
  real_T Y_tmp_1;
  real_T Y_tmp_2;
  real_T Y_tmp_3;
  real_T Y_tmp_4;
  real_T a21;
  real_T maxval;
  int32_T r1;
  int32_T r2;
  int32_T r3;
  std::memcpy(&b_A[0], &A[0], 9U * sizeof(real_T));
  r1 = 0;
  r2 = 1;
  r3 = 2;
  maxval = std::abs(A[0]);
  a21 = std::abs(A[1]);
  if (a21 > maxval) {
    maxval = a21;
    r1 = 1;
    r2 = 0;
  }

  if (std::abs(A[2]) > maxval) {
    r1 = 2;
    r2 = 1;
    r3 = 0;
  }

  b_A[r2] = A[r2] / A[r1];
  b_A[r3] /= b_A[r1];
  b_A[r2 + 3] -= b_A[r1 + 3] * b_A[r2];
  b_A[r3 + 3] -= b_A[r1 + 3] * b_A[r3];
  b_A[r2 + 6] -= b_A[r1 + 6] * b_A[r2];
  b_A[r3 + 6] -= b_A[r1 + 6] * b_A[r3];
  if (std::abs(b_A[r3 + 3]) > std::abs(b_A[r2 + 3])) {
    int32_T rtemp;
    rtemp = r2;
    r2 = r3;
    r3 = rtemp;
  }

  b_A[r3 + 3] /= b_A[r2 + 3];
  b_A[r3 + 6] -= b_A[r3 + 3] * b_A[r2 + 6];
  maxval = B[r1];
  a21 = B[r2] - maxval * b_A[r2];
  Y_tmp = b_A[r3 + 3];
  Y_tmp_0 = b_A[r3 + 6];
  Y_0 = ((B[r3] - maxval * b_A[r3]) - Y_tmp * a21) / Y_tmp_0;
  Y[2] = Y_0;
  Y_tmp_1 = b_A[r2 + 6];
  Y_tmp_2 = b_A[r2 + 3];
  a21 = (a21 - Y_tmp_1 * Y_0) / Y_tmp_2;
  Y[1] = a21;
  Y_tmp_3 = b_A[r1 + 6];
  Y_tmp_4 = b_A[r1 + 3];
  Y[0] = ((maxval - Y_tmp_3 * Y_0) - Y_tmp_4 * a21) / b_A[r1];
  maxval = B[r1 + 3];
  a21 = B[r2 + 3] - maxval * b_A[r2];
  Y_0 = ((B[r3 + 3] - maxval * b_A[r3]) - Y_tmp * a21) / Y_tmp_0;
  Y[5] = Y_0;
  a21 = (a21 - Y_tmp_1 * Y_0) / Y_tmp_2;
  Y[4] = a21;
  Y[3] = ((maxval - Y_tmp_3 * Y_0) - Y_tmp_4 * a21) / b_A[r1];
  maxval = B[r1 + 6];
  a21 = B[r2 + 6] - maxval * b_A[r2];
  Y_0 = ((B[r3 + 6] - maxval * b_A[r3]) - Y_tmp * a21) / Y_tmp_0;
  Y[8] = Y_0;
  a21 = (a21 - Y_tmp_1 * Y_0) / Y_tmp_2;
  Y[7] = a21;
  Y[6] = ((maxval - Y_tmp_3 * Y_0) - Y_tmp_4 * a21) / b_A[r1];
}

//
// File trailer for generated code.
//
// [EOF]
//
