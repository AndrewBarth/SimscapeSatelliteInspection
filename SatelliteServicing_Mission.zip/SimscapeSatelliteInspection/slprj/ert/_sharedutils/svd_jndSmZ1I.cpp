//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: svd_jndSmZ1I.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.47
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Tue Apr 30 15:15:56 2024
//
#include "rtwtypes.h"
#include "svd_jndSmZ1I.h"
#include <cstring>
#include "xnrm2_ZLcWpb61.h"
#include <cmath>
#include "xnrm2_CZPEua86.h"
#include <emmintrin.h>
#include "xaxpy_fV4GNNBY.h"
#include "xrotg_9ZHhnzNd.h"

// Function for MATLAB Function: '<S3>/computeCoverage'
void svd_jndSmZ1I(const real_T A[9], real_T U[3])
{
  __m128d tmp;
  real_T b_A[9];
  real_T e[3];
  real_T s[3];
  real_T work[3];
  real_T emm1;
  real_T nrm;
  real_T r;
  real_T rt;
  real_T shift;
  real_T smm1;
  real_T ztest0;
  int32_T b_ix;
  int32_T d;
  int32_T e_k;
  int32_T m;
  int32_T qjj;
  int32_T qp1;
  int32_T qq;
  int32_T qq_tmp;
  boolean_T apply_transform;
  boolean_T exitg1;
  std::memcpy(&b_A[0], &A[0], 9U * sizeof(real_T));
  s[0] = 0.0;
  e[0] = 0.0;
  work[0] = 0.0;
  s[1] = 0.0;
  e[1] = 0.0;
  work[1] = 0.0;
  s[2] = 0.0;
  e[2] = 0.0;
  work[2] = 0.0;
  for (m = 0; m < 2; m++) {
    qp1 = m + 2;
    qq_tmp = 3 * m + m;
    qq = qq_tmp + 1;
    apply_transform = false;
    nrm = xnrm2_ZLcWpb61(3 - m, b_A, qq_tmp + 1);
    if (nrm > 0.0) {
      apply_transform = true;
      if (b_A[qq_tmp] < 0.0) {
        nrm = -nrm;
      }

      s[m] = nrm;
      if (std::abs(nrm) >= 1.0020841800044864E-292) {
        nrm = 1.0 / nrm;
        d = (qq_tmp - m) + 3;
        b_ix = ((((d - qq_tmp) / 2) << 1) + qq_tmp) + 1;
        qjj = b_ix - 2;
        for (e_k = qq; e_k <= qjj; e_k += 2) {
          tmp = _mm_loadu_pd(&b_A[e_k - 1]);
          _mm_storeu_pd(&b_A[e_k - 1], _mm_mul_pd(tmp, _mm_set1_pd(nrm)));
        }

        for (e_k = b_ix; e_k <= d; e_k++) {
          b_A[e_k - 1] *= nrm;
        }
      } else {
        d = (qq_tmp - m) + 3;
        b_ix = ((((d - qq_tmp) / 2) << 1) + qq_tmp) + 1;
        qjj = b_ix - 2;
        for (e_k = qq; e_k <= qjj; e_k += 2) {
          tmp = _mm_loadu_pd(&b_A[e_k - 1]);
          _mm_storeu_pd(&b_A[e_k - 1], _mm_div_pd(tmp, _mm_set1_pd(s[m])));
        }

        for (e_k = b_ix; e_k <= d; e_k++) {
          b_A[e_k - 1] /= s[m];
        }
      }

      b_A[qq_tmp]++;
      s[m] = -s[m];
    } else {
      s[m] = 0.0;
    }

    for (b_ix = qp1; b_ix < 4; b_ix++) {
      qjj = (b_ix - 1) * 3 + m;
      if (apply_transform) {
        nrm = 0.0;
        qq = 3 - m;
        for (d = 0; d < qq; d++) {
          nrm += b_A[qq_tmp + d] * b_A[qjj + d];
        }

        nrm = -(nrm / b_A[qq_tmp]);
        if (!(nrm == 0.0)) {
          for (d = 0; d < qq; d++) {
            e_k = qjj + d;
            b_A[e_k] += b_A[qq_tmp + d] * nrm;
          }
        }
      }

      e[b_ix - 1] = b_A[qjj];
    }

    if (m + 1 <= 1) {
      nrm = xnrm2_CZPEua86(e, 2);
      if (nrm == 0.0) {
        e[0] = 0.0;
      } else {
        if (e[1] < 0.0) {
          e[0] = -nrm;
        } else {
          e[0] = nrm;
        }

        nrm = e[0];
        if (std::abs(e[0]) >= 1.0020841800044864E-292) {
          nrm = 1.0 / e[0];
          b_ix = ((((2 - m) / 2) << 1) + m) + 2;
          qjj = b_ix - 2;
          for (qq_tmp = qp1; qq_tmp <= qjj; qq_tmp += 2) {
            tmp = _mm_loadu_pd(&e[qq_tmp - 1]);
            _mm_storeu_pd(&e[qq_tmp - 1], _mm_mul_pd(tmp, _mm_set1_pd(nrm)));
          }

          for (qq_tmp = b_ix; qq_tmp < 4; qq_tmp++) {
            e[qq_tmp - 1] *= nrm;
          }
        } else {
          b_ix = ((((2 - m) / 2) << 1) + m) + 2;
          qjj = b_ix - 2;
          for (qq_tmp = qp1; qq_tmp <= qjj; qq_tmp += 2) {
            tmp = _mm_loadu_pd(&e[qq_tmp - 1]);
            _mm_storeu_pd(&e[qq_tmp - 1], _mm_div_pd(tmp, _mm_set1_pd(nrm)));
          }

          for (qq_tmp = b_ix; qq_tmp < 4; qq_tmp++) {
            e[qq_tmp - 1] /= nrm;
          }
        }

        e[1]++;
        e[0] = -e[0];
        for (qq_tmp = qp1; qq_tmp < 4; qq_tmp++) {
          work[qq_tmp - 1] = 0.0;
        }

        for (qq_tmp = qp1; qq_tmp < 4; qq_tmp++) {
          rt = e[qq_tmp - 1];
          if (!(rt == 0.0)) {
            b_ix = (qq_tmp - 1) * 3;
            work[1] += b_A[b_ix + 1] * rt;
            work[2] += b_A[b_ix + 2] * rt;
          }
        }

        for (qq_tmp = qp1; qq_tmp < 4; qq_tmp++) {
          xaxpy_fV4GNNBY(2, -e[qq_tmp - 1] / e[1], work, 2, b_A, 3 * (qq_tmp - 1)
                         + 2);
        }
      }
    }
  }

  m = 1;
  s[2] = b_A[8];
  e[1] = b_A[7];
  e[2] = 0.0;
  qp1 = 0;
  ztest0 = s[0];
  if (s[0] != 0.0) {
    rt = std::abs(s[0]);
    r = s[0] / rt;
    ztest0 = rt;
    s[0] = rt;
    e[0] /= r;
  }

  if (e[0] != 0.0) {
    rt = std::abs(e[0]);
    r = rt / e[0];
    e[0] = rt;
    s[1] *= r;
  }

  nrm = std::fmax(ztest0, std::abs(e[0]));
  ztest0 = s[1];
  if (s[1] != 0.0) {
    rt = std::abs(s[1]);
    r = s[1] / rt;
    ztest0 = rt;
    s[1] = rt;
    e[1] = b_A[7] / r;
  }

  if (e[1] != 0.0) {
    rt = std::abs(e[1]);
    r = rt / e[1];
    e[1] = rt;
    s[2] = b_A[8] * r;
  }

  nrm = std::fmax(nrm, std::fmax(ztest0, std::abs(e[1])));
  ztest0 = s[2];
  if (s[2] != 0.0) {
    rt = std::abs(s[2]);
    ztest0 = rt;
    s[2] = rt;
  }

  nrm = std::fmax(nrm, std::fmax(ztest0, 0.0));
  while ((m + 2 > 0) && (qp1 < 75)) {
    qq_tmp = m + 1;
    exitg1 = false;
    while (!(exitg1 || (qq_tmp == 0))) {
      ztest0 = std::abs(e[qq_tmp - 1]);
      if (ztest0 <= (std::abs(s[qq_tmp - 1]) + std::abs(s[qq_tmp])) *
          2.2204460492503131E-16) {
        e[qq_tmp - 1] = 0.0;
        exitg1 = true;
      } else if ((ztest0 <= 1.0020841800044864E-292) || ((qp1 > 20) && (ztest0 <=
        2.2204460492503131E-16 * nrm))) {
        e[qq_tmp - 1] = 0.0;
        exitg1 = true;
      } else {
        qq_tmp--;
      }
    }

    if (m + 1 == qq_tmp) {
      qjj = 4;
    } else {
      b_ix = m + 2;
      qjj = m + 2;
      exitg1 = false;
      while ((!exitg1) && (qjj >= qq_tmp)) {
        b_ix = qjj;
        if (qjj == qq_tmp) {
          exitg1 = true;
        } else {
          ztest0 = 0.0;
          if (qjj < m + 2) {
            ztest0 = std::abs(e[qjj - 1]);
          }

          if (qjj > qq_tmp + 1) {
            ztest0 += std::abs(e[qjj - 2]);
          }

          rt = std::abs(s[qjj - 1]);
          if ((rt <= 2.2204460492503131E-16 * ztest0) || (rt <=
               1.0020841800044864E-292)) {
            s[qjj - 1] = 0.0;
            exitg1 = true;
          } else {
            qjj--;
          }
        }
      }

      if (b_ix == qq_tmp) {
        qjj = 3;
      } else if (m + 2 == b_ix) {
        qjj = 1;
      } else {
        qjj = 2;
        qq_tmp = b_ix;
      }
    }

    switch (qjj) {
     case 1:
      ztest0 = e[m];
      e[m] = 0.0;
      for (b_ix = m + 1; b_ix >= qq_tmp + 1; b_ix--) {
        xrotg_9ZHhnzNd(&s[b_ix - 1], &ztest0, &rt, &r);
        if (b_ix > qq_tmp + 1) {
          ztest0 = -r * e[0];
          e[0] *= rt;
        }
      }
      break;

     case 2:
      ztest0 = e[qq_tmp - 1];
      e[qq_tmp - 1] = 0.0;
      for (b_ix = qq_tmp + 1; b_ix <= m + 2; b_ix++) {
        xrotg_9ZHhnzNd(&s[b_ix - 1], &ztest0, &r, &smm1);
        rt = e[b_ix - 1];
        ztest0 = -smm1 * rt;
        e[b_ix - 1] = rt * r;
      }
      break;

     case 3:
      ztest0 = s[m + 1];
      rt = std::fmax(std::fmax(std::fmax(std::fmax(std::abs(ztest0), std::abs
        (s[m])), std::abs(e[m])), std::abs(s[qq_tmp])), std::abs(e[qq_tmp]));
      ztest0 /= rt;
      smm1 = s[m] / rt;
      emm1 = e[m] / rt;
      r = s[qq_tmp] / rt;
      smm1 = ((smm1 + ztest0) * (smm1 - ztest0) + emm1 * emm1) / 2.0;
      emm1 *= ztest0;
      emm1 *= emm1;
      if ((smm1 != 0.0) || (emm1 != 0.0)) {
        shift = std::sqrt(smm1 * smm1 + emm1);
        if (smm1 < 0.0) {
          shift = -shift;
        }

        shift = emm1 / (smm1 + shift);
      } else {
        shift = 0.0;
      }

      ztest0 = (r + ztest0) * (r - ztest0) + shift;
      rt = e[qq_tmp] / rt * r;
      for (b_ix = qq_tmp + 1; b_ix <= m + 1; b_ix++) {
        xrotg_9ZHhnzNd(&ztest0, &rt, &r, &smm1);
        if (b_ix > qq_tmp + 1) {
          e[0] = ztest0;
        }

        emm1 = e[b_ix - 1];
        rt = s[b_ix - 1];
        e[b_ix - 1] = emm1 * r - rt * smm1;
        ztest0 = smm1 * s[b_ix];
        s[b_ix] *= r;
        s[b_ix - 1] = rt * r + emm1 * smm1;
        xrotg_9ZHhnzNd(&s[b_ix - 1], &ztest0, &r, &smm1);
        rt = e[b_ix - 1];
        ztest0 = rt * r + smm1 * s[b_ix];
        s[b_ix] = rt * -smm1 + r * s[b_ix];
        rt = smm1 * e[b_ix];
        e[b_ix] *= r;
      }

      e[m] = ztest0;
      qp1++;
      break;

     default:
      if (s[qq_tmp] < 0.0) {
        s[qq_tmp] = -s[qq_tmp];
      }

      qp1 = qq_tmp + 1;
      while ((qq_tmp + 1 < 3) && (s[qq_tmp] < s[qp1])) {
        rt = s[qq_tmp];
        s[qq_tmp] = s[qp1];
        s[qp1] = rt;
        qq_tmp = qp1;
        qp1++;
      }

      qp1 = 0;
      m--;
      break;
    }
  }

  U[0] = s[0];
  U[1] = s[1];
  U[2] = s[2];
}

//
// File trailer for generated code.
//
// [EOF]
//
