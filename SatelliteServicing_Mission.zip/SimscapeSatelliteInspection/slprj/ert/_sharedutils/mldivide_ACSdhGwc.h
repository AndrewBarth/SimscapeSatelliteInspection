//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: mldivide_ACSdhGwc.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.3
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep  1 10:31:47 2023
//
#ifndef RTW_HEADER_mldivide_ACSdhGwc_h_
#define RTW_HEADER_mldivide_ACSdhGwc_h_
#include "rtwtypes.h"

extern void mldivide_ACSdhGwc(const real_T A[9], const real_T B[9], real_T Y[9]);

#endif                                 // RTW_HEADER_mldivide_ACSdhGwc_h_

//
// File trailer for generated code.
//
// [EOF]
//
