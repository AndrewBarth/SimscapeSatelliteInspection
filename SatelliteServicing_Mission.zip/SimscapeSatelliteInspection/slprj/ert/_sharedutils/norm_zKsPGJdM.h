//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: norm_zKsPGJdM.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.44
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Thu Apr 25 11:51:27 2024
//
#ifndef RTW_HEADER_norm_zKsPGJdM_h_
#define RTW_HEADER_norm_zKsPGJdM_h_
#include "rtwtypes.h"

extern real_T norm_zKsPGJdM(const real_T x[3]);

#endif                                 // RTW_HEADER_norm_zKsPGJdM_h_

//
// File trailer for generated code.
//
// [EOF]
//
