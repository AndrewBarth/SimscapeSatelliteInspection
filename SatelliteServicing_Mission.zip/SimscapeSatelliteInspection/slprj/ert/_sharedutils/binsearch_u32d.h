//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// File: binsearch_u32d.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 4.7
// Simulink Coder version         : 9.8 (R2022b) 13-May-2022
// C/C++ source code generated on : Wed May 24 14:12:28 2023
//
#ifndef RTW_HEADER_binsearch_u32d_h_
#define RTW_HEADER_binsearch_u32d_h_
#include "rtwtypes.h"

extern uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex);

#endif                                 // RTW_HEADER_binsearch_u32d_h_

//
// File trailer for generated code.
//
// [EOF]
//
