//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: svd_7Gu53yjg.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.3
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep  1 10:31:47 2023
//
#include "rtwtypes.h"
#include "svd_7Gu53yjg.h"
#include <cstring>
#include "xnrm2_wVr87xYl.h"
#include "xdotc_aDpSMZ8I.h"
#include "xaxpy_WCvBBQc1.h"
#include "xdotc_hYsJecV0.h"
#include "xaxpy_YEe4MFbz.h"
#include <cmath>
#include "xnrm2_Nr2corQP.h"
#include <emmintrin.h>
#include "xrotg_9ZHhnzNd.h"
#include "xrot_PQNMFBbq.h"
#include "xrot_cHa9XTr0.h"
#include "xswap_66dnrKDh.h"
#include "xswap_TC0Nd8XC.h"
#include "xaxpy_DudtLs4O.h"
#include "xaxpy_096mtG8b.h"

// Function for MATLAB Function: '<S208>/computeTorque'
void svd_7Gu53yjg(const real_T A[18], real_T U[18], real_T s[3], real_T V[9])
{
  __m128d tmp;
  real_T b_A[18];
  real_T Vf[9];
  real_T work[6];
  real_T b_s[3];
  real_T e[3];
  real_T emm1;
  real_T nrm;
  real_T r;
  real_T rt;
  real_T shift;
  real_T smm1;
  real_T sqds;
  int32_T e_k;
  int32_T h;
  int32_T i;
  int32_T kase;
  int32_T qjj;
  int32_T qp1;
  int32_T qq;
  int32_T qq_tmp;
  boolean_T apply_transform;
  boolean_T exitg1;
  std::memcpy(&b_A[0], &A[0], 18U * sizeof(real_T));
  b_s[0] = 0.0;
  e[0] = 0.0;
  b_s[1] = 0.0;
  e[1] = 0.0;
  b_s[2] = 0.0;
  e[2] = 0.0;
  for (i = 0; i < 6; i++) {
    work[i] = 0.0;
  }

  std::memset(&U[0], 0, 18U * sizeof(real_T));
  std::memset(&Vf[0], 0, 9U * sizeof(real_T));
  for (i = 0; i < 3; i++) {
    qp1 = i + 2;
    qq_tmp = 6 * i + i;
    qq = qq_tmp + 1;
    apply_transform = false;
    nrm = xnrm2_wVr87xYl(6 - i, b_A, qq_tmp + 1);
    if (nrm > 0.0) {
      apply_transform = true;
      if (b_A[qq_tmp] < 0.0) {
        nrm = -nrm;
      }

      b_s[i] = nrm;
      if (std::abs(nrm) >= 1.0020841800044864E-292) {
        nrm = 1.0 / nrm;
        h = (qq_tmp - i) + 6;
        qjj = ((((h - qq_tmp) / 2) << 1) + qq_tmp) + 1;
        kase = qjj - 2;
        for (e_k = qq; e_k <= kase; e_k += 2) {
          tmp = _mm_loadu_pd(&b_A[e_k - 1]);
          _mm_storeu_pd(&b_A[e_k - 1], _mm_mul_pd(tmp, _mm_set1_pd(nrm)));
        }

        for (e_k = qjj; e_k <= h; e_k++) {
          b_A[e_k - 1] *= nrm;
        }
      } else {
        h = (qq_tmp - i) + 6;
        qjj = ((((h - qq_tmp) / 2) << 1) + qq_tmp) + 1;
        kase = qjj - 2;
        for (e_k = qq; e_k <= kase; e_k += 2) {
          tmp = _mm_loadu_pd(&b_A[e_k - 1]);
          _mm_storeu_pd(&b_A[e_k - 1], _mm_div_pd(tmp, _mm_set1_pd(b_s[i])));
        }

        for (e_k = qjj; e_k <= h; e_k++) {
          b_A[e_k - 1] /= b_s[i];
        }
      }

      b_A[qq_tmp]++;
      b_s[i] = -b_s[i];
    } else {
      b_s[i] = 0.0;
    }

    for (kase = qp1; kase < 4; kase++) {
      qjj = (kase - 1) * 6 + i;
      if (apply_transform) {
        xaxpy_YEe4MFbz(6 - i, -(xdotc_hYsJecV0(6 - i, b_A, qq_tmp + 1, b_A, qjj
          + 1) / b_A[qq_tmp]), qq_tmp + 1, b_A, qjj + 1);
      }

      e[kase - 1] = b_A[qjj];
    }

    for (kase = i + 1; kase < 7; kase++) {
      qjj = (6 * i + kase) - 1;
      U[qjj] = b_A[qjj];
    }

    if (i + 1 <= 1) {
      nrm = xnrm2_Nr2corQP(e, 2);
      if (nrm == 0.0) {
        e[0] = 0.0;
      } else {
        if (e[1] < 0.0) {
          e[0] = -nrm;
        } else {
          e[0] = nrm;
        }

        nrm = e[0];
        if (std::abs(e[0]) >= 1.0020841800044864E-292) {
          nrm = 1.0 / e[0];
          qjj = ((((2 - i) / 2) << 1) + i) + 2;
          kase = qjj - 2;
          for (qq = qp1; qq <= kase; qq += 2) {
            tmp = _mm_loadu_pd(&e[qq - 1]);
            _mm_storeu_pd(&e[qq - 1], _mm_mul_pd(tmp, _mm_set1_pd(nrm)));
          }

          for (qq = qjj; qq < 4; qq++) {
            e[qq - 1] *= nrm;
          }
        } else {
          qjj = ((((2 - i) / 2) << 1) + i) + 2;
          kase = qjj - 2;
          for (qq = qp1; qq <= kase; qq += 2) {
            tmp = _mm_loadu_pd(&e[qq - 1]);
            _mm_storeu_pd(&e[qq - 1], _mm_div_pd(tmp, _mm_set1_pd(nrm)));
          }

          for (qq = qjj; qq < 4; qq++) {
            e[qq - 1] /= nrm;
          }
        }

        e[1]++;
        e[0] = -e[0];
        for (qjj = qp1; qjj < 7; qjj++) {
          work[qjj - 1] = 0.0;
        }

        for (qjj = qp1; qjj < 4; qjj++) {
          xaxpy_DudtLs4O(5, e[qjj - 1], b_A, 6 * (qjj - 1) + 2, work, 2);
        }

        for (qjj = qp1; qjj < 4; qjj++) {
          xaxpy_096mtG8b(5, -e[qjj - 1] / e[1], work, 2, b_A, 6 * (qjj - 1) + 2);
        }
      }

      for (qjj = qp1; qjj < 4; qjj++) {
        Vf[qjj - 1] = e[qjj - 1];
      }
    }
  }

  i = 1;
  e[1] = b_A[13];
  e[2] = 0.0;
  for (qp1 = 2; qp1 >= 0; qp1--) {
    qq = 6 * qp1 + qp1;
    if (b_s[qp1] != 0.0) {
      for (kase = qp1 + 2; kase < 4; kase++) {
        qjj = ((kase - 1) * 6 + qp1) + 1;
        xaxpy_YEe4MFbz(6 - qp1, -(xdotc_hYsJecV0(6 - qp1, U, qq + 1, U, qjj) /
          U[qq]), qq + 1, U, qjj);
      }

      for (kase = qp1 + 1; kase < 7; kase++) {
        qjj = (6 * qp1 + kase) - 1;
        U[qjj] = -U[qjj];
      }

      U[qq]++;
      for (qjj = 0; qjj < qp1; qjj++) {
        U[qjj + 6 * qp1] = 0.0;
      }
    } else {
      for (qjj = 0; qjj < 6; qjj++) {
        U[qjj + 6 * qp1] = 0.0;
      }

      U[qq] = 1.0;
    }
  }

  for (qp1 = 2; qp1 >= 0; qp1--) {
    if ((qp1 + 1 <= 1) && (e[0] != 0.0)) {
      xaxpy_WCvBBQc1(-(xdotc_aDpSMZ8I(Vf, Vf, 5) / Vf[1]), Vf, 5);
      xaxpy_WCvBBQc1(-(xdotc_aDpSMZ8I(Vf, Vf, 8) / Vf[1]), Vf, 8);
    }

    Vf[3 * qp1] = 0.0;
    Vf[3 * qp1 + 1] = 0.0;
    Vf[3 * qp1 + 2] = 0.0;
    Vf[qp1 + 3 * qp1] = 1.0;
  }

  qp1 = 0;
  nrm = 0.0;
  for (qq = 0; qq < 3; qq++) {
    r = b_s[qq];
    if (r != 0.0) {
      rt = std::abs(r);
      r /= rt;
      b_s[qq] = rt;
      if (qq + 1 < 3) {
        e[qq] /= r;
      }

      qq_tmp = 6 * qq + 1;
      qjj = 6 + qq_tmp;
      kase = qq_tmp + 4;
      for (h = qq_tmp; h <= kase; h += 2) {
        tmp = _mm_loadu_pd(&U[h - 1]);
        _mm_storeu_pd(&U[h - 1], _mm_mul_pd(tmp, _mm_set1_pd(r)));
      }

      for (h = qjj; h <= qq_tmp + 5; h++) {
        U[h - 1] *= r;
      }
    }

    if (qq + 1 < 3) {
      r = e[qq];
      if (r != 0.0) {
        rt = std::abs(r);
        r = rt / r;
        e[qq] = rt;
        b_s[qq + 1] *= r;
        qq_tmp = (qq + 1) * 3 + 1;
        qjj = 2 + qq_tmp;
        for (h = qq_tmp; h <= qq_tmp; h += 2) {
          tmp = _mm_loadu_pd(&Vf[h - 1]);
          _mm_storeu_pd(&Vf[h - 1], _mm_mul_pd(tmp, _mm_set1_pd(r)));
        }

        for (h = qjj; h <= qq_tmp + 2; h++) {
          Vf[h - 1] *= r;
        }
      }
    }

    nrm = std::fmax(nrm, std::fmax(std::abs(b_s[qq]), std::abs(e[qq])));
  }

  while ((i + 2 > 0) && (qp1 < 75)) {
    qq = i + 1;
    exitg1 = false;
    while (!(exitg1 || (qq == 0))) {
      rt = std::abs(e[qq - 1]);
      if (rt <= (std::abs(b_s[qq - 1]) + std::abs(b_s[qq])) *
          2.2204460492503131E-16) {
        e[qq - 1] = 0.0;
        exitg1 = true;
      } else if ((rt <= 1.0020841800044864E-292) || ((qp1 > 20) && (rt <=
                   2.2204460492503131E-16 * nrm))) {
        e[qq - 1] = 0.0;
        exitg1 = true;
      } else {
        qq--;
      }
    }

    if (i + 1 == qq) {
      kase = 4;
    } else {
      qjj = i + 2;
      kase = i + 2;
      exitg1 = false;
      while ((!exitg1) && (kase >= qq)) {
        qjj = kase;
        if (kase == qq) {
          exitg1 = true;
        } else {
          rt = 0.0;
          if (kase < i + 2) {
            rt = std::abs(e[kase - 1]);
          }

          if (kase > qq + 1) {
            rt += std::abs(e[kase - 2]);
          }

          r = std::abs(b_s[kase - 1]);
          if ((r <= 2.2204460492503131E-16 * rt) || (r <=
               1.0020841800044864E-292)) {
            b_s[kase - 1] = 0.0;
            exitg1 = true;
          } else {
            kase--;
          }
        }
      }

      if (qjj == qq) {
        kase = 3;
      } else if (i + 2 == qjj) {
        kase = 1;
      } else {
        kase = 2;
        qq = qjj;
      }
    }

    switch (kase) {
     case 1:
      rt = e[i];
      e[i] = 0.0;
      for (qjj = i + 1; qjj >= qq + 1; qjj--) {
        xrotg_9ZHhnzNd(&b_s[qjj - 1], &rt, &r, &sqds);
        if (qjj > qq + 1) {
          rt = -sqds * e[0];
          e[0] *= r;
        }

        xrot_PQNMFBbq(Vf, 3 * (qjj - 1) + 1, 3 * (i + 1) + 1, r, sqds);
      }
      break;

     case 2:
      rt = e[qq - 1];
      e[qq - 1] = 0.0;
      for (qjj = qq + 1; qjj <= i + 2; qjj++) {
        xrotg_9ZHhnzNd(&b_s[qjj - 1], &rt, &sqds, &smm1);
        r = e[qjj - 1];
        rt = -smm1 * r;
        e[qjj - 1] = r * sqds;
        xrot_cHa9XTr0(U, 6 * (qjj - 1) + 1, 6 * (qq - 1) + 1, sqds, smm1);
      }
      break;

     case 3:
      rt = b_s[i + 1];
      r = std::fmax(std::fmax(std::fmax(std::fmax(std::abs(rt), std::abs(b_s[i])),
        std::abs(e[i])), std::abs(b_s[qq])), std::abs(e[qq]));
      rt /= r;
      smm1 = b_s[i] / r;
      emm1 = e[i] / r;
      sqds = b_s[qq] / r;
      smm1 = ((smm1 + rt) * (smm1 - rt) + emm1 * emm1) / 2.0;
      emm1 *= rt;
      emm1 *= emm1;
      if ((smm1 != 0.0) || (emm1 != 0.0)) {
        shift = std::sqrt(smm1 * smm1 + emm1);
        if (smm1 < 0.0) {
          shift = -shift;
        }

        shift = emm1 / (smm1 + shift);
      } else {
        shift = 0.0;
      }

      rt = (sqds + rt) * (sqds - rt) + shift;
      r = e[qq] / r * sqds;
      for (qjj = qq + 1; qjj <= i + 1; qjj++) {
        xrotg_9ZHhnzNd(&rt, &r, &sqds, &smm1);
        if (qjj > qq + 1) {
          e[0] = rt;
        }

        emm1 = e[qjj - 1];
        r = b_s[qjj - 1];
        e[qjj - 1] = emm1 * sqds - r * smm1;
        rt = smm1 * b_s[qjj];
        b_s[qjj] *= sqds;
        xrot_PQNMFBbq(Vf, 3 * (qjj - 1) + 1, 3 * qjj + 1, sqds, smm1);
        b_s[qjj - 1] = r * sqds + emm1 * smm1;
        xrotg_9ZHhnzNd(&b_s[qjj - 1], &rt, &sqds, &smm1);
        r = e[qjj - 1];
        rt = r * sqds + smm1 * b_s[qjj];
        b_s[qjj] = r * -smm1 + sqds * b_s[qjj];
        r = smm1 * e[qjj];
        e[qjj] *= sqds;
        xrot_cHa9XTr0(U, 6 * (qjj - 1) + 1, 6 * qjj + 1, sqds, smm1);
      }

      e[i] = rt;
      qp1++;
      break;

     default:
      if (b_s[qq] < 0.0) {
        b_s[qq] = -b_s[qq];
        qp1 = 3 * qq + 1;
        qjj = 2 + qp1;
        for (qq_tmp = qp1; qq_tmp <= qp1; qq_tmp += 2) {
          tmp = _mm_loadu_pd(&Vf[qq_tmp - 1]);
          _mm_storeu_pd(&Vf[qq_tmp - 1], _mm_mul_pd(tmp, _mm_set1_pd(-1.0)));
        }

        for (qq_tmp = qjj; qq_tmp <= qp1 + 2; qq_tmp++) {
          Vf[qq_tmp - 1] = -Vf[qq_tmp - 1];
        }
      }

      qp1 = qq + 1;
      while ((qq + 1 < 3) && (b_s[qq] < b_s[qp1])) {
        rt = b_s[qq];
        b_s[qq] = b_s[qp1];
        b_s[qp1] = rt;
        xswap_66dnrKDh(Vf, 3 * qq + 1, 3 * (qq + 1) + 1);
        xswap_TC0Nd8XC(U, 6 * qq + 1, 6 * (qq + 1) + 1);
        qq = qp1;
        qp1++;
      }

      qp1 = 0;
      i--;
      break;
    }
  }

  for (i = 0; i < 3; i++) {
    s[i] = b_s[i];
    V[3 * i] = Vf[3 * i];
    qp1 = 3 * i + 1;
    V[qp1] = Vf[qp1];
    qp1 = 3 * i + 2;
    V[qp1] = Vf[qp1];
  }
}

//
// File trailer for generated code.
//
// [EOF]
//
