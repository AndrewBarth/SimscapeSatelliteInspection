//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: xaxpy_YEe4MFbz.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.3
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep  1 10:31:47 2023
//
#include "rtwtypes.h"
#include "xaxpy_YEe4MFbz.h"

// Function for MATLAB Function: '<S208>/computeTorque'
void xaxpy_YEe4MFbz(int32_T n, real_T a, int32_T ix0, real_T y[18], int32_T iy0)
{
  if (!(a == 0.0)) {
    for (int32_T k{0}; k < n; k++) {
      int32_T tmp;
      tmp = (iy0 + k) - 1;
      y[tmp] += y[(ix0 + k) - 1] * a;
    }
  }
}

//
// File trailer for generated code.
//
// [EOF]
//
