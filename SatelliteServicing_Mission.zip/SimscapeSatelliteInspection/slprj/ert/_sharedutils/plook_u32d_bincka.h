//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: plook_u32d_bincka.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 4.17
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Thu Jul 13 11:00:50 2023
//
#ifndef RTW_HEADER_plook_u32d_bincka_h_
#define RTW_HEADER_plook_u32d_bincka_h_
#include "rtwtypes.h"

extern uint32_T plook_u32d_bincka(real_T u, const real_T bp[], uint32_T maxIndex);

#endif                                 // RTW_HEADER_plook_u32d_bincka_h_

//
// File trailer for generated code.
//
// [EOF]
//
