//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: xdotc_aDpSMZ8I.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.3
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep  1 10:31:47 2023
//
#ifndef RTW_HEADER_xdotc_aDpSMZ8I_h_
#define RTW_HEADER_xdotc_aDpSMZ8I_h_
#include "rtwtypes.h"

extern real_T xdotc_aDpSMZ8I(const real_T x[9], const real_T y[9], int32_T iy0);

#endif                                 // RTW_HEADER_xdotc_aDpSMZ8I_h_

//
// File trailer for generated code.
//
// [EOF]
//
