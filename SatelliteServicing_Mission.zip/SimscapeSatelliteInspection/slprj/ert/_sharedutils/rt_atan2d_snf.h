//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// File: rt_atan2d_snf.h
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 4.7
// Simulink Coder version         : 9.8 (R2022b) 13-May-2022
// C/C++ source code generated on : Wed May 24 14:12:28 2023
//
#ifndef RTW_HEADER_rt_atan2d_snf_h_
#define RTW_HEADER_rt_atan2d_snf_h_
#include "rtwtypes.h"

extern real_T rt_atan2d_snf(real_T u0, real_T u1);

#endif                                 // RTW_HEADER_rt_atan2d_snf_h_

//
// File trailer for generated code.
//
// [EOF]
//
