//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: xswap_TC0Nd8XC.cpp
//
// Code generated for Simulink model 'SatelliteServicing_Mission'.
//
// Model version                  : 5.3
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep  1 10:31:47 2023
//
#include "rtwtypes.h"
#include "xswap_TC0Nd8XC.h"

// Function for MATLAB Function: '<S208>/computeTorque'
void xswap_TC0Nd8XC(real_T x[18], int32_T ix0, int32_T iy0)
{
  for (int32_T k{0}; k < 6; k++) {
    real_T temp;
    int32_T temp_tmp;
    int32_T tmp;
    temp_tmp = (ix0 + k) - 1;
    temp = x[temp_tmp];
    tmp = (iy0 + k) - 1;
    x[temp_tmp] = x[tmp];
    x[tmp] = temp;
  }
}

//
// File trailer for generated code.
//
// [EOF]
//
