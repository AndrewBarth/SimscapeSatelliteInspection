#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
struct ssc_core_kesYKdRukKtCYLfoQ0YRJ5{struct{struct{struct{char const*
ssc_core_kjdqJsJTibClVTmfkrIlFw;char const*ssc_core__qEXoys3NqhTc5aGZjoM0i;}
ssc_core_kvZlvqC1JqdoYahhfIqkPq;struct{char const*
ssc_core_kjdqJsJTibClVTmfkrIlFw;char const*ssc_core__qEXoys3NqhTc5aGZjoM0i;}
ssc_core__CmZebP7mNptWDMef1TTIl;}ssc_core_V01A11djsUSPhydgdGoEM8;struct{struct
{char const*ssc_core__EXYd0BpsApngXjCLU66Qq;char const*
ssc_core_kaKiE6Wj2W0xjHCgFmOiEO;}ssc_core_F0zPq17YGsWWY9f__3XLFE;struct{char
const*ssc_core__EXYd0BpsApngXjCLU66Qq;char const*
ssc_core_kaKiE6Wj2W0xjHCgFmOiEO;char const*ssc_core_V_r1xwjDx7lwguJ2YCpUai;}
ssc_core__YmatZ07z0_k_ulppGYT3M;}ssc_core_kCihPvTAZxpx_H5ihyr_kC;struct{char
const*ssc_core_kpMuDXM8W__FWaXECbGWgq;char const*
ssc_core_kZL4P0QovRSWiqHRt1WIC6;}ssc_core_VWYj_r5wXZ0gbi3aGkkirz;}
ssc_core_VNb3dQocUud1ieYKQWZKSY;struct{struct{char const*
ssc_core_kTdqak9AqCGKcHj5IXmfZe;char const*ssc_core__ZW8YII_QJ4wiHEnAMUOgB;
char const*ssc_core__MNSKfpi3jteauByrrb2q7;}ssc_core_kdx8eT3TLLtTjLxaVSammf;}
ssc_core_Vb8i6ka6Ps0zj9AYvH4Qsj;};extern struct ssc_core_kesYKdRukKtCYLfoQ0YRJ5
ssc_core_VrvQtlpclEKjVTpcoDIr6q;struct ssc_core_kesYKdRukKtCYLfoQ0YRJ5
ssc_core_VrvQtlpclEKjVTpcoDIr6q={{{{
"Nonlinear projector failed to converge, residual norm too large.",
"Nonlinear projector is singular.",},{
"Linear projector failed due to the large residual norm.",
"Linear projector is singular.",},},{{"Constraints are inconsistent.",
"States are inconsistent.",},{"Constraints are inconsistent.",
"States are inconsistent.","Orthogonal projection is singular.",},},{
"Dynamic states are not consistent.",
"Failed to satisfy dynamic state constraints.",},},{{"Equation location is:",
"line %s","(no line number info)",},},};
