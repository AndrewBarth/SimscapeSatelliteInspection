#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
#include "pm_std.h"
typedef struct ssc_core_Fj_dFIC8mwWzaLFg5PWymM ssc_core_FWI1vmgxdR8me9ofVTzx6T
;typedef struct ssc_core_kzD2duJROPp_feaAjCFfnI ssc_core_VdNJjnSb6_lVXTG3JCLKal
;struct ssc_core_kzD2duJROPp_feaAjCFfnI{PmfMessageId(*
mc_kj_oOGqml_xqaXiiWNvUfG)(const ssc_core_VdNJjnSb6_lVXTG3JCLKal*
ssc_core__u7SkOaBUGdCdLyqO2X23S,const NeSystemInput*mc_kDRphcAfRHSbf1ZLKEDW9k)
;PmfMessageId(*ssc_core_k1svScxMAJ41hy4dH9bmSK)(const
ssc_core_VdNJjnSb6_lVXTG3JCLKal*ssc_core__u7SkOaBUGdCdLyqO2X23S,const
NeSystemInput*mc_kDRphcAfRHSbf1ZLKEDW9k);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
ssc_core_VdNJjnSb6_lVXTG3JCLKal*);ssc_core_FWI1vmgxdR8me9ofVTzx6T*
mc_VFNhKLCqbHpDYXjdjCOMmT;};ssc_core_VdNJjnSb6_lVXTG3JCLKal*
ssc_core_Fml092VdhNSIcaKdB4FldR(PmAllocator*mc_FZx3iFiX1YW7j5eEojoAPc);
#include "pm_std.h"
struct ssc_core_Fj_dFIC8mwWzaLFg5PWymM{PmAllocator*
ssc_core_Ff9S1xA4Ip4ZXeljM4_eEa;};static PmfMessageId
ssc_core_kzRZDnhxjoCpf1AdJQu4u9(const ssc_core_VdNJjnSb6_lVXTG3JCLKal*
ssc_core__u7SkOaBUGdCdLyqO2X23S,const NeSystemInput*mc_kDRphcAfRHSbf1ZLKEDW9k)
{(void)ssc_core__u7SkOaBUGdCdLyqO2X23S;(void)mc_kDRphcAfRHSbf1ZLKEDW9k;return
NULL;}static PmfMessageId ssc_core__An1NHhkYqlxVeaS8zuYA6(const
ssc_core_VdNJjnSb6_lVXTG3JCLKal*ssc_core__u7SkOaBUGdCdLyqO2X23S,const
NeSystemInput*mc_kDRphcAfRHSbf1ZLKEDW9k){(void)ssc_core__u7SkOaBUGdCdLyqO2X23S
;(void)mc_kDRphcAfRHSbf1ZLKEDW9k;return NULL;}static void
ssc_core_k4LRDlxGT8xJhur0A3yenA(ssc_core_VdNJjnSb6_lVXTG3JCLKal*
ssc_core__u7SkOaBUGdCdLyqO2X23S){PmAllocator*mc_FZx3iFiX1YW7j5eEojoAPc=
ssc_core__u7SkOaBUGdCdLyqO2X23S->mc_VFNhKLCqbHpDYXjdjCOMmT->
ssc_core_Ff9S1xA4Ip4ZXeljM4_eEa;{void*ssc_core_kk06poLCQlh5i5Yv6GSh7e=(
ssc_core__u7SkOaBUGdCdLyqO2X23S->mc_VFNhKLCqbHpDYXjdjCOMmT);if(
ssc_core_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FZx3iFiX1YW7j5eEojoAPc)->mFreeFcn(
mc_FZx3iFiX1YW7j5eEojoAPc,ssc_core_kk06poLCQlh5i5Yv6GSh7e);}};{void*
ssc_core_kk06poLCQlh5i5Yv6GSh7e=(ssc_core__u7SkOaBUGdCdLyqO2X23S);if(
ssc_core_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FZx3iFiX1YW7j5eEojoAPc)->mFreeFcn(
mc_FZx3iFiX1YW7j5eEojoAPc,ssc_core_kk06poLCQlh5i5Yv6GSh7e);}};}
ssc_core_VdNJjnSb6_lVXTG3JCLKal*ssc_core_Fml092VdhNSIcaKdB4FldR(PmAllocator*
mc_FZx3iFiX1YW7j5eEojoAPc){ssc_core_VdNJjnSb6_lVXTG3JCLKal*
ssc_core_VNb3dQocUud1ieYKQWZKSY=(ssc_core_VdNJjnSb6_lVXTG3JCLKal*)((
mc_FZx3iFiX1YW7j5eEojoAPc)->mCallocFcn((mc_FZx3iFiX1YW7j5eEojoAPc),(sizeof(
ssc_core_VdNJjnSb6_lVXTG3JCLKal)),(1)));ssc_core_FWI1vmgxdR8me9ofVTzx6T*
mc__d1alWYexptL_X5HTFhbNK=(ssc_core_FWI1vmgxdR8me9ofVTzx6T*)((
mc_FZx3iFiX1YW7j5eEojoAPc)->mCallocFcn((mc_FZx3iFiX1YW7j5eEojoAPc),(sizeof(
ssc_core_FWI1vmgxdR8me9ofVTzx6T)),(1)));mc__d1alWYexptL_X5HTFhbNK->
ssc_core_Ff9S1xA4Ip4ZXeljM4_eEa=mc_FZx3iFiX1YW7j5eEojoAPc;
ssc_core_VNb3dQocUud1ieYKQWZKSY->mc_kj_oOGqml_xqaXiiWNvUfG=
ssc_core_kzRZDnhxjoCpf1AdJQu4u9;ssc_core_VNb3dQocUud1ieYKQWZKSY->
ssc_core_k1svScxMAJ41hy4dH9bmSK=ssc_core__An1NHhkYqlxVeaS8zuYA6;
ssc_core_VNb3dQocUud1ieYKQWZKSY->mc_VYGWBho6N1K_eyHOMGjDiW=
ssc_core_k4LRDlxGT8xJhur0A3yenA;ssc_core_VNb3dQocUud1ieYKQWZKSY->
mc_VFNhKLCqbHpDYXjdjCOMmT=mc__d1alWYexptL_X5HTFhbNK;return
ssc_core_VNb3dQocUud1ieYKQWZKSY;}
