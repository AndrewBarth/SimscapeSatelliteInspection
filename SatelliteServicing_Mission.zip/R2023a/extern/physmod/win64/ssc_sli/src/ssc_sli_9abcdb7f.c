#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "pm_std.h"
#include "stdarg.h"
typedef NeuDiagnosticTree*ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E;typedef struct
ssc_st__0atO_17n_Ci_qYhoCxFUV ssc_st_F04yXT_zz14zgHdLildPgK;struct
NeuDiagnosticManagerTag{ssc_st_F04yXT_zz14zgHdLildPgK*mPrivateData;
ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E(*ssc_st_VESUSzIzeRWSV1xYVr5zH5)(const
NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z);void(*
ssc_st__RtuwtEn2c_yh1OySiqODN)(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,va_list args);void(*
ssc_st__YxE_N42_idoWyreGeTz9t)(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,va_list args);void(*
ssc_st_kAPwXpB5miCGVLsko_7ONE)(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE);void(*ssc_st__u9riBfE3RK3ZXQpAXjZW_)(const
NeuDiagnosticManager*ssc_st_FgQH451kC4lOZ5A2coatZe,const NeuDiagnosticManager*
src);const NeuDiagnosticTree*(*ssc_st_kqsZroyTBbpjb1za_BT1dv)(const
NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z)
;};PmfMessageId ssc_st_Fj4pG1CbqChThqCdYV3xux(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,...);PmfMessageId
ssc_st_FqMmOIGGjkpTZ58Esd_XuA(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,...);PmfMessageId
ssc_st_F5XP0Is_HAWucugpsjE8XK(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,...);PmfMessageId
ssc_st__w8As0Yf6B8Ji9iMi5WOGi(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,const char*
ssc_st_kvsOBKjJwlx5dTxrw7qAwS);PmfMessageId ssc_st__xrkslL_b0pOemBxsxBQx0(
const NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z,NeuDiagnosticLevel
ssc_st_FlRsyRMpiRpNY9kP14dKKM,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,const
char*ssc_st_kvsOBKjJwlx5dTxrw7qAwS);NeuDiagnosticManager*
neu_create_diagnostic_manager(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z);void
neu_destroy_diagnostic_manager(NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z);struct ssc_sli_k0S3nHzmyBtrX5U5QySkQ9{
PmSparsityPattern ssc_sli__lXoynJWcyhzayn0Hpkb2h;PmRealVector
ssc_sli_FmCjnlfy_Hlxba5hUdQ_7e;PmSparsityPattern ssc_sli_knMQ448fB683_eZbo4QDBU
;PmRealVector ssc_sli_F7RM_m_3oqh9_5wZCDdWHu;PmRealVector
ssc_sli_FmDhajaV6M0fdyKW3qk1_r;};typedef struct ssc_sli_k0S3nHzmyBtrX5U5QySkQ9
ssc_sli_Vzq7l2SdEQKDfDnfuswdjB;struct ssc_sli__ri7VJBwLPW9X1bO9uXMqs{
PmSparsityPattern ssc_sli_V5IQq4r_lx_4au004QC5wp;PmRealVector
ssc_sli_FMPtcQjw_q0fbiVUu569M3;PmSparsityPattern ssc_sli_ktRyvEF_03dgjuePPwPWZY
;PmRealVector ssc_sli_kgprbt2Kb8KEjulqbNMwHQ;PmRealVector
ssc_sli_Fe9Lz59VCoSBW9N3RO80o9;};typedef struct ssc_sli__ri7VJBwLPW9X1bO9uXMqs
ssc_sli_VGTmDQrTHVdDhX3yJWx1ej;struct ssc_sli__fATcOHUA1_8_msM_IL3mi{
ssc_sli_Vzq7l2SdEQKDfDnfuswdjB ssc_sli_VD3ZIoItPAxs_epBnhrnzB,
ssc_sli__f1Ztz_4Ko0DiyeAGi9pem;ssc_sli_VGTmDQrTHVdDhX3yJWx1ej
ssc_sli_V0qpSTdv02KbfiwiN61OSS;PmRealVector ssc_sli__BqVhX3A9xxQjieVZkGaSx;
real_T ssc_sli__TdXi7D_QctFeq_GuzE4uI;boolean_T ssc_core_VA9mbbfJfEpYb18iLHpsqK
;};typedef struct ssc_sli__fATcOHUA1_8_msM_IL3mi ssc_sli_kvQ5MfaAL6_ogiFAf_WuWW
;typedef void(*ssc_sli_FrKHFOOWZv0kbHnKPHakDv)(void*,PmCharVector);typedef
struct ssc_sli_FMF6JOM1KOxqeuBsCAQyB5{void*ssc_sli_V9G3clQtGo8rdHdO1JS52K;
ssc_sli_FrKHFOOWZv0kbHnKPHakDv ssc_sli_FRiVh68ViPKEg9hf4_Ug13;
ssc_sli_FrKHFOOWZv0kbHnKPHakDv ssc_sli_V0uWhYNCPl0kdXnb4REJgP;}
ssc_sli__dMka2DXsGloW9fCe3aDyi;boolean_T ic_solve_impl(PmRealVector*x,const
PmRealVector*mc_kEbBObcYFIxUZ5_77V3CO_,const ssc_sli_kvQ5MfaAL6_ogiFAf_WuWW*
ssc_sli_F_8iIeoxoi8wXeTxIwi_Uu,const ssc_sli__dMka2DXsGloW9fCe3aDyi*
mc__LOE3NllYqGGcHiwg6fX5o,NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z);
#include "math.h"
#include "string.h"
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);int_T pm_kkW9oQAVI7Wt_9Rzuat5bx(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,size_t pm_keOJjiAyBTtFhyWf033kni,
size_t pm_kJxontPsxndNYXwDXdE1iy,size_t pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);PmSparsityPattern*pm_create_sparsity_pattern(size_t
pm_keOJjiAyBTtFhyWf033kni,size_t pm_kJxontPsxndNYXwDXdE1iy,size_t
pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kTFq3qlgTulWiT6pafkmmT(PmSparsityPattern*pm__56dBn4vKXWjZ1nclFRYZB,const
PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);boolean_T
pm__ZRI70SuGwhmamUtcsoyxS(const PmSparsityPattern*pm__56dBn4vKXWjZ1nclFRYZB,
const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);PmSparsityPattern*
pm_FQMLyYzCQ5CtgHjze1nNJP(const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_FvcKvutPfxG9Xe1kjs7gg0(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);void pm_VYooJBURCwKrVu6RXzQZ_5(PmSparsityPattern*
pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm__YwdRBXissh3bPWPl30Fpe(size_t pm_FW8nEXbTFjdJhTIKepsgFT,
size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm_FFniD_kRQg_JWTYc5cmjGs(size_t pm_FW8nEXbTFjdJhTIKepsgFT,
size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm_FhqtSrxlPotrcypQHJ9Dcq(size_t pm__lqjegyKuwStj56WZLiC_e,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*
pm__TNI3M36rThlaTetY4tWiB(size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);
#include "pm_std.h"
PmSparsityPattern*mc_kAZzxJsz9tloc11S9uThaF(const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
mc_klSR73f0rO4LhXVlV6gmb7(real_T*mc_FkvBQdfnWOCY_uJC_r4riI,const
PmSparsityPattern*mc__z_znac6SDtIeyvo_HaL8F,const real_T*A,const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI);PmSparsityPattern*
mc__OkC5ssIRclKeDF7PdRNWG(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmIntVector*mc_kbzF46WM0FtKWeE0s7WR95,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void mc_VgJ42P0i5f4Hby5_Ow7gtm(real_T*
mc__nB0POFEJkOOXDZjc8BZu5,const PmSparsityPattern*mc__G8DEE_sSylod1iLuXNmpS,
const real_T*A,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const
PmIntVector*mc_kbzF46WM0FtKWeE0s7WR95);PmSparsityPattern*
mc__tKZgLZup1pKXLQCAtP8rU(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmIntVector*mc_kbzF46WM0FtKWeE0s7WR95,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void mc_kpAmYrZzcKGOgq9qpxzj07(real_T*
mc__nB0POFEJkOOXDZjc8BZu5,const PmSparsityPattern*mc__G8DEE_sSylod1iLuXNmpS,
const real_T*A,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const
PmIntVector*mc_kbzF46WM0FtKWeE0s7WR95,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void mc_FXA9yTEpI9pfhyLrn8ZGts(PmSparsityPattern*mc_VO4ezo9C6qdUWq1Fln4EVt,
PmRealVector*mc_kfuTzKNJF8C9XawgZFM5k9);PmSparsityPattern*
mc_V_3Bm28Cx08dj9ZMdrwaJg(const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,
const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const PmBoolVector*
mc_F50LHIM89Xpj_mZvqqCQnH,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*mc__qAqv2Z2m7K0VPPGKiCpwD(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const
PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*mc__mBVa3_c658wjuT_cJe_Qy(const PmSparsityPattern*b,const
PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa,PmAllocator*mc_FZx3iFiX1YW7j5eEojoAPc);void
mc_Fv2sZggivbSOc5zulDbRra(const PmRealVector*mc_k5z61obNZCWCbyygZn_fdK,const
real_T*mc__uV9GcaXWFlx_5jfPip5Mo,const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const
PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH);PmSparsityPattern*
mc__JB9jUvbb10FaTie1cmY8_(const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,
size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t mc_knvTkz3vM6t4a9WNgNRMzB,size_t
mc_VGPLyQQmjMlldLbUiddSkc,size_t mc_Fp_w9JW6vqt5eXL55IL0g1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*mc_VINzQey3e2GxYDxzr7cOY_(const
PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,size_t mc_Fxvltms7Im4baT5ZPxj7f2,
size_t mc_knvTkz3vM6t4a9WNgNRMzB,size_t mc_VGPLyQQmjMlldLbUiddSkc,size_t
mc_Fp_w9JW6vqt5eXL55IL0g1,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
mc_Fzylow9cnZxIhyL1O9nM0I(const PmRealVector*mc_VIutEr_JmfWNeDyKonnHVk,const
PmRealVector*mc_VW_HqYZElHCjWHwd6Iv4ON,const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t
mc_knvTkz3vM6t4a9WNgNRMzB,size_t mc_VGPLyQQmjMlldLbUiddSkc,size_t
mc_Fp_w9JW6vqt5eXL55IL0g1);void mc_FY8ifnDZsXphdqo3UGrtOk(PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,size_t n);void mc_kNxwVTI76g4kj9P52yKhA5(
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,size_t n);PmSparsityPattern*
mc_kNYMmfXA1XtHcmiWCr7l_C(const PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*
mc_VJlBwQnSeLpciXVTLb_llB(const PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*
mc__5C6m_ZyP9_NYekcJCEULM(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void mc__8x7kz_627_gXDli_FJo22(const PmRealVector*
mc_kuYGZlr6GiOSeqresCsPcM,const PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR,
const PmRealVector*mc_FmeGGSq6P2_Kg9j7twxwci,const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,const PmRealVector*mc_FQSQWg_QFOKIWm9DWdLQR6,const
PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,const PmRealVector*
mc_krOJvR5Qa1KQZu3eEsQtEU);PmSparsityPattern*mc_kyCwDjPxmBGRiTH73vrjJL(const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const PmSparsityPattern*
mc_VLr_Ia18P_8icXM9WFOfYI,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
mc__tyTSVoY7fpafmg4sUl1P3(const PmRealVector*mc_kuYGZlr6GiOSeqresCsPcM,const
PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR,const PmRealVector*
mc_FmeGGSq6P2_Kg9j7twxwci,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmRealVector*mc_FQSQWg_QFOKIWm9DWdLQR6,const PmSparsityPattern*
mc_VLr_Ia18P_8icXM9WFOfYI,const PmRealVector*mc_krOJvR5Qa1KQZu3eEsQtEU);
PmSparsityPattern*mc_kAJ3geuq0o8ebTsVAocwxT(const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void mc__Z9st0ivzkt_c5ayYUNbbq(const
PmRealVector*mc_kuYGZlr6GiOSeqresCsPcM,const PmSparsityPattern*
mc__ILFYYSbi7hW_uYs_eHsRR,const PmRealVector*mc_FmeGGSq6P2_Kg9j7twxwci,const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const PmRealVector*
mc_FQSQWg_QFOKIWm9DWdLQR6,const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,
const PmRealVector*mc_k0iOHO6BSf8IgTo550ELD8,const PmIntVector*
mc_kQx8tFCixwhfgiAY_Pi8wJ,const int mc___aedK39Pax6Ziebprhh0i);
PmSparsityPattern*mc_VI58f6RQKXS_Y5sclnoOPT(const PmSparsityPattern*a,const
PmSparsityPattern*b,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
#include "mc_std.h"
const McLinearAlgebraFactory*mc_get_csparse_linear_algebra(void);
#include "mc_std.h"
const McLinearAlgebraFactory*mc_get_csparse_rect_la(void);typedef struct
ssc_core_V9ruOSVbJAWZjuCR6XC_ZQ NeDae;typedef struct
ssc_core_FA8XEJR378pZY90nzcNDHK ssc_core_FUa6G82CLwKVie8oX5VDDu;typedef struct
ssc_core_kn2fkwOG390ucqMrkmBlTh ssc_core__vkZ3rfXeilTgHxrnS_l_7;typedef enum
ssc_core__4VOsIDToP0seTqpZ3OzBF{ssc_core_V6MH6x1to0xiZi0r6HsmD3= -1,
ssc_core_VDWQ52Z_V_4ce51ah_UGdx,ssc_core_koP_545U7Zp5Ymq02vu8dY,
ssc_core__2lwYHDzLZOn_X5J_fTSrd}ssc_core__4VOsIDToP0seTqpZ3OzBF;
ssc_core__4VOsIDToP0seTqpZ3OzBF ssc_core_FTzoitpYys8Aca2krGVZIS(void);void
ssc_core_VNQfrZTwQlSWia9xYHLPOQ(ssc_core__4VOsIDToP0seTqpZ3OzBF
ssc_core_VCMJww_KdPWKZDGZRw9nff);struct ssc_sli_kesYKdRukKtCYLfoQ0YRJ5{struct{
char const*ssc_sli_kA2O5ZswGt0GVaVR84AuTw;char const*
ssc_sli__Bh8L4iqdX0_gLkWHYCQN7;char const*ssc_sli_kdWyvurcxiWehyP0izpTrD;char
const*ssc_sli_FlQoCaxGmXCIXqitNSBxCU;char const*ssc_sli_Vr71R70CiapZbX8qSMxIRN
;char const*ssc_sli__r8NA2fHq_pdfTESDJl1_G;char const*
ssc_sli__xovyjU57Y8FguejP_eile;char const*ssc_sli__o2BHn0xC_hmhLL4u_UKlc;}
ssc_sli_VWMOD1ZJGDOAh1lnUsU4Uv;struct{char const*
ssc_sli_F0vla7hNn_0mf9149ste0X;char const*ssc_sli_VaXBNWcDjlxNh1jXvxNxcO;char
const*ssc_sli_VO_GhmqCz3h_ai9ip0AFrK;char const*ssc_sli_Vz1SKdYPN6_UYa5DQD9joB
;}ssc_sli_F4d46ozc4zdajyb7_f1vQT;struct{char const*
ssc_sli__J_WYAHczoKPaqXAQxwfYA;char const*ssc_sli_VNit5INJl8Gvgu9ygyKeRK;char
const*ssc_sli__i6v9zrssKdTVX6TwDRHYF;char const*ssc_sli_VK6W_CYqut_9duBNpo_NW_
;char const*ssc_sli_F9NdORwOpASrWmnDp_z_JI;char const*
ssc_sli_kREVjw5hQ7_Vgm_LqrMa_1;char const*ssc_sli_kcgW4UVG5USUf9f9YEc2nR;char
const*ssc_sli_VJ5Ejyvd5AOng9VcQKGenn;char const*ssc_sli_F8vzSvsWvJt4Y9mcFrhG03
;char const*ssc_sli__lBbJMjmnR89ge8iIZdac7;char const*
ssc_sli_F87n8LtJP6_ueiUWaPIqkY;char const*ssc_sli__R171_hVWNCKh1e1WolPTv;char
const*ssc_sli_kFWAsbOdlhpEjiLbrpFY84;char const*ssc_sli_FFEzYYFx9BCngDIKd0TIqO
;char const*ssc_sli__3yFY3ZhQx0VcaZYx_NzD6;char const*
ssc_sli_VfqOLabH8ipKVyWtojrug_;char const*ssc_sli_kCTuGPOAFtl1WiUF49NYa_;char
const*ssc_sli_VQ8ugq_HLOt8eXpxYSUYdG;char const*ssc_sli_FtYvMDVruoW8aucOScHo_c
;char const*ssc_sli_FoSY_fgumaKghmPc2zrBG3;char const*
ssc_sli__7bWMC3RmStmdypJC0uhyQ;char const*ssc_sli_kxlVNXTqwySAVi87i5IVCz;char
const*ssc_sli_VrCPh19MYu86g5vE9qSzAL;char const*ssc_sli_FnHeQnKLAM_7jqJrp3FONm
;char const*ssc_sli_V5buasEG6qCPYihPXblrw7;char const*
ssc_sli_V2CJIefQ61O9iTLsScW8Sv;char const*ssc_sli__zWqfX80Ykdyc1OiceR6vw;char
const*ssc_sli_FYRsBSSApRKUh5qxlGFDAd;char const*ssc_sli_VXvEzafsAY0meX2uKw9wW8
;}ssc_sli_k9czt_jnl5_CeqQbj6K4QZ;struct{char const*
ssc_sli_FhqoQ_bs_lGVcaAOk71Xsl;}ssc_sli_FJmvGQBFuuGy_msJoDLodF;};extern struct
ssc_sli_kesYKdRukKtCYLfoQ0YRJ5 ssc_sli_VqKh4Kz_QZS0XmkDAghkEa;struct
ssc_sli_kesYKdRukKtCYLfoQ0YRJ5 ssc_sli_VqKh4Kz_QZS0XmkDAghkEa={{
"When local solver is selected, the NDF2 local solver choice is not supported. Either unselect local solver, or choose Backward Euler or Trapezoidal Rule on the Solver Configuration block instead."
,"%s",
"Simscape succeeded in finding consistent states with which to start the simulation, but the states found may deviate from requested initial conditions."
,"Here is the set of components with unconverged equations:\n%s",
"Nonlinear solver to advance time one step failed to converge due to Linear Algebra error. Failed to solve using iteration matrix.\n"
,"Nonlinear solver to advance time one step failed to converge.\n",
"Nonlinear solver to advance time one step failed to converge, residual norm too large.\n"
,"Variable-step local solver failed to meet tolerance.",},{
"Insufficient memory budget for delay expressions history.",
"Simscape fixed-cost simulation configuration not supported with Simulink model configured to use local solver when referencing the model. Either disable the Use local solver when referencing model check box on the Model Referencing pane of the Configuration Parameters dialog box, or disable the Use fixed-cost runtime consistency iterations check box in the Solver Configuration block."
,
"Detected inconsistent parameters specified with simset or in the model reference hierarchy. Use the same settings for Solver, StartTime and FixedStep in the top model and all referenced models."
,"Unable to restore SimState due to model changes.",},{
"Failed to diagnose failure.",
"The Simscape network contains frequency-domain equations. Transient simulation of such networks is not allowed."
,
"Explicit solvers are not supported in frequency-time equation formulation. Choose an implicit solver (ode14x, ode15s, or ode23t) or use local solver."
,"%s","%s","%s","%s",
"First solve for initial conditions failed to converge. Trying again with all high priorities relaxed to low."
,
"Second solve for initial conditions failed to converge. Trying again with all variable targets ignored."
,
"Detected inconsistent solvers specified with simset or in the model reference hierarchy. Use the same solver in the top model and all referenced models."
,
"Detected nonfinite (Inf or NaN) values while evaluating equations or their partial derivatives at the start of initialization. Such equations may cause the initialization solve to fail. In order to fix this problem, you can either modify some equations or set different prestart values for some of the variables involved. The equations are listed below, as well as their prestart values in computational units.\n%s"
,"%s",
"Transient initialization at time %s, solving for consistent states with the modes of the model fixed, failed to converge."
,
"Transient initialization at time %s, solving for consistent states and modes, failed to converge."
,
"Solving for consistent states with discrete states of the model fixed failed to converge at time %s."
,"Steady state solve failed to converge.",
"Initial conditions solve failed to converge.","Stiffness diagnostic failed.",
"State derivative calculation failed, possibly due to singular upper-left (differential states and equations) corner of mass matrix."
,"Calculation for differential and algebraic state derivatives failed.","%s",
"... (Truncated error message at maximum length of buffer.)",
"Event iteration failed to converge within the iteration limit (100).",
"Nonlinear solver: Linear Algebra error. Failed to solve using iteration matrix."
,"Nonlinear solver failed to converge.",
"Nonlinear solver: failed to converge, residual norm too large.",
"Here is the set of components with unconverged equations:\n%s",
"Failed to update switched linear model, due to system singularity in current configuration."
,"The following event variables changed at the last allowed iteration:\n%s",},
{
"All discrete sample times in your model must be an integer multiple of the local solver sample time."
,},};boolean_T ssc_sli_kGp8empIuW0egibdYVnVuN(PmRealVector*
ssc_sli_kocfPzNL1b_Mda0uIxPLZf,const PmRealVector*
ssc_sli_kyPax65oMi4_e5Xhtl62wu,const PmRealVector*x,const PmRealVector*
ssc_sli_kpqrQkK0B44th5MJ4yHNtD,const PmSparsityPattern*
ssc_sli__nMMeWOrYSh_aXgWvg8TWf,real_T ssc_sli_kGdic_uNOGlMia8duIA_YD){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a,mc_VLHhnPUiNQpve5VIL9P3O9=
ssc_sli_kyPax65oMi4_e5Xhtl62wu->mN;mc_VWnvos7Q548uVH7p0208jN(
ssc_sli_kocfPzNL1b_Mda0uIxPLZf,-1.0,ssc_sli_kyPax65oMi4_e5Xhtl62wu);
mc_kM_Y9u9U2F_Cf9sWAtmMMu(ssc_sli_kocfPzNL1b_Mda0uIxPLZf,
ssc_sli_kpqrQkK0B44th5MJ4yHNtD,ssc_sli__nMMeWOrYSh_aXgWvg8TWf,x);for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(fabs(
ssc_sli_kocfPzNL1b_Mda0uIxPLZf->mX[mc_kwrB3ZoKf7OufTHWaHJV7a])>
ssc_sli_kGdic_uNOGlMia8duIA_YD){return false;}}return true;}boolean_T
ssc_sli_V7x4aATsVDO_WT7TnWOlu0(PmRealVector*ssc_sli_VG7xz2DynISkZDd40j79gN,
const PmRealVector*ssc_sli__NMmY0gfBDtrZaRkl7pJkL,const PmSparsityPattern*
ssc_sli_k8IwWyECqp4qbihJER_wTZ,PmRealVector*ssc_sli_kFbR0TCYZZ8ldecODErbOB,
boolean_T ssc_sli_Fqds_sOzyJ8RhyS1RHd0Rh,PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z
){const McLinearAlgebraFactory*ssc_sli__RaoL3gcnqtvbqvTOI8tAN=
ssc_sli_Fqds_sOzyJ8RhyS1RHd0Rh?mc_get_csparse_linear_algebra():
mc_get_csparse_rect_la();McLinearAlgebra*la=NULL;McLinearAlgebraStatus
ssc_sli_k4M7bSEmThKJbirXUDQgS6=MC_LA_OK;ssc_sli_k4M7bSEmThKJbirXUDQgS6=
ssc_sli__RaoL3gcnqtvbqvTOI8tAN->mCreateLinearAlgebra(
ssc_sli__RaoL3gcnqtvbqvTOI8tAN,&la,ssc_sli_k8IwWyECqp4qbihJER_wTZ);if(
ssc_sli_k4M7bSEmThKJbirXUDQgS6!=MC_LA_OK){return false;}
ssc_sli_k4M7bSEmThKJbirXUDQgS6=la->mFactor(la,ssc_sli__NMmY0gfBDtrZaRkl7pJkL->
mX);if(ssc_sli_k4M7bSEmThKJbirXUDQgS6!=MC_LA_OK){la->mDestructor(la);return
false;}ssc_sli_k4M7bSEmThKJbirXUDQgS6=la->mSolve(la,
ssc_sli__NMmY0gfBDtrZaRkl7pJkL->mX,ssc_sli_VG7xz2DynISkZDd40j79gN->mX,
ssc_sli_kFbR0TCYZZ8ldecODErbOB->mX);la->mDestructor(la);return
ssc_sli_k4M7bSEmThKJbirXUDQgS6==MC_LA_OK;}boolean_T
ssc_sli_Vfv6spxTpFOWb1HlQPIyNs(PmRealVector*ssc_core_Fi_9SaM2iHSHiy7LMBOqpC,
const PmRealVector*ssc_sli_FqTWkJphhedNi9LxNaZAUX,const PmRealVector*
ssc_sli__cSSln_j7Q4KimI4m_qozs,const PmSparsityPattern*
ssc_sli_k_ySqNmShXC7j1vNVMvepG,PmRealVector*ssc_sli_kyPax65oMi4_e5Xhtl62wu,
real_T ssc_sli_kGdic_uNOGlMia8duIA_YD,PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z){
boolean_T ssc_sli_k4M7bSEmThKJbirXUDQgS6;PmRealVector*
ssc_sli_kocfPzNL1b_Mda0uIxPLZf,*x;size_t mc_kwrB3ZoKf7OufTHWaHJV7a,
ssc_sli_F9XXYvbW1X_RXP6D2uUU48=ssc_sli_FqTWkJphhedNi9LxNaZAUX->mN,
ssc_core__Mwijnrb0M46cT7T_bvxpH=ssc_sli_kyPax65oMi4_e5Xhtl62wu->mN;
ssc_sli_kocfPzNL1b_Mda0uIxPLZf=pm_create_real_vector(
ssc_core__Mwijnrb0M46cT7T_bvxpH,mc_FOGg0ZWot2WdYenO8zaD4Z);x=
pm_create_real_vector(ssc_sli_F9XXYvbW1X_RXP6D2uUU48,mc_FOGg0ZWot2WdYenO8zaD4Z
);mc_VWnvos7Q548uVH7p0208jN(ssc_sli_kocfPzNL1b_Mda0uIxPLZf,-1.0,
ssc_sli_kyPax65oMi4_e5Xhtl62wu);mc_kM_Y9u9U2F_Cf9sWAtmMMu(
ssc_sli_kocfPzNL1b_Mda0uIxPLZf,ssc_sli__cSSln_j7Q4KimI4m_qozs,
ssc_sli_k_ySqNmShXC7j1vNVMvepG,ssc_sli_FqTWkJphhedNi9LxNaZAUX);
ssc_sli_k4M7bSEmThKJbirXUDQgS6=ssc_sli_V7x4aATsVDO_WT7TnWOlu0(x,
ssc_sli__cSSln_j7Q4KimI4m_qozs,ssc_sli_k_ySqNmShXC7j1vNVMvepG,
ssc_sli_kocfPzNL1b_Mda0uIxPLZf,false,mc_FOGg0ZWot2WdYenO8zaD4Z);if(
ssc_sli_k4M7bSEmThKJbirXUDQgS6){ssc_sli_k4M7bSEmThKJbirXUDQgS6=
ssc_sli_kGp8empIuW0egibdYVnVuN(ssc_sli_kocfPzNL1b_Mda0uIxPLZf,
ssc_sli_kocfPzNL1b_Mda0uIxPLZf,x,ssc_sli__cSSln_j7Q4KimI4m_qozs,
ssc_sli_k_ySqNmShXC7j1vNVMvepG,ssc_sli_kGdic_uNOGlMia8duIA_YD);if(
ssc_sli_k4M7bSEmThKJbirXUDQgS6){for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<ssc_sli_F9XXYvbW1X_RXP6D2uUU48;
mc_kwrB3ZoKf7OufTHWaHJV7a++){ssc_core_Fi_9SaM2iHSHiy7LMBOqpC->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=ssc_sli_FqTWkJphhedNi9LxNaZAUX->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]-x->mX[mc_kwrB3ZoKf7OufTHWaHJV7a];}}}
pm_destroy_real_vector(x,mc_FOGg0ZWot2WdYenO8zaD4Z);pm_destroy_real_vector(
ssc_sli_kocfPzNL1b_Mda0uIxPLZf,mc_FOGg0ZWot2WdYenO8zaD4Z);return
ssc_sli_k4M7bSEmThKJbirXUDQgS6;}boolean_T ssc_sli_khxq08nmaIlbcL_XAfqtwp(
PmRealVector*x,const PmSparsityPattern*ssc_sli_k_ySqNmShXC7j1vNVMvepG,const
PmRealVector*ssc_sli__cSSln_j7Q4KimI4m_qozs,const PmSparsityPattern*
ssc_sli__62DIq3x8_tOWH_o3cBG1t,const PmRealVector*
ssc_sli_kAduLAz6omh2XX0mOzAgfo,const PmRealVector*
ssc_sli_Vf6f_Xv03At_eHCaXslA_l,const PmRealVector*mc_Vi4Cp0qK964NYTFMGr9Ttn,
const PmRealVector*ssc_sli_FqTWkJphhedNi9LxNaZAUX,real_T
ssc_sli_kGdic_uNOGlMia8duIA_YD){size_t mc_kwrB3ZoKf7OufTHWaHJV7a;boolean_T
ssc_sli__TlE87LNm5C0YiLrL3Roi_=false;const size_t
ssc_sli_F9XXYvbW1X_RXP6D2uUU48=ssc_sli_FqTWkJphhedNi9LxNaZAUX->mN,n=
ssc_sli_Vf6f_Xv03At_eHCaXslA_l->mN;PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=
pm_default_allocator();PmRealVector*ssc_sli_krZ4mEqeUvGreaRgDiVlrW,*
ssc_sli_FeVcFpO_arpYVL1p0ki1An,*ssc_sli_kyPax65oMi4_e5Xhtl62wu;
ssc_sli_krZ4mEqeUvGreaRgDiVlrW=pm_create_real_vector(n,
mc_FOGg0ZWot2WdYenO8zaD4Z);ssc_sli_FeVcFpO_arpYVL1p0ki1An=
pm_create_real_vector(n,mc_FOGg0ZWot2WdYenO8zaD4Z);
ssc_sli_kyPax65oMi4_e5Xhtl62wu=pm_create_real_vector(n,
mc_FOGg0ZWot2WdYenO8zaD4Z);for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<ssc_sli_F9XXYvbW1X_RXP6D2uUU48;
mc_kwrB3ZoKf7OufTHWaHJV7a++){ssc_sli_FeVcFpO_arpYVL1p0ki1An->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=ssc_sli_FqTWkJphhedNi9LxNaZAUX->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}pm_rv_equals_rv(ssc_sli_kyPax65oMi4_e5Xhtl62wu,
ssc_sli_Vf6f_Xv03At_eHCaXslA_l);mc_kM_Y9u9U2F_Cf9sWAtmMMu(
ssc_sli_kyPax65oMi4_e5Xhtl62wu,ssc_sli_kAduLAz6omh2XX0mOzAgfo,
ssc_sli__62DIq3x8_tOWH_o3cBG1t,mc_Vi4Cp0qK964NYTFMGr9Ttn);
ssc_sli__TlE87LNm5C0YiLrL3Roi_=ssc_sli_Vfv6spxTpFOWb1HlQPIyNs(
ssc_sli_krZ4mEqeUvGreaRgDiVlrW,ssc_sli_FeVcFpO_arpYVL1p0ki1An,
ssc_sli__cSSln_j7Q4KimI4m_qozs,ssc_sli_k_ySqNmShXC7j1vNVMvepG,
ssc_sli_kyPax65oMi4_e5Xhtl62wu,ssc_sli_kGdic_uNOGlMia8duIA_YD,
mc_FOGg0ZWot2WdYenO8zaD4Z);if(ssc_sli__TlE87LNm5C0YiLrL3Roi_){for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
ssc_sli_F9XXYvbW1X_RXP6D2uUU48;mc_kwrB3ZoKf7OufTHWaHJV7a++){x->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=ssc_sli_krZ4mEqeUvGreaRgDiVlrW->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}pm_destroy_real_vector(
ssc_sli_kyPax65oMi4_e5Xhtl62wu,mc_FOGg0ZWot2WdYenO8zaD4Z);
pm_destroy_real_vector(ssc_sli_FeVcFpO_arpYVL1p0ki1An,
mc_FOGg0ZWot2WdYenO8zaD4Z);pm_destroy_real_vector(
ssc_sli_krZ4mEqeUvGreaRgDiVlrW,mc_FOGg0ZWot2WdYenO8zaD4Z);return
ssc_sli__TlE87LNm5C0YiLrL3Roi_;}boolean_T ssc_sli_FBy5QvvKweG5jHfeCywXsW(
PmRealVector*x,const PmSparsityPattern*ssc_sli__nMMeWOrYSh_aXgWvg8TWf,const
PmRealVector*ssc_sli_kpqrQkK0B44th5MJ4yHNtD,const PmSparsityPattern*
ssc_sli_FvDmXHErGo0GdyPQHwX7F0,const PmRealVector*
ssc_sli_kOj30KPm3HhPhLXrKvi0go,const PmRealVector*
ssc_sli_ksWyZI1nPZdVX9x__ej25Y,const PmRealVector*mc_Vi4Cp0qK964NYTFMGr9Ttn,
real_T ssc_sli_kGdic_uNOGlMia8duIA_YD){const double
ssc_sli__w2WnEf8nR8g_LBNYsXIcA=1.0e-8;PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=
pm_default_allocator();PmRealVector*mc_krOJvR5Qa1KQZu3eEsQtEU,*
ssc_sli_VcCKInIiim_ff9W5jQMwAn,*ssc_sli_Vx0_MG3SoGWGiHzV6jdZwR;
PmSparsityPattern*ssc_sli_k3X9ts0EMkhjZeqfYdM5sN,*
ssc_sli_V4ql96HXjzpxXLH3Q8xO_P;size_t mc_kwrB3ZoKf7OufTHWaHJV7a,
mc_VLHhnPUiNQpve5VIL9P3O9=ssc_sli__nMMeWOrYSh_aXgWvg8TWf->mNumRow;boolean_T
ssc_sli_k4M7bSEmThKJbirXUDQgS6;boolean_T ssc_sli_VoBPSgUt6_p3eD_o52v4s8=
ssc_core_FTzoitpYys8Aca2krGVZIS()==ssc_core_koP_545U7Zp5Ymq02vu8dY;
PmBoolVector*ssc_sli_kI55hIAhoAlMWXO1MbO6SC=NULL;PmRealVector*
ssc_sli_FNDfIeLW0axMb9N_SkoM00=NULL;if(mc_VLHhnPUiNQpve5VIL9P3O9==0){return
true;}(void)0;;if(ssc_sli_VoBPSgUt6_p3eD_o52v4s8){
ssc_sli_kI55hIAhoAlMWXO1MbO6SC=pm__jbisDMumXdocXANx5LhhY(
mc_VLHhnPUiNQpve5VIL9P3O9,mc_FOGg0ZWot2WdYenO8zaD4Z);mc__pFtu1g17h8ZaaZK4PpTkb
(ssc_sli_kI55hIAhoAlMWXO1MbO6SC,ssc_sli__nMMeWOrYSh_aXgWvg8TWf);
ssc_sli_FNDfIeLW0axMb9N_SkoM00=pm_create_real_vector(mc_VLHhnPUiNQpve5VIL9P3O9
,mc_FOGg0ZWot2WdYenO8zaD4Z);}ssc_sli_k3X9ts0EMkhjZeqfYdM5sN=
pm_FhqtSrxlPotrcypQHJ9Dcq(mc_VLHhnPUiNQpve5VIL9P3O9,mc_VLHhnPUiNQpve5VIL9P3O9,
mc_FOGg0ZWot2WdYenO8zaD4Z);ssc_sli_VcCKInIiim_ff9W5jQMwAn=
pm_create_real_vector(mc_VLHhnPUiNQpve5VIL9P3O9,mc_FOGg0ZWot2WdYenO8zaD4Z);
mc_krOJvR5Qa1KQZu3eEsQtEU=pm_create_real_vector(mc_VLHhnPUiNQpve5VIL9P3O9,
mc_FOGg0ZWot2WdYenO8zaD4Z);if(ssc_sli_VoBPSgUt6_p3eD_o52v4s8){(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a++){
ssc_sli_FNDfIeLW0axMb9N_SkoM00->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]=x->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a
++){if(!ssc_sli_VoBPSgUt6_p3eD_o52v4s8||ssc_sli_kI55hIAhoAlMWXO1MbO6SC->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]){ssc_sli_VcCKInIiim_ff9W5jQMwAn->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]= -ssc_sli__w2WnEf8nR8g_LBNYsXIcA;}else{
ssc_sli_VcCKInIiim_ff9W5jQMwAn->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]=0.0;}}
ssc_sli_V4ql96HXjzpxXLH3Q8xO_P=mc__5C6m_ZyP9_NYekcJCEULM(
ssc_sli_k3X9ts0EMkhjZeqfYdM5sN,ssc_sli__nMMeWOrYSh_aXgWvg8TWf,
mc_FOGg0ZWot2WdYenO8zaD4Z);ssc_sli_Vx0_MG3SoGWGiHzV6jdZwR=
pm_create_real_vector(((size_t)(ssc_sli_V4ql96HXjzpxXLH3Q8xO_P)->mJc[(
ssc_sli_V4ql96HXjzpxXLH3Q8xO_P)->mNumCol]),mc_FOGg0ZWot2WdYenO8zaD4Z);
mc__8x7kz_627_gXDli_FJo22(ssc_sli_Vx0_MG3SoGWGiHzV6jdZwR,
ssc_sli_V4ql96HXjzpxXLH3Q8xO_P,ssc_sli_kpqrQkK0B44th5MJ4yHNtD,
ssc_sli__nMMeWOrYSh_aXgWvg8TWf,ssc_sli_VcCKInIiim_ff9W5jQMwAn,
ssc_sli_k3X9ts0EMkhjZeqfYdM5sN,mc_krOJvR5Qa1KQZu3eEsQtEU);
mc__aNO1s5qwzt6fXwft5YgCz(mc_krOJvR5Qa1KQZu3eEsQtEU);mc_kM_Y9u9U2F_Cf9sWAtmMMu
(mc_krOJvR5Qa1KQZu3eEsQtEU,ssc_sli_kOj30KPm3HhPhLXrKvi0go,
ssc_sli_FvDmXHErGo0GdyPQHwX7F0,mc_Vi4Cp0qK964NYTFMGr9Ttn);for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(!
ssc_sli_VoBPSgUt6_p3eD_o52v4s8||ssc_sli_kI55hIAhoAlMWXO1MbO6SC->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]){mc_krOJvR5Qa1KQZu3eEsQtEU->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]+=ssc_sli_ksWyZI1nPZdVX9x__ej25Y->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]+x->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]*
ssc_sli__w2WnEf8nR8g_LBNYsXIcA;}else{mc_krOJvR5Qa1KQZu3eEsQtEU->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=0.0;}}mc_VWnvos7Q548uVH7p0208jN(
mc_krOJvR5Qa1KQZu3eEsQtEU,-1.0,mc_krOJvR5Qa1KQZu3eEsQtEU);
ssc_sli_k4M7bSEmThKJbirXUDQgS6=ssc_sli_V7x4aATsVDO_WT7TnWOlu0(x,
ssc_sli_Vx0_MG3SoGWGiHzV6jdZwR,ssc_sli_V4ql96HXjzpxXLH3Q8xO_P,
mc_krOJvR5Qa1KQZu3eEsQtEU,!ssc_sli_VoBPSgUt6_p3eD_o52v4s8,
mc_FOGg0ZWot2WdYenO8zaD4Z);if(ssc_sli_VoBPSgUt6_p3eD_o52v4s8){for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(!
ssc_sli_kI55hIAhoAlMWXO1MbO6SC->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]){x->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=ssc_sli_FNDfIeLW0axMb9N_SkoM00->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}}if(ssc_sli_k4M7bSEmThKJbirXUDQgS6){
ssc_sli_k4M7bSEmThKJbirXUDQgS6=ssc_sli_kGp8empIuW0egibdYVnVuN(
ssc_sli_VcCKInIiim_ff9W5jQMwAn,mc_krOJvR5Qa1KQZu3eEsQtEU,x,
ssc_sli_Vx0_MG3SoGWGiHzV6jdZwR,ssc_sli_V4ql96HXjzpxXLH3Q8xO_P,
ssc_sli_kGdic_uNOGlMia8duIA_YD);}pm_destroy_real_vector(
ssc_sli_Vx0_MG3SoGWGiHzV6jdZwR,mc_FOGg0ZWot2WdYenO8zaD4Z);
pm_VYooJBURCwKrVu6RXzQZ_5(ssc_sli_V4ql96HXjzpxXLH3Q8xO_P,
mc_FOGg0ZWot2WdYenO8zaD4Z);pm_destroy_real_vector(mc_krOJvR5Qa1KQZu3eEsQtEU,
mc_FOGg0ZWot2WdYenO8zaD4Z);pm_destroy_real_vector(
ssc_sli_VcCKInIiim_ff9W5jQMwAn,mc_FOGg0ZWot2WdYenO8zaD4Z);
pm_VYooJBURCwKrVu6RXzQZ_5(ssc_sli_k3X9ts0EMkhjZeqfYdM5sN,
mc_FOGg0ZWot2WdYenO8zaD4Z);if(ssc_sli_VoBPSgUt6_p3eD_o52v4s8){
pm_VuaGyqV_9K0Ia9Qgn65rsj(ssc_sli_kI55hIAhoAlMWXO1MbO6SC,
mc_FOGg0ZWot2WdYenO8zaD4Z);pm_destroy_real_vector(
ssc_sli_FNDfIeLW0axMb9N_SkoM00,mc_FOGg0ZWot2WdYenO8zaD4Z);}return
ssc_sli_k4M7bSEmThKJbirXUDQgS6;}void ssc_sli_kYb0nZ27pDhGeTE2ZZ7IgI(void*
ssc_sli__G4iWEp7EWKSf9wowgL14H,PmCharVector ssc_sli_V94OHC32_a85j1a8nI0gLx){}
boolean_T ic_solve_impl(PmRealVector*x,const PmRealVector*
mc_kEbBObcYFIxUZ5_77V3CO_,const ssc_sli_kvQ5MfaAL6_ogiFAf_WuWW*
ssc_sli_F_8iIeoxoi8wXeTxIwi_Uu,const ssc_sli__dMka2DXsGloW9fCe3aDyi*
mc__LOE3NllYqGGcHiwg6fX5o,NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z){
static ssc_sli__dMka2DXsGloW9fCe3aDyi ssc_sli_kxNWqNeTmcd4fyn3ZIR7uJ={NULL,
ssc_sli_kYb0nZ27pDhGeTE2ZZ7IgI,ssc_sli_kYb0nZ27pDhGeTE2ZZ7IgI};boolean_T
ssc_sli_FHHOtYrg45x7fTRNWOFOxA,ssc_sli_kalVw91HevOmgavxbq_ObT,
ssc_sli_k4M7bSEmThKJbirXUDQgS6;char ssc_sli_FlB7scl1YCKkj9afF8A1Jm[16384];
PmCharVector ssc_sli_V94OHC32_a85j1a8nI0gLx;const PmRealVector*
ssc_sli_FqTWkJphhedNi9LxNaZAUX= &(ssc_sli_F_8iIeoxoi8wXeTxIwi_Uu->
ssc_sli__BqVhX3A9xxQjieVZkGaSx);const ssc_sli_Vzq7l2SdEQKDfDnfuswdjB*
ssc_sli_k2gZrgu0nNheWLgTGH_uTD= &(ssc_sli_F_8iIeoxoi8wXeTxIwi_Uu->
ssc_sli_VD3ZIoItPAxs_epBnhrnzB);const ssc_sli_Vzq7l2SdEQKDfDnfuswdjB*
ssc_sli_V4umrDvg_cxHY5U2vQ_qPZ= &(ssc_sli_F_8iIeoxoi8wXeTxIwi_Uu->
ssc_sli__f1Ztz_4Ko0DiyeAGi9pem);const ssc_sli_VGTmDQrTHVdDhX3yJWx1ej*
ssc_sli_FJMbfw59rj81ZyEIJ5FxiE= &(ssc_sli_F_8iIeoxoi8wXeTxIwi_Uu->
ssc_sli_V0qpSTdv02KbfiwiN61OSS);real_T ssc_sli_kGdic_uNOGlMia8duIA_YD=
ssc_sli_F_8iIeoxoi8wXeTxIwi_Uu->ssc_sli__TdXi7D_QctFeq_GuzE4uI;boolean_T
ssc_sli__5vGAycqViWsauDxrtyP_E=ssc_sli_F_8iIeoxoi8wXeTxIwi_Uu->
ssc_core_VA9mbbfJfEpYb18iLHpsqK;ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE=(ssc_st_kPInN_8SRA_iYeTvYVKl3z)->
ssc_st_VESUSzIzeRWSV1xYVr5zH5((ssc_st_kPInN_8SRA_iYeTvYVKl3z));
ssc_sli_V94OHC32_a85j1a8nI0gLx.mN=16384;ssc_sli_V94OHC32_a85j1a8nI0gLx.mX=
ssc_sli_FlB7scl1YCKkj9afF8A1Jm;if(mc__LOE3NllYqGGcHiwg6fX5o==NULL){
mc__LOE3NllYqGGcHiwg6fX5o= &ssc_sli_kxNWqNeTmcd4fyn3ZIR7uJ;}
ssc_sli_FHHOtYrg45x7fTRNWOFOxA=ssc_sli_khxq08nmaIlbcL_XAfqtwp(x,&
ssc_sli_k2gZrgu0nNheWLgTGH_uTD->ssc_sli__lXoynJWcyhzayn0Hpkb2h,&
ssc_sli_k2gZrgu0nNheWLgTGH_uTD->ssc_sli_FmCjnlfy_Hlxba5hUdQ_7e,&
ssc_sli_k2gZrgu0nNheWLgTGH_uTD->ssc_sli_knMQ448fB683_eZbo4QDBU,&
ssc_sli_k2gZrgu0nNheWLgTGH_uTD->ssc_sli_F7RM_m_3oqh9_5wZCDdWHu,&
ssc_sli_k2gZrgu0nNheWLgTGH_uTD->ssc_sli_FmDhajaV6M0fdyKW3qk1_r,
mc_kEbBObcYFIxUZ5_77V3CO_,ssc_sli_FqTWkJphhedNi9LxNaZAUX,
ssc_sli_kGdic_uNOGlMia8duIA_YD);ssc_sli_k4M7bSEmThKJbirXUDQgS6=
ssc_sli_FHHOtYrg45x7fTRNWOFOxA;if(!ssc_sli_FHHOtYrg45x7fTRNWOFOxA){if(!
ssc_sli__5vGAycqViWsauDxrtyP_E){pmf_warning(ssc_sli_VqKh4Kz_QZS0XmkDAghkEa.
ssc_sli_k9czt_jnl5_CeqQbj6K4QZ.ssc_sli_VJ5Ejyvd5AOng9VcQKGenn);strcpy(
ssc_sli_V94OHC32_a85j1a8nI0gLx.mX,"");mc__LOE3NllYqGGcHiwg6fX5o->
ssc_sli_FRiVh68ViPKEg9hf4_Ug13(mc__LOE3NllYqGGcHiwg6fX5o->
ssc_sli_V9G3clQtGo8rdHdO1JS52K,ssc_sli_V94OHC32_a85j1a8nI0gLx);if(strlen(
ssc_sli_V94OHC32_a85j1a8nI0gLx.mX)>0){pmf_warning(
ssc_sli_VqKh4Kz_QZS0XmkDAghkEa.ssc_sli_k9czt_jnl5_CeqQbj6K4QZ.
ssc_sli_VK6W_CYqut_9duBNpo_NW_,ssc_sli_V94OHC32_a85j1a8nI0gLx.mX);}}
ssc_sli_kalVw91HevOmgavxbq_ObT=ssc_sli_khxq08nmaIlbcL_XAfqtwp(x,&
ssc_sli_V4umrDvg_cxHY5U2vQ_qPZ->ssc_sli__lXoynJWcyhzayn0Hpkb2h,&
ssc_sli_V4umrDvg_cxHY5U2vQ_qPZ->ssc_sli_FmCjnlfy_Hlxba5hUdQ_7e,&
ssc_sli_V4umrDvg_cxHY5U2vQ_qPZ->ssc_sli_knMQ448fB683_eZbo4QDBU,&
ssc_sli_V4umrDvg_cxHY5U2vQ_qPZ->ssc_sli_F7RM_m_3oqh9_5wZCDdWHu,&
ssc_sli_V4umrDvg_cxHY5U2vQ_qPZ->ssc_sli_FmDhajaV6M0fdyKW3qk1_r,
mc_kEbBObcYFIxUZ5_77V3CO_,ssc_sli_FqTWkJphhedNi9LxNaZAUX,
ssc_sli_kGdic_uNOGlMia8duIA_YD);if(!ssc_sli_kalVw91HevOmgavxbq_ObT){if(!
ssc_sli__5vGAycqViWsauDxrtyP_E){pmf_warning(ssc_sli_VqKh4Kz_QZS0XmkDAghkEa.
ssc_sli_k9czt_jnl5_CeqQbj6K4QZ.ssc_sli_F8vzSvsWvJt4Y9mcFrhG03);}
pm_rv_equals_rv(x,ssc_sli_FqTWkJphhedNi9LxNaZAUX);}
ssc_sli_k4M7bSEmThKJbirXUDQgS6=true;}if(ssc_sli__5vGAycqViWsauDxrtyP_E){
ssc_sli_k4M7bSEmThKJbirXUDQgS6=ssc_sli_FBy5QvvKweG5jHfeCywXsW(x,&
ssc_sli_FJMbfw59rj81ZyEIJ5FxiE->ssc_sli_V5IQq4r_lx_4au004QC5wp,&
ssc_sli_FJMbfw59rj81ZyEIJ5FxiE->ssc_sli_FMPtcQjw_q0fbiVUu569M3,&
ssc_sli_FJMbfw59rj81ZyEIJ5FxiE->ssc_sli_ktRyvEF_03dgjuePPwPWZY,&
ssc_sli_FJMbfw59rj81ZyEIJ5FxiE->ssc_sli_kgprbt2Kb8KEjulqbNMwHQ,&
ssc_sli_FJMbfw59rj81ZyEIJ5FxiE->ssc_sli_Fe9Lz59VCoSBW9N3RO80o9,
mc_kEbBObcYFIxUZ5_77V3CO_,ssc_sli_kGdic_uNOGlMia8duIA_YD);}if(
ssc_sli_k4M7bSEmThKJbirXUDQgS6){(ssc_st_kPInN_8SRA_iYeTvYVKl3z)->
ssc_st_kAPwXpB5miCGVLsko_7ONE((ssc_st_kPInN_8SRA_iYeTvYVKl3z),(
ssc_st_k3bA0_SocS_baqMdimEffE));}else{ssc_st_Fj4pG1CbqChThqCdYV3xux(
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_k3bA0_SocS_baqMdimEffE,
NEU_DIAGNOSTIC_LEVEL_TERSE,ssc_sli_VqKh4Kz_QZS0XmkDAghkEa.
ssc_sli_k9czt_jnl5_CeqQbj6K4QZ.ssc_sli_kCTuGPOAFtl1WiUF49NYa_);}return
ssc_sli_k4M7bSEmThKJbirXUDQgS6;}
