#include "pm_std.h"
#include "math.h"
#include "pm_std.h"
#include "pm_std.h"
struct sm_Va7rvzSwRbpB_iIiuSF8h_{real_T x;real_T sm_FzyLWRgau0pMYq2XSI3ETL;
real_T sm_FBDi_PCg670TjHgJTNPcHr;};typedef struct sm_Va7rvzSwRbpB_iIiuSF8h_
sm_FJDxOUSymMGic5lC7ZhrnL;struct sm__ZcjF29VfNpra1De9fqQ59{real_T x;real_T
sm_FzyLWRgau0pMYq2XSI3ETL;};typedef struct sm__ZcjF29VfNpra1De9fqQ59
sm_VA4uSngEZ2GoY18jGpiajo;struct sm_VQiPk6I_S_0teiYbT1MBSN{real_T
sm_FQferGZUKft3_i5GvYy4Oy;real_T x;real_T sm_FzyLWRgau0pMYq2XSI3ETL;real_T
sm_FBDi_PCg670TjHgJTNPcHr;};typedef struct sm_VQiPk6I_S_0teiYbT1MBSN
sm__3md8_onIiO6heiNB5D3_3;struct sm_k5mHxu1pFy4YaeyeIGf5bY{real_T
sm_V5gSkPeCSkdzZ1xMyj2v7U,sm__D1iFBxPf38RWiveIR1Iip,sm__hPet7vW5h0Zi1uUdLa_LW;
real_T sm_kdB_LoVum6OHeDEkf0n58b,sm__tdIR85BSYdzha7Mb8qhKj,
sm__WnakhFnl24_bX0NhL6CLW;real_T sm_FnXzm1MLmt04dPIhRbN5SW,
sm_VgeldyT0dAtjeHo3kvxpdi,sm_F3LgZdApwMGziTfUlk6dzB;};typedef struct
sm_k5mHxu1pFy4YaeyeIGf5bY sm_komYPTPtib40juqhd0nJcN;struct
sm_VPRZuZ2WMe0sWLVY78iT7z{real_T sm_V5gSkPeCSkdzZ1xMyj2v7U,
sm__D1iFBxPf38RWiveIR1Iip;real_T sm_kdB_LoVum6OHeDEkf0n58b,
sm__tdIR85BSYdzha7Mb8qhKj;};typedef struct sm_VPRZuZ2WMe0sWLVY78iT7z
sm_FGXM32_OTMKQfyd_tHfAMr;struct sm__sD2GKinhS_qYTF_z8BajY{
sm__3md8_onIiO6heiNB5D3_3 sm_VnD_HGFKVUOWdDAWvZhyEb;sm_FJDxOUSymMGic5lC7ZhrnL
sm_F32Ql82vv6pW_PYIdpkFQ0;};typedef struct sm__sD2GKinhS_qYTF_z8BajY
sm_k4kL9Om6RgxTZqdxJRM51B;struct sm_FECeXxDVdZtrjDWomEbSZK{real_T
sm_Flz54uVsi__UbP_LLGOB06;sm_VA4uSngEZ2GoY18jGpiajo sm_F32Ql82vv6pW_PYIdpkFQ0;
};typedef struct sm_FECeXxDVdZtrjDWomEbSZK sm_kCPAoKbsUt4wiPr6S1lZJh;struct
sm__CEhElfLt9_7aqLsGROeDF{sm_FJDxOUSymMGic5lC7ZhrnL sm_FN28mzn7A2hvYLPTU_L4bt;
sm_FJDxOUSymMGic5lC7ZhrnL sm_k61dA_LqfI4EY1W2W1B1mA;};typedef struct
sm__CEhElfLt9_7aqLsGROeDF sm_kNq2SpAav5tbb5Yx_VSirx;struct
sm_kjPRzrST9nKtZX9dr__i0m{real_T sm_FN28mzn7A2hvYLPTU_L4bt;
sm_VA4uSngEZ2GoY18jGpiajo sm_k61dA_LqfI4EY1W2W1B1mA;};typedef struct
sm_kjPRzrST9nKtZX9dr__i0m sm_VjTg1V8Io1pgfT8gvr9_7X;void pm_math_Vector3_add(
const sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_subtract(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_negate(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_scale(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,real_T
sm_FQferGZUKft3_i5GvYy4Oy,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Vector3_divide(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4);void
pm_math_Vector3_guardedDivide(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4);real_T
pm_math_Vector3_norm(const sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ
);void pm_math_Vector3_unit(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;void pm_math_Vector3_guardedUnit(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*sm__1Zf2IciMRCub1vvbEr1C4)
;real_T pm_math_Vector3_dot(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kNtPmLll5l8eiqwtk5kfJv);void pm_math_Vector3_cross(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kNtPmLll5l8eiqwtk5kfJv,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Vector3_compOrthogonalBasis(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kwrB3ZoKf7OufTHWaHJV7a,sm_FJDxOUSymMGic5lC7ZhrnL*sm_kyp6uAyJE40UVuAQNEYzS1,
sm_FJDxOUSymMGic5lC7ZhrnL*sm_V2__YrimeI4E_yWnhKofpy);void
sm_k_awJm8RfhOkja3gYFB_qc(const sm_VA4uSngEZ2GoY18jGpiajo*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_VA4uSngEZ2GoY18jGpiajo*
sm_kNtPmLll5l8eiqwtk5kfJv,sm_VA4uSngEZ2GoY18jGpiajo*sm__1Zf2IciMRCub1vvbEr1C4)
;void sm__NTLhOTEGOGWjuUcCmk7fn(const sm_VA4uSngEZ2GoY18jGpiajo*
sm__AuaKMC5koOPbXxPi_MZvt,const sm_VA4uSngEZ2GoY18jGpiajo*
sm_kNtPmLll5l8eiqwtk5kfJv,sm_VA4uSngEZ2GoY18jGpiajo*sm__1Zf2IciMRCub1vvbEr1C4)
;void sm_FABngh7X4lK_XXatV5zQht(const sm_VA4uSngEZ2GoY18jGpiajo*
sm_VgJW5ZqpwPpuY1inYtaofQ,sm_VA4uSngEZ2GoY18jGpiajo*sm__1Zf2IciMRCub1vvbEr1C4)
;void sm__GRqUBqq8ktijqH3JjP19i(const sm_VA4uSngEZ2GoY18jGpiajo*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_VA4uSngEZ2GoY18jGpiajo*sm__1Zf2IciMRCub1vvbEr1C4);void
sm_V7khM0Jvjl0HdimUelrRD7(const sm_VA4uSngEZ2GoY18jGpiajo*
sm_VgJW5ZqpwPpuY1inYtaofQ,real_T sm_FQferGZUKft3_i5GvYy4Oy,
sm_VA4uSngEZ2GoY18jGpiajo*sm__1Zf2IciMRCub1vvbEr1C4);real_T
sm__vHSeT0LPLCjd1NNdeCTMe(const sm_VA4uSngEZ2GoY18jGpiajo*
sm_VgJW5ZqpwPpuY1inYtaofQ);void pm_math_Quaternion_compose(const
sm__3md8_onIiO6heiNB5D3_3*sm_FbCdebDtDIhMduMKWA8Khy,const
sm__3md8_onIiO6heiNB5D3_3*sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_composeInverse(const
sm__3md8_onIiO6heiNB5D3_3*sm_FbCdebDtDIhMduMKWA8Khy,const
sm__3md8_onIiO6heiNB5D3_3*sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_inverseCompose(const
sm__3md8_onIiO6heiNB5D3_3*sm_FbCdebDtDIhMduMKWA8Khy,const
sm__3md8_onIiO6heiNB5D3_3*sm_krgkQdg3ZZ_0ded42Fk_8r,sm__3md8_onIiO6heiNB5D3_3*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_xform(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_xformI(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_xformJ(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_xformK(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_inverseXform(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_inverseXformI(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_inverseXformJ(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_inverseXformK(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Quaternion_Matrix3x3Ctor(const
sm_komYPTPtib40juqhd0nJcN*sm_FqUCZrSGGNOuePgRr82o_8,sm__3md8_onIiO6heiNB5D3_3*
sm_VnD_HGFKVUOWdDAWvZhyEb);void pm_math_Matrix3x3_compose(const
sm_komYPTPtib40juqhd0nJcN*sm_Fcuud3IN0odMZi54a1R_8f,const
sm_komYPTPtib40juqhd0nJcN*sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Matrix3x3_composeTranspose(const
sm_komYPTPtib40juqhd0nJcN*sm_Fcuud3IN0odMZi54a1R_8f,const
sm_komYPTPtib40juqhd0nJcN*sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Matrix3x3_transposeCompose(const
sm_komYPTPtib40juqhd0nJcN*sm_Fcuud3IN0odMZi54a1R_8f,const
sm_komYPTPtib40juqhd0nJcN*sm__09m2ugY6U_OXH9Il_a7Bj,sm_komYPTPtib40juqhd0nJcN*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Matrix3x3_preCross(const
sm_komYPTPtib40juqhd0nJcN*sm_F2l4p_g4sn02huHNflQjMH,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_komYPTPtib40juqhd0nJcN*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Matrix3x3_postCross(const
sm_komYPTPtib40juqhd0nJcN*sm_F2l4p_g4sn02huHNflQjMH,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_komYPTPtib40juqhd0nJcN*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Matrix3x3_xform(const
sm_komYPTPtib40juqhd0nJcN*sm_F2l4p_g4sn02huHNflQjMH,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Matrix3x3_transposeXform(const
sm_komYPTPtib40juqhd0nJcN*sm_F2l4p_g4sn02huHNflQjMH,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_VgJW5ZqpwPpuY1inYtaofQ,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Matrix3x3_QuaternionCtor(const
sm__3md8_onIiO6heiNB5D3_3*sm_VnD_HGFKVUOWdDAWvZhyEb,sm_komYPTPtib40juqhd0nJcN*
sm_FqUCZrSGGNOuePgRr82o_8);void pm_math_Matrix3x3_getValuesInColumns(const
sm_komYPTPtib40juqhd0nJcN*sm_F2l4p_g4sn02huHNflQjMH,double*
sm_k4y8mv5uXzheZimBIk_n7I);void pm_math_Transform3_compose(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_composeInverse(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_inverseCompose(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm__yWh8B7tCCdhiXMhhHUqbN,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_FGPQyC36Ly4PgaEVTyCKbe,sm_k4kL9Om6RgxTZqdxJRM51B*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_xformDir(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kEbBObcYFIxUZ5_77V3CO_,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_xformDirI(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_xformDirJ(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_xformDirK(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_inverseXformDir(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kEbBObcYFIxUZ5_77V3CO_,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_inverseXformDirI(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_inverseXformDirJ(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_inverseXformDirK(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_xformPoint(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,const
sm_FJDxOUSymMGic5lC7ZhrnL*pm__lqjegyKuwStj56WZLiC_e,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_Transform3_inverseXformPoint(const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,const
sm_FJDxOUSymMGic5lC7ZhrnL*pm__lqjegyKuwStj56WZLiC_e,sm_FJDxOUSymMGic5lC7ZhrnL*
sm__1Zf2IciMRCub1vvbEr1C4);void sm_k8ADxa6sAXCjWPuCpyN0mx(const
sm_kCPAoKbsUt4wiPr6S1lZJh*sm_V91rYIvDBkGRba7MvGcPUK,const
sm_VA4uSngEZ2GoY18jGpiajo*sm_kEbBObcYFIxUZ5_77V3CO_,sm_VA4uSngEZ2GoY18jGpiajo*
sm__1Zf2IciMRCub1vvbEr1C4);void sm_Vw4S4dHyYC_HdLZ9M7ALkV(const
sm_kCPAoKbsUt4wiPr6S1lZJh*sm_V91rYIvDBkGRba7MvGcPUK,const
sm_VA4uSngEZ2GoY18jGpiajo*sm_kEbBObcYFIxUZ5_77V3CO_,sm_VA4uSngEZ2GoY18jGpiajo*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_SpatialVector_add(const
sm_kNq2SpAav5tbb5Yx_VSirx*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_kNq2SpAav5tbb5Yx_VSirx*sm_kNtPmLll5l8eiqwtk5kfJv,sm_kNq2SpAav5tbb5Yx_VSirx*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_SpatialVector_subtract(const
sm_kNq2SpAav5tbb5Yx_VSirx*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_kNq2SpAav5tbb5Yx_VSirx*sm_kNtPmLll5l8eiqwtk5kfJv,sm_kNq2SpAav5tbb5Yx_VSirx*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_SpatialVector_xform(const
sm_kNq2SpAav5tbb5Yx_VSirx*sm_VgJW5ZqpwPpuY1inYtaofQ,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,sm_kNq2SpAav5tbb5Yx_VSirx*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_SpatialVector_inverseXform(const
sm_kNq2SpAav5tbb5Yx_VSirx*sm_VgJW5ZqpwPpuY1inYtaofQ,const
sm_k4kL9Om6RgxTZqdxJRM51B*sm_V91rYIvDBkGRba7MvGcPUK,sm_kNq2SpAav5tbb5Yx_VSirx*
sm__1Zf2IciMRCub1vvbEr1C4);void sm_kCxEF9ykh0Sgfyu3PLC_8S(const
sm_VjTg1V8Io1pgfT8gvr9_7X*sm__AuaKMC5koOPbXxPi_MZvt,const
sm_VjTg1V8Io1pgfT8gvr9_7X*sm_kNtPmLll5l8eiqwtk5kfJv,sm_VjTg1V8Io1pgfT8gvr9_7X*
sm__1Zf2IciMRCub1vvbEr1C4);void pm_math_lin_alg_geSolve2x2(const real_T
sm_F2l4p_g4sn02huHNflQjMH[4],const real_T b[2],real_T x[2]);void
sm_kFw5Hc0MIcWRf1TyZlVSYx(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kT9Nk90k05W6dXawldWxZF,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_Fsg1xEReOKlTbLYChSpHhT,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VSAYOUZM1zK7ZqkO4wjRIY)
;real_T sm_VCNAAYtylypLhDX8cqY2hq(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kT9Nk90k05W6dXawldWxZF,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_Fsg1xEReOKlTbLYChSpHhT,sm_FJDxOUSymMGic5lC7ZhrnL*sm_VSAYOUZM1zK7ZqkO4wjRIY)
;static real_T sm_kTN0fB7zC_G9XuzPJ4Migy(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kT9Nk90k05W6dXawldWxZF,const sm_FJDxOUSymMGic5lC7ZhrnL*
pm__lqjegyKuwStj56WZLiC_e,int sm__C7_bxWWay0ibaZzlTzB0d,int
sm_FnrjFNs9eQp9V5vCxPaoKw,int sm_kyp6uAyJE40UVuAQNEYzS1){const real_T
sm_FG350oy5KhSieeGidT6m0n=(*(&(*pm__lqjegyKuwStj56WZLiC_e).x+(
sm__C7_bxWWay0ibaZzlTzB0d)))/(*(&(*sm_kT9Nk90k05W6dXawldWxZF).x+(
sm__C7_bxWWay0ibaZzlTzB0d)));const real_T sm_k9vhyFTMKOdYgysUqibCZU=(*(&(*
pm__lqjegyKuwStj56WZLiC_e).x+(sm_FnrjFNs9eQp9V5vCxPaoKw)))/(*(&(*
sm_kT9Nk90k05W6dXawldWxZF).x+(sm_FnrjFNs9eQp9V5vCxPaoKw)));const real_T
sm_V2__YrimeI4E_yWnhKofpy=1.0-(sm_FG350oy5KhSieeGidT6m0n*
sm_FG350oy5KhSieeGidT6m0n+sm_k9vhyFTMKOdYgysUqibCZU*sm_k9vhyFTMKOdYgysUqibCZU)
;return(*(&(*sm_kT9Nk90k05W6dXawldWxZF).x+(sm_kyp6uAyJE40UVuAQNEYzS1)))*sqrt(
sm_V2__YrimeI4E_yWnhKofpy);}static void sm_VFTZIhGM7IG9_qIgX7C_Zo(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kT9Nk90k05W6dXawldWxZF,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm__AExROh1PVWNeP7hmMWuJv,sm_FJDxOUSymMGic5lC7ZhrnL*
pm__lqjegyKuwStj56WZLiC_e){const real_T sm_FrRR7cWTwOdoeHJEKRplf7=
sm_kT9Nk90k05W6dXawldWxZF->x*sm_kT9Nk90k05W6dXawldWxZF->x;const real_T
sm_FOC9NdhwsNtse11nBuYzs0=sm_kT9Nk90k05W6dXawldWxZF->sm_FzyLWRgau0pMYq2XSI3ETL
*sm_kT9Nk90k05W6dXawldWxZF->sm_FzyLWRgau0pMYq2XSI3ETL;const real_T
sm_VwSe67JBPr8HimDTWJGTH6=sm_kT9Nk90k05W6dXawldWxZF->sm_FBDi_PCg670TjHgJTNPcHr
*sm_kT9Nk90k05W6dXawldWxZF->sm_FBDi_PCg670TjHgJTNPcHr;const int
sm_kiwsUmjqOgxWWHe22JZvr8=5;real_T sm_F2l4p_g4sn02huHNflQjMH,
sm_Vqiy96WqvuhCaXm5e_vvT0,sm_FStFcQlyAJ_dVy4kGZXBPQ;int
sm_FbsbQRdIBwKmhqkBxxfakr;const int sm_V_W6rV3s9n8ljDz_1otz6L=
sm_kT9Nk90k05W6dXawldWxZF->x<sm_kT9Nk90k05W6dXawldWxZF->
sm_FzyLWRgau0pMYq2XSI3ETL?(sm_kT9Nk90k05W6dXawldWxZF->x<
sm_kT9Nk90k05W6dXawldWxZF->sm_FBDi_PCg670TjHgJTNPcHr?0:2):(
sm_kT9Nk90k05W6dXawldWxZF->sm_FzyLWRgau0pMYq2XSI3ETL<sm_kT9Nk90k05W6dXawldWxZF
->sm_FBDi_PCg670TjHgJTNPcHr?1:2);const int sm__zvO5u_pXw8FgaGKTJtx8T=
sm_kT9Nk90k05W6dXawldWxZF->x>sm_kT9Nk90k05W6dXawldWxZF->
sm_FzyLWRgau0pMYq2XSI3ETL?(sm_kT9Nk90k05W6dXawldWxZF->x>
sm_kT9Nk90k05W6dXawldWxZF->sm_FBDi_PCg670TjHgJTNPcHr?0:2):(
sm_kT9Nk90k05W6dXawldWxZF->sm_FzyLWRgau0pMYq2XSI3ETL>sm_kT9Nk90k05W6dXawldWxZF
->sm_FBDi_PCg670TjHgJTNPcHr?1:2);const real_T sm_F5jLAqkHwnxQaaApL1Hgzd=(*(&(*
sm_kT9Nk90k05W6dXawldWxZF).x+(sm_V_W6rV3s9n8ljDz_1otz6L)));const real_T
sm__SBn8JOhslODbTQTEMISLq=(*(&(*sm_kT9Nk90k05W6dXawldWxZF).x+(
sm__zvO5u_pXw8FgaGKTJtx8T)));const real_T sm_FJUzitoaVYW9i9nv_aa3CM=
sm_F5jLAqkHwnxQaaApL1Hgzd*(sm_F5jLAqkHwnxQaaApL1Hgzd/sm__SBn8JOhslODbTQTEMISLq
);sm_FJDxOUSymMGic5lC7ZhrnL sm_F6_MIA8cuDOcbm3MYmXY8J;real_T
sm_VxJGeiNkgXCriyJHh9D_1k;sm_F6_MIA8cuDOcbm3MYmXY8J.x=
sm__AExROh1PVWNeP7hmMWuJv->x/sm_kT9Nk90k05W6dXawldWxZF->x;
sm_F6_MIA8cuDOcbm3MYmXY8J.sm_FzyLWRgau0pMYq2XSI3ETL=sm__AExROh1PVWNeP7hmMWuJv
->sm_FzyLWRgau0pMYq2XSI3ETL/sm_kT9Nk90k05W6dXawldWxZF->
sm_FzyLWRgau0pMYq2XSI3ETL;sm_F6_MIA8cuDOcbm3MYmXY8J.sm_FBDi_PCg670TjHgJTNPcHr=
sm__AExROh1PVWNeP7hmMWuJv->sm_FBDi_PCg670TjHgJTNPcHr/sm_kT9Nk90k05W6dXawldWxZF
->sm_FBDi_PCg670TjHgJTNPcHr;sm_VxJGeiNkgXCriyJHh9D_1k=pm_math_Vector3_norm(&
sm_F6_MIA8cuDOcbm3MYmXY8J);if(sm_VxJGeiNkgXCriyJHh9D_1k==0.0){
pm__lqjegyKuwStj56WZLiC_e->x=pm__lqjegyKuwStj56WZLiC_e->
sm_FzyLWRgau0pMYq2XSI3ETL=pm__lqjegyKuwStj56WZLiC_e->sm_FBDi_PCg670TjHgJTNPcHr
=0.0;(*(&(*pm__lqjegyKuwStj56WZLiC_e).x+(sm_V_W6rV3s9n8ljDz_1otz6L)))=(*(&(*
sm_kT9Nk90k05W6dXawldWxZF).x+(sm_V_W6rV3s9n8ljDz_1otz6L)));return;}
pm_math_Vector3_divide(sm__AExROh1PVWNeP7hmMWuJv,sm_VxJGeiNkgXCriyJHh9D_1k,
pm__lqjegyKuwStj56WZLiC_e);sm_FStFcQlyAJ_dVy4kGZXBPQ=((
sm_VxJGeiNkgXCriyJHh9D_1k)*(sm_VxJGeiNkgXCriyJHh9D_1k))-1.0;if(
sm_FStFcQlyAJ_dVy4kGZXBPQ>=0.0)return;for(sm_FbsbQRdIBwKmhqkBxxfakr=0;
sm_FbsbQRdIBwKmhqkBxxfakr<sm_kiwsUmjqOgxWWHe22JZvr8;++
sm_FbsbQRdIBwKmhqkBxxfakr){sm_FJDxOUSymMGic5lC7ZhrnL n,
sm_kVWI8ALxJdCR_HFnxtl_u8;real_T sm_k7RVes5oHPO2Yi5DMSKkeo;n.x=
pm__lqjegyKuwStj56WZLiC_e->x/sm_FrRR7cWTwOdoeHJEKRplf7;n.
sm_FzyLWRgau0pMYq2XSI3ETL=pm__lqjegyKuwStj56WZLiC_e->sm_FzyLWRgau0pMYq2XSI3ETL
/sm_FOC9NdhwsNtse11nBuYzs0;n.sm_FBDi_PCg670TjHgJTNPcHr=
pm__lqjegyKuwStj56WZLiC_e->sm_FBDi_PCg670TjHgJTNPcHr/sm_VwSe67JBPr8HimDTWJGTH6
;pm_math_Vector3_unit(&n,&n);sm_kVWI8ALxJdCR_HFnxtl_u8 .x=n.x/
sm_kT9Nk90k05W6dXawldWxZF->x;sm_kVWI8ALxJdCR_HFnxtl_u8 .
sm_FzyLWRgau0pMYq2XSI3ETL=n.sm_FzyLWRgau0pMYq2XSI3ETL/
sm_kT9Nk90k05W6dXawldWxZF->sm_FzyLWRgau0pMYq2XSI3ETL;sm_kVWI8ALxJdCR_HFnxtl_u8
.sm_FBDi_PCg670TjHgJTNPcHr=n.sm_FBDi_PCg670TjHgJTNPcHr/
sm_kT9Nk90k05W6dXawldWxZF->sm_FBDi_PCg670TjHgJTNPcHr;sm_F2l4p_g4sn02huHNflQjMH
=((sm_kVWI8ALxJdCR_HFnxtl_u8 .x)*(sm_kVWI8ALxJdCR_HFnxtl_u8 .x))+((
sm_kVWI8ALxJdCR_HFnxtl_u8 .sm_FzyLWRgau0pMYq2XSI3ETL)*(
sm_kVWI8ALxJdCR_HFnxtl_u8 .sm_FzyLWRgau0pMYq2XSI3ETL))+((
sm_kVWI8ALxJdCR_HFnxtl_u8 .sm_FBDi_PCg670TjHgJTNPcHr)*(
sm_kVWI8ALxJdCR_HFnxtl_u8 .sm_FBDi_PCg670TjHgJTNPcHr));
sm_Vqiy96WqvuhCaXm5e_vvT0=2.0*pm_math_Vector3_dot(&sm_F6_MIA8cuDOcbm3MYmXY8J,&
sm_kVWI8ALxJdCR_HFnxtl_u8);sm_k7RVes5oHPO2Yi5DMSKkeo=(-
sm_Vqiy96WqvuhCaXm5e_vvT0+sqrt(sm_Vqiy96WqvuhCaXm5e_vvT0*
sm_Vqiy96WqvuhCaXm5e_vvT0-4*sm_F2l4p_g4sn02huHNflQjMH*
sm_FStFcQlyAJ_dVy4kGZXBPQ))/(2*sm_F2l4p_g4sn02huHNflQjMH);
pm__lqjegyKuwStj56WZLiC_e->x=sm__AExROh1PVWNeP7hmMWuJv->x+
sm_k7RVes5oHPO2Yi5DMSKkeo*n.x;pm__lqjegyKuwStj56WZLiC_e->
sm_FzyLWRgau0pMYq2XSI3ETL=sm__AExROh1PVWNeP7hmMWuJv->sm_FzyLWRgau0pMYq2XSI3ETL
+sm_k7RVes5oHPO2Yi5DMSKkeo*n.sm_FzyLWRgau0pMYq2XSI3ETL;
pm__lqjegyKuwStj56WZLiC_e->sm_FBDi_PCg670TjHgJTNPcHr=sm__AExROh1PVWNeP7hmMWuJv
->sm_FBDi_PCg670TjHgJTNPcHr+sm_k7RVes5oHPO2Yi5DMSKkeo*n.
sm_FBDi_PCg670TjHgJTNPcHr;if(sm_k7RVes5oHPO2Yi5DMSKkeo<
sm_FJUzitoaVYW9i9nv_aa3CM)break;}if(sm_FbsbQRdIBwKmhqkBxxfakr==
sm_kiwsUmjqOgxWWHe22JZvr8){const real_T sm_V3Prc2Wk2axhj5rXtbFCFI=((*(&(*
sm__AExROh1PVWNeP7hmMWuJv).x+(sm_V_W6rV3s9n8ljDz_1otz6L)))>0.0)?+1.0:-1.0;
pm__lqjegyKuwStj56WZLiC_e->x=pm__lqjegyKuwStj56WZLiC_e->
sm_FzyLWRgau0pMYq2XSI3ETL=pm__lqjegyKuwStj56WZLiC_e->sm_FBDi_PCg670TjHgJTNPcHr
=0.0;(*(&(*pm__lqjegyKuwStj56WZLiC_e).x+(sm_V_W6rV3s9n8ljDz_1otz6L)))=
sm_V3Prc2Wk2axhj5rXtbFCFI*sm_F5jLAqkHwnxQaaApL1Hgzd;}}void
sm_kFw5Hc0MIcWRf1TyZlVSYx(const sm_FJDxOUSymMGic5lC7ZhrnL*
sm_kT9Nk90k05W6dXawldWxZF,const sm_FJDxOUSymMGic5lC7ZhrnL*
sm__AExROh1PVWNeP7hmMWuJv,sm_FJDxOUSymMGic5lC7ZhrnL*pm__lqjegyKuwStj56WZLiC_e)
{int sm_FPwVUAP_do0ogeBnBjppr5;const real_T sm_FfDTppU8N_tOWuLK37x_08=1.0e-12;
int sm_kyp6uAyJE40UVuAQNEYzS1= -1;int sm__C7_bxWWay0ibaZzlTzB0d=0,
sm_FnrjFNs9eQp9V5vCxPaoKw=0;real_T sm_V3Prc2Wk2axhj5rXtbFCFI=0.0;real_T
sm_Vm8Les5eaiOvcy3X4EJmIO=0.0,sm__eWK1ZlMUg41VmxYbMEDLX=0.0;
sm_VFTZIhGM7IG9_qIgX7C_Zo(sm_kT9Nk90k05W6dXawldWxZF,sm__AExROh1PVWNeP7hmMWuJv,
pm__lqjegyKuwStj56WZLiC_e);for(sm_FPwVUAP_do0ogeBnBjppr5=0;
sm_FPwVUAP_do0ogeBnBjppr5<20;++sm_FPwVUAP_do0ogeBnBjppr5){
sm_FJDxOUSymMGic5lC7ZhrnL sm_kDTYNj3erXleeDgn6ZWFBW;real_T
sm_VIiVj8U5HAGIVepuonKTdR;real_T sm_VqT0gIZXuM8McuQYYsgQvq[2];const real_T
sm_FR_iOOt_RgS5c5eGw7zoDt=fabs(pm__lqjegyKuwStj56WZLiC_e->x)/
sm_kT9Nk90k05W6dXawldWxZF->x;const real_T sm_Vk0pkxeKVudghTDGdz_lp0=fabs(
pm__lqjegyKuwStj56WZLiC_e->sm_FzyLWRgau0pMYq2XSI3ETL)/
sm_kT9Nk90k05W6dXawldWxZF->sm_FzyLWRgau0pMYq2XSI3ETL;const real_T
sm__0REJ38_cKO_bunM1JCRT_=fabs(pm__lqjegyKuwStj56WZLiC_e->
sm_FBDi_PCg670TjHgJTNPcHr)/sm_kT9Nk90k05W6dXawldWxZF->
sm_FBDi_PCg670TjHgJTNPcHr;const int sm_kAttXW_erP0YVm76_Lqm9r=
sm_kyp6uAyJE40UVuAQNEYzS1;const int sm_kyp6uAyJE40UVuAQNEYzS1=
sm_FR_iOOt_RgS5c5eGw7zoDt>sm_Vk0pkxeKVudghTDGdz_lp0?(sm_FR_iOOt_RgS5c5eGw7zoDt
>sm__0REJ38_cKO_bunM1JCRT_?0:2):(sm_Vk0pkxeKVudghTDGdz_lp0>
sm__0REJ38_cKO_bunM1JCRT_?1:2);real_T x,sm_FzyLWRgau0pMYq2XSI3ETL,
sm_FBDi_PCg670TjHgJTNPcHr;real_T sm_VZFnp731kJ8Qh5Fjp50xGQ,
sm_k1azI0_pHdCpYiHxL0SOEE,sm_krdPQFBDdBWof1Y3GlYCMz;if(
sm_kyp6uAyJE40UVuAQNEYzS1!=sm_kAttXW_erP0YVm76_Lqm9r){real_T
sm_V8Q0kClEPrSW_qAvLLDJPG,sm__5rd1TtwCP4Oa1LLBNlZa4;sm__C7_bxWWay0ibaZzlTzB0d=
sm_kyp6uAyJE40UVuAQNEYzS1<2?(sm_kyp6uAyJE40UVuAQNEYzS1+1):0;
sm_FnrjFNs9eQp9V5vCxPaoKw=sm_kyp6uAyJE40UVuAQNEYzS1>0?(
sm_kyp6uAyJE40UVuAQNEYzS1-1):2;sm_V3Prc2Wk2axhj5rXtbFCFI=((*(&(*
pm__lqjegyKuwStj56WZLiC_e).x+(sm_kyp6uAyJE40UVuAQNEYzS1)))>0.0)?+1.0:-1.0;
sm_V8Q0kClEPrSW_qAvLLDJPG=(*(&(*sm_kT9Nk90k05W6dXawldWxZF).x+(
sm_kyp6uAyJE40UVuAQNEYzS1)))/(*(&(*sm_kT9Nk90k05W6dXawldWxZF).x+(
sm__C7_bxWWay0ibaZzlTzB0d)));sm__5rd1TtwCP4Oa1LLBNlZa4=(*(&(*
sm_kT9Nk90k05W6dXawldWxZF).x+(sm_kyp6uAyJE40UVuAQNEYzS1)))/(*(&(*
sm_kT9Nk90k05W6dXawldWxZF).x+(sm_FnrjFNs9eQp9V5vCxPaoKw)));
sm_Vm8Les5eaiOvcy3X4EJmIO=((sm_V8Q0kClEPrSW_qAvLLDJPG)*(
sm_V8Q0kClEPrSW_qAvLLDJPG));sm__eWK1ZlMUg41VmxYbMEDLX=((
sm__5rd1TtwCP4Oa1LLBNlZa4)*(sm__5rd1TtwCP4Oa1LLBNlZa4));}x=(*(&(*
pm__lqjegyKuwStj56WZLiC_e).x+(sm__C7_bxWWay0ibaZzlTzB0d)));
sm_FzyLWRgau0pMYq2XSI3ETL=(*(&(*pm__lqjegyKuwStj56WZLiC_e).x+(
sm_FnrjFNs9eQp9V5vCxPaoKw)));sm_FBDi_PCg670TjHgJTNPcHr=(*(&(*
pm__lqjegyKuwStj56WZLiC_e).x+(sm_kyp6uAyJE40UVuAQNEYzS1)));
sm_VZFnp731kJ8Qh5Fjp50xGQ= -sm_Vm8Les5eaiOvcy3X4EJmIO*x/
sm_FBDi_PCg670TjHgJTNPcHr;sm_k1azI0_pHdCpYiHxL0SOEE= -
sm__eWK1ZlMUg41VmxYbMEDLX*sm_FzyLWRgau0pMYq2XSI3ETL/sm_FBDi_PCg670TjHgJTNPcHr;
pm_math_Vector3_subtract(pm__lqjegyKuwStj56WZLiC_e,sm__AExROh1PVWNeP7hmMWuJv,&
sm_kDTYNj3erXleeDgn6ZWFBW);sm_krdPQFBDdBWof1Y3GlYCMz=(*(&(
sm_kDTYNj3erXleeDgn6ZWFBW).x+(sm_kyp6uAyJE40UVuAQNEYzS1)));
sm_VqT0gIZXuM8McuQYYsgQvq[0]=(*(&(sm_kDTYNj3erXleeDgn6ZWFBW).x+(
sm__C7_bxWWay0ibaZzlTzB0d)))+sm_VZFnp731kJ8Qh5Fjp50xGQ*
sm_krdPQFBDdBWof1Y3GlYCMz;sm_VqT0gIZXuM8McuQYYsgQvq[1]=(*(&(
sm_kDTYNj3erXleeDgn6ZWFBW).x+(sm_FnrjFNs9eQp9V5vCxPaoKw)))+
sm_k1azI0_pHdCpYiHxL0SOEE*sm_krdPQFBDdBWof1Y3GlYCMz;sm_VIiVj8U5HAGIVepuonKTdR=
pm_math_Vector3_norm(&sm_kDTYNj3erXleeDgn6ZWFBW);if(sm_VIiVj8U5HAGIVepuonKTdR<
sm_FfDTppU8N_tOWuLK37x_08)break;{const real_T sm_kv3YaCMaH2deYLeNZ78uzX=sqrt(
1.0+((sm_VZFnp731kJ8Qh5Fjp50xGQ)*(sm_VZFnp731kJ8Qh5Fjp50xGQ)));if(fabs(
sm_VqT0gIZXuM8McuQYYsgQvq[0])<sm_FfDTppU8N_tOWuLK37x_08*
sm_VIiVj8U5HAGIVepuonKTdR*sm_kv3YaCMaH2deYLeNZ78uzX){const real_T
sm_VCd9Hrdfm1lLe1IAZFTbOT=sqrt(1.0+((sm_k1azI0_pHdCpYiHxL0SOEE)*(
sm_k1azI0_pHdCpYiHxL0SOEE)));if(fabs(sm_VqT0gIZXuM8McuQYYsgQvq[1])<
sm_FfDTppU8N_tOWuLK37x_08*sm_VIiVj8U5HAGIVepuonKTdR*sm_VCd9Hrdfm1lLe1IAZFTbOT)
break;}}{const real_T sm_VMbPnjeK7IlFhyGN8BNZ_n=((sm_FBDi_PCg670TjHgJTNPcHr)*(
sm_FBDi_PCg670TjHgJTNPcHr));const real_T sm_k_fzfUdcK__SfiU6fCJIX9= -
sm_Vm8Les5eaiOvcy3X4EJmIO*(sm_FBDi_PCg670TjHgJTNPcHr-x*
sm_VZFnp731kJ8Qh5Fjp50xGQ)/sm_VMbPnjeK7IlFhyGN8BNZ_n;const real_T
sm_FCftATRiblGveLnzscUkhl= -sm__eWK1ZlMUg41VmxYbMEDLX*(
sm_FBDi_PCg670TjHgJTNPcHr-sm_FzyLWRgau0pMYq2XSI3ETL*sm_k1azI0_pHdCpYiHxL0SOEE)
/sm_VMbPnjeK7IlFhyGN8BNZ_n;const real_T sm__7prUKX2pcS9hPA_MKrkAz= -
sm_VZFnp731kJ8Qh5Fjp50xGQ*sm_k1azI0_pHdCpYiHxL0SOEE/sm_FBDi_PCg670TjHgJTNPcHr;
real_T sm_FWg1uaeb7UGUhi7VmEWdfA,sm_FmZWN6r0kfxSdX_xEH3gC7;const real_T
sm_k_r2Qo4PENWIgiGhJ4tJmR=1.0+sm_k_fzfUdcK__SfiU6fCJIX9*
sm_krdPQFBDdBWof1Y3GlYCMz+((sm_VZFnp731kJ8Qh5Fjp50xGQ)*(
sm_VZFnp731kJ8Qh5Fjp50xGQ));const real_T sm__S8hd_PjC2OpayqNbk_Sff=
sm__7prUKX2pcS9hPA_MKrkAz*sm_krdPQFBDdBWof1Y3GlYCMz+sm_VZFnp731kJ8Qh5Fjp50xGQ*
sm_k1azI0_pHdCpYiHxL0SOEE;const real_T sm_VsB3Uvv1wC0RgDQq0r__rj=1.0+
sm_FCftATRiblGveLnzscUkhl*sm_krdPQFBDdBWof1Y3GlYCMz+((
sm_k1azI0_pHdCpYiHxL0SOEE)*(sm_k1azI0_pHdCpYiHxL0SOEE));const real_T
sm_k1MS_iHkuQ_N_9nSUs_hoP=sm__S8hd_PjC2OpayqNbk_Sff;real_T
sm_kr54pdOF7m03iip5bybdRd[4],sm_VqUVWV52_Atgb1_f86RKvj[2];
sm_kr54pdOF7m03iip5bybdRd[0]=sm_k_r2Qo4PENWIgiGhJ4tJmR,
sm_kr54pdOF7m03iip5bybdRd[1]=sm_k1MS_iHkuQ_N_9nSUs_hoP,
sm_kr54pdOF7m03iip5bybdRd[2]=sm__S8hd_PjC2OpayqNbk_Sff,
sm_kr54pdOF7m03iip5bybdRd[3]=sm_VsB3Uvv1wC0RgDQq0r__rj;
sm_VqT0gIZXuM8McuQYYsgQvq[0]= -sm_VqT0gIZXuM8McuQYYsgQvq[0],
sm_VqT0gIZXuM8McuQYYsgQvq[1]= -sm_VqT0gIZXuM8McuQYYsgQvq[1];
pm_math_lin_alg_geSolve2x2(sm_kr54pdOF7m03iip5bybdRd,sm_VqT0gIZXuM8McuQYYsgQvq
,sm_VqUVWV52_Atgb1_f86RKvj);{const real_T sm_VOanr5Y2TU8uhTeVFY_0Nv=(*(&(*
sm_kT9Nk90k05W6dXawldWxZF).x+(sm__C7_bxWWay0ibaZzlTzB0d)));const real_T
sm_k1iJqBKsVS4zbLiknEiAjY=(*(&(*sm_kT9Nk90k05W6dXawldWxZF).x+(
sm_FnrjFNs9eQp9V5vCxPaoKw)));const real_T sm_FlXLZk_Iyj_KiLv5LZouhk=(*(&(*
pm__lqjegyKuwStj56WZLiC_e).x+(sm__C7_bxWWay0ibaZzlTzB0d)))/
sm_VOanr5Y2TU8uhTeVFY_0Nv;const real_T sm_FNz_bmETxdpgbmIpb1YnUV=(*(&(*
pm__lqjegyKuwStj56WZLiC_e).x+(sm_FnrjFNs9eQp9V5vCxPaoKw)))/
sm_k1iJqBKsVS4zbLiknEiAjY;const real_T sm__Oq3oK1SEidwV1uKneWeJI=
sm_VqUVWV52_Atgb1_f86RKvj[0]/sm_VOanr5Y2TU8uhTeVFY_0Nv;const real_T
sm_keV3VdtbRv07ae6e7uUryW=sm_VqUVWV52_Atgb1_f86RKvj[1]/
sm_k1iJqBKsVS4zbLiknEiAjY;const real_T sm_F2l4p_g4sn02huHNflQjMH=
sm__Oq3oK1SEidwV1uKneWeJI*sm__Oq3oK1SEidwV1uKneWeJI+sm_keV3VdtbRv07ae6e7uUryW*
sm_keV3VdtbRv07ae6e7uUryW;const real_T sm_Vqiy96WqvuhCaXm5e_vvT0=2.0*(
sm__Oq3oK1SEidwV1uKneWeJI*sm_FlXLZk_Iyj_KiLv5LZouhk+sm_keV3VdtbRv07ae6e7uUryW*
sm_FNz_bmETxdpgbmIpb1YnUV);const real_T sm_FStFcQlyAJ_dVy4kGZXBPQ=
sm_FlXLZk_Iyj_KiLv5LZouhk*sm_FlXLZk_Iyj_KiLv5LZouhk+sm_FNz_bmETxdpgbmIpb1YnUV*
sm_FNz_bmETxdpgbmIpb1YnUV-1.0;if(sm_F2l4p_g4sn02huHNflQjMH+
sm_Vqiy96WqvuhCaXm5e_vvT0+sm_FStFcQlyAJ_dVy4kGZXBPQ>0.0){const real_T
sm_k7RVes5oHPO2Yi5DMSKkeo=0.99*(-sm_Vqiy96WqvuhCaXm5e_vvT0+sqrt(
sm_Vqiy96WqvuhCaXm5e_vvT0*sm_Vqiy96WqvuhCaXm5e_vvT0-4*
sm_F2l4p_g4sn02huHNflQjMH*sm_FStFcQlyAJ_dVy4kGZXBPQ))/(2*
sm_F2l4p_g4sn02huHNflQjMH);sm_VqUVWV52_Atgb1_f86RKvj[0]*=
sm_k7RVes5oHPO2Yi5DMSKkeo;sm_VqUVWV52_Atgb1_f86RKvj[1]*=
sm_k7RVes5oHPO2Yi5DMSKkeo;}}sm_FWg1uaeb7UGUhi7VmEWdfA=x+
sm_VqUVWV52_Atgb1_f86RKvj[0];sm_FmZWN6r0kfxSdX_xEH3gC7=
sm_FzyLWRgau0pMYq2XSI3ETL+sm_VqUVWV52_Atgb1_f86RKvj[1];if(x*
sm_FWg1uaeb7UGUhi7VmEWdfA<0.0){const real_T sm_k7RVes5oHPO2Yi5DMSKkeo= -x/(
sm_FWg1uaeb7UGUhi7VmEWdfA-x);sm_FmZWN6r0kfxSdX_xEH3gC7=(1.0-
sm_k7RVes5oHPO2Yi5DMSKkeo)*sm_FzyLWRgau0pMYq2XSI3ETL+sm_k7RVes5oHPO2Yi5DMSKkeo
*sm_FmZWN6r0kfxSdX_xEH3gC7;sm_FWg1uaeb7UGUhi7VmEWdfA=0.0;}if(
sm_FzyLWRgau0pMYq2XSI3ETL*sm_FmZWN6r0kfxSdX_xEH3gC7<0.0){const real_T
sm_k7RVes5oHPO2Yi5DMSKkeo= -sm_FzyLWRgau0pMYq2XSI3ETL/(
sm_FmZWN6r0kfxSdX_xEH3gC7-sm_FzyLWRgau0pMYq2XSI3ETL);sm_FWg1uaeb7UGUhi7VmEWdfA
=(1.0-sm_k7RVes5oHPO2Yi5DMSKkeo)*x+sm_k7RVes5oHPO2Yi5DMSKkeo*
sm_FWg1uaeb7UGUhi7VmEWdfA;sm_FmZWN6r0kfxSdX_xEH3gC7=0.0;}(*(&(*
pm__lqjegyKuwStj56WZLiC_e).x+(sm__C7_bxWWay0ibaZzlTzB0d)))=
sm_FWg1uaeb7UGUhi7VmEWdfA;(*(&(*pm__lqjegyKuwStj56WZLiC_e).x+(
sm_FnrjFNs9eQp9V5vCxPaoKw)))=sm_FmZWN6r0kfxSdX_xEH3gC7;(*(&(*
pm__lqjegyKuwStj56WZLiC_e).x+(sm_kyp6uAyJE40UVuAQNEYzS1)))=
sm_V3Prc2Wk2axhj5rXtbFCFI*sm_kTN0fB7zC_G9XuzPJ4Migy(sm_kT9Nk90k05W6dXawldWxZF,
pm__lqjegyKuwStj56WZLiC_e,sm__C7_bxWWay0ibaZzlTzB0d,sm_FnrjFNs9eQp9V5vCxPaoKw,
sm_kyp6uAyJE40UVuAQNEYzS1);}}}real_T sm_VCNAAYtylypLhDX8cqY2hq(const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_kT9Nk90k05W6dXawldWxZF,const
sm_FJDxOUSymMGic5lC7ZhrnL*sm_Fsg1xEReOKlTbLYChSpHhT,sm_FJDxOUSymMGic5lC7ZhrnL*
sm_VSAYOUZM1zK7ZqkO4wjRIY){real_T sm__Mn_cVpt4AGtYDv8A4pXml,
sm__V6X0BItikKid9V47FK_Nq,sm__JHs3lgHjXp6gHav_WPPR8,sm_VEDlmiEaYZGiaLOBROC20K;
sm_FJDxOUSymMGic5lC7ZhrnL sm_VJnSJ6o6qdOwZXYKoqQJbg;real_T
sm_kd1Plhqj0HK8XLfhRAQVsc;sm_kFw5Hc0MIcWRf1TyZlVSYx(sm_kT9Nk90k05W6dXawldWxZF,
sm_Fsg1xEReOKlTbLYChSpHhT,sm_VSAYOUZM1zK7ZqkO4wjRIY);pm_math_Vector3_subtract(
sm_Fsg1xEReOKlTbLYChSpHhT,sm_VSAYOUZM1zK7ZqkO4wjRIY,&sm_VJnSJ6o6qdOwZXYKoqQJbg
);sm_kd1Plhqj0HK8XLfhRAQVsc=pm_math_Vector3_norm(&sm_VJnSJ6o6qdOwZXYKoqQJbg);
sm__Mn_cVpt4AGtYDv8A4pXml=sm_Fsg1xEReOKlTbLYChSpHhT->x/
sm_kT9Nk90k05W6dXawldWxZF->x;sm__V6X0BItikKid9V47FK_Nq=
sm_Fsg1xEReOKlTbLYChSpHhT->sm_FzyLWRgau0pMYq2XSI3ETL/sm_kT9Nk90k05W6dXawldWxZF
->sm_FzyLWRgau0pMYq2XSI3ETL;sm__JHs3lgHjXp6gHav_WPPR8=
sm_Fsg1xEReOKlTbLYChSpHhT->sm_FBDi_PCg670TjHgJTNPcHr/sm_kT9Nk90k05W6dXawldWxZF
->sm_FBDi_PCg670TjHgJTNPcHr;sm_VEDlmiEaYZGiaLOBROC20K=
sm__Mn_cVpt4AGtYDv8A4pXml*sm__Mn_cVpt4AGtYDv8A4pXml+sm__V6X0BItikKid9V47FK_Nq*
sm__V6X0BItikKid9V47FK_Nq+sm__JHs3lgHjXp6gHav_WPPR8*sm__JHs3lgHjXp6gHav_WPPR8-
1.0;sm_VEDlmiEaYZGiaLOBROC20K=(sm_VEDlmiEaYZGiaLOBROC20K<0.0?-1.0:1.0);
sm_kd1Plhqj0HK8XLfhRAQVsc*=sm_VEDlmiEaYZGiaLOBROC20K;return
sm_kd1Plhqj0HK8XLfhRAQVsc;}
