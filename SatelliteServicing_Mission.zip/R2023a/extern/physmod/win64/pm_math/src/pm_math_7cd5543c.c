#include "stddef.h"
#include "stdlib.h"
#include "pm_std.h"
extern creal_T pm_math_VblngOCNVBKdi19N4_Mcse(const creal_T
pm_math_FzyLWRgau0pMYq2XSI3ETL);
#include "pm_std.h"
extern void pm_math_V4wY5inRPrGJ_q94UMd56c(const int
pm_math_FdNKyaRLqeWhg5tGqF_VYT,const int pm_math__jwySfHyx1SXgXJeVWoIzb,const
real_T*pm_math_F2l4p_g4sn02huHNflQjMH,const real_T*
pm_math_Vqiy96WqvuhCaXm5e_vvT0,creal_T*pm_math_kJeUz19e49pVaDwcttsZep,creal_T*
pm_math_kyfq6L_eQbdYcPuOovpRDW,creal_T*pm_math_kXii4Miq3Y_ShPn9EHS3D5,creal_T*
pm_math_FYAUa2zJy8Cah1YsdPJok5,creal_T*pm_math__Vu43oWQSkpLiuph6ye1KN,creal_T*
pm_math_VHUYV1kdST0efLHvpiBBXm,creal_T*pm_math_VRZCD_UL_ESThy75dC9J8D,creal_T*
pm_math_Fo1tUR18sIdue1E1QXuOnL,creal_T*pm_math___7SXc4Q_w8saDIIf2ecjp,real_T*
pm_math_ktFLct2wbuxD_5iTvRiZEZ,real_T*pm_math_kHM1aMQ_rJdeheUxTze_oV,int32_T*
pm_math__qLHk6daYiGnXenMNt2kR_,int8_T*pm_math_VS3xMd4pLil0i5cxPD0ErK);
#include "pm_std.h"
extern real_T pm_math_V6hUjCc3PiCAauyMwJP5nb;extern real_T
pm_math_Vco4W7EuZu4k_1cAN9SDVG;extern real_T pm_math_k9HpTo0HuFt0gDRVyg17Wc;
extern real32_T pm_math__JOzYwXJOmSsiaZ6WMnnZZ;extern real32_T
pm_math_VaGr_igKLHx0bDW9g54I6v;extern real32_T pm_math_kZu0y5Pv4G8tg1EE_V6tGP;
extern void pm_math_F3OoZ1Weno85bujDCIyv_c(void);extern boolean_T
pm_math__LIYjt5pi54rVTuNKI6I5_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
boolean_T pm_math_VK2BuaMRCmOxjLjqE4tZMh(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T pm_math__J9snrOx2Cp4dD_e3lGtRm
(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T
pm_math_kwH13YYrpKtAbDLZ9Q_8I9(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx);
#include "math.h"
creal_T pm_math_VblngOCNVBKdi19N4_Mcse(const creal_T
pm_math_FzyLWRgau0pMYq2XSI3ETL){creal_T pm_math_FBDi_PCg670TjHgJTNPcHr;double
pm_math_VnDDTCPMOCtZbLkd7tVi0E;double pm_math__7xdKgx3l4OzY5IWurOMqm;double
pm_math_F32Ql82vv6pW_PYIdpkFQ0;pm_math_VnDDTCPMOCtZbLkd7tVi0E=fabs(
pm_math_FzyLWRgau0pMYq2XSI3ETL.re);pm_math__7xdKgx3l4OzY5IWurOMqm=fabs(
pm_math_FzyLWRgau0pMYq2XSI3ETL.im);if(pm_math_FzyLWRgau0pMYq2XSI3ETL.im==0.0){
pm_math_FBDi_PCg670TjHgJTNPcHr.re=1.0/pm_math_FzyLWRgau0pMYq2XSI3ETL.re;
pm_math_FBDi_PCg670TjHgJTNPcHr.im=0.0;}else if(pm_math_FzyLWRgau0pMYq2XSI3ETL.
re==0.0){pm_math_FBDi_PCg670TjHgJTNPcHr.re=0.0;pm_math_FBDi_PCg670TjHgJTNPcHr.
im= -1.0/pm_math_FzyLWRgau0pMYq2XSI3ETL.im;}else if(
pm_math_VnDDTCPMOCtZbLkd7tVi0E>pm_math__7xdKgx3l4OzY5IWurOMqm){
pm_math__7xdKgx3l4OzY5IWurOMqm=pm_math_FzyLWRgau0pMYq2XSI3ETL.im/
pm_math_FzyLWRgau0pMYq2XSI3ETL.re;pm_math_F32Ql82vv6pW_PYIdpkFQ0=
pm_math_FzyLWRgau0pMYq2XSI3ETL.re+pm_math__7xdKgx3l4OzY5IWurOMqm*
pm_math_FzyLWRgau0pMYq2XSI3ETL.im;pm_math_FBDi_PCg670TjHgJTNPcHr.re=1.0/
pm_math_F32Ql82vv6pW_PYIdpkFQ0;pm_math_FBDi_PCg670TjHgJTNPcHr.im= -
pm_math__7xdKgx3l4OzY5IWurOMqm/pm_math_F32Ql82vv6pW_PYIdpkFQ0;}else if(
pm_math_VnDDTCPMOCtZbLkd7tVi0E==pm_math__7xdKgx3l4OzY5IWurOMqm){
pm_math__7xdKgx3l4OzY5IWurOMqm=0.5;if(pm_math_FzyLWRgau0pMYq2XSI3ETL.re<0.0){
pm_math__7xdKgx3l4OzY5IWurOMqm= -0.5;}pm_math_F32Ql82vv6pW_PYIdpkFQ0=0.5;if(
pm_math_FzyLWRgau0pMYq2XSI3ETL.im<0.0){pm_math_F32Ql82vv6pW_PYIdpkFQ0= -0.5;}
pm_math_FBDi_PCg670TjHgJTNPcHr.re=pm_math__7xdKgx3l4OzY5IWurOMqm/
pm_math_VnDDTCPMOCtZbLkd7tVi0E;pm_math_FBDi_PCg670TjHgJTNPcHr.im= -
pm_math_F32Ql82vv6pW_PYIdpkFQ0/pm_math_VnDDTCPMOCtZbLkd7tVi0E;}else{
pm_math__7xdKgx3l4OzY5IWurOMqm=pm_math_FzyLWRgau0pMYq2XSI3ETL.re/
pm_math_FzyLWRgau0pMYq2XSI3ETL.im;pm_math_F32Ql82vv6pW_PYIdpkFQ0=
pm_math_FzyLWRgau0pMYq2XSI3ETL.im+pm_math__7xdKgx3l4OzY5IWurOMqm*
pm_math_FzyLWRgau0pMYq2XSI3ETL.re;pm_math_FBDi_PCg670TjHgJTNPcHr.re=
pm_math__7xdKgx3l4OzY5IWurOMqm/pm_math_F32Ql82vv6pW_PYIdpkFQ0;
pm_math_FBDi_PCg670TjHgJTNPcHr.im= -1.0/pm_math_F32Ql82vv6pW_PYIdpkFQ0;}return
pm_math_FBDi_PCg670TjHgJTNPcHr;}
