#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "string.h"
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
#include "pm_std.h"
typedef struct mc_VWJbTwnVZB_LVqIIM_COT0{int32_T mc_FvxKbdtfPKOYaymjtthQ0G,
mc__0REJ38_cKO_bunM1JCRT_,id;struct mc_VWJbTwnVZB_LVqIIM_COT0*
mc_Vk_mYyVPAa4IZeLta2BLLG,*mc_VKkEmtOg5lC4dH7wVVnG4C;}
mc_FSz7cV1MCGScXq_M5VT121;typedef struct mc_kjlHS2Mzxsh6gyVZ329fra{
mc_FSz7cV1MCGScXq_M5VT121*mc__a1o_SOX2HC3f9QpH_hO5s;PmIntVector*
mc__5uLb2__blGtb9EQ9Zwa2_;PmIntVector*mQ;}mc_F9HbKNDZMeOehmlKWGUdea;typedef
struct mc__fV9rOH7ci_OWykNO7xTBO{size_t mc_VLHhnPUiNQpve5VIL9P3O9,n;int32_T*
mc_FvxKbdtfPKOYaymjtthQ0G,*mc__0REJ38_cKO_bunM1JCRT_,*
mc_Vk_mYyVPAa4IZeLta2BLLG,*mc_VKkEmtOg5lC4dH7wVVnG4C;int32_T*
pm__lqjegyKuwStj56WZLiC_e,*mc__AExROh1PVWNeP7hmMWuJv;}
mc_FwUXSPCwCAC_jydGHlCZxe;PmIntVector*mc__oCV63DXBpKVZL_8tU2Wiz(const
mc_FSz7cV1MCGScXq_M5VT121*mc_VPPSxR3RRt0pXLadx2tWo7,const PmSparsityPattern*
mc_FNLG4N0Qc3OxdmBVwutDsy,PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z);void
mc__RLQweDZtv0hhLXz_f8MMi(mc_FSz7cV1MCGScXq_M5VT121*mc_Fxl4i6XHkE8cY9kYmlJixt)
;mc_FSz7cV1MCGScXq_M5VT121*mc_VCdOZjcBUFORayuNvO7rtI(mc_FSz7cV1MCGScXq_M5VT121
*mc_Fxl4i6XHkE8cY9kYmlJixt);void mc_VbHMSzzYu5_WZiNG_fSW8Q(
mc_FSz7cV1MCGScXq_M5VT121*mc_Fxl4i6XHkE8cY9kYmlJixt,int32_T
mc_FvxKbdtfPKOYaymjtthQ0G);int32_T mc__1AbngzPnBGnXXDldWop_b(
mc_FSz7cV1MCGScXq_M5VT121*mc_VPPSxR3RRt0pXLadx2tWo7);void
mc_VBCIjXiCCT_RXmHVT9WPVa(mc_F9HbKNDZMeOehmlKWGUdea*mc_VpSwxG2uxL4JaLmMQqUqTJ)
;mc_FwUXSPCwCAC_jydGHlCZxe*mc_F79LLfWDdKORZ1K7KKqAke(const
mc_F9HbKNDZMeOehmlKWGUdea*mc_VpSwxG2uxL4JaLmMQqUqTJ);mc_F9HbKNDZMeOehmlKWGUdea
*mc_perm_data_from_flat(const mc_FwUXSPCwCAC_jydGHlCZxe*
mc_Fw6WJxuximC4jHgRLzUSDo);void mc_Vq5AUJWyc3xVgP5Ff1_aP6(
mc_FwUXSPCwCAC_jydGHlCZxe*mc_Fw6WJxuximC4jHgRLzUSDo);
#include "limits.h"
#include "math.h"
#include "stdio.h"
typedef struct mc_kJu3kbp1UqpibDtb06hKK_{int32_T mc_FIxFweA3fcKFfuFXAKfA47;
int32_T mc_k_43QOoDDL_PZegt1kRhBI;int32_T mc_VLHhnPUiNQpve5VIL9P3O9;int32_T n;
int32_T*pm__lqjegyKuwStj56WZLiC_e;int32_T*mc_kwrB3ZoKf7OufTHWaHJV7a;double*x;
int32_T mc___ECRgjqShlp_PytRplerL;}mc_F5Olyc6xUoG7ZyDq78exBD;typedef struct
mc_kCiNuo5v78xTj5YTsyYRef{int32_T*mc_V1pxxydYEnWVVi3QKesjvf;double*x;
mc_F5Olyc6xUoG7ZyDq78exBD*A;}mc_FZtW0WFyhCCTVicSdDpulD;
mc_F5Olyc6xUoG7ZyDq78exBD*mc_F_KsXRscHI0GbqNNEbk0p9(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vqiy96WqvuhCaXm5e_vvT0,double mc_kcda_aHAM4WIXuM_xBDdLt,double
mc_kCPCzQ_4FF88XTgtMjWqKy);int32_T mc_FzsS3TwPKLdMiiny4fRXZB(
mc_FZtW0WFyhCCTVicSdDpulD*mc_F5vPJ6MbAI8phLV7sKWrKK,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kJW4fGfd5r_MiuJBhKSynA,const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_kmcvnGchjqCwaq5beTqlxC,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kyfq6L_eQbdYcPuOovpRDW);int32_T mc_FRcDfQc8skGuVLZfeGfRsQ(int32_T
mc_FruBC65sPgSaZ5e_Y8cbTC,const mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kPZtfcLRq8hvd17AwbGSfy(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_V91rYIvDBkGRba7MvGcPUK);int32_T
mc_VufLWRyy__x0aHcAK11u_9(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_VMB1wjlajc42dihJmzkfVL(mc_F5Olyc6xUoG7ZyDq78exBD*mc_V91rYIvDBkGRba7MvGcPUK,
int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double x);
int32_T mc_kyNdNb1Od1pmc5h9_bRwz3(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
double*x,double*mc_FzyLWRgau0pMYq2XSI3ETL);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kKDpTzN8jw8R_La01FPHqo(FILE*mc_Fe6copTTRcKEayCm87ABO_);int32_T
mc_FBcYs04mnxCNjei3Py1gDA(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b,double mc_FfDTppU8N_tOWuLK37x_08);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_F1T9nfE5YBd9_eUgmYQiFQ(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vqiy96WqvuhCaXm5e_vvT0);double mc__mMjuh4GBSd2gPZyGSIEB7(const
mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc__Wuhz03is3hpg54E4_8dDo(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kPdbGJs0Eb_x_Hxa5hZJEc);int32_T
mc_kjcu6drPCUOjbP4z73xob_(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kzs_RE98zypjVHi58lxG6O(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_kVkvrfpzuVduaPTr5FLF8K);void*mc_VInfIQCul4ShdLlbU4F0WB(int32_T n,size_t size
);void*mc__Mim_3QMMSxfi9M5sbbxcM(void*pm__lqjegyKuwStj56WZLiC_e);void*
mc_k0mbD5QrRepqjLd_9sSyDz(void*pm__lqjegyKuwStj56WZLiC_e,int32_T n,size_t size
,int32_T*mc__suOgr_4PeCIZi_uhoSVwf);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_VFJZ9bgvffCPg9PZXPkAVk(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n,int32_T
mc_FIxFweA3fcKFfuFXAKfA47,int32_T mc_kVkvrfpzuVduaPTr5FLF8K,int32_T
mc_Vk3BcXZzVaxpfi0XcV5sHr);mc_F5Olyc6xUoG7ZyDq78exBD*mc__BJ1NEDJTgOMhaJKDrM6pN
(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc_VptvBjskDA83heaLThR8oY(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_FIxFweA3fcKFfuFXAKfA47);void*
mc_ktrY1jmEuvhTfeGflVz93o(int32_T n,size_t size);int32_T
mc_Vw_wVSv6gGKFY1Dalcu6zm(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_kPdbGJs0Eb_x_Hxa5hZJEc);typedef struct mc__adJqrskeJhDYmBVMGWunh{int32_T*
mc_FjDIs2zMLtx5We_IND4g6I;int32_T*mc__AExROh1PVWNeP7hmMWuJv;int32_T*
mc_k6HeriBJpGdZiPlDO4UZXp;int32_T*mc_FXT4jPWj6stSWaiL5dan3b;int32_T*
mc_F_jeaQAcXwGbVXb0t9dFxz;int32_T mc_k3zUxpU0ydGajPq7EF4qn3;double
mc_ViTJrDHWLs8OjimuuiIsPe;double mc__GPciDcZ6Z0EViGxgxdf9y;}
mc_VWUvciwDK_dziLpafRxush;typedef struct mc_kp2eGzAtU2WUXP2RD6EKGO{
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo;mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vi4Cp0qK964NYTFMGr9Ttn;int32_T*mc_FjDIs2zMLtx5We_IND4g6I;double*
mc_Vqiy96WqvuhCaXm5e_vvT0;}mc_kPBB5xuFz74_aaM4N6U4Jv;typedef struct
mc_F7stcouwJ9CTjywpKHMmeT{mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo;
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn;mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FqUCZrSGGNOuePgRr82o_8;int32_T*mc_FjDIs2zMLtx5We_IND4g6I;int32_T*
mc__AExROh1PVWNeP7hmMWuJv;double*x;int32_T*mc__01SK3u3lG0GaLCTTSoVGO;int32_T
mc__0REJ38_cKO_bunM1JCRT_;int32_T mc_kNbvLmFI_EtAay5OpgNJFz;}
mc_k2Ca2__AWx8Yd9MBB6pntX;typedef struct mc__goErATdCI0HWaZaNs9Xzt{int32_T*
pm__lqjegyKuwStj56WZLiC_e;int32_T*mc__AExROh1PVWNeP7hmMWuJv;int32_T*
mc_kUQBO1dSP8_IVqRAUx4R8G;int32_T*mc_FQferGZUKft3_i5GvYy4Oy;int32_T
mc_kLMRRiSdJr4aaLEtYiWmgE;int32_T mc__ys6fNnaK541fDBqN87Aa_[5];int32_T
mc_Fet2g81LNVG6_mJHNhUAfo[5];}mc_koBw_auTeOpFWTLu_1_hd3;int32_T*
mc_FAnXK3hkeY_FimobZpSWy4(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A);mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_kF0bdRSgaVCZhHmbCIFdvh(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
mc_VWUvciwDK_dziLpafRxush*mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_koBw_auTeOpFWTLu_1_hd3
*mc__JYcNbbJ8GxnaT0gipcMUY(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_k6QxQSbjWyGhcXikh7jTLf);int32_T mc_FEBJlPSzZh_ZiqgXtpZSYe(
mc_F5Olyc6xUoG7ZyDq78exBD*A,double mc_FfDTppU8N_tOWuLK37x_08);int32_T
mc_VywKLPGT27tscy1s60Ehlb(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_ViJBWCuvxwlcXP5hTDAmft(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kJeUz19e49pVaDwcttsZep,int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,double
mc_kCPCzQ_4FF88XTgtMjWqKy,double*x);int32_T mc_Vux1rLMHdIOwYHo_GgP0nf(const
int32_T*pm__lqjegyKuwStj56WZLiC_e,const double*b,double*x,int32_T n);int32_T
mc_V3SIv4FNXnS__9UCAN4nes(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc__ut5UfJwzNlZ_XZC_yEgKo,double*x);int32_T mc__U2f_z8iKPWQZTkLMApmoB(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,double*x);
mc_kPBB5xuFz74_aaM4N6U4Jv*mc__OANyqXuH__Wi5n3l9hrJe(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT,double mc_FfDTppU8N_tOWuLK37x_08);int32_T
mc_F0B4l8FzVghjVeO_dlmLre(mc_k2Ca2__AWx8Yd9MBB6pntX*mc_F3nVSXkoDK8VeeL5OmY0_B,
const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc__0REJ38_cKO_bunM1JCRT_,double
mc_FfDTppU8N_tOWuLK37x_08);int32_T mc_k0_k_zhpwQdeVq5LHulheI(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,double*x,int32_T
mc__0REJ38_cKO_bunM1JCRT_);int32_T mc_kZxFnksrKp_zYuKnqu2HE7(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x,int32_T
mc__0REJ38_cKO_bunM1JCRT_);mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VD2E_WGEctCGXH2bprw8Sw
(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT,int32_T*mc__q70gXw8N_xsWy9UoFEkTZ);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_k9MmNIu2n4W9jaO59BYYYQ(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*pm__lqjegyKuwStj56WZLiC_e,const
int32_T*mc__AExROh1PVWNeP7hmMWuJv,int32_T mc_kVkvrfpzuVduaPTr5FLF8K);int32_T*
mc__wD389_14ZOPfyx5EQ5Eez(const int32_T*pm__lqjegyKuwStj56WZLiC_e,int32_T n);
int32_T mc_VQ7L8M0ejvGI_H70X2UUEW(const int32_T*pm__lqjegyKuwStj56WZLiC_e,
const double*b,double*x,int32_T n);mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_FnFQE__lyw88fDjvIJlbiy(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
mc_VWUvciwDK_dziLpafRxush*mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_VWUvciwDK_dziLpafRxush
*mc_VHjWZG2MGPlHg9FEzWcJP5(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A);mc_VWUvciwDK_dziLpafRxush*
mc__HBpzStane0GaaQtDu_y9F(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_VWCrbzOuAe4hay4E_Unnfg);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_V0SSOL16_J8_aXLgyS19I7(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*mc_FjDIs2zMLtx5We_IND4g6I,int32_T
mc_kVkvrfpzuVduaPTr5FLF8K);int32_T mc_VLrR9_1UGwSOj5Fn6W7Qqm(
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,int32_T
mc__Gce0mZquR4HgLX8bLfI0G,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp);int32_T
mc_kX6eNI2bFZ__cyLxZQzP6Z(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x);int32_T mc_FRCJeuT32S4AW5Dz6aeK7v(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x);
mc_VWUvciwDK_dziLpafRxush*mc_Fe3WdhVNm1lm_TputcgM_w(mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VZ5qqYWDqx_NaqOx3T8EeD
(mc_kPBB5xuFz74_aaM4N6U4Jv*mc_F3nVSXkoDK8VeeL5OmY0_B);
mc_koBw_auTeOpFWTLu_1_hd3*mc_kqyKn15o9uW8cumoBbxjEC(mc_koBw_auTeOpFWTLu_1_hd3*
mc_kyfq6L_eQbdYcPuOovpRDW);mc_k2Ca2__AWx8Yd9MBB6pntX*mc_VHN9RInD2_hMj5etCbnyx_
(int32_T n,int32_T mc_ViTJrDHWLs8OjimuuiIsPe,int32_T mc__GPciDcZ6Z0EViGxgxdf9y
,int32_T mc_kzJQc_tutvlgaDzae7WNSs);mc_k2Ca2__AWx8Yd9MBB6pntX*
mc__yL5RKrY3uxPdqSDLO3FGs(mc_k2Ca2__AWx8Yd9MBB6pntX*mc_F3nVSXkoDK8VeeL5OmY0_B)
;mc_FZtW0WFyhCCTVicSdDpulD*mc__HHwQflOYfSli96OPqkpYJ(int32_T
mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n,int32_T mc_kNgcOktCtQxdYedrGvFn5i);
mc_FZtW0WFyhCCTVicSdDpulD*mc_Fbb_drPN_2hT_m2GWLCLZl(mc_FZtW0WFyhCCTVicSdDpulD*
mc_F5vPJ6MbAI8phLV7sKWrKK);int32_T*mc_Vq30ZRWDg0Ope1BH5Wlxn6(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp,const
int32_T*mc_VlzlbuXTjytugLyuufocD_,int32_T mc_F4FqMtzrIr0Ih9YO_bpGqr);double
mc_FVvAdrNPbiK3ciVovphJqC(int32_T*pm__lqjegyKuwStj56WZLiC_e,int32_T*
mc_FFZbGh27ya8eem_J_hUtAZ,int32_T n);int32_T mc_VqGwhdpnmyGkc5egfuzI9R(int32_T
mc_kyp6uAyJE40UVuAQNEYzS1,mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,
int32_T mc_V_3pIMGNi1pQiyeoIJloym,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,int32_T*
mc__nUrXnK_PlSWXDXfav4gTu,const int32_T*mc_FjDIs2zMLtx5We_IND4g6I);int32_T
mc__PAs7jPQB3p6jamHMS77BU(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_V2__YrimeI4E_yWnhKofpy,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp,int32_T*
mc_FQferGZUKft3_i5GvYy4Oy,int32_T*mc_V1pxxydYEnWVVi3QKesjvf);int32_T*
mc_kvTl6JgGLlpghLCj7SJ8Zb(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_F4FqMtzrIr0Ih9YO_bpGqr);int32_T mc__78cLFJw_ySFbTb4k127zA(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T(*mc__afZS_O3BMKpbuqov2Sqn2)(int32_T,
int32_T,double,void*),void*pm__sjTRWOMR4WzZisVeB2fYm);double
mc_FCxXZX7qax4Cf1qhlQMJ_K(double*x,double*mc_kCPCzQ_4FF88XTgtMjWqKy,int32_T n)
;int32_T mc_VjKkbv4A0k47XifnshEiFz(int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T
mc_kyp6uAyJE40UVuAQNEYzS1,const int32_T*mc__gfup5UQrKdtaLq0JwxBv8,int32_T*
mc_F_OdG3IuH0OSgXl2PAC3Wt,int32_T*mc_FYLTf08Tnt0_hXkhRr2i3V,int32_T*
mc_FaaXUqBjXi_Cc58Cr7D5Pw,int32_T*mc_kCfp_4sWHvtwdmGWqI8AP3);int32_T*
mc__KcZrPHSqmd_Winpkn_zbn(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_k6QxQSbjWyGhcXikh7jTLf);int32_T*mc_VSXwwVMHmJpqfu39VY7afd(const int32_T*
mc_k6HeriBJpGdZiPlDO4UZXp,int32_T n);int32_T*mc_kkUWSotb_oO3YDxqYUxvcp(int32_T
n,int32_T mc_k6QxQSbjWyGhcXikh7jTLf);int32_T mc_VJp2YHG9mB_gfHKfpAYT7q(
mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,const int32_T*
mc_FjDIs2zMLtx5We_IND4g6I);int32_T mc__bZ1EHlIu8t8WL63CWhZ5j(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double
mc_kCPCzQ_4FF88XTgtMjWqKy,int32_T*mc_V1pxxydYEnWVVi3QKesjvf,double*x,int32_T
mc__CLRBwg4eOSEiqHPYKDedF,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
int32_T mc___ECRgjqShlp_PytRplerL);mc_koBw_auTeOpFWTLu_1_hd3*
mc__17ror7eCZl9eiXoZ3px_g(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_VI_gkAfbWYGleX3FfR8roq(mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,
const mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,double*x,const
int32_T*mc_FjDIs2zMLtx5We_IND4g6I,int32_T mc___aedK39Pax6Ziebprhh0i);int32_T
mc_Fx2UoNYY4W0WY5iaMITghy(int32_T mc_kyp6uAyJE40UVuAQNEYzS1,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc_FcKez189ghKAYyDjWA9v5n,const int32_T*
mc_FTf2iFFdsgK3hewKsMgEx4,int32_T*mc_VlzlbuXTjytugLyuufocD_,int32_T*
mc_F65aUsM8ggpTgiucZs1fmm);mc_koBw_auTeOpFWTLu_1_hd3*mc_VfRC_16CnDtIYTHey4Izis
(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n);mc_koBw_auTeOpFWTLu_1_hd3*
mc_Fm6BWhHX7o4Vai4IMTAE87(mc_koBw_auTeOpFWTLu_1_hd3*mc_kyfq6L_eQbdYcPuOovpRDW,
mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,void*
mc_V1pxxydYEnWVVi3QKesjvf,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kYUYSnR_wtpicaLJHkpwi_(mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,void*mc_V1pxxydYEnWVVi3QKesjvf,void*x,int32_T
mc__suOgr_4PeCIZi_uhoSVwf);int32_T*mc_Ff7NuTFKk3OCYDKMqomZ1z(int32_T*
pm__lqjegyKuwStj56WZLiC_e,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
void*mc_V1pxxydYEnWVVi3QKesjvf,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
mc_kPBB5xuFz74_aaM4N6U4Jv*mc___7vbyf5jjtDZHYPmA3rvK(mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_F3nVSXkoDK8VeeL5OmY0_B,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
void*mc_V1pxxydYEnWVVi3QKesjvf,void*x,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
static void mc_FxNbO06jjQpyiTpue3qEw2(PmIntVector*mc__AExROh1PVWNeP7hmMWuJv,
const mc_FSz7cV1MCGScXq_M5VT121*mc_VPPSxR3RRt0pXLadx2tWo7,const
PmSparsityPattern*A){if(mc_VPPSxR3RRt0pXLadx2tWo7==NULL){return;}if(
mc_VPPSxR3RRt0pXLadx2tWo7->mc_Vk_mYyVPAa4IZeLta2BLLG==NULL&&
mc_VPPSxR3RRt0pXLadx2tWo7->mc_VKkEmtOg5lC4dH7wVVnG4C==NULL){
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0;mc_VWUvciwDK_dziLpafRxush*
mc_VlVj07ij7V4UeHqkwtzXUZ;int32_T mc_FvxKbdtfPKOYaymjtthQ0G=
mc_VPPSxR3RRt0pXLadx2tWo7->mc_FvxKbdtfPKOYaymjtthQ0G,n=
mc_VPPSxR3RRt0pXLadx2tWo7->mc__0REJ38_cKO_bunM1JCRT_;int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a,mc_kyp6uAyJE40UVuAQNEYzS1,mc_V2__YrimeI4E_yWnhKofpy=
0;int32_T mc_kNgcOktCtQxdYedrGvFn5i=A->mJc[mc_FvxKbdtfPKOYaymjtthQ0G+n]-A->mJc
[mc_FvxKbdtfPKOYaymjtthQ0G];mc_Vqiy96WqvuhCaXm5e_vvT0=
mc_VFJZ9bgvffCPg9PZXPkAVk((int32_T)A->mNumRow,n,mc_kNgcOktCtQxdYedrGvFn5i,0,0)
;for(mc_kwrB3ZoKf7OufTHWaHJV7a=mc_FvxKbdtfPKOYaymjtthQ0G;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_FvxKbdtfPKOYaymjtthQ0G+n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc_Vqiy96WqvuhCaXm5e_vvT0->
pm__lqjegyKuwStj56WZLiC_e[mc_kwrB3ZoKf7OufTHWaHJV7a-mc_FvxKbdtfPKOYaymjtthQ0G]
=mc_V2__YrimeI4E_yWnhKofpy;for(mc_kyp6uAyJE40UVuAQNEYzS1=A->mJc[
mc_kwrB3ZoKf7OufTHWaHJV7a];mc_kyp6uAyJE40UVuAQNEYzS1<A->mJc[
mc_kwrB3ZoKf7OufTHWaHJV7a+1];mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_Vqiy96WqvuhCaXm5e_vvT0->mc_kwrB3ZoKf7OufTHWaHJV7a[mc_V2__YrimeI4E_yWnhKofpy
]=A->mIr[mc_kyp6uAyJE40UVuAQNEYzS1];mc_V2__YrimeI4E_yWnhKofpy++;}}
mc_Vqiy96WqvuhCaXm5e_vvT0->pm__lqjegyKuwStj56WZLiC_e[n]=
mc_V2__YrimeI4E_yWnhKofpy;mc_VlVj07ij7V4UeHqkwtzXUZ=mc__HBpzStane0GaaQtDu_y9F(
2,mc_Vqiy96WqvuhCaXm5e_vvT0,0);for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__AExROh1PVWNeP7hmMWuJv->mX[mc_FvxKbdtfPKOYaymjtthQ0G+
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_VlVj07ij7V4UeHqkwtzXUZ->
mc__AExROh1PVWNeP7hmMWuJv[mc_kwrB3ZoKf7OufTHWaHJV7a]+mc_FvxKbdtfPKOYaymjtthQ0G
;}mc_Fe3WdhVNm1lm_TputcgM_w(mc_VlVj07ij7V4UeHqkwtzXUZ);
mc__BJ1NEDJTgOMhaJKDrM6pN(mc_Vqiy96WqvuhCaXm5e_vvT0);}else{
mc_FxNbO06jjQpyiTpue3qEw2(mc__AExROh1PVWNeP7hmMWuJv,mc_VPPSxR3RRt0pXLadx2tWo7
->mc_Vk_mYyVPAa4IZeLta2BLLG,A);mc_FxNbO06jjQpyiTpue3qEw2(
mc__AExROh1PVWNeP7hmMWuJv,mc_VPPSxR3RRt0pXLadx2tWo7->mc_VKkEmtOg5lC4dH7wVVnG4C
,A);}}PmIntVector*mc__oCV63DXBpKVZL_8tU2Wiz(const mc_FSz7cV1MCGScXq_M5VT121*
mc_VPPSxR3RRt0pXLadx2tWo7,const PmSparsityPattern*mc_FNLG4N0Qc3OxdmBVwutDsy,
PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z){PmIntVector*mc__AExROh1PVWNeP7hmMWuJv=
pm_create_int_vector(mc_FNLG4N0Qc3OxdmBVwutDsy->mNumCol,
mc_FOGg0ZWot2WdYenO8zaD4Z);int32_T mc_kwrB3ZoKf7OufTHWaHJV7a;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<(int32_T)
mc_FNLG4N0Qc3OxdmBVwutDsy->mNumCol;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__AExROh1PVWNeP7hmMWuJv->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]=
mc_kwrB3ZoKf7OufTHWaHJV7a;}mc_FxNbO06jjQpyiTpue3qEw2(mc__AExROh1PVWNeP7hmMWuJv
,mc_VPPSxR3RRt0pXLadx2tWo7,mc_FNLG4N0Qc3OxdmBVwutDsy);return
mc__AExROh1PVWNeP7hmMWuJv;}void mc__RLQweDZtv0hhLXz_f8MMi(
mc_FSz7cV1MCGScXq_M5VT121*mc_Fxl4i6XHkE8cY9kYmlJixt){PmAllocator*
mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();if(mc_Fxl4i6XHkE8cY9kYmlJixt
==NULL){return;}mc__RLQweDZtv0hhLXz_f8MMi(mc_Fxl4i6XHkE8cY9kYmlJixt->
mc_Vk_mYyVPAa4IZeLta2BLLG);mc__RLQweDZtv0hhLXz_f8MMi(mc_Fxl4i6XHkE8cY9kYmlJixt
->mc_VKkEmtOg5lC4dH7wVVnG4C);{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc_Fxl4i6XHkE8cY9kYmlJixt);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc_kk06poLCQlh5i5Yv6GSh7e);}};}mc_FSz7cV1MCGScXq_M5VT121*
mc_VCdOZjcBUFORayuNvO7rtI(mc_FSz7cV1MCGScXq_M5VT121*mc_Fxl4i6XHkE8cY9kYmlJixt)
{PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();
mc_FSz7cV1MCGScXq_M5VT121*mc_kYhU_F2NWIGQWeKUr5mofO;if(
mc_Fxl4i6XHkE8cY9kYmlJixt==NULL){return NULL;}mc_kYhU_F2NWIGQWeKUr5mofO=(
mc_FSz7cV1MCGScXq_M5VT121*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(mc_FSz7cV1MCGScXq_M5VT121)),(1)));
mc_kYhU_F2NWIGQWeKUr5mofO->mc_FvxKbdtfPKOYaymjtthQ0G=mc_Fxl4i6XHkE8cY9kYmlJixt
->mc_FvxKbdtfPKOYaymjtthQ0G;mc_kYhU_F2NWIGQWeKUr5mofO->
mc__0REJ38_cKO_bunM1JCRT_=mc_Fxl4i6XHkE8cY9kYmlJixt->mc__0REJ38_cKO_bunM1JCRT_
;mc_kYhU_F2NWIGQWeKUr5mofO->id=mc_Fxl4i6XHkE8cY9kYmlJixt->id;
mc_kYhU_F2NWIGQWeKUr5mofO->mc_Vk_mYyVPAa4IZeLta2BLLG=mc_VCdOZjcBUFORayuNvO7rtI
(mc_Fxl4i6XHkE8cY9kYmlJixt->mc_Vk_mYyVPAa4IZeLta2BLLG);
mc_kYhU_F2NWIGQWeKUr5mofO->mc_VKkEmtOg5lC4dH7wVVnG4C=mc_VCdOZjcBUFORayuNvO7rtI
(mc_Fxl4i6XHkE8cY9kYmlJixt->mc_VKkEmtOg5lC4dH7wVVnG4C);return
mc_kYhU_F2NWIGQWeKUr5mofO;}void mc_VbHMSzzYu5_WZiNG_fSW8Q(
mc_FSz7cV1MCGScXq_M5VT121*mc_Fxl4i6XHkE8cY9kYmlJixt,int32_T
mc_FvxKbdtfPKOYaymjtthQ0G){if(mc_Fxl4i6XHkE8cY9kYmlJixt==NULL){return;}
mc_Fxl4i6XHkE8cY9kYmlJixt->mc_FvxKbdtfPKOYaymjtthQ0G+=
mc_FvxKbdtfPKOYaymjtthQ0G;mc_VbHMSzzYu5_WZiNG_fSW8Q(mc_Fxl4i6XHkE8cY9kYmlJixt
->mc_Vk_mYyVPAa4IZeLta2BLLG,mc_FvxKbdtfPKOYaymjtthQ0G);
mc_VbHMSzzYu5_WZiNG_fSW8Q(mc_Fxl4i6XHkE8cY9kYmlJixt->mc_VKkEmtOg5lC4dH7wVVnG4C
,mc_FvxKbdtfPKOYaymjtthQ0G);}int32_T mc__1AbngzPnBGnXXDldWop_b(
mc_FSz7cV1MCGScXq_M5VT121*mc_VPPSxR3RRt0pXLadx2tWo7){if(
mc_VPPSxR3RRt0pXLadx2tWo7==NULL){return 0;}if(mc_VPPSxR3RRt0pXLadx2tWo7->
mc_Vk_mYyVPAa4IZeLta2BLLG==NULL){(void)0;;return 1;}(void)0;;return(((
mc__1AbngzPnBGnXXDldWop_b(mc_VPPSxR3RRt0pXLadx2tWo7->mc_Vk_mYyVPAa4IZeLta2BLLG
))>(mc__1AbngzPnBGnXXDldWop_b(mc_VPPSxR3RRt0pXLadx2tWo7->
mc_VKkEmtOg5lC4dH7wVVnG4C)))?(mc__1AbngzPnBGnXXDldWop_b(
mc_VPPSxR3RRt0pXLadx2tWo7->mc_Vk_mYyVPAa4IZeLta2BLLG)):(
mc__1AbngzPnBGnXXDldWop_b(mc_VPPSxR3RRt0pXLadx2tWo7->mc_VKkEmtOg5lC4dH7wVVnG4C
)))+1;}static size_t mc__SDS_Inxs0WpW1FiYNbXzn(const mc_FSz7cV1MCGScXq_M5VT121
*mc_Fxl4i6XHkE8cY9kYmlJixt){if(mc_Fxl4i6XHkE8cY9kYmlJixt==NULL){return 0;}
return 1+mc__SDS_Inxs0WpW1FiYNbXzn(mc_Fxl4i6XHkE8cY9kYmlJixt->
mc_Vk_mYyVPAa4IZeLta2BLLG)+mc__SDS_Inxs0WpW1FiYNbXzn(mc_Fxl4i6XHkE8cY9kYmlJixt
->mc_VKkEmtOg5lC4dH7wVVnG4C);}static mc_FSz7cV1MCGScXq_M5VT121*
mc_VtbWuADjscCuhi_DrcIwXM(const mc_FwUXSPCwCAC_jydGHlCZxe*
mc_Fw6WJxuximC4jHgRLzUSDo,size_t*n){PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=
pm_default_allocator();mc_FSz7cV1MCGScXq_M5VT121*mc_VPPSxR3RRt0pXLadx2tWo7=(
mc_FSz7cV1MCGScXq_M5VT121*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(mc_FSz7cV1MCGScXq_M5VT121)),(1)));size_t
mc_VLHhnPUiNQpve5VIL9P3O9= *n;int32_T mc_Vk_mYyVPAa4IZeLta2BLLG=
mc_Fw6WJxuximC4jHgRLzUSDo->mc_Vk_mYyVPAa4IZeLta2BLLG[mc_VLHhnPUiNQpve5VIL9P3O9
];int32_T mc_VKkEmtOg5lC4dH7wVVnG4C=mc_Fw6WJxuximC4jHgRLzUSDo->
mc_VKkEmtOg5lC4dH7wVVnG4C[mc_VLHhnPUiNQpve5VIL9P3O9];mc_VPPSxR3RRt0pXLadx2tWo7
->id=(int32_T)mc_VLHhnPUiNQpve5VIL9P3O9;mc_VPPSxR3RRt0pXLadx2tWo7->
mc_FvxKbdtfPKOYaymjtthQ0G=mc_Fw6WJxuximC4jHgRLzUSDo->mc_FvxKbdtfPKOYaymjtthQ0G
[mc_VLHhnPUiNQpve5VIL9P3O9];mc_VPPSxR3RRt0pXLadx2tWo7->
mc__0REJ38_cKO_bunM1JCRT_=mc_Fw6WJxuximC4jHgRLzUSDo->mc__0REJ38_cKO_bunM1JCRT_
[mc_VLHhnPUiNQpve5VIL9P3O9];(*n)++;mc_VPPSxR3RRt0pXLadx2tWo7->
mc_Vk_mYyVPAa4IZeLta2BLLG=mc_Vk_mYyVPAa4IZeLta2BLLG==1?
mc_VtbWuADjscCuhi_DrcIwXM(mc_Fw6WJxuximC4jHgRLzUSDo,n):NULL;
mc_VPPSxR3RRt0pXLadx2tWo7->mc_VKkEmtOg5lC4dH7wVVnG4C=mc_VKkEmtOg5lC4dH7wVVnG4C
==1?mc_VtbWuADjscCuhi_DrcIwXM(mc_Fw6WJxuximC4jHgRLzUSDo,n):NULL;return
mc_VPPSxR3RRt0pXLadx2tWo7;}static size_t mc_FbICXktKQV0bjDjjb_yY0v(
mc_FwUXSPCwCAC_jydGHlCZxe*mc_Fw6WJxuximC4jHgRLzUSDo,const
mc_FSz7cV1MCGScXq_M5VT121*mc_Fxl4i6XHkE8cY9kYmlJixt,size_t n){if(
mc_Fxl4i6XHkE8cY9kYmlJixt==NULL){return n;}mc_Fw6WJxuximC4jHgRLzUSDo->
mc_FvxKbdtfPKOYaymjtthQ0G[n]=mc_Fxl4i6XHkE8cY9kYmlJixt->
mc_FvxKbdtfPKOYaymjtthQ0G;mc_Fw6WJxuximC4jHgRLzUSDo->mc__0REJ38_cKO_bunM1JCRT_
[n]=mc_Fxl4i6XHkE8cY9kYmlJixt->mc__0REJ38_cKO_bunM1JCRT_;
mc_Fw6WJxuximC4jHgRLzUSDo->mc_Vk_mYyVPAa4IZeLta2BLLG[n]=
mc_Fxl4i6XHkE8cY9kYmlJixt->mc_Vk_mYyVPAa4IZeLta2BLLG==NULL?0:1;
mc_Fw6WJxuximC4jHgRLzUSDo->mc_VKkEmtOg5lC4dH7wVVnG4C[n]=
mc_Fxl4i6XHkE8cY9kYmlJixt->mc_VKkEmtOg5lC4dH7wVVnG4C==NULL?0:1;n++;n=
mc_FbICXktKQV0bjDjjb_yY0v(mc_Fw6WJxuximC4jHgRLzUSDo,mc_Fxl4i6XHkE8cY9kYmlJixt
->mc_Vk_mYyVPAa4IZeLta2BLLG,n);n=mc_FbICXktKQV0bjDjjb_yY0v(
mc_Fw6WJxuximC4jHgRLzUSDo,mc_Fxl4i6XHkE8cY9kYmlJixt->mc_VKkEmtOg5lC4dH7wVVnG4C
,n);return n;}mc_FwUXSPCwCAC_jydGHlCZxe*mc_F79LLfWDdKORZ1K7KKqAke(const
mc_F9HbKNDZMeOehmlKWGUdea*mc_VpSwxG2uxL4JaLmMQqUqTJ){PmAllocator*
mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();mc_FwUXSPCwCAC_jydGHlCZxe*
mc_Fw6WJxuximC4jHgRLzUSDo=(mc_FwUXSPCwCAC_jydGHlCZxe*)((
mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
mc_FwUXSPCwCAC_jydGHlCZxe)),(1)));size_t mc_VLHhnPUiNQpve5VIL9P3O9=
mc__SDS_Inxs0WpW1FiYNbXzn(mc_VpSwxG2uxL4JaLmMQqUqTJ->mc__a1o_SOX2HC3f9QpH_hO5s
);size_t n=mc_VpSwxG2uxL4JaLmMQqUqTJ->mc__5uLb2__blGtb9EQ9Zwa2_->mN;
mc_Fw6WJxuximC4jHgRLzUSDo->mc_FvxKbdtfPKOYaymjtthQ0G=(int32_T*)((
mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
int32_T)),(mc_VLHhnPUiNQpve5VIL9P3O9)));mc_Fw6WJxuximC4jHgRLzUSDo->
mc__0REJ38_cKO_bunM1JCRT_=(int32_T*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(int32_T)),(mc_VLHhnPUiNQpve5VIL9P3O9)));
mc_Fw6WJxuximC4jHgRLzUSDo->mc_Vk_mYyVPAa4IZeLta2BLLG=(int32_T*)((
mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
int32_T)),(mc_VLHhnPUiNQpve5VIL9P3O9)));mc_Fw6WJxuximC4jHgRLzUSDo->
mc_VKkEmtOg5lC4dH7wVVnG4C=(int32_T*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(int32_T)),(mc_VLHhnPUiNQpve5VIL9P3O9)));
mc_Fw6WJxuximC4jHgRLzUSDo->pm__lqjegyKuwStj56WZLiC_e=(int32_T*)((
mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
int32_T)),(n)));mc_Fw6WJxuximC4jHgRLzUSDo->mc__AExROh1PVWNeP7hmMWuJv=(int32_T*
)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
int32_T)),(n)));mc_Fw6WJxuximC4jHgRLzUSDo->mc_VLHhnPUiNQpve5VIL9P3O9=
mc_VLHhnPUiNQpve5VIL9P3O9;mc_Fw6WJxuximC4jHgRLzUSDo->n=n;memcpy(
mc_Fw6WJxuximC4jHgRLzUSDo->pm__lqjegyKuwStj56WZLiC_e,mc_VpSwxG2uxL4JaLmMQqUqTJ
->mc__5uLb2__blGtb9EQ9Zwa2_->mX,mc_VpSwxG2uxL4JaLmMQqUqTJ->
mc__5uLb2__blGtb9EQ9Zwa2_->mN*sizeof(int32_T));memcpy(
mc_Fw6WJxuximC4jHgRLzUSDo->mc__AExROh1PVWNeP7hmMWuJv,mc_VpSwxG2uxL4JaLmMQqUqTJ
->mQ->mX,mc_VpSwxG2uxL4JaLmMQqUqTJ->mQ->mN*sizeof(int32_T));
mc_FbICXktKQV0bjDjjb_yY0v(mc_Fw6WJxuximC4jHgRLzUSDo,mc_VpSwxG2uxL4JaLmMQqUqTJ
->mc__a1o_SOX2HC3f9QpH_hO5s,0);return mc_Fw6WJxuximC4jHgRLzUSDo;}void
mc_Vq5AUJWyc3xVgP5Ff1_aP6(mc_FwUXSPCwCAC_jydGHlCZxe*mc_Fw6WJxuximC4jHgRLzUSDo)
{PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();if(
mc_Fw6WJxuximC4jHgRLzUSDo==NULL){return;}{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc_Fw6WJxuximC4jHgRLzUSDo->mc_FvxKbdtfPKOYaymjtthQ0G);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(
mc_FOGg0ZWot2WdYenO8zaD4Z,mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc_Fw6WJxuximC4jHgRLzUSDo->
mc__0REJ38_cKO_bunM1JCRT_);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc_Fw6WJxuximC4jHgRLzUSDo->mc_Vk_mYyVPAa4IZeLta2BLLG);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(
mc_FOGg0ZWot2WdYenO8zaD4Z,mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc_Fw6WJxuximC4jHgRLzUSDo->
mc_VKkEmtOg5lC4dH7wVVnG4C);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc_Fw6WJxuximC4jHgRLzUSDo->pm__lqjegyKuwStj56WZLiC_e);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(
mc_FOGg0ZWot2WdYenO8zaD4Z,mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc_Fw6WJxuximC4jHgRLzUSDo->
mc__AExROh1PVWNeP7hmMWuJv);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc_Fw6WJxuximC4jHgRLzUSDo);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc_kk06poLCQlh5i5Yv6GSh7e);}};}mc_F9HbKNDZMeOehmlKWGUdea*
mc_perm_data_from_flat(const mc_FwUXSPCwCAC_jydGHlCZxe*
mc_Fw6WJxuximC4jHgRLzUSDo){PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=
pm_default_allocator();mc_F9HbKNDZMeOehmlKWGUdea*mc_VpSwxG2uxL4JaLmMQqUqTJ=(
mc_F9HbKNDZMeOehmlKWGUdea*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(mc_F9HbKNDZMeOehmlKWGUdea)),(1)));size_t n=
0;mc_VpSwxG2uxL4JaLmMQqUqTJ->mc__a1o_SOX2HC3f9QpH_hO5s=
mc_VtbWuADjscCuhi_DrcIwXM(mc_Fw6WJxuximC4jHgRLzUSDo,&n);
mc_VpSwxG2uxL4JaLmMQqUqTJ->mc__5uLb2__blGtb9EQ9Zwa2_=pm_create_int_vector(
mc_Fw6WJxuximC4jHgRLzUSDo->n,mc_FOGg0ZWot2WdYenO8zaD4Z);
mc_VpSwxG2uxL4JaLmMQqUqTJ->mQ=pm_create_int_vector(mc_Fw6WJxuximC4jHgRLzUSDo->
n,mc_FOGg0ZWot2WdYenO8zaD4Z);memcpy(mc_VpSwxG2uxL4JaLmMQqUqTJ->
mc__5uLb2__blGtb9EQ9Zwa2_->mX,mc_Fw6WJxuximC4jHgRLzUSDo->
pm__lqjegyKuwStj56WZLiC_e,mc_Fw6WJxuximC4jHgRLzUSDo->n*sizeof(int32_T));memcpy
(mc_VpSwxG2uxL4JaLmMQqUqTJ->mQ->mX,mc_Fw6WJxuximC4jHgRLzUSDo->
mc__AExROh1PVWNeP7hmMWuJv,mc_Fw6WJxuximC4jHgRLzUSDo->n*sizeof(int32_T));return
mc_VpSwxG2uxL4JaLmMQqUqTJ;}void mc_VBCIjXiCCT_RXmHVT9WPVa(
mc_F9HbKNDZMeOehmlKWGUdea*mc_VpSwxG2uxL4JaLmMQqUqTJ){PmAllocator*
mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();if(mc_VpSwxG2uxL4JaLmMQqUqTJ
==NULL){return;}mc__RLQweDZtv0hhLXz_f8MMi(mc_VpSwxG2uxL4JaLmMQqUqTJ->
mc__a1o_SOX2HC3f9QpH_hO5s);pm_destroy_int_vector(mc_VpSwxG2uxL4JaLmMQqUqTJ->
mc__5uLb2__blGtb9EQ9Zwa2_,mc_FOGg0ZWot2WdYenO8zaD4Z);pm_destroy_int_vector(
mc_VpSwxG2uxL4JaLmMQqUqTJ->mQ,mc_FOGg0ZWot2WdYenO8zaD4Z);{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc_VpSwxG2uxL4JaLmMQqUqTJ);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(
mc_FOGg0ZWot2WdYenO8zaD4Z,mc_kk06poLCQlh5i5Yv6GSh7e);}};}
