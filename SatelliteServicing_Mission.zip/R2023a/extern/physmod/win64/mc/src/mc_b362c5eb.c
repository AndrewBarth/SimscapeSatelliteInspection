#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "pm_std.h"
typedef struct pm_V1heuUPdFYSBhXSTZrzev1{size_t mNumRow;size_t mNumCol;real_T*
mX;}pm_FMSUHHOOKD8acuFWLEq4lL;pm_FMSUHHOOKD8acuFWLEq4lL*
pm__IzxUodah3x2_u_ENKAuGk(size_t pm__6bYkkT4Shd0e1DZPlpqqb,size_t
pm__g5DiU2QzFtUiL4XoU6SMs,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
pm_FMSUHHOOKD8acuFWLEq4lL*pm__vffvPR7IsS2XyyCPqmNPs(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm__sjTRWOMR4WzZisVeB2fYm,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);void pm__uc9LGWqLf03gLt6Sr9mtw(
pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);void pm_VuZ05R76dw4R_5mH59xUl3(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60);size_t
pm_kXhhlZLW3c8yiTFYZWcurB(const pm_FMSUHHOOKD8acuFWLEq4lL*
pm_k5aqR5haGY_ZXuGDU2ua60);PMF_DEPLOY_STATIC real_T pm_VWoHHtf6OqO6YXA_khGhQm(
const pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60,size_t
pm_kplAJmOlA30feiNcOzi7oj,size_t pm_Fr_bHKkQKFWbfi50VWd5Pw){return
pm_k5aqR5haGY_ZXuGDU2ua60->mX[pm_kplAJmOlA30feiNcOzi7oj+
pm_Fr_bHKkQKFWbfi50VWd5Pw*pm_k5aqR5haGY_ZXuGDU2ua60->mNumRow];}
PMF_DEPLOY_STATIC void pm_kzEZvMeJLvOmgX1qMXsT0P(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60,size_t
pm_kplAJmOlA30feiNcOzi7oj,size_t pm_Fr_bHKkQKFWbfi50VWd5Pw,real_T
pm_kpzAtHMD4_WnheH0UiioSE){pm_k5aqR5haGY_ZXuGDU2ua60->mX[
pm_kplAJmOlA30feiNcOzi7oj+pm_Fr_bHKkQKFWbfi50VWd5Pw*pm_k5aqR5haGY_ZXuGDU2ua60
->mNumRow]=pm_kpzAtHMD4_WnheH0UiioSE;}void pm_kqNP_VNVXgWGcLsAqt8n_A(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm_kUO9H2UqXf8k_y6THPribZ,const PmRealVector*
pm_V9BoL4F3KMGcYqNc2RhxW_,const PmSparsityPattern*pm_FbpiqbN30g8sY9B6YI6RUP);
void pm_kRraI4tqfotp_aUXOIifb6(const pm_FMSUHHOOKD8acuFWLEq4lL*dst,const
pm_FMSUHHOOKD8acuFWLEq4lL*src);boolean_T pm__DD6QRkN3jGod5UZotcfi8(const
pm_FMSUHHOOKD8acuFWLEq4lL*dst,const pm_FMSUHHOOKD8acuFWLEq4lL*src);boolean_T
pm__Wj7kGLfa8_wfmNCNFVchb(const pm_FMSUHHOOKD8acuFWLEq4lL*dst,size_t
pm_kFiZgJyKzlhBjiAGyCdzxA,const pm_FMSUHHOOKD8acuFWLEq4lL*src,size_t
pm_VLyT3I17Hm8phLoGoAFHeg,size_t pm__dZ3R3yisKSMd19Osaf1CO);void
pm_VL4rp2NEaF8Tcu2gE6TeeU(const pm_FMSUHHOOKD8acuFWLEq4lL*dst,size_t
pm_kFiZgJyKzlhBjiAGyCdzxA,const pm_FMSUHHOOKD8acuFWLEq4lL*src,size_t
pm_VLyT3I17Hm8phLoGoAFHeg,size_t pm__dZ3R3yisKSMd19Osaf1CO);void
mc_VdnTcdNV1g__YLmY4HxrQK(const pm_FMSUHHOOKD8acuFWLEq4lL*
mc_kK2ERk3NOnCDZHX6LjFxRN,const PmRealVector*mc_VZ33PiQ7jrpDXPxl0aBtJr,const
PmIntVector*mc__eZAEnaPmP4fV9XClVoNF1,const PmRealVector*
mc_V73bmXoMQmKcVuw5a9Yd0N,size_t mc__3cEDbJUb9_Cj9UY4l8PU2,size_t
mc_kNDKyLu0sp8Pguc5P_NKw0);int32_T mc_Fkdm_lGNeplrhXmz3Lwbrp(const
pm_FMSUHHOOKD8acuFWLEq4lL*mc_VWCrbzOuAe4hay4E_Unnfg,real_T
mc_Vt63uqKg_5C8j1icbTXz_b,size_t mc_kNDKyLu0sp8Pguc5P_NKw0);real_T
mc__RE_GtsPV2puZDY2OURkMi(const pm_FMSUHHOOKD8acuFWLEq4lL*
mc_VQWFowNaABtIfPdipkLojF,size_t mc_kNDKyLu0sp8Pguc5P_NKw0);int32_T
mc__SEWpAvGM8dNgDW0N_iwSR(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T
mc_V2__YrimeI4E_yWnhKofpy,real_T*mc_VWCrbzOuAe4hay4E_Unnfg,real_T*
mc_kTQbRrK9Zn49jTgjOBqDPQ,real_T*mc_FzyLWRgau0pMYq2XSI3ETL);int32_T
mc_V6QraIJGeDx_WL62rZJoeI(const int32_T mc_VLHhnPUiNQpve5VIL9P3O9,const
PmRealVector*mc_VywcWlG6FdxujeMf4bYmwX,const PmRealVector*
mc__RFc_GCf8KhSdTo2saqv0g,const pm_FMSUHHOOKD8acuFWLEq4lL*
mc_VjJIxgR0KOS0ayvnr1MHao,const PmRealVector*mc_VZ33PiQ7jrpDXPxl0aBtJr,const
PmIntVector*mc__eZAEnaPmP4fV9XClVoNF1);
#include "math.h"
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);
#include "pm_std.h"
PmSparsityPattern*mc_kAZzxJsz9tloc11S9uThaF(const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
mc_klSR73f0rO4LhXVlV6gmb7(real_T*mc_FkvBQdfnWOCY_uJC_r4riI,const
PmSparsityPattern*mc__z_znac6SDtIeyvo_HaL8F,const real_T*A,const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI);PmSparsityPattern*
mc__OkC5ssIRclKeDF7PdRNWG(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmIntVector*mc_kbzF46WM0FtKWeE0s7WR95,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void mc_VgJ42P0i5f4Hby5_Ow7gtm(real_T*
mc__nB0POFEJkOOXDZjc8BZu5,const PmSparsityPattern*mc__G8DEE_sSylod1iLuXNmpS,
const real_T*A,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const
PmIntVector*mc_kbzF46WM0FtKWeE0s7WR95);PmSparsityPattern*
mc__tKZgLZup1pKXLQCAtP8rU(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmIntVector*mc_kbzF46WM0FtKWeE0s7WR95,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void mc_kpAmYrZzcKGOgq9qpxzj07(real_T*
mc__nB0POFEJkOOXDZjc8BZu5,const PmSparsityPattern*mc__G8DEE_sSylod1iLuXNmpS,
const real_T*A,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const
PmIntVector*mc_kbzF46WM0FtKWeE0s7WR95,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void mc_FXA9yTEpI9pfhyLrn8ZGts(PmSparsityPattern*mc_VO4ezo9C6qdUWq1Fln4EVt,
PmRealVector*mc_kfuTzKNJF8C9XawgZFM5k9);PmSparsityPattern*
mc_V_3Bm28Cx08dj9ZMdrwaJg(const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,
const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const PmBoolVector*
mc_F50LHIM89Xpj_mZvqqCQnH,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*mc__qAqv2Z2m7K0VPPGKiCpwD(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const
PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*mc__mBVa3_c658wjuT_cJe_Qy(const PmSparsityPattern*b,const
PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa,PmAllocator*mc_FZx3iFiX1YW7j5eEojoAPc);void
mc_Fv2sZggivbSOc5zulDbRra(const PmRealVector*mc_k5z61obNZCWCbyygZn_fdK,const
real_T*mc__uV9GcaXWFlx_5jfPip5Mo,const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const
PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH);PmSparsityPattern*
mc__JB9jUvbb10FaTie1cmY8_(const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,
size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t mc_knvTkz3vM6t4a9WNgNRMzB,size_t
mc_VGPLyQQmjMlldLbUiddSkc,size_t mc_Fp_w9JW6vqt5eXL55IL0g1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*mc_VINzQey3e2GxYDxzr7cOY_(const
PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,size_t mc_Fxvltms7Im4baT5ZPxj7f2,
size_t mc_knvTkz3vM6t4a9WNgNRMzB,size_t mc_VGPLyQQmjMlldLbUiddSkc,size_t
mc_Fp_w9JW6vqt5eXL55IL0g1,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
mc_Fzylow9cnZxIhyL1O9nM0I(const PmRealVector*mc_VIutEr_JmfWNeDyKonnHVk,const
PmRealVector*mc_VW_HqYZElHCjWHwd6Iv4ON,const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t
mc_knvTkz3vM6t4a9WNgNRMzB,size_t mc_VGPLyQQmjMlldLbUiddSkc,size_t
mc_Fp_w9JW6vqt5eXL55IL0g1);void mc_FY8ifnDZsXphdqo3UGrtOk(PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,size_t n);void mc_kNxwVTI76g4kj9P52yKhA5(
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,size_t n);PmSparsityPattern*
mc_kNYMmfXA1XtHcmiWCr7l_C(const PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*
mc_VJlBwQnSeLpciXVTLb_llB(const PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*
mc__5C6m_ZyP9_NYekcJCEULM(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void mc__8x7kz_627_gXDli_FJo22(const PmRealVector*
mc_kuYGZlr6GiOSeqresCsPcM,const PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR,
const PmRealVector*mc_FmeGGSq6P2_Kg9j7twxwci,const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,const PmRealVector*mc_FQSQWg_QFOKIWm9DWdLQR6,const
PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,const PmRealVector*
mc_krOJvR5Qa1KQZu3eEsQtEU);PmSparsityPattern*mc_kyCwDjPxmBGRiTH73vrjJL(const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const PmSparsityPattern*
mc_VLr_Ia18P_8icXM9WFOfYI,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
mc__tyTSVoY7fpafmg4sUl1P3(const PmRealVector*mc_kuYGZlr6GiOSeqresCsPcM,const
PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR,const PmRealVector*
mc_FmeGGSq6P2_Kg9j7twxwci,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmRealVector*mc_FQSQWg_QFOKIWm9DWdLQR6,const PmSparsityPattern*
mc_VLr_Ia18P_8icXM9WFOfYI,const PmRealVector*mc_krOJvR5Qa1KQZu3eEsQtEU);
PmSparsityPattern*mc_kAJ3geuq0o8ebTsVAocwxT(const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void mc__Z9st0ivzkt_c5ayYUNbbq(const
PmRealVector*mc_kuYGZlr6GiOSeqresCsPcM,const PmSparsityPattern*
mc__ILFYYSbi7hW_uYs_eHsRR,const PmRealVector*mc_FmeGGSq6P2_Kg9j7twxwci,const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const PmRealVector*
mc_FQSQWg_QFOKIWm9DWdLQR6,const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,
const PmRealVector*mc_k0iOHO6BSf8IgTo550ELD8,const PmIntVector*
mc_kQx8tFCixwhfgiAY_Pi8wJ,const int mc___aedK39Pax6Ziebprhh0i);
PmSparsityPattern*mc_VI58f6RQKXS_Y5sclnoOPT(const PmSparsityPattern*a,const
PmSparsityPattern*b,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);void
mc_FnltG8zzfr0scmeWNwQzW9(real_T*mc_kJeUz19e49pVaDwcttsZep,int32_T
mc_F3nVSXkoDK8VeeL5OmY0_B,real_T*mc__WadSiE0LKCAYTdBOZVq99){real_T
mc_VRYYo80g8Gt_ZyEKRXCsw_=0.0;real_T*mc__ETpmKEb9t_6_uqy2dDtPw=
mc_kJeUz19e49pVaDwcttsZep;while(mc_F3nVSXkoDK8VeeL5OmY0_B--){{if(fabs(
mc_VRYYo80g8Gt_ZyEKRXCsw_)>fabs(*mc__ETpmKEb9t_6_uqy2dDtPw)){real_T
mc_FFvdRuzi2OGlaa4iw1XuCB=(*mc__ETpmKEb9t_6_uqy2dDtPw)/(
mc_VRYYo80g8Gt_ZyEKRXCsw_);(mc_VRYYo80g8Gt_ZyEKRXCsw_)=(fabs(
mc_VRYYo80g8Gt_ZyEKRXCsw_)*sqrt(1+mc_FFvdRuzi2OGlaa4iw1XuCB*
mc_FFvdRuzi2OGlaa4iw1XuCB));}else{if((*mc__ETpmKEb9t_6_uqy2dDtPw)==0.0){(
mc_VRYYo80g8Gt_ZyEKRXCsw_)=0.0;}else{real_T mc_FFvdRuzi2OGlaa4iw1XuCB=(
mc_VRYYo80g8Gt_ZyEKRXCsw_)/(*mc__ETpmKEb9t_6_uqy2dDtPw);(
mc_VRYYo80g8Gt_ZyEKRXCsw_)=(fabs(*mc__ETpmKEb9t_6_uqy2dDtPw)*sqrt(1+
mc_FFvdRuzi2OGlaa4iw1XuCB*mc_FFvdRuzi2OGlaa4iw1XuCB));}}};
mc__ETpmKEb9t_6_uqy2dDtPw++;}*mc__WadSiE0LKCAYTdBOZVq99=
mc_VRYYo80g8Gt_ZyEKRXCsw_;}void mc_VdnTcdNV1g__YLmY4HxrQK(const
pm_FMSUHHOOKD8acuFWLEq4lL*mc_kK2ERk3NOnCDZHX6LjFxRN,const PmRealVector*
mc_VZ33PiQ7jrpDXPxl0aBtJr,const PmIntVector*mc__eZAEnaPmP4fV9XClVoNF1,const
PmRealVector*mc_V73bmXoMQmKcVuw5a9Yd0N,size_t mc__3cEDbJUb9_Cj9UY4l8PU2,size_t
mc_kNDKyLu0sp8Pguc5P_NKw0){int32_T mc_VLHhnPUiNQpve5VIL9P3O9=((int32_T)(
mc_kK2ERk3NOnCDZHX6LjFxRN->mNumRow));int32_T n=((int32_T)(
mc_kNDKyLu0sp8Pguc5P_NKw0));int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,
mc_kyp6uAyJE40UVuAQNEYzS1,mc_FlcK3Fc_kWOwdeoC78cTfx,mc__lO81KuDBk41W9Wd2wAkb0,
mc_VGvNcp5jm_l3fmLCC_tyjs,mc_FDG3wUulCLxAhHDy8tQ6Zx,mc_kY30jPK_4J8UZy7wWmgk5V,
mc__epTP49opvlmj9zAk5YIHj;real_T mc__1eAP9V6_J_NYm_1gTIm7A,
mc_Frl9Y1Vw32xGeP3KCstBuR,mc_kc_Le2kmDm_TbHtWyMgFyz,mc_F3hIP89KiXOg_DgTB0_IFU,
mc_Fk2O4u6vQUpibmbv8Kjgnn,*mc__d7gkv9vMLhcYPICPcC5X_,*
mc_VgZLri__KJl2e14Sx3Jvy6,mc_VhCwJ10QjUxzg5l2ImlZpw;int32_T
mc__3TsTiO5bfOPV19qAs0rQN,mc_kUPRnQZwX1dSbqI0HmVq4f,mc_VCTwyEFHYUWMdXuHAtRliU,
mc__vIqq4PR28dSbuLi1_wpVo;real_T*x=mc_kK2ERk3NOnCDZHX6LjFxRN->mX;real_T*
mc_kTQbRrK9Zn49jTgjOBqDPQ=mc_VZ33PiQ7jrpDXPxl0aBtJr->mX;int32_T*
mc_FrVYLSQleN4GYXlrWrmRui=mc__eZAEnaPmP4fV9XClVoNF1->mX;real_T*
mc_VRZCD_UL_ESThy75dC9J8D=mc_V73bmXoMQmKcVuw5a9Yd0N->mX;(void)0;;(void)0;;(
void)0;;(void)0;;(void)0;;mc_FDG3wUulCLxAhHDy8tQ6Zx=((int32_T)(
mc__3cEDbJUb9_Cj9UY4l8PU2));mc_kY30jPK_4J8UZy7wWmgk5V=n-1;for(
mc_kyp6uAyJE40UVuAQNEYzS1=((int32_T)(mc__3cEDbJUb9_Cj9UY4l8PU2));
mc_kyp6uAyJE40UVuAQNEYzS1<n;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_FrVYLSQleN4GYXlrWrmRui[mc_kyp6uAyJE40UVuAQNEYzS1]=mc_kyp6uAyJE40UVuAQNEYzS1
;}if(mc_VLHhnPUiNQpve5VIL9P3O9*n!=0){(void)0;;for(mc_kyp6uAyJE40UVuAQNEYzS1=
mc_FDG3wUulCLxAhHDy8tQ6Zx;mc_kyp6uAyJE40UVuAQNEYzS1<=mc_kY30jPK_4J8UZy7wWmgk5V
;mc_kyp6uAyJE40UVuAQNEYzS1++){mc__3TsTiO5bfOPV19qAs0rQN=
mc_kyp6uAyJE40UVuAQNEYzS1*mc_VLHhnPUiNQpve5VIL9P3O9;mc_FnltG8zzfr0scmeWNwQzW9(
x+mc__3TsTiO5bfOPV19qAs0rQN,mc_VLHhnPUiNQpve5VIL9P3O9,&
mc_Fk2O4u6vQUpibmbv8Kjgnn);mc_VRZCD_UL_ESThy75dC9J8D[mc_kyp6uAyJE40UVuAQNEYzS1
]=mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1]=
mc_Fk2O4u6vQUpibmbv8Kjgnn;}for(mc__lO81KuDBk41W9Wd2wAkb0=0;
mc__lO81KuDBk41W9Wd2wAkb0<mc_FDG3wUulCLxAhHDy8tQ6Zx;mc__lO81KuDBk41W9Wd2wAkb0
++){mc__epTP49opvlmj9zAk5YIHj=mc_VLHhnPUiNQpve5VIL9P3O9-
mc__lO81KuDBk41W9Wd2wAkb0;mc_VCTwyEFHYUWMdXuHAtRliU=mc__lO81KuDBk41W9Wd2wAkb0*
(mc_VLHhnPUiNQpve5VIL9P3O9+1);mc__d7gkv9vMLhcYPICPcC5X_=x+
mc_VCTwyEFHYUWMdXuHAtRliU;mc_Frl9Y1Vw32xGeP3KCstBuR= -(*
mc__d7gkv9vMLhcYPICPcC5X_);*mc__d7gkv9vMLhcYPICPcC5X_=
mc_kTQbRrK9Zn49jTgjOBqDPQ[mc__lO81KuDBk41W9Wd2wAkb0];for(
mc_kyp6uAyJE40UVuAQNEYzS1=((int32_T)(mc__3cEDbJUb9_Cj9UY4l8PU2));
mc_kyp6uAyJE40UVuAQNEYzS1<n;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc__vIqq4PR28dSbuLi1_wpVo=mc_kyp6uAyJE40UVuAQNEYzS1*mc_VLHhnPUiNQpve5VIL9P3O9+
mc__lO81KuDBk41W9Wd2wAkb0;mc_VgZLri__KJl2e14Sx3Jvy6=x+
mc__vIqq4PR28dSbuLi1_wpVo;mc__1eAP9V6_J_NYm_1gTIm7A=0.0;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc__epTP49opvlmj9zAk5YIHj;mc_kwrB3ZoKf7OufTHWaHJV7a
-->0;){mc__1eAP9V6_J_NYm_1gTIm7A-=(*mc__d7gkv9vMLhcYPICPcC5X_)*(*
mc_VgZLri__KJl2e14Sx3Jvy6);mc__d7gkv9vMLhcYPICPcC5X_++;
mc_VgZLri__KJl2e14Sx3Jvy6++;}mc__d7gkv9vMLhcYPICPcC5X_=x+
mc_VCTwyEFHYUWMdXuHAtRliU;mc_VgZLri__KJl2e14Sx3Jvy6=x+
mc__vIqq4PR28dSbuLi1_wpVo;mc__1eAP9V6_J_NYm_1gTIm7A/= *
mc__d7gkv9vMLhcYPICPcC5X_;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc__epTP49opvlmj9zAk5YIHj;mc_kwrB3ZoKf7OufTHWaHJV7a-->0;){*
mc_VgZLri__KJl2e14Sx3Jvy6+=mc__1eAP9V6_J_NYm_1gTIm7A*(*
mc__d7gkv9vMLhcYPICPcC5X_);if(fabs(*mc_VgZLri__KJl2e14Sx3Jvy6)<fabs(10.0*
pmf_get_eps()*mc__1eAP9V6_J_NYm_1gTIm7A*(*mc__d7gkv9vMLhcYPICPcC5X_))){*
mc_VgZLri__KJl2e14Sx3Jvy6=0.0;}mc__d7gkv9vMLhcYPICPcC5X_++;
mc_VgZLri__KJl2e14Sx3Jvy6++;}mc__d7gkv9vMLhcYPICPcC5X_=x+
mc_VCTwyEFHYUWMdXuHAtRliU;mc_VgZLri__KJl2e14Sx3Jvy6=x+
mc__vIqq4PR28dSbuLi1_wpVo;if(mc_kyp6uAyJE40UVuAQNEYzS1<
mc_FDG3wUulCLxAhHDy8tQ6Zx||mc_kyp6uAyJE40UVuAQNEYzS1>mc_kY30jPK_4J8UZy7wWmgk5V
||fabs(mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1])==0.0){continue;}
mc_F3hIP89KiXOg_DgTB0_IFU=1.0-pow((fabs(*mc_VgZLri__KJl2e14Sx3Jvy6)/
mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1]),2.0);if(
mc_F3hIP89KiXOg_DgTB0_IFU<0.0){mc_F3hIP89KiXOg_DgTB0_IFU=0.0;}
mc__1eAP9V6_J_NYm_1gTIm7A=mc_F3hIP89KiXOg_DgTB0_IFU;mc_F3hIP89KiXOg_DgTB0_IFU=
1.0+0.05*mc_F3hIP89KiXOg_DgTB0_IFU*pow((mc_kTQbRrK9Zn49jTgjOBqDPQ[
mc_kyp6uAyJE40UVuAQNEYzS1]/mc_VRZCD_UL_ESThy75dC9J8D[mc_kyp6uAyJE40UVuAQNEYzS1
]),2.0);if(mc_F3hIP89KiXOg_DgTB0_IFU!=1.0){mc_Fk2O4u6vQUpibmbv8Kjgnn=sqrt(
mc__1eAP9V6_J_NYm_1gTIm7A);mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1
]*=mc_Fk2O4u6vQUpibmbv8Kjgnn;}else{mc_FnltG8zzfr0scmeWNwQzW9(++
mc_VgZLri__KJl2e14Sx3Jvy6,mc__epTP49opvlmj9zAk5YIHj-1,&
mc_Fk2O4u6vQUpibmbv8Kjgnn);mc_VRZCD_UL_ESThy75dC9J8D[mc_kyp6uAyJE40UVuAQNEYzS1
]=mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1]=
mc_Fk2O4u6vQUpibmbv8Kjgnn;}}mc_kTQbRrK9Zn49jTgjOBqDPQ[
mc__lO81KuDBk41W9Wd2wAkb0]= *mc__d7gkv9vMLhcYPICPcC5X_;*
mc__d7gkv9vMLhcYPICPcC5X_= -mc_Frl9Y1Vw32xGeP3KCstBuR;}for(
mc__lO81KuDBk41W9Wd2wAkb0=((int32_T)(mc__3cEDbJUb9_Cj9UY4l8PU2));
mc__lO81KuDBk41W9Wd2wAkb0<((mc_VLHhnPUiNQpve5VIL9P3O9)<(n)?(
mc_VLHhnPUiNQpve5VIL9P3O9):(n));mc__lO81KuDBk41W9Wd2wAkb0++){
mc__epTP49opvlmj9zAk5YIHj=mc_VLHhnPUiNQpve5VIL9P3O9-mc__lO81KuDBk41W9Wd2wAkb0;
if(mc__lO81KuDBk41W9Wd2wAkb0>=mc_FDG3wUulCLxAhHDy8tQ6Zx&&
mc__lO81KuDBk41W9Wd2wAkb0<mc_kY30jPK_4J8UZy7wWmgk5V){mc_kc_Le2kmDm_TbHtWyMgFyz
=0.0;mc_VGvNcp5jm_l3fmLCC_tyjs=mc__lO81KuDBk41W9Wd2wAkb0;for(
mc_kyp6uAyJE40UVuAQNEYzS1=mc__lO81KuDBk41W9Wd2wAkb0;mc_kyp6uAyJE40UVuAQNEYzS1
<=mc_kY30jPK_4J8UZy7wWmgk5V;mc_kyp6uAyJE40UVuAQNEYzS1++){if(
mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1]>mc_kc_Le2kmDm_TbHtWyMgFyz
){mc_kc_Le2kmDm_TbHtWyMgFyz=mc_kTQbRrK9Zn49jTgjOBqDPQ[
mc_kyp6uAyJE40UVuAQNEYzS1];mc_VGvNcp5jm_l3fmLCC_tyjs=mc_kyp6uAyJE40UVuAQNEYzS1
;}}if(mc_VGvNcp5jm_l3fmLCC_tyjs!=mc__lO81KuDBk41W9Wd2wAkb0){
mc_kUPRnQZwX1dSbqI0HmVq4f=mc__lO81KuDBk41W9Wd2wAkb0*mc_VLHhnPUiNQpve5VIL9P3O9;
mc__3TsTiO5bfOPV19qAs0rQN=mc_VGvNcp5jm_l3fmLCC_tyjs*mc_VLHhnPUiNQpve5VIL9P3O9;
mc__d7gkv9vMLhcYPICPcC5X_=x+mc_kUPRnQZwX1dSbqI0HmVq4f;
mc_VgZLri__KJl2e14Sx3Jvy6=x+mc__3TsTiO5bfOPV19qAs0rQN;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a
-->0;){mc_Fk2O4u6vQUpibmbv8Kjgnn= *mc__d7gkv9vMLhcYPICPcC5X_;*
mc__d7gkv9vMLhcYPICPcC5X_= *mc_VgZLri__KJl2e14Sx3Jvy6;*
mc_VgZLri__KJl2e14Sx3Jvy6=mc_Fk2O4u6vQUpibmbv8Kjgnn;mc__d7gkv9vMLhcYPICPcC5X_
++;mc_VgZLri__KJl2e14Sx3Jvy6++;}mc_kTQbRrK9Zn49jTgjOBqDPQ[
mc_VGvNcp5jm_l3fmLCC_tyjs]=mc_kTQbRrK9Zn49jTgjOBqDPQ[mc__lO81KuDBk41W9Wd2wAkb0
];mc_VRZCD_UL_ESThy75dC9J8D[mc_VGvNcp5jm_l3fmLCC_tyjs]=
mc_VRZCD_UL_ESThy75dC9J8D[mc__lO81KuDBk41W9Wd2wAkb0];mc_FlcK3Fc_kWOwdeoC78cTfx
=mc_FrVYLSQleN4GYXlrWrmRui[mc_VGvNcp5jm_l3fmLCC_tyjs];
mc_FrVYLSQleN4GYXlrWrmRui[mc_VGvNcp5jm_l3fmLCC_tyjs]=mc_FrVYLSQleN4GYXlrWrmRui
[mc__lO81KuDBk41W9Wd2wAkb0];mc_FrVYLSQleN4GYXlrWrmRui[
mc__lO81KuDBk41W9Wd2wAkb0]=mc_FlcK3Fc_kWOwdeoC78cTfx;}}
mc_kTQbRrK9Zn49jTgjOBqDPQ[mc__lO81KuDBk41W9Wd2wAkb0]=0.0;if(
mc__lO81KuDBk41W9Wd2wAkb0==(mc_VLHhnPUiNQpve5VIL9P3O9-1)){continue;}
mc_VCTwyEFHYUWMdXuHAtRliU=mc__lO81KuDBk41W9Wd2wAkb0*(mc_VLHhnPUiNQpve5VIL9P3O9
+1);mc__d7gkv9vMLhcYPICPcC5X_=x+mc_VCTwyEFHYUWMdXuHAtRliU;
mc_FnltG8zzfr0scmeWNwQzW9(mc__d7gkv9vMLhcYPICPcC5X_,mc__epTP49opvlmj9zAk5YIHj,
&mc_Frl9Y1Vw32xGeP3KCstBuR);if(fabs(mc_Frl9Y1Vw32xGeP3KCstBuR)==0.0){continue;
}if(fabs(*mc__d7gkv9vMLhcYPICPcC5X_)!=0.0){mc_Frl9Y1Vw32xGeP3KCstBuR=(*
mc__d7gkv9vMLhcYPICPcC5X_>=0.0)?fabs(mc_Frl9Y1Vw32xGeP3KCstBuR):-fabs(
mc_Frl9Y1Vw32xGeP3KCstBuR);}mc_VgZLri__KJl2e14Sx3Jvy6=
mc__d7gkv9vMLhcYPICPcC5X_;mc_VhCwJ10QjUxzg5l2ImlZpw=5.0e-20*
mc_Frl9Y1Vw32xGeP3KCstBuR;if(mc_VhCwJ10QjUxzg5l2ImlZpw!=0.0){
mc_Fk2O4u6vQUpibmbv8Kjgnn=1.0/mc_Frl9Y1Vw32xGeP3KCstBuR;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc__epTP49opvlmj9zAk5YIHj;mc_kwrB3ZoKf7OufTHWaHJV7a
-->0;){*mc_VgZLri__KJl2e14Sx3Jvy6*=mc_Fk2O4u6vQUpibmbv8Kjgnn;
mc_VgZLri__KJl2e14Sx3Jvy6++;}}else{for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc__epTP49opvlmj9zAk5YIHj;mc_kwrB3ZoKf7OufTHWaHJV7a-->0;){*
mc_VgZLri__KJl2e14Sx3Jvy6/=mc_Frl9Y1Vw32xGeP3KCstBuR;mc_VgZLri__KJl2e14Sx3Jvy6
++;}}*mc__d7gkv9vMLhcYPICPcC5X_+=1.0;for(mc_kyp6uAyJE40UVuAQNEYzS1=
mc__lO81KuDBk41W9Wd2wAkb0+1;mc_kyp6uAyJE40UVuAQNEYzS1<n;
mc_kyp6uAyJE40UVuAQNEYzS1++){mc__vIqq4PR28dSbuLi1_wpVo=
mc_kyp6uAyJE40UVuAQNEYzS1*mc_VLHhnPUiNQpve5VIL9P3O9+mc__lO81KuDBk41W9Wd2wAkb0;
mc_VgZLri__KJl2e14Sx3Jvy6=x+mc__vIqq4PR28dSbuLi1_wpVo;
mc__1eAP9V6_J_NYm_1gTIm7A=0.0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc__epTP49opvlmj9zAk5YIHj;mc_kwrB3ZoKf7OufTHWaHJV7a-->0;){
mc__1eAP9V6_J_NYm_1gTIm7A-=(*mc__d7gkv9vMLhcYPICPcC5X_)*(*
mc_VgZLri__KJl2e14Sx3Jvy6);mc__d7gkv9vMLhcYPICPcC5X_++;
mc_VgZLri__KJl2e14Sx3Jvy6++;}mc__d7gkv9vMLhcYPICPcC5X_=x+
mc_VCTwyEFHYUWMdXuHAtRliU;mc_VgZLri__KJl2e14Sx3Jvy6=x+
mc__vIqq4PR28dSbuLi1_wpVo;mc__1eAP9V6_J_NYm_1gTIm7A/= *
mc__d7gkv9vMLhcYPICPcC5X_;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc__epTP49opvlmj9zAk5YIHj;mc_kwrB3ZoKf7OufTHWaHJV7a-->0;){*
mc_VgZLri__KJl2e14Sx3Jvy6+=mc__1eAP9V6_J_NYm_1gTIm7A*(*
mc__d7gkv9vMLhcYPICPcC5X_);if(fabs(*mc_VgZLri__KJl2e14Sx3Jvy6)<fabs(10.0*
pmf_get_eps()*mc__1eAP9V6_J_NYm_1gTIm7A*(*mc__d7gkv9vMLhcYPICPcC5X_))){*
mc_VgZLri__KJl2e14Sx3Jvy6=0.0;}mc__d7gkv9vMLhcYPICPcC5X_++;
mc_VgZLri__KJl2e14Sx3Jvy6++;}mc__d7gkv9vMLhcYPICPcC5X_=x+
mc_VCTwyEFHYUWMdXuHAtRliU;mc_VgZLri__KJl2e14Sx3Jvy6=x+
mc__vIqq4PR28dSbuLi1_wpVo;if(mc_kyp6uAyJE40UVuAQNEYzS1<
mc_FDG3wUulCLxAhHDy8tQ6Zx||mc_kyp6uAyJE40UVuAQNEYzS1>mc_kY30jPK_4J8UZy7wWmgk5V
||fabs(mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1])==0.0){continue;}
mc_F3hIP89KiXOg_DgTB0_IFU=1.0-pow((fabs(*mc_VgZLri__KJl2e14Sx3Jvy6)/
mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1]),2.0);if(
mc_F3hIP89KiXOg_DgTB0_IFU<0.0){mc_F3hIP89KiXOg_DgTB0_IFU=0.0;}
mc__1eAP9V6_J_NYm_1gTIm7A=mc_F3hIP89KiXOg_DgTB0_IFU;mc_F3hIP89KiXOg_DgTB0_IFU=
1.0+0.05*mc_F3hIP89KiXOg_DgTB0_IFU*pow((mc_kTQbRrK9Zn49jTgjOBqDPQ[
mc_kyp6uAyJE40UVuAQNEYzS1]/mc_VRZCD_UL_ESThy75dC9J8D[mc_kyp6uAyJE40UVuAQNEYzS1
]),2.0);if(mc_F3hIP89KiXOg_DgTB0_IFU!=1.0){mc_Fk2O4u6vQUpibmbv8Kjgnn=sqrt(
mc__1eAP9V6_J_NYm_1gTIm7A);mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1
]*=mc_Fk2O4u6vQUpibmbv8Kjgnn;}else{mc_FnltG8zzfr0scmeWNwQzW9(++
mc_VgZLri__KJl2e14Sx3Jvy6,mc__epTP49opvlmj9zAk5YIHj-1,&
mc_Fk2O4u6vQUpibmbv8Kjgnn);mc_VRZCD_UL_ESThy75dC9J8D[mc_kyp6uAyJE40UVuAQNEYzS1
]=mc_kTQbRrK9Zn49jTgjOBqDPQ[mc_kyp6uAyJE40UVuAQNEYzS1]=
mc_Fk2O4u6vQUpibmbv8Kjgnn;}}mc_kTQbRrK9Zn49jTgjOBqDPQ[
mc__lO81KuDBk41W9Wd2wAkb0]= *mc__d7gkv9vMLhcYPICPcC5X_;*
mc__d7gkv9vMLhcYPICPcC5X_= -mc_Frl9Y1Vw32xGeP3KCstBuR;}};return;}int32_T
mc_Fkdm_lGNeplrhXmz3Lwbrp(const pm_FMSUHHOOKD8acuFWLEq4lL*
mc_VQWFowNaABtIfPdipkLojF,real_T mc_Vt63uqKg_5C8j1icbTXz_b,size_t
mc_kNDKyLu0sp8Pguc5P_NKw0){int32_T mc_V97n_svAQI86jykAS8CiYB=((int32_T)(
mc_VQWFowNaABtIfPdipkLojF->mNumRow));int32_T mc_kyp6uAyJE40UVuAQNEYzS1,
mc_VESVVna1U8KQ_9OvaOghNl,mc_VTqv0IWy_NdQj1xkFRaWX8;int32_T
mc_V2__YrimeI4E_yWnhKofpy= -1;real_T mc__1eAP9V6_J_NYm_1gTIm7A;real_T*
mc_VWCrbzOuAe4hay4E_Unnfg=mc_VQWFowNaABtIfPdipkLojF->mX;if(
mc_VWCrbzOuAe4hay4E_Unnfg!=NULL){mc_VTqv0IWy_NdQj1xkFRaWX8=((
mc_V97n_svAQI86jykAS8CiYB)<(((int32_T)(mc_kNDKyLu0sp8Pguc5P_NKw0)))?(
mc_V97n_svAQI86jykAS8CiYB):(((int32_T)(mc_kNDKyLu0sp8Pguc5P_NKw0))));for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc_VTqv0IWy_NdQj1xkFRaWX8;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_VESVVna1U8KQ_9OvaOghNl=mc_kyp6uAyJE40UVuAQNEYzS1*(mc_V97n_svAQI86jykAS8CiYB
+1);mc__1eAP9V6_J_NYm_1gTIm7A=fabs(*(mc_VWCrbzOuAe4hay4E_Unnfg+
mc_VESVVna1U8KQ_9OvaOghNl));if(mc__1eAP9V6_J_NYm_1gTIm7A>
mc_Vt63uqKg_5C8j1icbTXz_b){mc_V2__YrimeI4E_yWnhKofpy=mc_kyp6uAyJE40UVuAQNEYzS1
;}}}else{int32_T mc_kpL6NzuwGohXciuEn1oD5K=((int32_T)(
mc_VQWFowNaABtIfPdipkLojF->mNumCol));(void)0;;}mc_V2__YrimeI4E_yWnhKofpy++;
return mc_V2__YrimeI4E_yWnhKofpy;}real_T mc__RE_GtsPV2puZDY2OURkMi(const
pm_FMSUHHOOKD8acuFWLEq4lL*mc_VQWFowNaABtIfPdipkLojF,size_t
mc_kNDKyLu0sp8Pguc5P_NKw0){int32_T mc__q70gXw8N_xsWy9UoFEkTZ=
mc_Fkdm_lGNeplrhXmz3Lwbrp(mc_VQWFowNaABtIfPdipkLojF,0.0,
mc_kNDKyLu0sp8Pguc5P_NKw0);if(mc__q70gXw8N_xsWy9UoFEkTZ>0){real_T
mc_FE7t0GfBuAW1fuWZPxel_q=0.0;real_T mc_FTmBApB9w1Otgew4IWWhwD= -1.0;int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc__q70gXw8N_xsWy9UoFEkTZ;++
mc_kwrB3ZoKf7OufTHWaHJV7a){real_T mc__dWdDNurhAtCi9JSs6Apsz=fabs(
pm_VWoHHtf6OqO6YXA_khGhQm(mc_VQWFowNaABtIfPdipkLojF,mc_kwrB3ZoKf7OufTHWaHJV7a,
mc_kwrB3ZoKf7OufTHWaHJV7a));if(mc__dWdDNurhAtCi9JSs6Apsz>
mc_FE7t0GfBuAW1fuWZPxel_q){mc_FE7t0GfBuAW1fuWZPxel_q=mc__dWdDNurhAtCi9JSs6Apsz
;}if((mc_FTmBApB9w1Otgew4IWWhwD<0.0)||(mc__dWdDNurhAtCi9JSs6Apsz<
mc_FTmBApB9w1Otgew4IWWhwD)){mc_FTmBApB9w1Otgew4IWWhwD=
mc__dWdDNurhAtCi9JSs6Apsz;}}return(mc_FE7t0GfBuAW1fuWZPxel_q/
mc_FTmBApB9w1Otgew4IWWhwD);}return 0.0;}static void mc_V3ALocysV68YgP1R3V3ZE_(
int32_T n,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,real_T*mc_VWCrbzOuAe4hay4E_Unnfg,
real_T*mc_VJZIyX7kuiW2iDFXwUKbpG,real_T*mc_FzyLWRgau0pMYq2XSI3ETL){if((
mc_VWCrbzOuAe4hay4E_Unnfg!=NULL)&&(fabs(*mc_VJZIyX7kuiW2iDFXwUKbpG)!=0.0)){
int32_T mc__1y29sW6WMtEWa9cXa7p7w,mc_kwrB3ZoKf7OufTHWaHJV7a,
mc_VESVVna1U8KQ_9OvaOghNl;real_T mc__1eAP9V6_J_NYm_1gTIm7A,
mc__0Gxic3Bpu_HjDevqjQi0l,*mc_FYZz1y0gQlxadqVuZF3GGC,*
mc_FsXzQT7CFnhMVmsxvJDfxd;mc__1y29sW6WMtEWa9cXa7p7w=n-
mc_kyp6uAyJE40UVuAQNEYzS1;mc_VESVVna1U8KQ_9OvaOghNl=mc_kyp6uAyJE40UVuAQNEYzS1*
(n+1);mc_FYZz1y0gQlxadqVuZF3GGC=mc_VWCrbzOuAe4hay4E_Unnfg+
mc_VESVVna1U8KQ_9OvaOghNl;mc__0Gxic3Bpu_HjDevqjQi0l= *
mc_FYZz1y0gQlxadqVuZF3GGC;*mc_FYZz1y0gQlxadqVuZF3GGC= *
mc_VJZIyX7kuiW2iDFXwUKbpG;mc__1eAP9V6_J_NYm_1gTIm7A=0.0;
mc_FsXzQT7CFnhMVmsxvJDfxd=mc_FzyLWRgau0pMYq2XSI3ETL;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc__1y29sW6WMtEWa9cXa7p7w;mc_kwrB3ZoKf7OufTHWaHJV7a
-->0;){mc__1eAP9V6_J_NYm_1gTIm7A-=(*mc_FYZz1y0gQlxadqVuZF3GGC)*(*
mc_FsXzQT7CFnhMVmsxvJDfxd);mc_FYZz1y0gQlxadqVuZF3GGC++;
mc_FsXzQT7CFnhMVmsxvJDfxd++;}mc_FYZz1y0gQlxadqVuZF3GGC=
mc_VWCrbzOuAe4hay4E_Unnfg+mc_VESVVna1U8KQ_9OvaOghNl;mc__1eAP9V6_J_NYm_1gTIm7A
/= *mc_FYZz1y0gQlxadqVuZF3GGC;mc_FsXzQT7CFnhMVmsxvJDfxd=
mc_FzyLWRgau0pMYq2XSI3ETL;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc__1y29sW6WMtEWa9cXa7p7w;mc_kwrB3ZoKf7OufTHWaHJV7a-->0;){*
mc_FsXzQT7CFnhMVmsxvJDfxd+=mc__1eAP9V6_J_NYm_1gTIm7A*(*
mc_FYZz1y0gQlxadqVuZF3GGC);mc_FYZz1y0gQlxadqVuZF3GGC++;
mc_FsXzQT7CFnhMVmsxvJDfxd++;}mc_FYZz1y0gQlxadqVuZF3GGC=
mc_VWCrbzOuAe4hay4E_Unnfg+mc_VESVVna1U8KQ_9OvaOghNl;*mc_FYZz1y0gQlxadqVuZF3GGC
=mc__0Gxic3Bpu_HjDevqjQi0l;}}static int32_T mc_kOcssraS16SAbe618__T5U(int32_T
mc_VLHhnPUiNQpve5VIL9P3O9,int32_T mc_V2__YrimeI4E_yWnhKofpy,real_T*
mc_VWCrbzOuAe4hay4E_Unnfg,real_T*mc_kTQbRrK9Zn49jTgjOBqDPQ,real_T*
mc_FzyLWRgau0pMYq2XSI3ETL){int32_T mc_kyp6uAyJE40UVuAQNEYzS1,
mc_kSEW12lLld4uY1T_UcY6kY=0;real_T*mc_V54qTRZvRZtVc9X6tsYve9,*
mc_FsXzQT7CFnhMVmsxvJDfxd;mc_kyp6uAyJE40UVuAQNEYzS1=((
mc_V2__YrimeI4E_yWnhKofpy)<(mc_VLHhnPUiNQpve5VIL9P3O9-1)?(
mc_V2__YrimeI4E_yWnhKofpy):(mc_VLHhnPUiNQpve5VIL9P3O9-1));if(
mc_kyp6uAyJE40UVuAQNEYzS1<=0){return(mc_kSEW12lLld4uY1T_UcY6kY);};(void)0;;(
void)0;;mc_V54qTRZvRZtVc9X6tsYve9=mc_kTQbRrK9Zn49jTgjOBqDPQ+
mc_kyp6uAyJE40UVuAQNEYzS1-1;mc_FsXzQT7CFnhMVmsxvJDfxd=
mc_FzyLWRgau0pMYq2XSI3ETL+mc_kyp6uAyJE40UVuAQNEYzS1-1;while(
mc_kyp6uAyJE40UVuAQNEYzS1--){mc_V3ALocysV68YgP1R3V3ZE_(
mc_VLHhnPUiNQpve5VIL9P3O9,mc_kyp6uAyJE40UVuAQNEYzS1,mc_VWCrbzOuAe4hay4E_Unnfg,
mc_V54qTRZvRZtVc9X6tsYve9--,mc_FsXzQT7CFnhMVmsxvJDfxd--);}return(
mc_kSEW12lLld4uY1T_UcY6kY);}int32_T mc__SEWpAvGM8dNgDW0N_iwSR(int32_T
mc_VLHhnPUiNQpve5VIL9P3O9,int32_T mc_V2__YrimeI4E_yWnhKofpy,real_T*
mc_VWCrbzOuAe4hay4E_Unnfg,real_T*mc_kTQbRrK9Zn49jTgjOBqDPQ,real_T*
mc_FzyLWRgau0pMYq2XSI3ETL){int32_T mc_kyp6uAyJE40UVuAQNEYzS1,
mc__n_mbZayf4_ViymCHt71tt,mc_kSEW12lLld4uY1T_UcY6kY=0;real_T*
mc_V54qTRZvRZtVc9X6tsYve9,*mc_FsXzQT7CFnhMVmsxvJDfxd;mc__n_mbZayf4_ViymCHt71tt
=((mc_V2__YrimeI4E_yWnhKofpy)<(mc_VLHhnPUiNQpve5VIL9P3O9-1)?(
mc_V2__YrimeI4E_yWnhKofpy):(mc_VLHhnPUiNQpve5VIL9P3O9-1));if(
mc__n_mbZayf4_ViymCHt71tt<=0){return(mc_kSEW12lLld4uY1T_UcY6kY);}(void)0;;(
void)0;;mc_V54qTRZvRZtVc9X6tsYve9=mc_kTQbRrK9Zn49jTgjOBqDPQ;
mc_FsXzQT7CFnhMVmsxvJDfxd=mc_FzyLWRgau0pMYq2XSI3ETL;for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc__n_mbZayf4_ViymCHt71tt;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_V3ALocysV68YgP1R3V3ZE_(mc_VLHhnPUiNQpve5VIL9P3O9,mc_kyp6uAyJE40UVuAQNEYzS1,
mc_VWCrbzOuAe4hay4E_Unnfg,mc_V54qTRZvRZtVc9X6tsYve9++,
mc_FsXzQT7CFnhMVmsxvJDfxd++);}return(mc_kSEW12lLld4uY1T_UcY6kY);}int32_T
mc_V6QraIJGeDx_WL62rZJoeI(const int32_T mc_VLHhnPUiNQpve5VIL9P3O9,const
PmRealVector*mc_VywcWlG6FdxujeMf4bYmwX,const PmRealVector*
mc__RFc_GCf8KhSdTo2saqv0g,const pm_FMSUHHOOKD8acuFWLEq4lL*
mc_VjJIxgR0KOS0ayvnr1MHao,const PmRealVector*mc_VZ33PiQ7jrpDXPxl0aBtJr,const
PmIntVector*mc__eZAEnaPmP4fV9XClVoNF1){int32_T mc_V2__YrimeI4E_yWnhKofpy=0;
const real_T*mc_FYb3BU2fbqC_bHhRn9AW9b=mc_VywcWlG6FdxujeMf4bYmwX->mX;real_T*
mc_V5gSkPeCSkdzZ1xMyj2v7U=mc__RFc_GCf8KhSdTo2saqv0g->mX;real_T*
mc_VWCrbzOuAe4hay4E_Unnfg=mc_VjJIxgR0KOS0ayvnr1MHao->mX;real_T*
mc_kTQbRrK9Zn49jTgjOBqDPQ=mc_VZ33PiQ7jrpDXPxl0aBtJr->mX;const int32_T*
mc_FrVYLSQleN4GYXlrWrmRui=mc__eZAEnaPmP4fV9XClVoNF1->mX;const int32_T n=((
int32_T)(mc_VjJIxgR0KOS0ayvnr1MHao->mNumRow));(void)0;;(void)0;;(void)0;;(void
)0;;(void)0;;(void)0;;if((mc_VLHhnPUiNQpve5VIL9P3O9>0)&&(n>0)){int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a,mc_kyp6uAyJE40UVuAQNEYzS1;(void)0;;
mc_V2__YrimeI4E_yWnhKofpy=mc_Fkdm_lGNeplrhXmz3Lwbrp(mc_VjJIxgR0KOS0ayvnr1MHao,
0.0,((int32_T)(mc_VLHhnPUiNQpve5VIL9P3O9)));for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<mc_VLHhnPUiNQpve5VIL9P3O9;mc_kyp6uAyJE40UVuAQNEYzS1
++){(void)0;;mc_V5gSkPeCSkdzZ1xMyj2v7U[mc_kyp6uAyJE40UVuAQNEYzS1]=
mc_FYb3BU2fbqC_bHhRn9AW9b[mc_FrVYLSQleN4GYXlrWrmRui[mc_kyp6uAyJE40UVuAQNEYzS1]
];}for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_V2__YrimeI4E_yWnhKofpy;mc_kwrB3ZoKf7OufTHWaHJV7a++){for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc_kwrB3ZoKf7OufTHWaHJV7a;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_V5gSkPeCSkdzZ1xMyj2v7U[mc_kwrB3ZoKf7OufTHWaHJV7a]-=
mc_VWCrbzOuAe4hay4E_Unnfg[mc_kyp6uAyJE40UVuAQNEYzS1+n*
mc_kwrB3ZoKf7OufTHWaHJV7a]*mc_V5gSkPeCSkdzZ1xMyj2v7U[mc_kyp6uAyJE40UVuAQNEYzS1
];}mc_V5gSkPeCSkdzZ1xMyj2v7U[mc_kwrB3ZoKf7OufTHWaHJV7a]/=
mc_VWCrbzOuAe4hay4E_Unnfg[mc_kwrB3ZoKf7OufTHWaHJV7a+n*
mc_kwrB3ZoKf7OufTHWaHJV7a];}for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_V2__YrimeI4E_yWnhKofpy;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc_V5gSkPeCSkdzZ1xMyj2v7U[
mc_kwrB3ZoKf7OufTHWaHJV7a]=0.0;}mc_kOcssraS16SAbe618__T5U(n,
mc_VLHhnPUiNQpve5VIL9P3O9,mc_VWCrbzOuAe4hay4E_Unnfg,mc_kTQbRrK9Zn49jTgjOBqDPQ,
mc_V5gSkPeCSkdzZ1xMyj2v7U);}else{mc__aNO1s5qwzt6fXwft5YgCz(
mc__RFc_GCf8KhSdTo2saqv0g);}return(mc_V2__YrimeI4E_yWnhKofpy);}
