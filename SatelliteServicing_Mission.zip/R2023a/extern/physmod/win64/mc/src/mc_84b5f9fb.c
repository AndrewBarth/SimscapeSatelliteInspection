#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
typedef void*(*mc_FkLPw5qSgbtfXPjiTTsMib)(void*);typedef struct
mc__X_HHcuYRKSoeadMsf6h0a{void*mc_kJaPD0SF9bKtdHPQJyrhtv;size_t
mc_Vbr5eqH3ENhKgPrE0rHGwZ;}mc_kW6ayL4fFaxvcajE0EcNHC;typedef struct
mc_VUoa7yJ8oPdcVyAh1JpD3y mc_kTtzoaRBzntliy1LEJfc0r;typedef struct
mc_F4Uk_muRArKTWiMEBFR7PO{mc_kTtzoaRBzntliy1LEJfc0r*(*
mc__wc2tCUDwk87X1QDBaJiKw)(mc_FkLPw5qSgbtfXPjiTTsMib mc_kYZL2_ypSZp_beKV07wnOI
,size_t n);int(*mc_F5UYWROxhuW7bXP2qFH6l5)(mc_kTtzoaRBzntliy1LEJfc0r*tm,void*
arg);void(*mc_FxdfIsrDZ_OpXHH2KZQasB)(mc_kTtzoaRBzntliy1LEJfc0r*tm);}
mc_FEi_3IF8psl_XH4yBOu3mh;typedef struct mc__GU3aKCcfhldXiBd1lQ_fp
mc__zHJTsqokd8xjuXHijLpG6;void mc_register_thread_support(
mc_FEi_3IF8psl_XH4yBOu3mh*mc__LOE3NllYqGGcHiwg6fX5o);mc_FEi_3IF8psl_XH4yBOu3mh
*mc_FEl3DXb7ypKke5uZ90Xlyw(void);mc__zHJTsqokd8xjuXHijLpG6*
mc_V4Y8IvqWFgGLZ1YthqZz6A(size_t mc_F5WfvJZgg6pBiHOz_1m50n);void
mc_kbfEOfn7DOGmfyLmEcjphP(mc__zHJTsqokd8xjuXHijLpG6*mc_FTrf1ab_5kp6a9RTKMrrkU)
;void mc__oQL_XqhEStTZ5g5jEdh6_(mc__zHJTsqokd8xjuXHijLpG6*
mc_FTrf1ab_5kp6a9RTKMrrkU,size_t id);
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);
#include "pm_std.h"
#include "pm_std.h"
struct mc__GU3aKCcfhldXiBd1lQ_fp{boolean_T*mc_FYFLZ2nkmvd_VeAE53T1_E;boolean_T
mc__FEEfWmB4J8LgqxWXBgpFv;size_t mc_k2JWfv8acYtBa1zEg5kgjp;};struct
mc_VUoa7yJ8oPdcVyAh1JpD3y{boolean_T mc__UtWMahBsUC_cm2eeWjnDg;};static
mc_kTtzoaRBzntliy1LEJfc0r*mc_k5n3_tw9VC4WV9VqV_GMk1(mc_FkLPw5qSgbtfXPjiTTsMib
mc_kYZL2_ypSZp_beKV07wnOI,size_t n){(void)mc_kYZL2_ypSZp_beKV07wnOI;(void)n;(
void)0;return NULL;}static void mc_k_ewgSHZm9Sieuvn3KQ7Ck(
mc_kTtzoaRBzntliy1LEJfc0r*tm){(void)tm;(void)0;}static int
mc_kiKkRwjkBMWYXehYrdxA8t(mc_kTtzoaRBzntliy1LEJfc0r*tm,void*arg){(void)tm;(
void)arg;(void)0;return 0;}static mc_FEi_3IF8psl_XH4yBOu3mh
mc__WvqNRe7wNpwh5_rPOr9Bd={&mc_k5n3_tw9VC4WV9VqV_GMk1,&
mc_kiKkRwjkBMWYXehYrdxA8t,&mc_k_ewgSHZm9Sieuvn3KQ7Ck};void
mc_register_thread_support(mc_FEi_3IF8psl_XH4yBOu3mh*mc__LOE3NllYqGGcHiwg6fX5o
){mc__WvqNRe7wNpwh5_rPOr9Bd= *mc__LOE3NllYqGGcHiwg6fX5o;}
mc_FEi_3IF8psl_XH4yBOu3mh*mc_FEl3DXb7ypKke5uZ90Xlyw(void){return&
mc__WvqNRe7wNpwh5_rPOr9Bd;}mc__zHJTsqokd8xjuXHijLpG6*mc_V4Y8IvqWFgGLZ1YthqZz6A
(size_t mc_F5WfvJZgg6pBiHOz_1m50n){PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=
pm_default_allocator();mc__zHJTsqokd8xjuXHijLpG6*mc_FTrf1ab_5kp6a9RTKMrrkU=(
mc__zHJTsqokd8xjuXHijLpG6*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(mc__zHJTsqokd8xjuXHijLpG6)),(1)));boolean_T
*mc_FVSmPu0b7qdSjup2rVu4xv=(boolean_T*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->
mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(boolean_T)),(
mc_F5WfvJZgg6pBiHOz_1m50n)));size_t mc_kwrB3ZoKf7OufTHWaHJV7a;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_F5WfvJZgg6pBiHOz_1m50n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_FVSmPu0b7qdSjup2rVu4xv[mc_kwrB3ZoKf7OufTHWaHJV7a]=false;}
mc_FTrf1ab_5kp6a9RTKMrrkU->mc__FEEfWmB4J8LgqxWXBgpFv=false;
mc_FTrf1ab_5kp6a9RTKMrrkU->mc_FYFLZ2nkmvd_VeAE53T1_E=mc_FVSmPu0b7qdSjup2rVu4xv
;mc_FTrf1ab_5kp6a9RTKMrrkU->mc_k2JWfv8acYtBa1zEg5kgjp=
mc_F5WfvJZgg6pBiHOz_1m50n;return mc_FTrf1ab_5kp6a9RTKMrrkU;}void
mc_kbfEOfn7DOGmfyLmEcjphP(mc__zHJTsqokd8xjuXHijLpG6*mc_FTrf1ab_5kp6a9RTKMrrkU)
{PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc_FTrf1ab_5kp6a9RTKMrrkU->
mc_FYFLZ2nkmvd_VeAE53T1_E);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc_FTrf1ab_5kp6a9RTKMrrkU);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc_kk06poLCQlh5i5Yv6GSh7e);}};}static void mc_Fl08pQFl7ISPXyQx6Vbf1j(volatile
mc__zHJTsqokd8xjuXHijLpG6*mc_FTrf1ab_5kp6a9RTKMrrkU,size_t id,boolean_T
mc_Fe6copTTRcKEayCm87ABO_){mc_FTrf1ab_5kp6a9RTKMrrkU->
mc_FYFLZ2nkmvd_VeAE53T1_E[id]=mc_Fe6copTTRcKEayCm87ABO_;if(id==0){while(true){
boolean_T mc_VjhYhS80mAxGbqYC1TeREr=true;size_t mc_kwrB3ZoKf7OufTHWaHJV7a;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_FTrf1ab_5kp6a9RTKMrrkU->mc_k2JWfv8acYtBa1zEg5kgjp;mc_kwrB3ZoKf7OufTHWaHJV7a
++){if(mc_FTrf1ab_5kp6a9RTKMrrkU->mc_FYFLZ2nkmvd_VeAE53T1_E[
mc_kwrB3ZoKf7OufTHWaHJV7a]!=mc_Fe6copTTRcKEayCm87ABO_){
mc_VjhYhS80mAxGbqYC1TeREr=false;}}if(mc_VjhYhS80mAxGbqYC1TeREr){break;}}
mc_FTrf1ab_5kp6a9RTKMrrkU->mc__FEEfWmB4J8LgqxWXBgpFv=mc_Fe6copTTRcKEayCm87ABO_
;}while(mc_FTrf1ab_5kp6a9RTKMrrkU->mc__FEEfWmB4J8LgqxWXBgpFv!=
mc_Fe6copTTRcKEayCm87ABO_){}}void mc__oQL_XqhEStTZ5g5jEdh6_(
mc__zHJTsqokd8xjuXHijLpG6*mc_FTrf1ab_5kp6a9RTKMrrkU,size_t id){
mc_Fl08pQFl7ISPXyQx6Vbf1j(mc_FTrf1ab_5kp6a9RTKMrrkU,id,true);
mc_Fl08pQFl7ISPXyQx6Vbf1j(mc_FTrf1ab_5kp6a9RTKMrrkU,id,false);}
