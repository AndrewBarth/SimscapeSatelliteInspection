#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
typedef struct mc_Var10krMyESoVH5ms3BC9B mc__WlvosIwzPCsYqQiQK98uS;typedef
struct mc_kqfi0XZ31I8oVa0UrBAUOQ mc__5DSuSOY5EGKVHbPTvScZ2;struct
mc_Var10krMyESoVH5ms3BC9B{void(*mc_VrNsQKHIiLOFaL3PHRFxZL)(const
mc__WlvosIwzPCsYqQiQK98uS*mc_kvQDtolRtcCacq65L23hPv);void(*
mc_kt9hW2swhpxchivzz5BlCP)(const mc__WlvosIwzPCsYqQiQK98uS*
mc_kvQDtolRtcCacq65L23hPv,real_T time,const PmRealVector*
mc_kg4CyRgbu6OdeewZOel7Qx);size_t(*mc_F1CrZ_uwhg_eju4CALy3h1)(const
mc__WlvosIwzPCsYqQiQK98uS*mc_kvQDtolRtcCacq65L23hPv);void(*
mc_ka3KJ9VlXFK0ZidY3O7sZM)(const mc__WlvosIwzPCsYqQiQK98uS*
mc_kvQDtolRtcCacq65L23hPv,size_t mc_FruBC65sPgSaZ5e_Y8cbTC,real_T time,const
PmRealVector*mc_kg4CyRgbu6OdeewZOel7Qx);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
mc__WlvosIwzPCsYqQiQK98uS*);size_t mc_kNhmJUZe0oOm_1XC7EH51R;
mc__5DSuSOY5EGKVHbPTvScZ2*mc_VFNhKLCqbHpDYXjdjCOMmT;};
mc__WlvosIwzPCsYqQiQK98uS*mc_k43ukWhB7ctcYqEtIqIF2t(size_t
mc_FDFXbMvo_20_WeM4X5aZux,size_t mc_ksP_VoZ3t_SqgyYvFYlpj7,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);struct mc_kqfi0XZ31I8oVa0UrBAUOQ{size_t
mc_F1CrZ_uwhg_eju4CALy3h1;size_t mc_kX2jC2zOD5tdZaZEt_Z8yE;size_t
mc_ko8lMqCEE7G2e5llardcqj;PmRealVector*mc_V58Fh62KPR_si1wLViLxu1;PmRealVector*
*mc_VELrIEUHeudCamAhgAMD2P;PmAllocator*mc_Ff9S1xA4Ip4ZXeljM4_eEa;};static void
mc_V_1CCxvSvJWQWLbjtVzfRW(const mc__WlvosIwzPCsYqQiQK98uS*
mc_kvQDtolRtcCacq65L23hPv){mc_kvQDtolRtcCacq65L23hPv->
mc_VFNhKLCqbHpDYXjdjCOMmT->mc_ko8lMqCEE7G2e5llardcqj=0;}static size_t
mc__RkA7kwoZE4hdiYqaGXmjV(const mc__WlvosIwzPCsYqQiQK98uS*
mc_kvQDtolRtcCacq65L23hPv){(void)0;;return((mc_kvQDtolRtcCacq65L23hPv->
mc_VFNhKLCqbHpDYXjdjCOMmT->mc_ko8lMqCEE7G2e5llardcqj-1)<(
mc_kvQDtolRtcCacq65L23hPv->mc_VFNhKLCqbHpDYXjdjCOMmT->
mc_F1CrZ_uwhg_eju4CALy3h1)?(mc_kvQDtolRtcCacq65L23hPv->
mc_VFNhKLCqbHpDYXjdjCOMmT->mc_ko8lMqCEE7G2e5llardcqj-1):(
mc_kvQDtolRtcCacq65L23hPv->mc_VFNhKLCqbHpDYXjdjCOMmT->
mc_F1CrZ_uwhg_eju4CALy3h1));}static void mc_kKTWfBd_B1xldDDfjOmm51(const
mc__WlvosIwzPCsYqQiQK98uS*mc_kvQDtolRtcCacq65L23hPv,real_T time,const
PmRealVector*mc_kg4CyRgbu6OdeewZOel7Qx){mc__5DSuSOY5EGKVHbPTvScZ2*
mc__d1alWYexptL_X5HTFhbNK=mc_kvQDtolRtcCacq65L23hPv->mc_VFNhKLCqbHpDYXjdjCOMmT
;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0;PmRealVector mc_VymAMNoymESHXTUtdMRo7f;
mc_VymAMNoymESHXTUtdMRo7f.mN=mc__d1alWYexptL_X5HTFhbNK->
mc_ko8lMqCEE7G2e5llardcqj;mc_VymAMNoymESHXTUtdMRo7f.mX=
mc__d1alWYexptL_X5HTFhbNK->mc_V58Fh62KPR_si1wLViLxu1->mX+
mc__d1alWYexptL_X5HTFhbNK->mc_kX2jC2zOD5tdZaZEt_Z8yE-mc__d1alWYexptL_X5HTFhbNK
->mc_ko8lMqCEE7G2e5llardcqj;if(!mc_kk65_VI6zC0mWHqRziXpjX(&
mc_VymAMNoymESHXTUtdMRo7f,time)){mc__d1alWYexptL_X5HTFhbNK->
mc_ko8lMqCEE7G2e5llardcqj=((mc__d1alWYexptL_X5HTFhbNK->
mc_kX2jC2zOD5tdZaZEt_Z8yE)<(mc__d1alWYexptL_X5HTFhbNK->
mc_ko8lMqCEE7G2e5llardcqj+1)?(mc__d1alWYexptL_X5HTFhbNK->
mc_kX2jC2zOD5tdZaZEt_Z8yE):(mc__d1alWYexptL_X5HTFhbNK->
mc_ko8lMqCEE7G2e5llardcqj+1));for(mc_kh3C5f6ZAPlGWXfJykpWPn=1;
mc_kh3C5f6ZAPlGWXfJykpWPn<mc__d1alWYexptL_X5HTFhbNK->mc_kX2jC2zOD5tdZaZEt_Z8yE
;mc_kh3C5f6ZAPlGWXfJykpWPn++){mc__d1alWYexptL_X5HTFhbNK->
mc_V58Fh62KPR_si1wLViLxu1->mX[mc_kh3C5f6ZAPlGWXfJykpWPn-1]=
mc__d1alWYexptL_X5HTFhbNK->mc_V58Fh62KPR_si1wLViLxu1->mX[
mc_kh3C5f6ZAPlGWXfJykpWPn];pm_rv_equals_rv(mc__d1alWYexptL_X5HTFhbNK->
mc_VELrIEUHeudCamAhgAMD2P[mc_kh3C5f6ZAPlGWXfJykpWPn-1],
mc__d1alWYexptL_X5HTFhbNK->mc_VELrIEUHeudCamAhgAMD2P[mc_kh3C5f6ZAPlGWXfJykpWPn
]);}mc__d1alWYexptL_X5HTFhbNK->mc_V58Fh62KPR_si1wLViLxu1->mX[
mc__d1alWYexptL_X5HTFhbNK->mc_kX2jC2zOD5tdZaZEt_Z8yE-1]=time;pm_rv_equals_rv(
mc__d1alWYexptL_X5HTFhbNK->mc_VELrIEUHeudCamAhgAMD2P[mc__d1alWYexptL_X5HTFhbNK
->mc_kX2jC2zOD5tdZaZEt_Z8yE-1],mc_kg4CyRgbu6OdeewZOel7Qx);}}static void
mc_Fx_lHzGzg_0ziDmOnd5Fe5(const mc__WlvosIwzPCsYqQiQK98uS*
mc_kvQDtolRtcCacq65L23hPv,size_t mc_FruBC65sPgSaZ5e_Y8cbTC,real_T time,const
PmRealVector*mc_kg4CyRgbu6OdeewZOel7Qx){mc__5DSuSOY5EGKVHbPTvScZ2*
mc__d1alWYexptL_X5HTFhbNK=mc_kvQDtolRtcCacq65L23hPv->mc_VFNhKLCqbHpDYXjdjCOMmT
;size_t mc_FQhc2zS5zmGug5tCROrz9Q=0;(void)0;;(void)0;;
mc_FQhc2zS5zmGug5tCROrz9Q=((mc__d1alWYexptL_X5HTFhbNK->
mc_ko8lMqCEE7G2e5llardcqj)<(mc_FruBC65sPgSaZ5e_Y8cbTC+1)?(
mc__d1alWYexptL_X5HTFhbNK->mc_ko8lMqCEE7G2e5llardcqj):(
mc_FruBC65sPgSaZ5e_Y8cbTC+1));mc__aNO1s5qwzt6fXwft5YgCz(
mc_kg4CyRgbu6OdeewZOel7Qx);{size_t mc_kbu8w0vYuX8_dHRq2Pe2Dw=
mc__d1alWYexptL_X5HTFhbNK->mc_kX2jC2zOD5tdZaZEt_Z8yE-mc_FQhc2zS5zmGug5tCROrz9Q
;size_t mc_Vs6xonQX17Krc5vXv8T_zq=mc__d1alWYexptL_X5HTFhbNK->
mc_kX2jC2zOD5tdZaZEt_Z8yE;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0;for(
mc_kh3C5f6ZAPlGWXfJykpWPn=mc_kbu8w0vYuX8_dHRq2Pe2Dw;mc_kh3C5f6ZAPlGWXfJykpWPn<
mc_Vs6xonQX17Krc5vXv8T_zq;mc_kh3C5f6ZAPlGWXfJykpWPn++){real_T
mc__E5Rh2UEUhpdeqd_cWFDvv=1.0;size_t mc_VGYx_j9dv385_iduZsRem5=0;for(
mc_VGYx_j9dv385_iduZsRem5=mc_kbu8w0vYuX8_dHRq2Pe2Dw;mc_VGYx_j9dv385_iduZsRem5<
mc_Vs6xonQX17Krc5vXv8T_zq;mc_VGYx_j9dv385_iduZsRem5++){if(
mc_VGYx_j9dv385_iduZsRem5!=mc_kh3C5f6ZAPlGWXfJykpWPn){
mc__E5Rh2UEUhpdeqd_cWFDvv*=(time-mc__d1alWYexptL_X5HTFhbNK->
mc_V58Fh62KPR_si1wLViLxu1->mX[mc_VGYx_j9dv385_iduZsRem5])/(
mc__d1alWYexptL_X5HTFhbNK->mc_V58Fh62KPR_si1wLViLxu1->mX[
mc_kh3C5f6ZAPlGWXfJykpWPn]-mc__d1alWYexptL_X5HTFhbNK->
mc_V58Fh62KPR_si1wLViLxu1->mX[mc_VGYx_j9dv385_iduZsRem5]);}}
mc_V3CZVT50_V_xeia9SYYptc(mc_kg4CyRgbu6OdeewZOel7Qx,mc__E5Rh2UEUhpdeqd_cWFDvv,
mc__d1alWYexptL_X5HTFhbNK->mc_VELrIEUHeudCamAhgAMD2P[mc_kh3C5f6ZAPlGWXfJykpWPn
]);}}}static void mc_kJ_mvMJzvTpKhTmTdFusyf(mc__WlvosIwzPCsYqQiQK98uS*
mc_kvQDtolRtcCacq65L23hPv){mc__5DSuSOY5EGKVHbPTvScZ2*mc__d1alWYexptL_X5HTFhbNK
=mc_kvQDtolRtcCacq65L23hPv->mc_VFNhKLCqbHpDYXjdjCOMmT;PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY=mc__d1alWYexptL_X5HTFhbNK->mc_Ff9S1xA4Ip4ZXeljM4_eEa
;{size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<mc__d1alWYexptL_X5HTFhbNK->mc_kX2jC2zOD5tdZaZEt_Z8yE
;mc_kh3C5f6ZAPlGWXfJykpWPn++){pm_destroy_real_vector(mc__d1alWYexptL_X5HTFhbNK
->mc_VELrIEUHeudCamAhgAMD2P[mc_kh3C5f6ZAPlGWXfJykpWPn],
pm_FbYb_iLqY2hwZTVlVaiqJY);}}{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc__d1alWYexptL_X5HTFhbNK->mc_VELrIEUHeudCamAhgAMD2P);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(
pm_FbYb_iLqY2hwZTVlVaiqJY,mc_kk06poLCQlh5i5Yv6GSh7e);}};pm_destroy_real_vector
(mc__d1alWYexptL_X5HTFhbNK->mc_V58Fh62KPR_si1wLViLxu1,
pm_FbYb_iLqY2hwZTVlVaiqJY);{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc_kvQDtolRtcCacq65L23hPv->mc_VFNhKLCqbHpDYXjdjCOMmT);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(
pm_FbYb_iLqY2hwZTVlVaiqJY,mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc_kvQDtolRtcCacq65L23hPv);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(
pm_FbYb_iLqY2hwZTVlVaiqJY,mc_kk06poLCQlh5i5Yv6GSh7e);}};}
mc__WlvosIwzPCsYqQiQK98uS*mc_k43ukWhB7ctcYqEtIqIF2t(size_t
mc_FDFXbMvo_20_WeM4X5aZux,size_t mc_ksP_VoZ3t_SqgyYvFYlpj7,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY){mc__WlvosIwzPCsYqQiQK98uS*mc_kvQDtolRtcCacq65L23hPv
=(mc__WlvosIwzPCsYqQiQK98uS*)((pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((
pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(mc__WlvosIwzPCsYqQiQK98uS)),(1)));
mc__5DSuSOY5EGKVHbPTvScZ2*mc__d1alWYexptL_X5HTFhbNK=(mc__5DSuSOY5EGKVHbPTvScZ2
*)((pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof
(mc__5DSuSOY5EGKVHbPTvScZ2)),(1)));mc__d1alWYexptL_X5HTFhbNK->
mc_F1CrZ_uwhg_eju4CALy3h1=mc_ksP_VoZ3t_SqgyYvFYlpj7;mc__d1alWYexptL_X5HTFhbNK
->mc_kX2jC2zOD5tdZaZEt_Z8yE=mc__d1alWYexptL_X5HTFhbNK->
mc_F1CrZ_uwhg_eju4CALy3h1+1;mc__d1alWYexptL_X5HTFhbNK->
mc_ko8lMqCEE7G2e5llardcqj=0;mc__d1alWYexptL_X5HTFhbNK->
mc_V58Fh62KPR_si1wLViLxu1=pm_create_real_vector(mc__d1alWYexptL_X5HTFhbNK->
mc_kX2jC2zOD5tdZaZEt_Z8yE,pm_FbYb_iLqY2hwZTVlVaiqJY);mc__d1alWYexptL_X5HTFhbNK
->mc_VELrIEUHeudCamAhgAMD2P=(PmRealVector**)((pm_FbYb_iLqY2hwZTVlVaiqJY)->
mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(PmRealVector*)),(
mc__d1alWYexptL_X5HTFhbNK->mc_kX2jC2zOD5tdZaZEt_Z8yE)));{size_t
mc_kh3C5f6ZAPlGWXfJykpWPn=0;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<mc__d1alWYexptL_X5HTFhbNK->mc_kX2jC2zOD5tdZaZEt_Z8yE
;mc_kh3C5f6ZAPlGWXfJykpWPn++){mc__d1alWYexptL_X5HTFhbNK->
mc_VELrIEUHeudCamAhgAMD2P[mc_kh3C5f6ZAPlGWXfJykpWPn]=pm_create_real_vector(
mc_FDFXbMvo_20_WeM4X5aZux,pm_FbYb_iLqY2hwZTVlVaiqJY);}}
mc__d1alWYexptL_X5HTFhbNK->mc_Ff9S1xA4Ip4ZXeljM4_eEa=pm_FbYb_iLqY2hwZTVlVaiqJY
;mc_kvQDtolRtcCacq65L23hPv->mc_VrNsQKHIiLOFaL3PHRFxZL= &
mc_V_1CCxvSvJWQWLbjtVzfRW;mc_kvQDtolRtcCacq65L23hPv->mc_kt9hW2swhpxchivzz5BlCP
= &mc_kKTWfBd_B1xldDDfjOmm51;mc_kvQDtolRtcCacq65L23hPv->
mc_F1CrZ_uwhg_eju4CALy3h1= &mc__RkA7kwoZE4hdiYqaGXmjV;
mc_kvQDtolRtcCacq65L23hPv->mc_ka3KJ9VlXFK0ZidY3O7sZM= &
mc_Fx_lHzGzg_0ziDmOnd5Fe5;mc_kvQDtolRtcCacq65L23hPv->mc_VYGWBho6N1K_eyHOMGjDiW
= &mc_kJ_mvMJzvTpKhTmTdFusyf;mc_kvQDtolRtcCacq65L23hPv->
mc_kNhmJUZe0oOm_1XC7EH51R=mc_ksP_VoZ3t_SqgyYvFYlpj7;mc_kvQDtolRtcCacq65L23hPv
->mc_VFNhKLCqbHpDYXjdjCOMmT=mc__d1alWYexptL_X5HTFhbNK;return
mc_kvQDtolRtcCacq65L23hPv;}
