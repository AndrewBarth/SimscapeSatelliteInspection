#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "pm_std.h"
#include "mc_std.h"
typedef enum{mc_FfS9gFGHqKt_fDwFfcldkw= -1,mc_FFaaXY_gkbSTcyLBvtfrzS,
mc_VUd8H_Dz0yp8cmQqTd7DxF,mc_kmVKy2ciwP4fcTEzXFmnvU,mc_VW_0L0rb93GgXq8_OmdwHv,
mc_kHoWGgwi3OdzaXvPvG1YY7,mc___D_4trEmdK8jyKCH6E_ac,mc_Fei8BCRUgBdwhDvvD5FrSo}
mc_kQtOKCqS08dIbumyDnHNDL;typedef struct mc_VJ95jMweiZWSVLsSPpLjbI
mc__w8slDeOjOCYX5XtAOAaVQ;struct McRealFunctionTag{mc__w8slDeOjOCYX5XtAOAaVQ*
mc_ko6_hiERTRldgDROOJBQCH;mc_kQtOKCqS08dIbumyDnHNDL(*mc_VAvAkWmhpT_WWme_3E1U91
)(const void*mc_kDRphcAfRHSbf1ZLKEDW9k,const PmRealVector*
mc_VgqbsB_3R4GTjLQeEYi1Qc,mc__w8slDeOjOCYX5XtAOAaVQ*mc__d1alWYexptL_X5HTFhbNK)
;const void*(*mc_FXz9GdGvpOKnh5e2dYstBe)(const McRealFunction*
mc_k0CXwzVaibdnZiGUCx6PMZ);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(McRealFunction*
mc_k0CXwzVaibdnZiGUCx6PMZ);};typedef struct mc_VqsYk672m3G9YuweR9VjuM
mc_Vfjzfv7SnSWthXl7BAncu7;struct McIntFunctionTag{mc_Vfjzfv7SnSWthXl7BAncu7*
mc_ko6_hiERTRldgDROOJBQCH;void(*mc_VAvAkWmhpT_WWme_3E1U91)(const void*
mc_kDRphcAfRHSbf1ZLKEDW9k,const PmIntVector*mc_VgqbsB_3R4GTjLQeEYi1Qc,
mc_Vfjzfv7SnSWthXl7BAncu7*mc__d1alWYexptL_X5HTFhbNK);const void*(*
mc_FXz9GdGvpOKnh5e2dYstBe)(const McIntFunction*mc_k0CXwzVaibdnZiGUCx6PMZ);void
(*mc_VYGWBho6N1K_eyHOMGjDiW)(McIntFunction*mc_k0CXwzVaibdnZiGUCx6PMZ);};
typedef struct mc_kIf5GUUnTAOChauG3_6hhe mc_k3jb_ssG91tZa9bwLjlWEj;struct
McMatrixFunctionTag{mc_k3jb_ssG91tZa9bwLjlWEj*mc_ko6_hiERTRldgDROOJBQCH;const
PmSparsityPattern*mc_kjWUPQN_Ui4d_enzFJIsF_;void(*mc_VAvAkWmhpT_WWme_3E1U91)(
const void*mc_kDRphcAfRHSbf1ZLKEDW9k,const PmRealVector*
mc_VgqbsB_3R4GTjLQeEYi1Qc,mc_k3jb_ssG91tZa9bwLjlWEj*mc__d1alWYexptL_X5HTFhbNK)
;const void*(*mc_FXz9GdGvpOKnh5e2dYstBe)(const McMatrixFunction*
mc_k0CXwzVaibdnZiGUCx6PMZ);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(McMatrixFunction*
mc_k0CXwzVaibdnZiGUCx6PMZ);};typedef struct mc_knhZCtHxFBxXg5tgJuUCEK
mc_kZbwbT_kvDGzcDUgumpykL;typedef struct mc_FBH8iD7u05pSXm_5ubaK2V
mc_FdKBw8fvqLW3Y5joYOEBEt;struct mc_FBH8iD7u05pSXm_5ubaK2V{
mc_kZbwbT_kvDGzcDUgumpykL*mc_VFNhKLCqbHpDYXjdjCOMmT;void(*
mc__0E_4xnbx6lPba4uVbPsWK)(const mc_FdKBw8fvqLW3Y5joYOEBEt*
mc__3hSkv0Wz8pGW5lmLxQaXM,const void*mc_kDRphcAfRHSbf1ZLKEDW9k);
McMatrixFunction*(*mc_FBMgSgsPcuhAfqqbis_q6w)(const mc_FdKBw8fvqLW3Y5joYOEBEt*
mc__3hSkv0Wz8pGW5lmLxQaXM);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
mc_FdKBw8fvqLW3Y5joYOEBEt*mc__3hSkv0Wz8pGW5lmLxQaXM);};
mc_FdKBw8fvqLW3Y5joYOEBEt*mc_V7lAu3dITJGBeukLWd4htI(McMatrixFunction*
mc_FVG9mW_iV00Sd5jvvtdbAo,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);McMatrixFunction*mc__4fFDnwFhbSuaLZ4NJB06a(const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_kVkvrfpzuVduaPTr5FLF8K,const void*mc_FK93a0pHvcdVXqZct6q8ja,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);McMatrixFunction*mc_Vl4aaEoJK_KwYaROiytCdQ(
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,PmRealVector*
mc_kVkvrfpzuVduaPTr5FLF8K,const void*mc_FK93a0pHvcdVXqZct6q8ja,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);McMatrixFunction*mc_keWxvg6kivCmgu_AS8haey(
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,PmRealVector*
mc_kVkvrfpzuVduaPTr5FLF8K,McMatrixFunction*pm__sjTRWOMR4WzZisVeB2fYm,
PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);struct mc_knhZCtHxFBxXg5tgJuUCEK{
McMatrixFunction*mc_k3vk5HaEDW8jVuPep0yW1r;PmAllocator*
mc_Ff9S1xA4Ip4ZXeljM4_eEa;PmRealVector*mc_VELrIEUHeudCamAhgAMD2P;};static void
mc__SdsxokyX2lQeqDQ5WzJ9a(const mc_FdKBw8fvqLW3Y5joYOEBEt*
mc__3hSkv0Wz8pGW5lmLxQaXM,const void*mc_kDRphcAfRHSbf1ZLKEDW9k){(*((
mc__3hSkv0Wz8pGW5lmLxQaXM->mc_VFNhKLCqbHpDYXjdjCOMmT->
mc_k3vk5HaEDW8jVuPep0yW1r)->mc_VAvAkWmhpT_WWme_3E1U91))((
mc_kDRphcAfRHSbf1ZLKEDW9k),(mc__3hSkv0Wz8pGW5lmLxQaXM->
mc_VFNhKLCqbHpDYXjdjCOMmT->mc_VELrIEUHeudCamAhgAMD2P),((
mc__3hSkv0Wz8pGW5lmLxQaXM->mc_VFNhKLCqbHpDYXjdjCOMmT->
mc_k3vk5HaEDW8jVuPep0yW1r)->mc_ko6_hiERTRldgDROOJBQCH));}static
McMatrixFunction*mc_Fu3bB_YoD5_9bLle7J1moR(const mc_FdKBw8fvqLW3Y5joYOEBEt*
mc__3hSkv0Wz8pGW5lmLxQaXM){mc_kZbwbT_kvDGzcDUgumpykL*mc__d1alWYexptL_X5HTFhbNK
=mc__3hSkv0Wz8pGW5lmLxQaXM->mc_VFNhKLCqbHpDYXjdjCOMmT;McMatrixFunction*src=
mc__d1alWYexptL_X5HTFhbNK->mc_k3vk5HaEDW8jVuPep0yW1r;return
mc__4fFDnwFhbSuaLZ4NJB06a(src->mc_kjWUPQN_Ui4d_enzFJIsF_,
mc__d1alWYexptL_X5HTFhbNK->mc_VELrIEUHeudCamAhgAMD2P,(src)->
mc_FXz9GdGvpOKnh5e2dYstBe((src)),mc__d1alWYexptL_X5HTFhbNK->
mc_Ff9S1xA4Ip4ZXeljM4_eEa);}static void mc_VgMu_erWWdpAhDbMASxJrB(
mc_FdKBw8fvqLW3Y5joYOEBEt*mc__3hSkv0Wz8pGW5lmLxQaXM){mc_kZbwbT_kvDGzcDUgumpykL
*mc__d1alWYexptL_X5HTFhbNK=mc__3hSkv0Wz8pGW5lmLxQaXM->
mc_VFNhKLCqbHpDYXjdjCOMmT;PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY=
mc__d1alWYexptL_X5HTFhbNK->mc_Ff9S1xA4Ip4ZXeljM4_eEa;(
mc__d1alWYexptL_X5HTFhbNK->mc_k3vk5HaEDW8jVuPep0yW1r)->
mc_VYGWBho6N1K_eyHOMGjDiW(mc__d1alWYexptL_X5HTFhbNK->mc_k3vk5HaEDW8jVuPep0yW1r
);pm_destroy_real_vector(mc__d1alWYexptL_X5HTFhbNK->mc_VELrIEUHeudCamAhgAMD2P,
pm_FbYb_iLqY2hwZTVlVaiqJY);{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc__d1alWYexptL_X5HTFhbNK);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc__3hSkv0Wz8pGW5lmLxQaXM);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
mc_kk06poLCQlh5i5Yv6GSh7e);}};}mc_FdKBw8fvqLW3Y5joYOEBEt*
mc_V7lAu3dITJGBeukLWd4htI(McMatrixFunction*mc__3hSkv0Wz8pGW5lmLxQaXM,
PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY){mc_FdKBw8fvqLW3Y5joYOEBEt*
mc_k0CXwzVaibdnZiGUCx6PMZ=(mc_FdKBw8fvqLW3Y5joYOEBEt*)((
pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(
mc_FdKBw8fvqLW3Y5joYOEBEt)),(1)));mc_kZbwbT_kvDGzcDUgumpykL*
mc__d1alWYexptL_X5HTFhbNK=(mc_kZbwbT_kvDGzcDUgumpykL*)((
pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(
mc_kZbwbT_kvDGzcDUgumpykL)),(1)));mc__d1alWYexptL_X5HTFhbNK->
mc_k3vk5HaEDW8jVuPep0yW1r=mc__3hSkv0Wz8pGW5lmLxQaXM;mc__d1alWYexptL_X5HTFhbNK
->mc_Ff9S1xA4Ip4ZXeljM4_eEa=pm_FbYb_iLqY2hwZTVlVaiqJY;
mc__d1alWYexptL_X5HTFhbNK->mc_VELrIEUHeudCamAhgAMD2P=pm_create_real_vector(((
size_t)(mc__3hSkv0Wz8pGW5lmLxQaXM->mc_kjWUPQN_Ui4d_enzFJIsF_)->mJc[(
mc__3hSkv0Wz8pGW5lmLxQaXM->mc_kjWUPQN_Ui4d_enzFJIsF_)->mNumCol]),
pm_FbYb_iLqY2hwZTVlVaiqJY);(*((mc__3hSkv0Wz8pGW5lmLxQaXM)->
mc_VAvAkWmhpT_WWme_3E1U91))(((mc__3hSkv0Wz8pGW5lmLxQaXM)->
mc_FXz9GdGvpOKnh5e2dYstBe((mc__3hSkv0Wz8pGW5lmLxQaXM))),(
mc__d1alWYexptL_X5HTFhbNK->mc_VELrIEUHeudCamAhgAMD2P),((
mc__3hSkv0Wz8pGW5lmLxQaXM)->mc_ko6_hiERTRldgDROOJBQCH));
mc_k0CXwzVaibdnZiGUCx6PMZ->mc_VFNhKLCqbHpDYXjdjCOMmT=mc__d1alWYexptL_X5HTFhbNK
;mc_k0CXwzVaibdnZiGUCx6PMZ->mc__0E_4xnbx6lPba4uVbPsWK= &
mc__SdsxokyX2lQeqDQ5WzJ9a;mc_k0CXwzVaibdnZiGUCx6PMZ->mc_FBMgSgsPcuhAfqqbis_q6w
= &mc_Fu3bB_YoD5_9bLle7J1moR;mc_k0CXwzVaibdnZiGUCx6PMZ->
mc_VYGWBho6N1K_eyHOMGjDiW= &mc_VgMu_erWWdpAhDbMASxJrB;return
mc_k0CXwzVaibdnZiGUCx6PMZ;}
