#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "mc_std.h"
const McLinearAlgebraFactory*mc_V8hcGoGUqVCbYm6_XzatbE(void);
#include "string.h"
#include "limits.h"
#include "math.h"
#include "stdio.h"
typedef struct mc_kJu3kbp1UqpibDtb06hKK_{int32_T mc_FIxFweA3fcKFfuFXAKfA47;
int32_T mc_k_43QOoDDL_PZegt1kRhBI;int32_T mc_VLHhnPUiNQpve5VIL9P3O9;int32_T n;
int32_T*pm__lqjegyKuwStj56WZLiC_e;int32_T*mc_kwrB3ZoKf7OufTHWaHJV7a;double*x;
int32_T mc___ECRgjqShlp_PytRplerL;}mc_F5Olyc6xUoG7ZyDq78exBD;typedef struct
mc_kCiNuo5v78xTj5YTsyYRef{int32_T*mc_V1pxxydYEnWVVi3QKesjvf;double*x;
mc_F5Olyc6xUoG7ZyDq78exBD*A;}mc_FZtW0WFyhCCTVicSdDpulD;
mc_F5Olyc6xUoG7ZyDq78exBD*mc_F_KsXRscHI0GbqNNEbk0p9(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vqiy96WqvuhCaXm5e_vvT0,double mc_kcda_aHAM4WIXuM_xBDdLt,double
mc_kCPCzQ_4FF88XTgtMjWqKy);int32_T mc_FzsS3TwPKLdMiiny4fRXZB(
mc_FZtW0WFyhCCTVicSdDpulD*mc_F5vPJ6MbAI8phLV7sKWrKK,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kJW4fGfd5r_MiuJBhKSynA,const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_kmcvnGchjqCwaq5beTqlxC,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kyfq6L_eQbdYcPuOovpRDW);int32_T mc_FRcDfQc8skGuVLZfeGfRsQ(int32_T
mc_FruBC65sPgSaZ5e_Y8cbTC,const mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kPZtfcLRq8hvd17AwbGSfy(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_V91rYIvDBkGRba7MvGcPUK);int32_T
mc_VufLWRyy__x0aHcAK11u_9(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_VMB1wjlajc42dihJmzkfVL(mc_F5Olyc6xUoG7ZyDq78exBD*mc_V91rYIvDBkGRba7MvGcPUK,
int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double x);
int32_T mc_kyNdNb1Od1pmc5h9_bRwz3(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
double*x,double*mc_FzyLWRgau0pMYq2XSI3ETL);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kKDpTzN8jw8R_La01FPHqo(FILE*mc_Fe6copTTRcKEayCm87ABO_);int32_T
mc_FBcYs04mnxCNjei3Py1gDA(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b,double mc_FfDTppU8N_tOWuLK37x_08);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_F1T9nfE5YBd9_eUgmYQiFQ(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vqiy96WqvuhCaXm5e_vvT0);double mc__mMjuh4GBSd2gPZyGSIEB7(const
mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc__Wuhz03is3hpg54E4_8dDo(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kPdbGJs0Eb_x_Hxa5hZJEc);int32_T
mc_kjcu6drPCUOjbP4z73xob_(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kzs_RE98zypjVHi58lxG6O(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_kVkvrfpzuVduaPTr5FLF8K);void*mc_VInfIQCul4ShdLlbU4F0WB(int32_T n,size_t size
);void*mc__Mim_3QMMSxfi9M5sbbxcM(void*pm__lqjegyKuwStj56WZLiC_e);void*
mc_k0mbD5QrRepqjLd_9sSyDz(void*pm__lqjegyKuwStj56WZLiC_e,int32_T n,size_t size
,int32_T*mc__suOgr_4PeCIZi_uhoSVwf);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_VFJZ9bgvffCPg9PZXPkAVk(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n,int32_T
mc_FIxFweA3fcKFfuFXAKfA47,int32_T mc_kVkvrfpzuVduaPTr5FLF8K,int32_T
mc_Vk3BcXZzVaxpfi0XcV5sHr);mc_F5Olyc6xUoG7ZyDq78exBD*mc__BJ1NEDJTgOMhaJKDrM6pN
(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc_VptvBjskDA83heaLThR8oY(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_FIxFweA3fcKFfuFXAKfA47);void*
mc_ktrY1jmEuvhTfeGflVz93o(int32_T n,size_t size);int32_T
mc_Vw_wVSv6gGKFY1Dalcu6zm(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_kPdbGJs0Eb_x_Hxa5hZJEc);typedef struct mc__adJqrskeJhDYmBVMGWunh{int32_T*
mc_FjDIs2zMLtx5We_IND4g6I;int32_T*mc__AExROh1PVWNeP7hmMWuJv;int32_T*
mc_k6HeriBJpGdZiPlDO4UZXp;int32_T*mc_FXT4jPWj6stSWaiL5dan3b;int32_T*
mc_F_jeaQAcXwGbVXb0t9dFxz;int32_T mc_k3zUxpU0ydGajPq7EF4qn3;double
mc_ViTJrDHWLs8OjimuuiIsPe;double mc__GPciDcZ6Z0EViGxgxdf9y;}
mc_VWUvciwDK_dziLpafRxush;typedef struct mc_kp2eGzAtU2WUXP2RD6EKGO{
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo;mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vi4Cp0qK964NYTFMGr9Ttn;int32_T*mc_FjDIs2zMLtx5We_IND4g6I;double*
mc_Vqiy96WqvuhCaXm5e_vvT0;}mc_kPBB5xuFz74_aaM4N6U4Jv;typedef struct
mc_F7stcouwJ9CTjywpKHMmeT{mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo;
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn;mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FqUCZrSGGNOuePgRr82o_8;int32_T*mc_FjDIs2zMLtx5We_IND4g6I;int32_T*
mc__AExROh1PVWNeP7hmMWuJv;double*x;int32_T*mc__01SK3u3lG0GaLCTTSoVGO;int32_T
mc__0REJ38_cKO_bunM1JCRT_;int32_T mc_kNbvLmFI_EtAay5OpgNJFz;}
mc_k2Ca2__AWx8Yd9MBB6pntX;typedef struct mc__goErATdCI0HWaZaNs9Xzt{int32_T*
pm__lqjegyKuwStj56WZLiC_e;int32_T*mc__AExROh1PVWNeP7hmMWuJv;int32_T*
mc_kUQBO1dSP8_IVqRAUx4R8G;int32_T*mc_FQferGZUKft3_i5GvYy4Oy;int32_T
mc_kLMRRiSdJr4aaLEtYiWmgE;int32_T mc__ys6fNnaK541fDBqN87Aa_[5];int32_T
mc_Fet2g81LNVG6_mJHNhUAfo[5];}mc_koBw_auTeOpFWTLu_1_hd3;int32_T*
mc_FAnXK3hkeY_FimobZpSWy4(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A);mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_kF0bdRSgaVCZhHmbCIFdvh(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
mc_VWUvciwDK_dziLpafRxush*mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_koBw_auTeOpFWTLu_1_hd3
*mc__JYcNbbJ8GxnaT0gipcMUY(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_k6QxQSbjWyGhcXikh7jTLf);int32_T mc_FEBJlPSzZh_ZiqgXtpZSYe(
mc_F5Olyc6xUoG7ZyDq78exBD*A,double mc_FfDTppU8N_tOWuLK37x_08);int32_T
mc_VywKLPGT27tscy1s60Ehlb(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_ViJBWCuvxwlcXP5hTDAmft(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kJeUz19e49pVaDwcttsZep,int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,double
mc_kCPCzQ_4FF88XTgtMjWqKy,double*x);int32_T mc_Vux1rLMHdIOwYHo_GgP0nf(const
int32_T*pm__lqjegyKuwStj56WZLiC_e,const double*b,double*x,int32_T n);int32_T
mc_V3SIv4FNXnS__9UCAN4nes(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc__ut5UfJwzNlZ_XZC_yEgKo,double*x);int32_T mc__U2f_z8iKPWQZTkLMApmoB(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,double*x);
mc_kPBB5xuFz74_aaM4N6U4Jv*mc__OANyqXuH__Wi5n3l9hrJe(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT,double mc_FfDTppU8N_tOWuLK37x_08);int32_T
mc_F0B4l8FzVghjVeO_dlmLre(mc_k2Ca2__AWx8Yd9MBB6pntX*mc_F3nVSXkoDK8VeeL5OmY0_B,
const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc__0REJ38_cKO_bunM1JCRT_,double
mc_FfDTppU8N_tOWuLK37x_08);int32_T mc_k0_k_zhpwQdeVq5LHulheI(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,double*x,int32_T
mc__0REJ38_cKO_bunM1JCRT_);int32_T mc_kZxFnksrKp_zYuKnqu2HE7(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x,int32_T
mc__0REJ38_cKO_bunM1JCRT_);mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VD2E_WGEctCGXH2bprw8Sw
(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT,int32_T*mc__q70gXw8N_xsWy9UoFEkTZ);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_k9MmNIu2n4W9jaO59BYYYQ(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*pm__lqjegyKuwStj56WZLiC_e,const
int32_T*mc__AExROh1PVWNeP7hmMWuJv,int32_T mc_kVkvrfpzuVduaPTr5FLF8K);int32_T*
mc__wD389_14ZOPfyx5EQ5Eez(const int32_T*pm__lqjegyKuwStj56WZLiC_e,int32_T n);
int32_T mc_VQ7L8M0ejvGI_H70X2UUEW(const int32_T*pm__lqjegyKuwStj56WZLiC_e,
const double*b,double*x,int32_T n);mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_FnFQE__lyw88fDjvIJlbiy(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
mc_VWUvciwDK_dziLpafRxush*mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_VWUvciwDK_dziLpafRxush
*mc_VHjWZG2MGPlHg9FEzWcJP5(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A);mc_VWUvciwDK_dziLpafRxush*
mc__HBpzStane0GaaQtDu_y9F(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_VWCrbzOuAe4hay4E_Unnfg);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_V0SSOL16_J8_aXLgyS19I7(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*mc_FjDIs2zMLtx5We_IND4g6I,int32_T
mc_kVkvrfpzuVduaPTr5FLF8K);int32_T mc_VLrR9_1UGwSOj5Fn6W7Qqm(
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,int32_T
mc__Gce0mZquR4HgLX8bLfI0G,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp);int32_T
mc_kX6eNI2bFZ__cyLxZQzP6Z(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x);int32_T mc_FRCJeuT32S4AW5Dz6aeK7v(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x);
mc_VWUvciwDK_dziLpafRxush*mc_Fe3WdhVNm1lm_TputcgM_w(mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VZ5qqYWDqx_NaqOx3T8EeD
(mc_kPBB5xuFz74_aaM4N6U4Jv*mc_F3nVSXkoDK8VeeL5OmY0_B);
mc_koBw_auTeOpFWTLu_1_hd3*mc_kqyKn15o9uW8cumoBbxjEC(mc_koBw_auTeOpFWTLu_1_hd3*
mc_kyfq6L_eQbdYcPuOovpRDW);mc_k2Ca2__AWx8Yd9MBB6pntX*mc_VHN9RInD2_hMj5etCbnyx_
(int32_T n,int32_T mc_ViTJrDHWLs8OjimuuiIsPe,int32_T mc__GPciDcZ6Z0EViGxgxdf9y
,int32_T mc_kzJQc_tutvlgaDzae7WNSs);mc_k2Ca2__AWx8Yd9MBB6pntX*
mc__yL5RKrY3uxPdqSDLO3FGs(mc_k2Ca2__AWx8Yd9MBB6pntX*mc_F3nVSXkoDK8VeeL5OmY0_B)
;mc_FZtW0WFyhCCTVicSdDpulD*mc__HHwQflOYfSli96OPqkpYJ(int32_T
mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n,int32_T mc_kNgcOktCtQxdYedrGvFn5i);
mc_FZtW0WFyhCCTVicSdDpulD*mc_Fbb_drPN_2hT_m2GWLCLZl(mc_FZtW0WFyhCCTVicSdDpulD*
mc_F5vPJ6MbAI8phLV7sKWrKK);int32_T*mc_Vq30ZRWDg0Ope1BH5Wlxn6(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp,const
int32_T*mc_VlzlbuXTjytugLyuufocD_,int32_T mc_F4FqMtzrIr0Ih9YO_bpGqr);double
mc_FVvAdrNPbiK3ciVovphJqC(int32_T*pm__lqjegyKuwStj56WZLiC_e,int32_T*
mc_FFZbGh27ya8eem_J_hUtAZ,int32_T n);int32_T mc_VqGwhdpnmyGkc5egfuzI9R(int32_T
mc_kyp6uAyJE40UVuAQNEYzS1,mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,
int32_T mc_V_3pIMGNi1pQiyeoIJloym,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,int32_T*
mc__nUrXnK_PlSWXDXfav4gTu,const int32_T*mc_FjDIs2zMLtx5We_IND4g6I);int32_T
mc__PAs7jPQB3p6jamHMS77BU(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_V2__YrimeI4E_yWnhKofpy,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp,int32_T*
mc_FQferGZUKft3_i5GvYy4Oy,int32_T*mc_V1pxxydYEnWVVi3QKesjvf);int32_T*
mc_kvTl6JgGLlpghLCj7SJ8Zb(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_F4FqMtzrIr0Ih9YO_bpGqr);int32_T mc__78cLFJw_ySFbTb4k127zA(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T(*mc__afZS_O3BMKpbuqov2Sqn2)(int32_T,
int32_T,double,void*),void*pm__sjTRWOMR4WzZisVeB2fYm);double
mc_FCxXZX7qax4Cf1qhlQMJ_K(double*x,double*mc_kCPCzQ_4FF88XTgtMjWqKy,int32_T n)
;int32_T mc_VjKkbv4A0k47XifnshEiFz(int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T
mc_kyp6uAyJE40UVuAQNEYzS1,const int32_T*mc__gfup5UQrKdtaLq0JwxBv8,int32_T*
mc_F_OdG3IuH0OSgXl2PAC3Wt,int32_T*mc_FYLTf08Tnt0_hXkhRr2i3V,int32_T*
mc_FaaXUqBjXi_Cc58Cr7D5Pw,int32_T*mc_kCfp_4sWHvtwdmGWqI8AP3);int32_T*
mc__KcZrPHSqmd_Winpkn_zbn(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_k6QxQSbjWyGhcXikh7jTLf);int32_T*mc_VSXwwVMHmJpqfu39VY7afd(const int32_T*
mc_k6HeriBJpGdZiPlDO4UZXp,int32_T n);int32_T*mc_kkUWSotb_oO3YDxqYUxvcp(int32_T
n,int32_T mc_k6QxQSbjWyGhcXikh7jTLf);int32_T mc_VJp2YHG9mB_gfHKfpAYT7q(
mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,const int32_T*
mc_FjDIs2zMLtx5We_IND4g6I);int32_T mc__bZ1EHlIu8t8WL63CWhZ5j(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double
mc_kCPCzQ_4FF88XTgtMjWqKy,int32_T*mc_V1pxxydYEnWVVi3QKesjvf,double*x,int32_T
mc__CLRBwg4eOSEiqHPYKDedF,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
int32_T mc___ECRgjqShlp_PytRplerL);mc_koBw_auTeOpFWTLu_1_hd3*
mc__17ror7eCZl9eiXoZ3px_g(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_VI_gkAfbWYGleX3FfR8roq(mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,
const mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,double*x,const
int32_T*mc_FjDIs2zMLtx5We_IND4g6I,int32_T mc___aedK39Pax6Ziebprhh0i);int32_T
mc_Fx2UoNYY4W0WY5iaMITghy(int32_T mc_kyp6uAyJE40UVuAQNEYzS1,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc_FcKez189ghKAYyDjWA9v5n,const int32_T*
mc_FTf2iFFdsgK3hewKsMgEx4,int32_T*mc_VlzlbuXTjytugLyuufocD_,int32_T*
mc_F65aUsM8ggpTgiucZs1fmm);mc_koBw_auTeOpFWTLu_1_hd3*mc_VfRC_16CnDtIYTHey4Izis
(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n);mc_koBw_auTeOpFWTLu_1_hd3*
mc_Fm6BWhHX7o4Vai4IMTAE87(mc_koBw_auTeOpFWTLu_1_hd3*mc_kyfq6L_eQbdYcPuOovpRDW,
mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,void*
mc_V1pxxydYEnWVVi3QKesjvf,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kYUYSnR_wtpicaLJHkpwi_(mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,void*mc_V1pxxydYEnWVVi3QKesjvf,void*x,int32_T
mc__suOgr_4PeCIZi_uhoSVwf);int32_T*mc_Ff7NuTFKk3OCYDKMqomZ1z(int32_T*
pm__lqjegyKuwStj56WZLiC_e,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
void*mc_V1pxxydYEnWVVi3QKesjvf,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
mc_kPBB5xuFz74_aaM4N6U4Jv*mc___7vbyf5jjtDZHYPmA3rvK(mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_F3nVSXkoDK8VeeL5OmY0_B,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
void*mc_V1pxxydYEnWVVi3QKesjvf,void*x,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);
#include "pm_std.h"
int32_T mc_kMIYc2vvZF4diPzIODxwiJ(size_t mc_VLHhnPUiNQpve5VIL9P3O9,size_t n,
PmRealVector*x,real_T*mc_FQSbIYXQcT89hqZsk9hjCr,int32_T*
mc_FPwVUAP_do0ogeBnBjppr5,void(*mc_VAE55EycVwWlZergDUGzxo)(int32_T
mc_V45upKVqFMGjWmb_LkY2NN,PmRealVector*x,PmRealVector*
mc_FzyLWRgau0pMYq2XSI3ETL,void*mc__Cr5wNt2rCpkiDym6nrBn7),void*
mc__Cr5wNt2rCpkiDym6nrBn7,real_T mc_kJ9luRcBhVKJbmfAE8b_l6,PmRealVector*
mc_kEbBObcYFIxUZ5_77V3CO_,PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,PmRealVector*
mc_V1pxxydYEnWVVi3QKesjvf,real_T atol,real_T mc__uA8j0yEGhSfh55lNHGpFy,int32_T
mc_ViHjyaoAKgKbhL7s3pT2cS);
#include "mc_std.h"
struct McLinearAlgebraDataTag{mc_F5Olyc6xUoG7ZyDq78exBD*
mc_VUplbU3G1JpmeDqSL1tjsp;mc_F5Olyc6xUoG7ZyDq78exBD*mc_kRpaqqW2mqhGVPq6RD1cDN;
PmRealVector*mc_Fxfy_MzNGkOrf1jm4xp4tZ;PmRealVector*mc_Vv5oq9btYE_NayVegDEcft;
mc_VWUvciwDK_dziLpafRxush*mc_VWYP8mH8ptpI_LSk0OlgUt;mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_VrMh138Yw_4dYmfdgfHovn;mc_kPBB5xuFz74_aaM4N6U4Jv*mc_Fq251S4kReShgqniL_gX5U;
int32_T mc__h_bTuBtpZhZZuHwef1rNn,mc_VwoYdX3Zamdsiat5BVrApo;int32_T*
mc_VAfhr3YA6bhZbDlrZXyXsO;};static PmRealVector*mc_VK8fWZZHirGrePfGeE0yC0(
int32_T mc_VLHhnPUiNQpve5VIL9P3O9){PmRealVector*mc_FT26l1uzQBOS_y80nUyhjZ;
real_T*mc_VgJW5ZqpwPpuY1inYtaofQ=mc_VInfIQCul4ShdLlbU4F0WB(
mc_VLHhnPUiNQpve5VIL9P3O9,sizeof(real_T));(void)0;;mc_FT26l1uzQBOS_y80nUyhjZ=
mc_VInfIQCul4ShdLlbU4F0WB(1,sizeof(PmRealVector));(void)0;;
mc_FT26l1uzQBOS_y80nUyhjZ->mN=mc_VLHhnPUiNQpve5VIL9P3O9;
mc_FT26l1uzQBOS_y80nUyhjZ->mX=mc_VgJW5ZqpwPpuY1inYtaofQ;return
mc_FT26l1uzQBOS_y80nUyhjZ;}static void mc_ka3fv5ZaTclmVmf8Y2_Nux(PmRealVector*
mc_FT26l1uzQBOS_y80nUyhjZ){(void)0;;mc__Mim_3QMMSxfi9M5sbbxcM(
mc_FT26l1uzQBOS_y80nUyhjZ->mX);mc__Mim_3QMMSxfi9M5sbbxcM(
mc_FT26l1uzQBOS_y80nUyhjZ);}static McLinearAlgebraData*
mc_kZJTC7s31MOnhaPEeadI_T(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z,const
PmSparsityPattern*A,int32_T mc_VLfhtrJkZcWwhmTdEnSnSd){McLinearAlgebraData*
mc__1Zf2IciMRCub1vvbEr1C4=(McLinearAlgebraData*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->
mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(McLinearAlgebraData)),(1)));
int32_T mc_kNgcOktCtQxdYedrGvFn5i;size_t mc__Mwijnrb0M46cT7T_bvxpH;(void)0;;
mc__1Zf2IciMRCub1vvbEr1C4->mc_VUplbU3G1JpmeDqSL1tjsp=mc_VFJZ9bgvffCPg9PZXPkAVk
(((int32_T)(A->mNumRow)),((int32_T)(A->mNumCol)),((int32_T)(((size_t)(A)->mJc[
(A)->mNumCol]))),0,0);memcpy(mc__1Zf2IciMRCub1vvbEr1C4->
mc_VUplbU3G1JpmeDqSL1tjsp->pm__lqjegyKuwStj56WZLiC_e,A->mJc,(A->mNumCol+1)*
sizeof(int32_T));memcpy(mc__1Zf2IciMRCub1vvbEr1C4->mc_VUplbU3G1JpmeDqSL1tjsp->
mc_kwrB3ZoKf7OufTHWaHJV7a,A->mIr,((size_t)(A)->mJc[(A)->mNumCol])*sizeof(
int32_T));mc_kNgcOktCtQxdYedrGvFn5i=mc__1Zf2IciMRCub1vvbEr1C4->
mc_VUplbU3G1JpmeDqSL1tjsp->pm__lqjegyKuwStj56WZLiC_e[mc_VLfhtrJkZcWwhmTdEnSnSd
];mc__1Zf2IciMRCub1vvbEr1C4->mc_kRpaqqW2mqhGVPq6RD1cDN=
mc_VFJZ9bgvffCPg9PZXPkAVk(mc__1Zf2IciMRCub1vvbEr1C4->mc_VUplbU3G1JpmeDqSL1tjsp
->mc_VLHhnPUiNQpve5VIL9P3O9,mc_VLfhtrJkZcWwhmTdEnSnSd,
mc_kNgcOktCtQxdYedrGvFn5i,0,0);memcpy(mc__1Zf2IciMRCub1vvbEr1C4->
mc_kRpaqqW2mqhGVPq6RD1cDN->pm__lqjegyKuwStj56WZLiC_e,mc__1Zf2IciMRCub1vvbEr1C4
->mc_VUplbU3G1JpmeDqSL1tjsp->pm__lqjegyKuwStj56WZLiC_e,(
mc_VLfhtrJkZcWwhmTdEnSnSd+1)*sizeof(int32_T));memcpy(mc__1Zf2IciMRCub1vvbEr1C4
->mc_kRpaqqW2mqhGVPq6RD1cDN->mc_kwrB3ZoKf7OufTHWaHJV7a,
mc__1Zf2IciMRCub1vvbEr1C4->mc_VUplbU3G1JpmeDqSL1tjsp->
mc_kwrB3ZoKf7OufTHWaHJV7a,mc_kNgcOktCtQxdYedrGvFn5i*sizeof(int32_T));
mc__Mwijnrb0M46cT7T_bvxpH=((A->mNumCol)>(A->mNumRow)?(A->mNumCol):(A->mNumRow)
);mc__1Zf2IciMRCub1vvbEr1C4->mc_Fxfy_MzNGkOrf1jm4xp4tZ=pm_create_real_vector(
mc__Mwijnrb0M46cT7T_bvxpH,mc_FOGg0ZWot2WdYenO8zaD4Z);mc__1Zf2IciMRCub1vvbEr1C4
->mc_Vv5oq9btYE_NayVegDEcft=pm_create_real_vector(mc__Mwijnrb0M46cT7T_bvxpH,
mc_FOGg0ZWot2WdYenO8zaD4Z);mc__1Zf2IciMRCub1vvbEr1C4->
mc_VWYP8mH8ptpI_LSk0OlgUt=NULL;mc__1Zf2IciMRCub1vvbEr1C4->
mc_VrMh138Yw_4dYmfdgfHovn=NULL;mc__1Zf2IciMRCub1vvbEr1C4->
mc_Fq251S4kReShgqniL_gX5U=NULL;mc__1Zf2IciMRCub1vvbEr1C4->
mc_VAfhr3YA6bhZbDlrZXyXsO=NULL;mc__1Zf2IciMRCub1vvbEr1C4->
mc_VwoYdX3Zamdsiat5BVrApo=0;return mc__1Zf2IciMRCub1vvbEr1C4;}static
McLinearAlgebraStatus mc__tHHcz4o6GG9a1kqvmtzHT(McLinearAlgebra*la){
McLinearAlgebraData*mc__jwhY0lO0YpMZmcUVIb7vl=la->mPrivateData;
mc_VWUvciwDK_dziLpafRxush*mc___P9NRZNO_CDiqZDuK90dc;int32_T
mc__jwySfHyx1SXgXJeVWoIzb,mc_FuFAmdh0OsGeZq_7D92_Ih,mc_kwrB3ZoKf7OufTHWaHJV7a;
(void)0;;mc__jwhY0lO0YpMZmcUVIb7vl->mc_VWYP8mH8ptpI_LSk0OlgUt=
mc__HBpzStane0GaaQtDu_y9F(2,mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VUplbU3G1JpmeDqSL1tjsp,0);(void)0;;mc___P9NRZNO_CDiqZDuK90dc=
mc__HBpzStane0GaaQtDu_y9F(2,mc__jwhY0lO0YpMZmcUVIb7vl->
mc_kRpaqqW2mqhGVPq6RD1cDN,0);(void)0;;mc__jwySfHyx1SXgXJeVWoIzb=
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VUplbU3G1JpmeDqSL1tjsp->n;
mc_FuFAmdh0OsGeZq_7D92_Ih=mc__jwhY0lO0YpMZmcUVIb7vl->mc_kRpaqqW2mqhGVPq6RD1cDN
->n;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc__jwySfHyx1SXgXJeVWoIzb;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_FuFAmdh0OsGeZq_7D92_Ih){mc__jwhY0lO0YpMZmcUVIb7vl
->mc_VWYP8mH8ptpI_LSk0OlgUt->mc__AExROh1PVWNeP7hmMWuJv[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc___P9NRZNO_CDiqZDuK90dc->
mc__AExROh1PVWNeP7hmMWuJv[mc_kwrB3ZoKf7OufTHWaHJV7a];}else{
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VWYP8mH8ptpI_LSk0OlgUt->
mc__AExROh1PVWNeP7hmMWuJv[mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_kwrB3ZoKf7OufTHWaHJV7a
;}}mc_Fe3WdhVNm1lm_TputcgM_w(mc___P9NRZNO_CDiqZDuK90dc);return MC_LA_OK;}
static void mc_Vy_fjgxsq_SSbX4KmqN0U1(McLinearAlgebraData*
mc__jwhY0lO0YpMZmcUVIb7vl){mc_VZ5qqYWDqx_NaqOx3T8EeD(mc__jwhY0lO0YpMZmcUVIb7vl
->mc_VrMh138Yw_4dYmfdgfHovn);mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VrMh138Yw_4dYmfdgfHovn=NULL;}static McLinearAlgebraStatus
mc_F8uhRXx48w8ObHelAsVTuH(McLinearAlgebra*la,const real_T*
mc_kcMuz7xytzhifPfhbjJNYL){McLinearAlgebraData*mc__jwhY0lO0YpMZmcUVIb7vl=la->
mPrivateData;mc_Vy_fjgxsq_SSbX4KmqN0U1(mc__jwhY0lO0YpMZmcUVIb7vl);memcpy(&(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VUplbU3G1JpmeDqSL1tjsp->x),&
mc_kcMuz7xytzhifPfhbjJNYL,sizeof(real_T*));mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VrMh138Yw_4dYmfdgfHovn=mc_VD2E_WGEctCGXH2bprw8Sw(mc__jwhY0lO0YpMZmcUVIb7vl
->mc_VUplbU3G1JpmeDqSL1tjsp,mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VWYP8mH8ptpI_LSk0OlgUt,&mc__jwhY0lO0YpMZmcUVIb7vl->
mc__h_bTuBtpZhZZuHwef1rNn);mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VUplbU3G1JpmeDqSL1tjsp->x=NULL;return MC_LA_OK;}static void
mc_VAE55EycVwWlZergDUGzxo(int32_T mc_V45upKVqFMGjWmb_LkY2NN,PmRealVector*x,
PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,void*mc__Cr5wNt2rCpkiDym6nrBn7){
McLinearAlgebraData*mc__jwhY0lO0YpMZmcUVIb7vl=(McLinearAlgebraData*)
mc__Cr5wNt2rCpkiDym6nrBn7;int32_T mc_VLHhnPUiNQpve5VIL9P3O9=
mc__jwhY0lO0YpMZmcUVIb7vl->mc__h_bTuBtpZhZZuHwef1rNn,n=
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VwoYdX3Zamdsiat5BVrApo;int32_T*
mc_FjDIs2zMLtx5We_IND4g6I=mc__jwhY0lO0YpMZmcUVIb7vl->mc_VrMh138Yw_4dYmfdgfHovn
->mc_FjDIs2zMLtx5We_IND4g6I,*mc__cwYebDEcQKuZml_giRPLY=
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VAfhr3YA6bhZbDlrZXyXsO;mc_F5Olyc6xUoG7ZyDq78exBD
*mc_VUplbU3G1JpmeDqSL1tjsp=mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VUplbU3G1JpmeDqSL1tjsp;int32_T*pm__56dBn4vKXWjZ1nclFRYZB=
mc_VUplbU3G1JpmeDqSL1tjsp->pm__lqjegyKuwStj56WZLiC_e,*
mc__y6AHqs0MMlccDJwS55r1U=mc_VUplbU3G1JpmeDqSL1tjsp->mc_kwrB3ZoKf7OufTHWaHJV7a
;double*mc_kcMuz7xytzhifPfhbjJNYL=mc_VUplbU3G1JpmeDqSL1tjsp->x;int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a,mc__1eAP9V6_J_NYm_1gTIm7A,pm_Fr_bHKkQKFWbfi50VWd5Pw,
pm_kplAJmOlA30feiNcOzi7oj;mc__aNO1s5qwzt6fXwft5YgCz(mc__jwhY0lO0YpMZmcUVIb7vl
->mc_Vv5oq9btYE_NayVegDEcft);if(mc_V45upKVqFMGjWmb_LkY2NN==1){for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){pm_Fr_bHKkQKFWbfi50VWd5Pw=
mc__cwYebDEcQKuZml_giRPLY[mc_kwrB3ZoKf7OufTHWaHJV7a];for(
mc__1eAP9V6_J_NYm_1gTIm7A=pm__56dBn4vKXWjZ1nclFRYZB[pm_Fr_bHKkQKFWbfi50VWd5Pw]
;mc__1eAP9V6_J_NYm_1gTIm7A<pm__56dBn4vKXWjZ1nclFRYZB[pm_Fr_bHKkQKFWbfi50VWd5Pw
+1];mc__1eAP9V6_J_NYm_1gTIm7A++){pm_kplAJmOlA30feiNcOzi7oj=
mc__y6AHqs0MMlccDJwS55r1U[mc__1eAP9V6_J_NYm_1gTIm7A];if(
mc_FjDIs2zMLtx5We_IND4g6I[pm_kplAJmOlA30feiNcOzi7oj]<mc_VLHhnPUiNQpve5VIL9P3O9
){mc__jwhY0lO0YpMZmcUVIb7vl->mc_Vv5oq9btYE_NayVegDEcft->mX[
mc_FjDIs2zMLtx5We_IND4g6I[pm_kplAJmOlA30feiNcOzi7oj]]+=
mc_kcMuz7xytzhifPfhbjJNYL[mc__1eAP9V6_J_NYm_1gTIm7A]*x->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}}mc_V3SIv4FNXnS__9UCAN4nes(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VrMh138Yw_4dYmfdgfHovn->
mc__ut5UfJwzNlZ_XZC_yEgKo,mc__jwhY0lO0YpMZmcUVIb7vl->mc_Vv5oq9btYE_NayVegDEcft
->mX);mc_kX6eNI2bFZ__cyLxZQzP6Z(mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VrMh138Yw_4dYmfdgfHovn->mc_Vi4Cp0qK964NYTFMGr9Ttn,mc__jwhY0lO0YpMZmcUVIb7vl
->mc_Vv5oq9btYE_NayVegDEcft->mX);for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a
++){mc_FzyLWRgau0pMYq2XSI3ETL->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]+=
mc__jwhY0lO0YpMZmcUVIb7vl->mc_Vv5oq9btYE_NayVegDEcft->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}else if(mc_V45upKVqFMGjWmb_LkY2NN==2){for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__jwhY0lO0YpMZmcUVIb7vl->mc_Vv5oq9btYE_NayVegDEcft->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_FzyLWRgau0pMYq2XSI3ETL->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}mc_V3SIv4FNXnS__9UCAN4nes(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fq251S4kReShgqniL_gX5U->
mc__ut5UfJwzNlZ_XZC_yEgKo,mc__jwhY0lO0YpMZmcUVIb7vl->mc_Vv5oq9btYE_NayVegDEcft
->mX);mc_kX6eNI2bFZ__cyLxZQzP6Z(mc__jwhY0lO0YpMZmcUVIb7vl->
mc_Fq251S4kReShgqniL_gX5U->mc_Vi4Cp0qK964NYTFMGr9Ttn,mc__jwhY0lO0YpMZmcUVIb7vl
->mc_Vv5oq9btYE_NayVegDEcft->mX);for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
pm_Fr_bHKkQKFWbfi50VWd5Pw=mc__cwYebDEcQKuZml_giRPLY[mc_kwrB3ZoKf7OufTHWaHJV7a]
;for(mc__1eAP9V6_J_NYm_1gTIm7A=pm__56dBn4vKXWjZ1nclFRYZB[
pm_Fr_bHKkQKFWbfi50VWd5Pw];mc__1eAP9V6_J_NYm_1gTIm7A<pm__56dBn4vKXWjZ1nclFRYZB
[pm_Fr_bHKkQKFWbfi50VWd5Pw+1];mc__1eAP9V6_J_NYm_1gTIm7A++){
pm_kplAJmOlA30feiNcOzi7oj=mc__y6AHqs0MMlccDJwS55r1U[mc__1eAP9V6_J_NYm_1gTIm7A]
;if(mc_FjDIs2zMLtx5We_IND4g6I[pm_kplAJmOlA30feiNcOzi7oj]<
mc_VLHhnPUiNQpve5VIL9P3O9){x->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]+=
mc_kcMuz7xytzhifPfhbjJNYL[mc__1eAP9V6_J_NYm_1gTIm7A]*mc__jwhY0lO0YpMZmcUVIb7vl
->mc_Vv5oq9btYE_NayVegDEcft->mX[mc_FjDIs2zMLtx5We_IND4g6I[
pm_kplAJmOlA30feiNcOzi7oj]];}}}}}static McLinearAlgebraStatus
mc_VqKBXLKHVNpFY97eBwAjyG(McLinearAlgebra*la,const real_T*
mc_kcMuz7xytzhifPfhbjJNYL,real_T*mc_kbGQl9Z9UwdegH9xeQk2IK,const real_T*
mc_Vqiy96WqvuhCaXm5e_vvT0){McLinearAlgebraData*mc__jwhY0lO0YpMZmcUVIb7vl=la->
mPrivateData;const real_T atol=1e-16;const real_T mc__uA8j0yEGhSfh55lNHGpFy=
1e-16;const real_T mc_FCszVrf1G20Sb5E1bqDcSC=0.3;const int32_T
mc_kiFRfnczP_Cjgq1OP2KFAV=6;int32_T n=mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VUplbU3G1JpmeDqSL1tjsp->n;int32_T mc_VLHhnPUiNQpve5VIL9P3O9=
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VUplbU3G1JpmeDqSL1tjsp->
mc_VLHhnPUiNQpve5VIL9P3O9;int32_T mc_V2__YrimeI4E_yWnhKofpy=
mc__jwhY0lO0YpMZmcUVIb7vl->mc__h_bTuBtpZhZZuHwef1rNn;int32_T
mc_VwoYdX3Zamdsiat5BVrApo=0,pm_Fr_bHKkQKFWbfi50VWd5Pw=0,
mc_kwrB3ZoKf7OufTHWaHJV7a=0;int32_T*pm__56dBn4vKXWjZ1nclFRYZB,*
mc__AExROh1PVWNeP7hmMWuJv;mc__aNO1s5qwzt6fXwft5YgCz(mc__jwhY0lO0YpMZmcUVIb7vl
->mc_Fxfy_MzNGkOrf1jm4xp4tZ);mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VAfhr3YA6bhZbDlrZXyXsO=mc_VInfIQCul4ShdLlbU4F0WB(n,sizeof(int32_T));if(n>0)
{memset(mc_kbGQl9Z9UwdegH9xeQk2IK,0,n*sizeof(real_T));
mc__AExROh1PVWNeP7hmMWuJv=mc__jwhY0lO0YpMZmcUVIb7vl->mc_VWYP8mH8ptpI_LSk0OlgUt
->mc__AExROh1PVWNeP7hmMWuJv;pm__56dBn4vKXWjZ1nclFRYZB=
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VUplbU3G1JpmeDqSL1tjsp->
pm__lqjegyKuwStj56WZLiC_e;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_V2__YrimeI4E_yWnhKofpy;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){pm_Fr_bHKkQKFWbfi50VWd5Pw=
mc__AExROh1PVWNeP7hmMWuJv[mc_kwrB3ZoKf7OufTHWaHJV7a];if(
pm__56dBn4vKXWjZ1nclFRYZB[pm_Fr_bHKkQKFWbfi50VWd5Pw+1]>
pm__56dBn4vKXWjZ1nclFRYZB[pm_Fr_bHKkQKFWbfi50VWd5Pw]){
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VAfhr3YA6bhZbDlrZXyXsO[mc_VwoYdX3Zamdsiat5BVrApo
++]=pm_Fr_bHKkQKFWbfi50VWd5Pw;}}}mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VwoYdX3Zamdsiat5BVrApo=mc_VwoYdX3Zamdsiat5BVrApo;if(
mc_V2__YrimeI4E_yWnhKofpy>0){mc_Vux1rLMHdIOwYHo_GgP0nf(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VrMh138Yw_4dYmfdgfHovn->
mc_FjDIs2zMLtx5We_IND4g6I,mc_Vqiy96WqvuhCaXm5e_vvT0,mc__jwhY0lO0YpMZmcUVIb7vl
->mc_Fxfy_MzNGkOrf1jm4xp4tZ->mX,mc_VLHhnPUiNQpve5VIL9P3O9);
mc_V3SIv4FNXnS__9UCAN4nes(mc__jwhY0lO0YpMZmcUVIb7vl->mc_VrMh138Yw_4dYmfdgfHovn
->mc__ut5UfJwzNlZ_XZC_yEgKo,mc__jwhY0lO0YpMZmcUVIb7vl->
mc_Fxfy_MzNGkOrf1jm4xp4tZ->mX);mc_kX6eNI2bFZ__cyLxZQzP6Z(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VrMh138Yw_4dYmfdgfHovn->
mc_Vi4Cp0qK964NYTFMGr9Ttn,mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fxfy_MzNGkOrf1jm4xp4tZ
->mX);memset(mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fxfy_MzNGkOrf1jm4xp4tZ->mX+
mc_V2__YrimeI4E_yWnhKofpy,0,(n-mc_V2__YrimeI4E_yWnhKofpy)*sizeof(real_T));if(
mc_VwoYdX3Zamdsiat5BVrApo==0){mc_Vux1rLMHdIOwYHo_GgP0nf(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VWYP8mH8ptpI_LSk0OlgUt->
mc__AExROh1PVWNeP7hmMWuJv,mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fxfy_MzNGkOrf1jm4xp4tZ
->mX,mc_kbGQl9Z9UwdegH9xeQk2IK,n);}else{PmRealVector*mc__6lBg5Jk_4K9g5RkRElqVn
;PmRealVector*mc_Fr1eJsaQ1SdXY5bLPjPQ7b;PmRealVector*mc_VBt9scaffuSciXZhmsTh8_
;PmRealVector*mc_VNFkcflrJ6x5iambNlYbdn;real_T mc_VO8cQD99MZ_PbHyNrxaa0q;
int32_T mc_FPwVUAP_do0ogeBnBjppr5,mc_ViHjyaoAKgKbhL7s3pT2cS;real_T
mc__8411I7Mf0KmcLL3cw9krt;int32_T mc_FUdXx2ElPJW_d1ydSbxpdO;memcpy(&(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VUplbU3G1JpmeDqSL1tjsp->x),&
mc_kcMuz7xytzhifPfhbjJNYL,sizeof(real_T*));mc__jwhY0lO0YpMZmcUVIb7vl->
mc_Fq251S4kReShgqniL_gX5U=mc_VInfIQCul4ShdLlbU4F0WB(1,sizeof(
mc_kPBB5xuFz74_aaM4N6U4Jv));mc__jwhY0lO0YpMZmcUVIb7vl->
mc_Fq251S4kReShgqniL_gX5U->mc_Vi4Cp0qK964NYTFMGr9Ttn=mc_kzs_RE98zypjVHi58lxG6O
(mc__jwhY0lO0YpMZmcUVIb7vl->mc_VrMh138Yw_4dYmfdgfHovn->
mc__ut5UfJwzNlZ_XZC_yEgKo,1);mc__jwhY0lO0YpMZmcUVIb7vl->
mc_Fq251S4kReShgqniL_gX5U->mc__ut5UfJwzNlZ_XZC_yEgKo=mc_kzs_RE98zypjVHi58lxG6O
(mc__jwhY0lO0YpMZmcUVIb7vl->mc_VrMh138Yw_4dYmfdgfHovn->
mc_Vi4Cp0qK964NYTFMGr9Ttn,1);mc__jwhY0lO0YpMZmcUVIb7vl->
mc_Fq251S4kReShgqniL_gX5U->mc_FjDIs2zMLtx5We_IND4g6I=NULL;
mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fq251S4kReShgqniL_gX5U->
mc_Vqiy96WqvuhCaXm5e_vvT0=NULL;mc__6lBg5Jk_4K9g5RkRElqVn=
mc_VK8fWZZHirGrePfGeE0yC0(mc_V2__YrimeI4E_yWnhKofpy);mc_Fr1eJsaQ1SdXY5bLPjPQ7b
=mc_VK8fWZZHirGrePfGeE0yC0(mc_VwoYdX3Zamdsiat5BVrApo);
mc_VBt9scaffuSciXZhmsTh8_=mc_VK8fWZZHirGrePfGeE0yC0(mc_VwoYdX3Zamdsiat5BVrApo)
;mc_VNFkcflrJ6x5iambNlYbdn=mc_VK8fWZZHirGrePfGeE0yC0(mc_VwoYdX3Zamdsiat5BVrApo
);for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_V2__YrimeI4E_yWnhKofpy;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__6lBg5Jk_4K9g5RkRElqVn->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]=
mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fxfy_MzNGkOrf1jm4xp4tZ->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}mc_VO8cQD99MZ_PbHyNrxaa0q=
mc_F1fvRD4xlFhBdyqJtcgdmn(mc__6lBg5Jk_4K9g5RkRElqVn);mc_ViHjyaoAKgKbhL7s3pT2cS
=((mc_V2__YrimeI4E_yWnhKofpy)<(mc_VwoYdX3Zamdsiat5BVrApo)?(
mc_V2__YrimeI4E_yWnhKofpy):(mc_VwoYdX3Zamdsiat5BVrApo));
mc_ViHjyaoAKgKbhL7s3pT2cS=((mc_ViHjyaoAKgKbhL7s3pT2cS+1)<(
mc_kiFRfnczP_Cjgq1OP2KFAV)?(mc_ViHjyaoAKgKbhL7s3pT2cS+1):(
mc_kiFRfnczP_Cjgq1OP2KFAV));mc_FUdXx2ElPJW_d1ydSbxpdO=
mc_kMIYc2vvZF4diPzIODxwiJ(mc_V2__YrimeI4E_yWnhKofpy,mc_VwoYdX3Zamdsiat5BVrApo,
mc_VNFkcflrJ6x5iambNlYbdn,&mc__8411I7Mf0KmcLL3cw9krt,&
mc_FPwVUAP_do0ogeBnBjppr5,mc_VAE55EycVwWlZergDUGzxo,mc__jwhY0lO0YpMZmcUVIb7vl,
1.0,mc__6lBg5Jk_4K9g5RkRElqVn,mc_Fr1eJsaQ1SdXY5bLPjPQ7b,
mc_VBt9scaffuSciXZhmsTh8_,atol,mc__uA8j0yEGhSfh55lNHGpFy,
mc_ViHjyaoAKgKbhL7s3pT2cS);if(mc__8411I7Mf0KmcLL3cw9krt<
mc_FCszVrf1G20Sb5E1bqDcSC*mc_VO8cQD99MZ_PbHyNrxaa0q){mc_VWnvos7Q548uVH7p0208jN
(mc_Fr1eJsaQ1SdXY5bLPjPQ7b,-1.0,mc_VNFkcflrJ6x5iambNlYbdn);
mc_VAE55EycVwWlZergDUGzxo(1,mc_Fr1eJsaQ1SdXY5bLPjPQ7b,
mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fxfy_MzNGkOrf1jm4xp4tZ,mc__jwhY0lO0YpMZmcUVIb7vl
);mc_Vux1rLMHdIOwYHo_GgP0nf(mc__jwhY0lO0YpMZmcUVIb7vl->
mc_VWYP8mH8ptpI_LSk0OlgUt->mc__AExROh1PVWNeP7hmMWuJv,mc__jwhY0lO0YpMZmcUVIb7vl
->mc_Fxfy_MzNGkOrf1jm4xp4tZ->mX,mc_kbGQl9Z9UwdegH9xeQk2IK,n);for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VwoYdX3Zamdsiat5BVrApo;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_kbGQl9Z9UwdegH9xeQk2IK[mc__jwhY0lO0YpMZmcUVIb7vl->mc_VAfhr3YA6bhZbDlrZXyXsO
[mc_kwrB3ZoKf7OufTHWaHJV7a]]=mc_VNFkcflrJ6x5iambNlYbdn->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}else{mc_Vux1rLMHdIOwYHo_GgP0nf(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VWYP8mH8ptpI_LSk0OlgUt->
mc__AExROh1PVWNeP7hmMWuJv,mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fxfy_MzNGkOrf1jm4xp4tZ
->mX,mc_kbGQl9Z9UwdegH9xeQk2IK,n);}mc_ka3fv5ZaTclmVmf8Y2_Nux(
mc__6lBg5Jk_4K9g5RkRElqVn);mc_ka3fv5ZaTclmVmf8Y2_Nux(mc_Fr1eJsaQ1SdXY5bLPjPQ7b
);mc_ka3fv5ZaTclmVmf8Y2_Nux(mc_VBt9scaffuSciXZhmsTh8_);
mc_ka3fv5ZaTclmVmf8Y2_Nux(mc_VNFkcflrJ6x5iambNlYbdn);mc_VZ5qqYWDqx_NaqOx3T8EeD
(mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fq251S4kReShgqniL_gX5U);
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VUplbU3G1JpmeDqSL1tjsp->x=NULL;}}
mc__Mim_3QMMSxfi9M5sbbxcM(mc__jwhY0lO0YpMZmcUVIb7vl->mc_VAfhr3YA6bhZbDlrZXyXsO
);return MC_LA_OK;}static real_T mc_FO656MwZo6KtZP4_BTHtqp(const
McLinearAlgebra*la){McLinearAlgebraData*mc__jwhY0lO0YpMZmcUVIb7vl=la->
mPrivateData;(void)0;;if(mc__jwhY0lO0YpMZmcUVIb7vl->mc__h_bTuBtpZhZZuHwef1rNn>
0){mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn=
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VrMh138Yw_4dYmfdgfHovn->
mc_Vi4Cp0qK964NYTFMGr9Ttn;real_T mc_FE7t0GfBuAW1fuWZPxel_q=0.0;real_T
mc_FTmBApB9w1Otgew4IWWhwD= -1.0;int32_T mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc__jwhY0lO0YpMZmcUVIb7vl->mc__h_bTuBtpZhZZuHwef1rNn;++
mc_kwrB3ZoKf7OufTHWaHJV7a){real_T mc__dWdDNurhAtCi9JSs6Apsz=fabs(
mc_Vi4Cp0qK964NYTFMGr9Ttn->x[mc_Vi4Cp0qK964NYTFMGr9Ttn->
pm__lqjegyKuwStj56WZLiC_e[mc_kwrB3ZoKf7OufTHWaHJV7a+1]-1]);if(
mc__dWdDNurhAtCi9JSs6Apsz>mc_FE7t0GfBuAW1fuWZPxel_q){mc_FE7t0GfBuAW1fuWZPxel_q
=mc__dWdDNurhAtCi9JSs6Apsz;}if((mc_FTmBApB9w1Otgew4IWWhwD<0.0)||(
mc__dWdDNurhAtCi9JSs6Apsz<mc_FTmBApB9w1Otgew4IWWhwD)){
mc_FTmBApB9w1Otgew4IWWhwD=mc__dWdDNurhAtCi9JSs6Apsz;}}return(
mc_FE7t0GfBuAW1fuWZPxel_q/mc_FTmBApB9w1Otgew4IWWhwD);}return 0.0;}static size_t
mc_VBDfuknvScd_fLszRMJizW(const McLinearAlgebra*la){(void)0;return 0;}static
void mc_FFsaGoyknDlhXP_F_MMCXd(McLinearAlgebra*la){McLinearAlgebraData*
mc__jwhY0lO0YpMZmcUVIb7vl=la->mPrivateData;PmAllocator*
mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();mc_Vy_fjgxsq_SSbX4KmqN0U1(
mc__jwhY0lO0YpMZmcUVIb7vl);mc_Fe3WdhVNm1lm_TputcgM_w(mc__jwhY0lO0YpMZmcUVIb7vl
->mc_VWYP8mH8ptpI_LSk0OlgUt);mc__BJ1NEDJTgOMhaJKDrM6pN(
mc__jwhY0lO0YpMZmcUVIb7vl->mc_VUplbU3G1JpmeDqSL1tjsp);
mc__BJ1NEDJTgOMhaJKDrM6pN(mc__jwhY0lO0YpMZmcUVIb7vl->mc_kRpaqqW2mqhGVPq6RD1cDN
);pm_destroy_real_vector(mc__jwhY0lO0YpMZmcUVIb7vl->mc_Fxfy_MzNGkOrf1jm4xp4tZ,
mc_FOGg0ZWot2WdYenO8zaD4Z);pm_destroy_real_vector(mc__jwhY0lO0YpMZmcUVIb7vl->
mc_Vv5oq9btYE_NayVegDEcft,mc_FOGg0ZWot2WdYenO8zaD4Z);{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc__jwhY0lO0YpMZmcUVIb7vl);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(
mc_FOGg0ZWot2WdYenO8zaD4Z,mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(la);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc_kk06poLCQlh5i5Yv6GSh7e);}};}static McLinearAlgebraStatus
mc_VMr4JsX85_Cvf5hO79GiCP(const McLinearAlgebraFactory*
mc__RtkHrrPEelBbDRCt5cBnV,McLinearAlgebra**mc_kUiN9yDkl4dshyxp7WLjGd,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,size_t mc_VLfhtrJkZcWwhmTdEnSnSd){
PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();McLinearAlgebra*
la=(McLinearAlgebra*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(McLinearAlgebra)),(1)));
McLinearAlgebraStatus mc__1Zf2IciMRCub1vvbEr1C4;la->mPrivateData=
mc_kZJTC7s31MOnhaPEeadI_T(mc_FOGg0ZWot2WdYenO8zaD4Z,mc__srK5LmyWw42ZyPnbOWDWJ,
(int32_T)mc_VLfhtrJkZcWwhmTdEnSnSd);la->mFactor= &mc_F8uhRXx48w8ObHelAsVTuH;la
->mSolve= &mc_VqKBXLKHVNpFY97eBwAjyG;la->mCondest= &mc_FO656MwZo6KtZP4_BTHtqp;
la->mMemusage= &mc_VBDfuknvScd_fLszRMJizW;la->mDestructor= &
mc_FFsaGoyknDlhXP_F_MMCXd;mc__1Zf2IciMRCub1vvbEr1C4=mc__tHHcz4o6GG9a1kqvmtzHT(
la);if(mc__1Zf2IciMRCub1vvbEr1C4!=MC_LA_OK){return mc__1Zf2IciMRCub1vvbEr1C4;}
*mc_kUiN9yDkl4dshyxp7WLjGd=la;return MC_LA_OK;}static McLinearAlgebraStatus
mc_kxQU3qZR_y4iaPvP3EYApY(const McLinearAlgebraFactory*
mc__RtkHrrPEelBbDRCt5cBnV,McLinearAlgebra**mc_kUiN9yDkl4dshyxp7WLjGd,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ){return mc_VMr4JsX85_Cvf5hO79GiCP(
mc__RtkHrrPEelBbDRCt5cBnV,mc_kUiN9yDkl4dshyxp7WLjGd,mc__srK5LmyWw42ZyPnbOWDWJ,
mc__srK5LmyWw42ZyPnbOWDWJ->mNumCol);}const McLinearAlgebraFactory*
mc_V8hcGoGUqVCbYm6_XzatbE(void){static McLinearAlgebraFactory
mc__RtkHrrPEelBbDRCt5cBnV;mc__RtkHrrPEelBbDRCt5cBnV.mCreateLinearAlgebra= &
mc_kxQU3qZR_y4iaPvP3EYApY;mc__RtkHrrPEelBbDRCt5cBnV.
mCreateLinearAlgebraComplete= &mc_VMr4JsX85_Cvf5hO79GiCP;return&
mc__RtkHrrPEelBbDRCt5cBnV;}
