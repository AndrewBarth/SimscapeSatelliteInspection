#include "pm_std.h"
#include "ne_std.h"
typedef struct ssc_st_kemRd3LD2_pPVaAsNA5YDG ssc_st_VVipzh2oIBtKZ5hNqD2z_1;
typedef struct ssc_st_VAZekvvzo5CUcm0GE7lD8S ssc_st_FdhjQ_x6uEtWf5NrhiXPkC;
struct ssc_st_kemRd3LD2_pPVaAsNA5YDG{ssc_st_FdhjQ_x6uEtWf5NrhiXPkC*
mPrivateData;void(*mc_kt9hW2swhpxchivzz5BlCP)(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st__pLwoU6jmvWSV9dXhEIoIv,NeuDiagnosticTree*ssc_st_kBj0wT0jErl0hDNP9N5QnJ)
;NeuDiagnosticTree*(*ssc_st__ncbpuIDzMOrgqwrOKx4qs)(
ssc_st_VVipzh2oIBtKZ5hNqD2z_1*ssc_st__pLwoU6jmvWSV9dXhEIoIv);NeuDiagnosticTree
*(*ssc_st_kQPAw1xwSVSbhTWPocMRHj)(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st__pLwoU6jmvWSV9dXhEIoIv);NeuDiagnosticTree*(*
ssc_st_FWUr7cMI27_XXuAo82pt8h)(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st__pLwoU6jmvWSV9dXhEIoIv,size_t n);size_t(*ssc_st_FRrT3ZKfnZCQ_TCtuEK5hH)
(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*ssc_st__pLwoU6jmvWSV9dXhEIoIv);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st__pLwoU6jmvWSV9dXhEIoIv);};ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st_F__qZQpW_J4sVP_0nua696(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z);
#include "string.h"
#include "pm_std.h"
struct ssc_st_VAZekvvzo5CUcm0GE7lD8S{PmAllocator*ssc_st_FyUeLiATLG4zWes0mMKZnu
;size_t ssc_st_kJKIiuWImf8dg9pI3f8pc5;size_t mSize;NeuDiagnosticTree**
ssc_st__3742BpjxzxJjmXriotnZ8;};static void ssc_st_F4H5qzX7P1tfjHMzM48Nuh(
ssc_st_VVipzh2oIBtKZ5hNqD2z_1*mc_FawmFe5oOEC_cmkvZc1Kaa,NeuDiagnosticTree*
ssc_st_kBj0wT0jErl0hDNP9N5QnJ){if(mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->
mSize>=mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->ssc_st_kJKIiuWImf8dg9pI3f8pc5)
{NeuDiagnosticTree**ssc_st__0Gxic3Bpu_HjDevqjQi0l=mc_FawmFe5oOEC_cmkvZc1Kaa->
mPrivateData->ssc_st__3742BpjxzxJjmXriotnZ8;(void)0;;mc_FawmFe5oOEC_cmkvZc1Kaa
->mPrivateData->ssc_st_kJKIiuWImf8dg9pI3f8pc5*=2;mc_FawmFe5oOEC_cmkvZc1Kaa->
mPrivateData->ssc_st__3742BpjxzxJjmXriotnZ8=(NeuDiagnosticTree**)((
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->ssc_st_FyUeLiATLG4zWes0mMKZnu)->
mCallocFcn((mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->
ssc_st_FyUeLiATLG4zWes0mMKZnu),(sizeof(NeuDiagnosticTree*)),(
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->ssc_st_kJKIiuWImf8dg9pI3f8pc5)));
memcpy(mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->ssc_st__3742BpjxzxJjmXriotnZ8,
ssc_st__0Gxic3Bpu_HjDevqjQi0l,mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->mSize*
sizeof(NeuDiagnosticTree*));{void*ssc_st_kk06poLCQlh5i5Yv6GSh7e=(
ssc_st__0Gxic3Bpu_HjDevqjQi0l);if(ssc_st_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->ssc_st_FyUeLiATLG4zWes0mMKZnu)->
mFreeFcn(mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->
ssc_st_FyUeLiATLG4zWes0mMKZnu,ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};}(void)0;;
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->ssc_st__3742BpjxzxJjmXriotnZ8[(
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->mSize)++]=
ssc_st_kBj0wT0jErl0hDNP9N5QnJ;}static NeuDiagnosticTree*
ssc_st_FEzS7XssJml9ViYnKxc76R(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
mc_FawmFe5oOEC_cmkvZc1Kaa){(void)0;;(void)0;;return mc_FawmFe5oOEC_cmkvZc1Kaa
->mPrivateData->ssc_st__3742BpjxzxJjmXriotnZ8[--(mc_FawmFe5oOEC_cmkvZc1Kaa->
mPrivateData->mSize)];}static NeuDiagnosticTree*ssc_st_kJcxrUYoNIC5am6xkTcdUO(
ssc_st_VVipzh2oIBtKZ5hNqD2z_1*mc_FawmFe5oOEC_cmkvZc1Kaa,size_t
ssc_st_V2__YrimeI4E_yWnhKofpy){(void)0;;(void)0;;return
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->ssc_st__3742BpjxzxJjmXriotnZ8[
ssc_st_V2__YrimeI4E_yWnhKofpy];}static NeuDiagnosticTree*
ssc_st__rZ5DLvGFchqiLdMql401t(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
mc_FawmFe5oOEC_cmkvZc1Kaa){size_t n=mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->
mSize;if(n>0){return ssc_st_kJcxrUYoNIC5am6xkTcdUO(mc_FawmFe5oOEC_cmkvZc1Kaa,n
-1);}else{return NULL;}}static size_t ssc_st_VgMqsX7mTCCv_atfRHMVFp(
ssc_st_VVipzh2oIBtKZ5hNqD2z_1*mc_FawmFe5oOEC_cmkvZc1Kaa){return
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->mSize;}static void
ssc_st_FfoRLAEATm0bZ53YlcsbRa(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
mc_FawmFe5oOEC_cmkvZc1Kaa){PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->ssc_st_FyUeLiATLG4zWes0mMKZnu;{void*
ssc_st_kk06poLCQlh5i5Yv6GSh7e=(mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData->
ssc_st__3742BpjxzxJjmXriotnZ8);if(ssc_st_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_st_kk06poLCQlh5i5Yv6GSh7e=(
mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData);if(ssc_st_kk06poLCQlh5i5Yv6GSh7e!=0){
(mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_st_kk06poLCQlh5i5Yv6GSh7e=(
mc_FawmFe5oOEC_cmkvZc1Kaa);if(ssc_st_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};}ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st_F__qZQpW_J4sVP_0nua696(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z){
ssc_st_VVipzh2oIBtKZ5hNqD2z_1*mc_FawmFe5oOEC_cmkvZc1Kaa=(
ssc_st_VVipzh2oIBtKZ5hNqD2z_1*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(ssc_st_VVipzh2oIBtKZ5hNqD2z_1)),(1)));
ssc_st_FdhjQ_x6uEtWf5NrhiXPkC*mc__d1alWYexptL_X5HTFhbNK=(
ssc_st_FdhjQ_x6uEtWf5NrhiXPkC*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(ssc_st_FdhjQ_x6uEtWf5NrhiXPkC)),(1)));const
size_t ssc_st_k_XtCql81Q4tVa9W_jwdyw=5;mc__d1alWYexptL_X5HTFhbNK->
ssc_st_FyUeLiATLG4zWes0mMKZnu=mc_FOGg0ZWot2WdYenO8zaD4Z;
mc__d1alWYexptL_X5HTFhbNK->ssc_st_kJKIiuWImf8dg9pI3f8pc5=
ssc_st_k_XtCql81Q4tVa9W_jwdyw;mc__d1alWYexptL_X5HTFhbNK->mSize=0;
mc__d1alWYexptL_X5HTFhbNK->ssc_st__3742BpjxzxJjmXriotnZ8=(NeuDiagnosticTree**)
((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
NeuDiagnosticTree*)),(mc__d1alWYexptL_X5HTFhbNK->ssc_st_kJKIiuWImf8dg9pI3f8pc5
)));mc_FawmFe5oOEC_cmkvZc1Kaa->mPrivateData=mc__d1alWYexptL_X5HTFhbNK;
mc_FawmFe5oOEC_cmkvZc1Kaa->mc_kt9hW2swhpxchivzz5BlCP= &
ssc_st_F4H5qzX7P1tfjHMzM48Nuh;mc_FawmFe5oOEC_cmkvZc1Kaa->
ssc_st__ncbpuIDzMOrgqwrOKx4qs= &ssc_st_FEzS7XssJml9ViYnKxc76R;
mc_FawmFe5oOEC_cmkvZc1Kaa->ssc_st_kQPAw1xwSVSbhTWPocMRHj= &
ssc_st__rZ5DLvGFchqiLdMql401t;mc_FawmFe5oOEC_cmkvZc1Kaa->
ssc_st_FWUr7cMI27_XXuAo82pt8h= &ssc_st_kJcxrUYoNIC5am6xkTcdUO;
mc_FawmFe5oOEC_cmkvZc1Kaa->ssc_st_FRrT3ZKfnZCQ_TCtuEK5hH= &
ssc_st_VgMqsX7mTCCv_atfRHMVFp;mc_FawmFe5oOEC_cmkvZc1Kaa->
mc_VYGWBho6N1K_eyHOMGjDiW= &ssc_st_FfoRLAEATm0bZ53YlcsbRa;return
mc_FawmFe5oOEC_cmkvZc1Kaa;}
